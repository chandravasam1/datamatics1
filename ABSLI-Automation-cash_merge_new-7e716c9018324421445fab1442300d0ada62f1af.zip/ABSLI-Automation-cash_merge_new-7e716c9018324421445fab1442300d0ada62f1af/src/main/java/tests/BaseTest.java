package tests;

import com.absli.drivers.AndroidDriverBuilder;
import com.absli.appium.AppiumServer;
import com.absli.drivers.IOSDriverBuilder;
import com.absli.drivers.WebDriverBuilder;
import com.absli.enums.Env;
import com.absli.enums.PlatformName;
import com.absli.enums.PlatformType;
import com.absli.enums.RunType;
import com.absli.helpers.models.DeviceContext;
import com.absli.listeners.SuiteLevelDriverCreator;
import com.absli.listeners.TestLevelDriverCreator;
import com.absli.pageObjects.CreateApplPage;
import com.absli.pageObjects.SignInPage;
import com.absli.runner.TestRunner;
import com.absli.utils.CommonUtils;
import com.absli.utils.WaitUtils;
import com.google.common.collect.ImmutableMap;
import com.ssts.pcloudy.appium.PCloudyAppiumSession;
import com.ssts.pcloudy.exception.ConnectError;
import com.ssts.util.reporting.ExecutionResult;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import io.qameta.allure.Step;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.ITestResult;
import org.testng.annotations.*;

import java.io.IOException;
import java.util.concurrent.TimeUnit;
import static com.github.automatedowl.tools.AllureEnvironmentWriter.allureEnvironmentWriter;


import static com.absli.logger.LoggingManager.logMessage;

public class BaseTest {
    public WebDriver driver;
    public PCloudyAppiumSession pCloudyAppiumSession;
    public static String ENV;
    public static String PLATFORM_TYPE;
    public static String PLATFORM_NAME;
    public static String RUN_TYPE;
    public static String MODEL;
    public static String APP_TYPE;
    public static String HEADLESS;
    public static String CONTEXT;
    CommonUtils commonUtils = new CommonUtils();
    CreateApplPage createApplPage;
    WaitUtils waitUtils = new WaitUtils();

    public BaseTest() {

    }

    @Parameters({"platformType", "platformName", "model","runType","appType","env","myDeviceContext"})
    public BaseTest(String platformType, String platformName, String model, String runType, String appType, String env,String myDeviceContext) {
        this.ENV = env;
        this.PLATFORM_TYPE = platformType;
        this.PLATFORM_NAME = platformName;
        this.RUN_TYPE = runType;
        this.MODEL = model;
        this.APP_TYPE = appType;
        this.CONTEXT = myDeviceContext;
    }

    public void setAllureEnvironment() {
        logMessage("calling allure environment");
        allureEnvironmentWriter(
                ImmutableMap.<String, String>builder()
                        .put("Platform Type", PLATFORM_TYPE)
                        .put("Platform Name", PLATFORM_NAME)
                        .put("Environment", ENV)
                        .put("Application",APP_TYPE)
                        .put("URL in case of WEB platform execution",getBaseUrl(ENV))
                        .build(),System.getProperty("user.dir")
                        + "/allure-results/");
    }

    @Parameters({"platformType", "platformName"})
    //@BeforeTest
    @Step("start appium server step....")
    public void startAppiumServer(String platformType, @Optional String platformName) throws IOException {
        logMessage("Starting appium server.....");
        if (platformType.equalsIgnoreCase(PlatformType.MOBILE.toString())) {
            killExistingAppiumProcess();
            if (AppiumServer.appium == null || !AppiumServer.appium.isRunning()) {
                AppiumServer.start();
                logMessage("Appium server has been started");
            }
        }
    }

    @Parameters({"platformType", "platformName"})
    //@AfterTest
    @Step("stop appium server step....")
    public void stopAppiumServer(String platformType, @Optional String platformName) throws IOException {
        if (platformType.equalsIgnoreCase(PlatformType.MOBILE.toString())) {
        //    if (AppiumServer.appium != null || AppiumServer.appium.isRunning()) {
            if (AppiumServer.appium != null) {
                AppiumServer.stop();
                logMessage("Appium server has been stopped");
            }
        }
    }

    @Parameters({"platformType", "platformName", "model","runType","appType","env","headless","myDeviceContext"})
    //@BeforeClass(alwaysRun = true)
    @Step("create driver step....")
    public WebDriver setupDriver(@Optional String platformType, @Optional String platformName, @Optional String model, @Optional String runType, @Optional String appType, @Optional String env, @Optional String headless, @Optional String myDeviceContext) throws IOException, InterruptedException, ConnectError {
        logMessage("===========>>>>>>. In side setup driver base method");
        //extent.startReport();
        this.ENV = env;
        this.PLATFORM_TYPE = platformType;
        this.PLATFORM_NAME = platformName;
        this.RUN_TYPE = runType;
        this.MODEL = model;
        this.APP_TYPE = appType;
        this.HEADLESS = headless;

        //setAllureEnvironment();

        if (platformType.equalsIgnoreCase(PlatformType.WEB.toString()))
        {
            driver = setupWebDriver(platformName,env);
        } else if (platformType.equalsIgnoreCase(PlatformType.MOBILE.toString())) {
            if (runType.equalsIgnoreCase(RunType.LOCAL.toString())) {
                //start appium locally
                //startAppiumServer(platformType,platformName);
            }
            driver = setupMobileDriver(platformType, platformName, model,runType,appType,env,myDeviceContext);
        }

        return driver;

    }

    @Step("create mobile driver step .....")
    public WebDriver setupMobileDriver(String platformType, String platformName, String model, String runType, String appType, String env, String myDeviceContext) throws IOException, InterruptedException, ConnectError {
        logMessage("===========>>>>>>. In side mobile setup driver base method ----  1");

        if (platformName.equalsIgnoreCase(PlatformName.ANDROID.toString())) {
            if (runType.equalsIgnoreCase(RunType.LOCAL.toString()) ) {
                switch(appType) {
                    case "native": driver = new AndroidDriverBuilder().setupDriver(model,PlatformName.APP.toString());
                                    break;
                    case "mobilebrowser":
                                    driver = new AndroidDriverBuilder().setupDriver(model,PlatformName.MOBILEBROWSER.toString());
                                    String url = getBaseUrl(env);
                                    driver.get(url);
                        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
                        logMessage("..............Opening url: "+url+" in browser..........");
                                    break;
                    default:  logMessage("Invalid app type parameter");
                }
            }
            else if (runType.equalsIgnoreCase("pcloudy")) {
                switch(appType) {
                    case "native":
                        driver = new AndroidDriverBuilder().setupPcloudyAndroidAppDriver(model,PlatformName.APP.toString(),myDeviceContext);
                                    break;
                    case "mobilebrowser":
                                        System.out.println("Inside mobile browser -----> android switch statement");
                                        driver = new AndroidDriverBuilder().setupPcloudyAndroidBrowserDriver(model,PlatformName.MOBILEBROWSER.toString(),myDeviceContext);
                                        String url = getBaseUrl(env);
                                        driver.get(url);
                        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
                        logMessage("..............Opening url: "+url+" in browser..........");
                        break;

                    default:          logMessage("Invalid app type parameter");
                }
            }
        } else if (platformName.equalsIgnoreCase(PlatformName.IOS.toString())) {
            if (runType.equalsIgnoreCase("local") ) {
                switch(appType) {
                    case "native": driver = new IOSDriverBuilder().setupDriver(model,PlatformName.APP.toString());
                                    break;
                    case "mobilebrowser":
                        driver = new IOSDriverBuilder().setupDriver(model,PlatformName.MOBILEBROWSER.toString());
                        String url = getBaseUrl(env);
                        driver.get(url);
                        logMessage("..............Opening url: "+url+" in browser..........");
                        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
                        break;
                    default:  logMessage("Invalid app type parameter");
                }
            }
            else if (runType.equalsIgnoreCase("pcloudy")) {
                switch(appType) {
                    case "native":
                                driver = new IOSDriverBuilder().setupPcloudyIOSAppDriver(model,PlatformName.APP.toString(),myDeviceContext);
                                            break;
                    case "mobilebrowser":   driver = new IOSDriverBuilder().setupPcloudyIOSBrowserDriver(model,PlatformName.MOBILEBROWSER.toString(),myDeviceContext);
                                            String url = getBaseUrl(env);
                                            driver.get(url);
                                            logMessage("..............Opening url: "+url+" in browser..........");
                                            driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
                                            break;
                    default:          logMessage("Invalid app type parameter");
                }
            }
        logMessage(model + " driver has been created for execution......");
        }

        return driver;
    }

    public String  getBaseUrl(String env) {
        return Env.valueOf(env).getUrl();
    }

    @Step("create web driver step .....")
    public WebDriver setupWebDriver(String platformName,String env) {
        if (platformName.equalsIgnoreCase(PlatformName.CHROME.toString())) {
            driver = new WebDriverBuilder().setupDriver(platformName);
        } else if (platformName.equalsIgnoreCase(PlatformName.FIREFOX.toString())) {
            driver = new WebDriverBuilder().setupDriver(platformName);
        } else if (platformName.equalsIgnoreCase(PlatformName.SAFARI.toString())) {
                driver = new WebDriverBuilder().setupDriver(platformName);
        } else if (platformName.equalsIgnoreCase(PlatformName.IE.toString())) {
            driver = new WebDriverBuilder().setupDriver(platformName);
        }
        logMessage(platformName + " driver has been created for execution");
        String url = getBaseUrl(env);
        driver.get(url);
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        logMessage("..............Opening url: "+url+" in browser..........");
        return driver;
    }

    public void relaunch()  {
        driver = new TestLevelDriverCreator().getDriver();
        switch (PLATFORM_NAME.toLowerCase()) {
            case "android": new AndroidDriverBuilder().relauchApp((AndroidDriver) driver);
                DesiredCapabilities caps = new DesiredCapabilities();
                caps.setCapability("appWaitActivity", "com.absli.leap.MainActivity");
                 waitUtils.waitUntilVisible(driver,new SignInPage(driver).eleSignInButton,30);
                break;
            case "ios":     new IOSDriverBuilder().relauchApp((IOSDriver) driver);
                            waitUtils.waitUntilVisible(driver,new SignInPage(driver).eleSignInButton,30);

                            break;
            default:        new WebDriverBuilder().urlRedirect(getBaseUrl(ENV),driver);
                            waitUtils.waitUntilPageLoad(driver);
        }
    }

    public String getPlatform() {
        return PLATFORM_NAME.trim();
    }

    public Boolean isAndroid() {
        if(getPlatform().trim().equalsIgnoreCase("android")) {
            return true;
        }
        else
            return false;
    }

    public Boolean isIOS() {
        if(getPlatform().trim().equalsIgnoreCase("ios")) {
            return true;
        }
        else
            return false;
    }

    public Boolean isWeb() {
        if (PLATFORM_TYPE.trim().equalsIgnoreCase("web")) {
            return true;
        }
        else {
            return false;
        }
    }

    @AfterSuite(alwaysRun = true)
    @Parameters({ "myDeviceContext" })
    @Step("teardown step .....")
    public void teardownDriver(@Optional String myDeviceContext,ITestResult result) throws Exception {
        if(getPlatform().equalsIgnoreCase("android") && RUN_TYPE.equalsIgnoreCase(RunType.PCLOUDY.toString())) {
            new AndroidDriverBuilder().quitDrivers(myDeviceContext);
            new AndroidDriverBuilder().releasepCloudyDevices(myDeviceContext);
        }
        else if(getPlatform().equalsIgnoreCase("ios") && RUN_TYPE.equalsIgnoreCase(RunType.PCLOUDY.toString())) {
            new IOSDriverBuilder().quitDrivers(myDeviceContext);
            new IOSDriverBuilder().releasepCloudyDevices(myDeviceContext);

        }
        else {
            if (!(driver ==null)) {
                driver.quit();
                //driver.close();
                logMessage("Driver has been quit from execution");
                //stopAppiumServer(PLATFORM_TYPE,PLATFORM_NAME);
            }
        }

        //extent.getResult(result);
    }


    //@AfterTest
    @Parameters({ "myDeviceContext" })
    @Step("teardown step .....")
    public void teardownSession(@Optional String myDeviceContext) throws Exception {
        if(getPlatform().equalsIgnoreCase("android") && RUN_TYPE.equalsIgnoreCase(RunType.PCLOUDY.toString())) {
            new AndroidDriverBuilder().releasepCloudyDevices(myDeviceContext);
        }
        else if(getPlatform().equalsIgnoreCase("ios") && RUN_TYPE.equalsIgnoreCase(RunType.PCLOUDY.toString())) {
            new IOSDriverBuilder().releasepCloudyDevices(myDeviceContext);
        }

        //extent.endReport();
    }

    @Step("kill appium server .....")
    private void killExistingAppiumProcess() throws IOException {
        Runtime.getRuntime().exec("killall node");
        logMessage("Killing existing appium process");
    }

    public WebDriver getDriver() {
        return  driver;
    }

    public DeviceContext getContext() {
        return TestRunner.allDeviceContexts.get(CONTEXT);
    }
}