package tests.journeys;


import com.absli.helpers.dataProviders.DataProviders;
import com.absli.helpers.jsonReaders.ReadJson;
import com.absli.helpers.models.ProposerModel;
import com.absli.listeners.TestLevelDriverCreator;
import com.absli.listeners.TestListener;
import com.absli.pageObjects.*;
import com.absli.utils.CommonUtils;
import com.absli.utils.PropertiesUtils;
import com.absli.utils.WaitUtils;
import io.qameta.allure.Description;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import tests.BaseTest;
import tests.TestFactory;

import java.io.IOException;

@Listeners({TestLevelDriverCreator.class})
public class RefusedPolicy extends BaseTest {
    ProposerModel proposerModel;
    ReadJson jsonObj;
    CreateApplPage createApplPage;
    CommonUtils commonUtils;
    WaitUtils waitUtils;
    PropertiesUtils prop;
    SignInPage signIn;
    EnachRegistrationPage enachPage;
    CaptureEmailIdPage captureEmailIdPage;
    ExistingPolicyPage existingPolicyPage;
    RefusedPolicyPage refusedPolicyPage;

    @BeforeClass
    public void preSetup() throws IOException, InterruptedException {
        driver = new TestLevelDriverCreator(). getDriver();
        commonUtils = new CommonUtils();
        waitUtils = new WaitUtils();
        prop = new PropertiesUtils();
        refusedPolicyPage=new RefusedPolicyPage(driver);

    }

    @BeforeMethod
    public void relaunch()  {
        new BaseTest().relaunch();
    }
    @Test(dataProvider = "dataRefusedPolicyProvider", dataProviderClass = DataProviders.class,priority = 1)
    @Description("Test case Description: verify customer able to select refusedPolicy")
    public void verify_refused_policy(String username, String password, String policy, String leadid, String proposersame, String propinsurednotsame, String isnri, String pmobile, String ppan, String imobile,
                                      String ipan, String firstname, String lastname,
                                      String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame,
                                      String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                      String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                      String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                      String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                      String clickverify,String renewpremiumscreentitle,String paymentmethod, String drawdate, String fundsource,
                                      String nomineescreentitle, String nomineefirstname, String nomineelastname, String nomineeday,
                                      String nomineemonth, String nomineeyear, String nomineegender, String relationshipwithproposer, String nomineeshare,
                                      String ismwppolicy,String addressscreentitle, String typeofaddress, String addresspincode, String address1, String address2, String address3,
                                      String personalDetailsscreentitle, String cityName, String preferredLanguage, String alernateNumber, String resTelephoneNumber,String emailaddressValidations,
                                      String maritalStatus, String fathersNameOrSpouseName,
                                      String mothersName,String question1,String answer1,String valueToBeEnter,
                                      String question2,String answer2,String valueToBeEnter2,
                                      String question3,String answer3,String valueToBeEnter3,
                                      String question4,String answer4,String valueToBeEnter4, String qualification, String occupation, String employeerName, String nameOfBusinessOrduties,
                                      String typeOfOrganization, String designation, String annualIncome,String policyStatus,String exPolicyscreenTitle,String  exNameofInsurer,String exSumAssured,
                                      String expolicyNumber,String exyearOfApplication,String exbasePlan,String exannualpremium,String expolicystatus,String medicalPolicy,String refPolicyScreentitle,
                                      String  reNameofInsurer,String reSumAssured,String refreason,
                                      String insurerName1, String sumAssured1, String reason1,
                                      String insurerName2, String sumAssured2, String reason2,
                                      String insurerName3, String sumAssured3, String reason3,
                                      String insurerName4, String sumAssured4, String reason4, String policyPurposeScreen,
                                      String purposeOption1, String purposeOption2, String purposeOption3) throws Exception {

      new TestFactory().gotoRefusedPolicies(driver,username,password,policy,leadid,proposersame,propinsurednotsame,isnri,pmobile
                ,ppan,imobile,ipan,firstname,lastname,middlename,day,month,year,gender,planjourney,proposerstate,advisorstatesame,plan,sumassured
                ,smokertype,planoptions,increasinglevel,ecs,term,ppt,premiumterm,premiumamount,rider,rideramount,minrider,maxrider,ridererror,click,generateillustrations,clickcontinue,ifsccode
                ,bankaccno,accholdername,accounttype,pennyalert,clickverify,renewpremiumscreentitle,paymentmethod,drawdate,fundsource,nomineescreentitle
                ,nomineefirstname,nomineelastname,nomineeday,nomineemonth,nomineeyear,nomineegender,relationshipwithproposer,nomineeshare,ismwppolicy,addressscreentitle,typeofaddress
                ,addresspincode,address1,address2,address3,personalDetailsscreentitle,cityName,preferredLanguage,alernateNumber,resTelephoneNumber,emailaddressValidations,maritalStatus,fathersNameOrSpouseName,mothersName,
              question1,answer1,valueToBeEnter,question2,answer2,valueToBeEnter2,question3,answer3,valueToBeEnter3,question4,answer4,valueToBeEnter4,qualification,occupation
                ,employeerName,nameOfBusinessOrduties,typeOfOrganization,designation,annualIncome,policyStatus,exPolicyscreenTitle,exNameofInsurer,exSumAssured,expolicyNumber,exyearOfApplication,exbasePlan,exannualpremium,expolicystatus
                ,medicalPolicy,refPolicyScreentitle,reNameofInsurer,reSumAssured,refreason,policyPurposeScreen,purposeOption1,purposeOption2,purposeOption3);

        if (refusedPolicyPage.refeusedPolicy.isDisplayed()) {
            refusedPolicyPage.setInsurerName(reNameofInsurer);
            refusedPolicyPage.setsumAssured(Long.valueOf(reSumAssured));
            refusedPolicyPage.setReasonToRefeused(refreason);
            commonUtils.selectButtonByName("No",driver);
            waitUtils.wait2Seconds();
            commonUtils.selectButtonByName("SAVE",driver);

        }
        existingPolicyPage.multipleOptionsSelection();
        existingPolicyPage.selectPurposeInsurence(purposeOption1);
        existingPolicyPage.selectPurposeInsurence(purposeOption2);
        existingPolicyPage.selectPurposeInsurence(purposeOption3);
    }
   // @Test(dataProvider = "dataRefusedPolicyProvider", dataProviderClass = DataProviders.class,priority = 1)
    @Description("Test case Description: verify customer able to select ExistingPolicy")
    public void verify_edit_refused_policy(String username, String password, String policy, String leadid, String proposersame, String propinsurednotsame, String isnri, String pmobile, String ppan, String imobile,
                                           String ipan, String firstname, String lastname,
                                           String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame,
                                           String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                           String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                           String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                           String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                           String clickverify,String renewpremiumscreentitle,String paymentmethod, String drawdate, String fundsource,
                                           String nomineescreentitle, String nomineefirstname, String nomineelastname, String nomineeday,
                                           String nomineemonth, String nomineeyear, String nomineegender, String relationshipwithproposer, String nomineeshare,
                                           String ismwppolicy,String addressscreentitle, String typeofaddress, String addresspincode, String address1, String address2, String address3,
                                           String personalDetailsscreentitle, String cityName, String preferredLanguage, String alernateNumber, String resTelephoneNumber,String emailaddressValidations,
                                           String maritalStatus, String fathersNameOrSpouseName,
                                           String mothersName, String qualification, String occupation, String employeerName, String nameOfBusinessOrduties,
                                           String typeOfOrganization, String designation, String annualIncome,String policyStatus,String exPolicyscreenTitle,String  exNameofInsurer,String exSumAssured,
                                           String expolicyNumber,String exyearOfApplication,String exbasePlan,String exannualpremium,String expolicystatus,String medicalPolicy,String refPolicyScreentitle,
                                           String  reNameofInsurer,String reSumAssured,String refreason,
                                           String insurerName1, String sumAssured1, String reason1,
                                           String insurerName2, String sumAssured2, String reason2,
                                           String insurerName3, String sumAssured3, String reason3,
                                           String insurerName4, String sumAssured4, String reason4, String policyPurposeScreen,
                                           String purposeOption1, String purposeOption2, String purposeOption3) throws Exception {

      /*  new TestFactory().gotoRefusedPolicies(driver,username,password,policy,leadid,proposersame,propinsurednotsame,isnri,pmobile
                ,ppan,imobile,ipan,firstname,lastname,middlename,day,month,year,gender,planjourney,proposerstate,advisorstatesame,plan,sumassured
                ,smokertype,planoptions,increasinglevel,ecs,term,ppt,premiumterm,premiumamount,rider,rideramount,minrider,maxrider,ridererror,click,generateillustrations,clickcontinue,ifsccode
                ,bankaccno,accholdername,accounttype,pennyalert,clickverify,renewpremiumscreentitle,paymentmethod,drawdate,fundsource,nomineescreentitle
                ,nomineefirstname,nomineelastname,nomineeday,nomineemonth,nomineeyear,nomineegender,relationshipwithproposer,nomineeshare,ismwppolicy,addressscreentitle,typeofaddress
                ,addresspincode,address1,address2,address3,personalDetailsscreentitle,cityName,preferredLanguage,alernateNumber,resTelephoneNumber,emailaddressValidations,maritalStatus,fathersNameOrSpouseName,mothersName,qualification,occupation
                ,employeerName,nameOfBusinessOrduties,typeOfOrganization,designation,annualIncome,policyStatus,exPolicyscreenTitle,exNameofInsurer,exSumAssured,expolicyNumber,exyearOfApplication,exbasePlan,exannualpremium,expolicystatus
                ,medicalPolicy,refPolicyScreentitle,reNameofInsurer,reSumAssured,refreason,policyPurposeScreen,purposeOption1,purposeOption2,purposeOption3);
*/
    }
    //@Test(dataProvider = "dataRefusedPolicyProvider", dataProviderClass = DataProviders.class,priority = 1)
    @Description("Test case Description: verify customer able to select ExistingPolicy")
    public void verify_remove_refused_policy(String username, String password, String policy, String leadid, String proposersame, String propinsurednotsame, String isnri, String pmobile, String ppan, String imobile,
                                             String ipan, String firstname, String lastname,
                                             String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame,
                                             String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                             String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                             String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                             String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                             String clickverify,String renewpremiumscreentitle,String paymentmethod, String drawdate, String fundsource,
                                             String nomineescreentitle, String nomineefirstname, String nomineelastname, String nomineeday,
                                             String nomineemonth, String nomineeyear, String nomineegender, String relationshipwithproposer, String nomineeshare,
                                             String ismwppolicy,String addressscreentitle, String typeofaddress, String addresspincode, String address1, String address2, String address3,
                                             String personalDetailsscreentitle, String cityName, String preferredLanguage, String alernateNumber, String resTelephoneNumber,String emailaddressValidations,
                                             String maritalStatus, String fathersNameOrSpouseName,
                                             String mothersName, String qualification, String occupation, String employeerName, String nameOfBusinessOrduties,
                                             String typeOfOrganization, String designation, String annualIncome,String policyStatus,String exPolicyscreenTitle,String  exNameofInsurer,String exSumAssured,
                                             String expolicyNumber,String exyearOfApplication,String exbasePlan,String exannualpremium,String expolicystatus,String medicalPolicy,String refPolicyScreentitle,
                                             String  reNameofInsurer,String reSumAssured,String refreason,
                                             String insurerName1, String sumAssured1, String reason1,
                                             String insurerName2, String sumAssured2, String reason2,
                                             String insurerName3, String sumAssured3, String reason3,
                                             String insurerName4, String sumAssured4, String reason4, String policyPurposeScreen,
                                             String purposeOption1, String purposeOption2, String purposeOption3) throws Exception {

        /*new TestFactory().gotoRefusedPolicies(driver,username,password,policy,leadid,proposersame,propinsurednotsame,isnri,pmobile
                ,ppan,imobile,ipan,firstname,lastname,middlename,day,month,year,gender,planjourney,proposerstate,advisorstatesame,plan,sumassured
                ,smokertype,planoptions,increasinglevel,ecs,term,ppt,premiumterm,premiumamount,rider,rideramount,minrider,maxrider,ridererror,click,generateillustrations,clickcontinue,ifsccode
                ,bankaccno,accholdername,accounttype,pennyalert,clickverify,renewpremiumscreentitle,paymentmethod,drawdate,fundsource,nomineescreentitle
                ,nomineefirstname,nomineelastname,nomineeday,nomineemonth,nomineeyear,nomineegender,relationshipwithproposer,nomineeshare,ismwppolicy,addressscreentitle,typeofaddress
                ,addresspincode,address1,address2,address3,personalDetailsscreentitle,cityName,preferredLanguage,alernateNumber,resTelephoneNumber,emailaddressValidations,maritalStatus,fathersNameOrSpouseName,mothersName,qualification,occupation
                ,employeerName,nameOfBusinessOrduties,typeOfOrganization,designation,annualIncome,policyStatus,exPolicyscreenTitle,exNameofInsurer,exSumAssured,expolicyNumber,exyearOfApplication,exbasePlan,exannualpremium,expolicystatus
                ,medicalPolicy,refPolicyScreentitle,reNameofInsurer,reSumAssured,refreason,policyPurposeScreen,purposeOption1,purposeOption2,purposeOption3);
*/
    }
  //  @Test(dataProvider = "dataRefusedPolicyProvider", dataProviderClass = DataProviders.class,priority = 5)
    @Description("verify customer able to select ExistingPolicy")
    public void verify_add_five_Refused_policy(String username, String password, String policy, String leadid, String proposersame, String propinsurednotsame, String isnri, String pmobile, String ppan, String imobile,
                                                String ipan, String firstname, String lastname,
                                                String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame,
                                                String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                                String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                                String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                                String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                                String clickverify,String renewpremiumscreentitle,String paymentmethod, String drawdate, String fundsource,
                                                String nomineescreentitle, String nomineefirstname, String nomineelastname, String nomineeday,
                                                String nomineemonth, String nomineeyear, String nomineegender, String relationshipwithproposer, String nomineeshare,
                                                String ismwppolicy,String addressscreentitle, String typeofaddress, String addresspincode, String address1, String address2, String address3,
                                                String personalDetailsscreentitle, String cityName, String preferredLanguage, String alernateNumber, String resTelephoneNumber,String emailaddressValidations,
                                                String maritalStatus, String fathersNameOrSpouseName,
                                                String mothersName, String qualification, String occupation, String employeerName, String nameOfBusinessOrduties,
                                                String typeOfOrganization, String designation, String annualIncome,String policyStatus,String exPolicyscreenTitle,String  exNameofInsurer,String exSumAssured,
                                                String expolicyNumber,String exyearOfApplication,String exbasePlan,String exannualpremium,String expolicystatus,String medicalPolicy,String refPolicyScreentitle,String  reNameofInsurer,String reSumAssured,String refreason,
                                                String insurerName1, String sumAssured1, String reason1,
                                                String insurerName2, String sumAssured2, String reason2,
                                                String insurerName3, String sumAssured3, String reason3,
                                                String insurerName4, String sumAssured4, String reason4, String policyPurposeScreen,
                                                String purposeOption1, String purposeOption2, String purposeOption3) throws Exception {

       /* new TestFactory().gotoRefusedPolicies(driver,username,password,policy,leadid,proposersame,propinsurednotsame,isnri,pmobile
        ,ppan,imobile,ipan,firstname,lastname,middlename,day,month,year,gender,planjourney,proposerstate,advisorstatesame,plan,sumassured
                ,smokertype,planoptions,increasinglevel,ecs,term,ppt,premiumterm,premiumamount,rider,rideramount,minrider,maxrider,ridererror,click,generateillustrations,clickcontinue,ifsccode
                ,bankaccno,accholdername,accounttype,pennyalert,clickverify,renewpremiumscreentitle,paymentmethod,drawdate,fundsource,nomineescreentitle
                ,nomineefirstname,nomineelastname,nomineeday,nomineemonth,nomineeyear,nomineegender,relationshipwithproposer,nomineeshare,ismwppolicy,addressscreentitle,typeofaddress
                ,addresspincode,address1,address2,address3,personalDetailsscreentitle,cityName,preferredLanguage,alernateNumber,resTelephoneNumber,emailaddressValidations,maritalStatus,fathersNameOrSpouseName,mothersName,qualification,occupation
                ,employeerName,nameOfBusinessOrduties,typeOfOrganization,designation,annualIncome,policyStatus,exPolicyscreenTitle,exNameofInsurer,exSumAssured,expolicyNumber,exyearOfApplication,exbasePlan,exannualpremium,expolicystatus
                ,medicalPolicy,refPolicyScreentitle,reNameofInsurer,reSumAssured,refreason,policyPurposeScreen,purposeOption1,purposeOption2,purposeOption3);
*/
        refusedPolicyPage.addRefusedPolicy(insurerName1,sumAssured1,reason1);
        refusedPolicyPage.addRefusedPolicy(insurerName2,sumAssured2,reason2);
        refusedPolicyPage.addRefusedPolicy(insurerName3,sumAssured3,reason3);
        refusedPolicyPage.addRefusedPolicy(insurerName4,sumAssured4,reason4);
    }

}
