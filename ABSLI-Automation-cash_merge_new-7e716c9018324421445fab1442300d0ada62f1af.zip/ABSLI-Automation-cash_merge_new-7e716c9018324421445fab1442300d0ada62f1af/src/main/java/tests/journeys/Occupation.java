package tests.journeys;

import com.absli.helpers.dataProviders.DataProviders;
import com.absli.helpers.jsonReaders.ReadJson;
import com.absli.helpers.models.ProposerModel;
import com.absli.listeners.RetryAnalyzer;
import com.absli.listeners.TestLevelDriverCreator;
import com.absli.pageObjects.CreateApplPage;
import com.absli.pageObjects.OccupationPage;
import com.absli.pageObjects.SignInPage;
import com.absli.utils.CommonUtils;
import com.absli.utils.PropertiesUtils;
import com.absli.utils.WaitUtils;
import io.qameta.allure.Description;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import tests.BaseTest;
import tests.TestFactory;

import java.io.IOException;

@Listeners({TestLevelDriverCreator.class})
public class Occupation extends BaseTest{
    ProposerModel proposerModel;
    ReadJson jsonObj;
    CreateApplPage createApplPage;
    CommonUtils commonUtils;
    WaitUtils waitUtils;
    PropertiesUtils prop;
    SignInPage signIn;
    OccupationPage occupation;


    @BeforeClass
    public void preSetup() throws IOException, InterruptedException {
        driver = new TestLevelDriverCreator().getDriver();

        commonUtils = new CommonUtils();
        waitUtils = new WaitUtils();
        prop = new PropertiesUtils();
        occupation = new OccupationPage(driver);
    }

    @AfterMethod
    public void relaunch()  {
        new BaseTest().relaunch();

    }

    @Test(dataProvider = "dataOccupationProvider",dataProviderClass = DataProviders.class,priority = 1,retryAnalyzer = RetryAnalyzer.class)
    @Description("Occupation selection with others option")
    public void occupation(String username, String password, String policy, String leadid, String proposersame,
                              String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                              String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                              String ecs, String term, String ppt, String premiumterm, String premiumamount,
                              String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                              String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                              String clickverify, String renewpremiumscreentitle, String paymentmethod, String drawdate, String fundsource,
                              String nomineescreentitle, String nomineefirstname, String nomineelastname, String nomineeday,
                              String nomineemonth, String nomineeyear, String nomineegender, String relationshipwithproposer, String nomineeshare,
                              String ismwppolicy,
                              String addressscreentitle, String typeofaddress, String addresspincode, String address1, String address2, String address3,
                              String personalDetailsscreentitle, String cityName, String preferredLanguage, String alernateNumber, String resTelephoneNumber,
                              String PersonalEmailId,String PersonalMaritalStatus, String FatherSpouseName,String MotherName, String MaidenName,String Qualification,String Others, String Occupation, String typeOfOccupation, String NameofEmployer, String Designation, String AnnualIncome,
                           String SpouseAnnualIncome ,String ParentInsuranceCover, String ParentAnnualIncome, String SpouseInsuranceCover) throws Exception {


        new TestFactory().gotoQualification(driver, username, password, policy, leadid, proposersame,
                relationwithinsured, isrelationanswer, isnri, pmobile, ppan, imobile, ipan, firstname, lastname,
                middlename, day, month, year, gender, planjourney, proposerstate, advisorstatesame, plan, sumassured, smokertype, planoptions, increasinglevel,
                ecs, term, ppt, premiumterm, premiumamount,
                rider, rideramount, minrider, maxrider, ridererror, click, generateillustrations,
                clickcontinue, ifsccode, bankaccno, accholdername, accounttype, pennyalert, clickverify
                , renewpremiumscreentitle, paymentmethod, drawdate, fundsource,
                nomineescreentitle, nomineefirstname, nomineelastname, nomineeday, nomineemonth, nomineeyear, nomineegender, relationshipwithproposer, typeofaddress, addresspincode, address1, address2, address3, personalDetailsscreentitle, cityName);

        occupation.inputPersonalEmailId(PersonalEmailId);
        waitUtils.waitForElementToBeVisible(driver, occupation.eleFatherSpouseNameInput, 20, "Element not visible");
        occupation.chooseMaritalStatus(PersonalMaritalStatus);
        occupation.inputPersonalFatherSpouseName(FatherSpouseName);
        occupation.inputPersonalMotherName(MotherName);
        commonUtils.scrollTillEndOfPage(driver);
        Assert.assertEquals(occupation.eleOccupationDrpBtn.getText(),"");
        occupation.chooseOccupation(Occupation);
        occupation.validateOccupationFields(Occupation);
        //createApplPage.eleOccupationAnnualIncome.isDisplayed();
        //createApplPage.eleOccupationInsuranceCover.isDisplayed();
    }

    //@Test(dataProvider = "dataOccupationProvider",dataProviderClass = DataProviders.class,priority = 2,retryAnalyzer = RetryAnalyzer.class)
    @Description("Occupation dropdown list validation")
    public void occupation_list_validation(String username, String password, String policy, String leadid, String proposersame,
                                              String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                              String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                              String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                              String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                              String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                              String clickverify, String renewpremiumscreentitle, String paymentmethod, String drawdate, String fundsource,
                                              String nomineescreentitle, String nomineefirstname, String nomineelastname, String nomineeday,
                                              String nomineemonth, String nomineeyear, String nomineegender, String relationshipwithproposer, String nomineeshare,
                                              String ismwppolicy,
                                              String addressscreentitle, String typeofaddress, String addresspincode, String address1, String address2, String address3,
                                              String personalDetailsscreentitle, String cityName, String preferredLanguage, String alernateNumber, String resTelephoneNumber,
                                              String PersonalEmailId,String PersonalMaritalStatus, String FatherSpouseName,String MotherName, String MaidenName,String Qualification,String Others,String Occupation, String typeOfOccupation) throws Exception {

        new TestFactory().gotoQualification(driver, username,  password,  policy,  leadid,  proposersame,
                relationwithinsured,isrelationanswer, isnri, pmobile, ppan, imobile, ipan, firstname, lastname,
                middlename, day, month, year, gender, planjourney, proposerstate, advisorstatesame, plan,sumassured, smokertype, planoptions, increasinglevel,
                ecs, term, ppt, premiumterm, premiumamount,
                rider, rideramount, minrider, maxrider, ridererror, click, generateillustrations,
                clickcontinue, ifsccode, bankaccno, accholdername, accounttype, pennyalert,clickverify
                ,  renewpremiumscreentitle, paymentmethod, drawdate, fundsource,
                nomineescreentitle, nomineefirstname, nomineelastname, nomineeday, nomineemonth, nomineeyear,nomineegender,relationshipwithproposer,typeofaddress, addresspincode, address1, address2, address3, personalDetailsscreentitle, cityName);

        occupation.inputPersonalEmailId(PersonalEmailId);
        waitUtils.waitForElementToBeVisible(driver,occupation.eleFatherSpouseNameInput,20,"Element not visible");
        occupation.chooseMaritalStatus(PersonalMaritalStatus);
        occupation.inputPersonalFatherSpouseName(FatherSpouseName);
        occupation.inputPersonalMotherName(MotherName);
        commonUtils.scrollTillEndOfPage(driver);
        occupation.eleOccupationDrpBtn.click();
        occupation.validateOccupationList();
    }

    //@Test(dataProvider = "dataOccupationProvider",dataProviderClass = DataProviders.class,priority = 3,retryAnalyzer = RetryAnalyzer.class)
    @Description("Type of organisation dropdown list validation")
    public void organisation_list_validation(String username, String password, String policy, String leadid, String proposersame,
                                           String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                           String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                           String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                           String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                           String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                           String clickverify, String renewpremiumscreentitle, String paymentmethod, String drawdate, String fundsource,
                                           String nomineescreentitle, String nomineefirstname, String nomineelastname, String nomineeday,
                                           String nomineemonth, String nomineeyear, String nomineegender, String relationshipwithproposer, String nomineeshare,
                                           String ismwppolicy,
                                           String addressscreentitle, String typeofaddress, String addresspincode, String address1, String address2, String address3,
                                           String personalDetailsscreentitle, String cityName, String preferredLanguage, String alernateNumber, String resTelephoneNumber,
                                           String PersonalEmailId,String PersonalMaritalStatus, String FatherSpouseName,String MotherName, String MaidenName,String Qualification,String Others,String Occupation, String typeOfOccupation) throws Exception {


        new TestFactory().gotoQualification(driver, username,  password,  policy,  leadid,  proposersame,
                relationwithinsured,isrelationanswer, isnri, pmobile, ppan, imobile, ipan, firstname, lastname,
                middlename, day, month, year, gender, planjourney, proposerstate, advisorstatesame, plan,sumassured, smokertype, planoptions, increasinglevel,
                ecs, term, ppt, premiumterm, premiumamount,
                rider, rideramount, minrider, maxrider, ridererror, click, generateillustrations,
                clickcontinue, ifsccode, bankaccno, accholdername, accounttype, pennyalert,clickverify
                ,  renewpremiumscreentitle, paymentmethod, drawdate, fundsource,
                nomineescreentitle, nomineefirstname, nomineelastname, nomineeday, nomineemonth, nomineeyear,nomineegender,relationshipwithproposer,typeofaddress, addresspincode, address1, address2, address3, personalDetailsscreentitle, cityName);


        occupation.inputPersonalEmailId(PersonalEmailId);
        waitUtils.waitForElementToBeVisible(driver,occupation.eleFatherSpouseNameInput,20,"Element not visible");
        occupation.chooseMaritalStatus(PersonalMaritalStatus);
        occupation.inputPersonalFatherSpouseName(FatherSpouseName);
        occupation.inputPersonalMotherName(MotherName);
        commonUtils.scrollTillEndOfPage(driver);
        occupation.chooseOccupation(Occupation);
        waitUtils.waitForElementToBeVisible(driver,occupation.eleTypeOfOgranisationDrpBtn,10,"Type of organisation field should displayed");
        occupation.eleTypeOfOgranisationDrpBtn.click();
        occupation.validateTypeofOrganisationList();
    }
}



/*
* Verify occupation Dropdown Fields
* Verify Type of Organisation Dropdown fields
* If the user chooses agriculture - then only Annual income needs to be asked
* if user select the Student - then Annual income and Insurance cover needs to be asked.
* */