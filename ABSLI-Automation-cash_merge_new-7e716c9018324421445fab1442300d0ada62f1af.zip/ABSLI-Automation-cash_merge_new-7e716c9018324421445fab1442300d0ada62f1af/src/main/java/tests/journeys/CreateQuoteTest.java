package tests.journeys;

import com.absli.enums.ScrollDirection;
import com.absli.helpers.dataProviders.DataProviders;
import com.absli.listeners.RetryAnalyzer;
import com.absli.listeners.TestLevelDriverCreator;
import com.absli.listeners.TestListener;
import com.absli.helpers.jsonReaders.ReadJson;
import com.absli.helpers.models.ProposerModel;
import com.absli.pageObjects.CreateApplPage;
import com.absli.pageObjects.SignInPage;
import com.absli.utils.*;
import io.appium.java_client.ios.IOSDriver;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.*;
import tests.BaseTest;
import tests.TestFactory;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;

@Listeners({TestLevelDriverCreator.class})
public class CreateQuoteTest extends BaseTest {
    ProposerModel proposerModel;
    ReadJson jsonObj;
    SignInPage signIn;
    CreateApplPage createApplPage;
    CommonUtils commonUtils;
    WaitUtils waitUtils;
    PropertiesUtils prop;

    @BeforeClass
    public void preSetup() throws IOException, InterruptedException {
        driver = new TestLevelDriverCreator().getDriver();
        commonUtils = new CommonUtils();
        waitUtils = new WaitUtils();
        prop = new PropertiesUtils();
        new BaseTest().relaunch();
        createApplPage = new CreateApplPage(driver);


    }

    //@AfterMethod
    public void relaunch()  {
        new BaseTest().relaunch();
    }

    @Test(dataProvider = "quoteDataProvider",dataProviderClass = DataProviders.class,description = "Verify the quote generated for default values configured",priority = 1)
    public void createquote_default_values_annual(String username, String password, String policy, String leadid, String proposersame, String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                                  String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate,
                                                  String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                                  String ecs, String term, String ppt, String premiumterm, String premiumamount) throws InterruptedException, IOException {

        new TestFactory().gotoViewQuote( driver,  username,   password,   policy,   leadid,   proposersame,
                relationwithinsured,  isrelationanswer,   isnri,   pmobile,   ppan,   imobile,   ipan,   firstname,   lastname,
                middlename,   day,   month,   year,   gender,   planjourney,   proposerstate,   advisorstatesame,   plan);
        //commonUtils.iosScroll(driver,"ACTIONS","XCUIElementTypeStaticText");
        commonUtils.iosScroll(driver,"type == 'XCUIElementTypeStaticText' AND value == 'ACTIONS'",ScrollDirection.DOWN.getDir());
        //commonUtils.clickOnScrollForIos(driver,createApplPage.elePolicyTermInput);
        System.out.println("premium amout from excel:"+ premiumamount);
        System.out.println("premium amout from code:"+ createApplPage.getPremiumAmount());
        Assert.assertEquals(commonUtils.decimalFormatter(premiumamount),commonUtils.decimalFormatter(createApplPage.getPremiumAmount()));
    }

    //@Test(dataProvider = "quoteDataProvider",dataProviderClass = DataProviders.class,description = "Verify the quote generated for different sum assured amount",priority = 2)
    public void createquote_with_different_sum_assured_value(String username, String password, String policy, String leadid, String proposersame, String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                                             String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate,
                                                             String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                                             String ecs, String term, String ppt, String premiumterm, String premiumamount) throws InterruptedException, IOException {
        /*createQuote(  username,   password,   policy,   leadid,   proposersame,   relationwithinsured, 	isrelationanswer,   isnri,   pmobile,   ppan,   imobile,   ipan,   firstname,   lastname,
                middlename,   day,   month,   year,   gender,   planjourney,   proposerstate,   advisorstatesame,   plan,   sumassured,   smokertype,   planoptions,   increasinglevel,
                ecs,   term,   ppt,   premiumterm,   premiumamount);*/
        new TestFactory().gotoViewQuote( driver,  username,   password,   policy,   leadid,   proposersame,
                relationwithinsured,  isrelationanswer,   isnri,   pmobile,   ppan,   imobile,   ipan,   firstname,   lastname,
                middlename,   day,   month,   year,   gender,   planjourney,   proposerstate,   advisorstatesame,   plan);

        createApplPage.clearSumAssuredInputValue();
        createApplPage.inputSumAssured(sumassured);
        commonUtils.scrollTillEndOfPage(driver);
        System.out.println("premium amout from excel:"+ premiumamount);
        System.out.println("premium amout from code:"+ createApplPage.getPremiumAmount());
        Assert.assertEquals(commonUtils.decimalFormatter(premiumamount),commonUtils.decimalFormatter(createApplPage.getPremiumAmount()));
    }

    //@Test(dataProvider = "quoteDataProvider",dataProviderClass = DataProviders.class,description = "Verify the quote generated when premium period is Monthly",priority = 3)
    public void createquote_default_values_monthly(String username, String password, String policy, String leadid, String proposersame, String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                                   String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate,
                                                   String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                                   String ecs, String term, String ppt, String premiumterm, String premiumamount) throws InterruptedException, IOException {
        /*createQuote(  username,   password,   policy,   leadid,   proposersame,   relationwithinsured, 	isrelationanswer,   isnri,   pmobile,   ppan,   imobile,   ipan,   firstname,   lastname,
                middlename,   day,   month,   year,   gender,   planjourney,   proposerstate,   advisorstatesame,   plan,   sumassured,   smokertype,   planoptions,   increasinglevel,
                ecs,   term,   ppt,   premiumterm,   premiumamount);*/

        new TestFactory().gotoViewQuote( driver,  username,   password,   policy,   leadid,   proposersame,
                relationwithinsured,  isrelationanswer,   isnri,   pmobile,   ppan,   imobile,   ipan,   firstname,   lastname,
                middlename,   day,   month,   year,   gender,   planjourney,   proposerstate,   advisorstatesame,   plan);
        commonUtils.scrollTillEndOfPage(driver);
        createApplPage.choosePremiumPeriod(premiumterm);
        waitUtils.wait5Seconds();
        System.out.println("premium amout from excel:"+ premiumamount);
        System.out.println("premium amout from code:"+ createApplPage.getPremiumAmount());
        Assert.assertEquals(commonUtils.decimalFormatter(premiumamount),commonUtils.decimalFormatter(createApplPage.getPremiumAmount()));

    }

    //@Test(dataProvider = "quoteDataProvider",dataProviderClass = DataProviders.class,description = "Verify the quote generated when premium period is Quarterly",priority = 4)
    public void createquote_default_values_quarterly(String username, String password, String policy, String leadid, String proposersame, String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                                     String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate,
                                                     String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                                     String ecs, String term, String ppt, String premiumterm, String premiumamount) throws InterruptedException, IOException {
        /*createQuote(  username,   password,   policy,   leadid,   proposersame,   relationwithinsured, 	isrelationanswer,   isnri,   pmobile,   ppan,   imobile,   ipan,   firstname,   lastname,
                middlename,   day,   month,   year,   gender,   planjourney,   proposerstate,   advisorstatesame,   plan,   sumassured,   smokertype,   planoptions,   increasinglevel,
                ecs,   term,   ppt,   premiumterm,   premiumamount);*/

        new TestFactory().gotoViewQuote( driver,  username,   password,   policy,   leadid,   proposersame,
                relationwithinsured,  isrelationanswer,   isnri,   pmobile,   ppan,   imobile,   ipan,   firstname,   lastname,
                middlename,   day,   month,   year,   gender,   planjourney,   proposerstate,   advisorstatesame,   plan);
        commonUtils.scrollTillEndOfPage(driver);
        createApplPage.choosePremiumPeriod(premiumterm);
        waitUtils.wait5Seconds();
        System.out.println("premium amout from excel:"+ premiumamount);
        System.out.println("premium amout from code:"+ createApplPage.getPremiumAmount());
        //Assert.assertEquals(commonUtils.decimalFormatter(premiumamount),commonUtils.decimalFormatter(createApplPage.getPremiumAmount()));

    }
    //@Test(dataProvider = "quoteDataProvider",dataProviderClass = DataProviders.class,description = "Verify the quote generated when policy term is changed",priority = 5)
    public void createquote_term(String username, String password, String policy, String leadid, String proposersame, String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                 String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate,
                                 String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                 String ecs, String term, String ppt, String premiumterm, String premiumamount) throws InterruptedException, IOException {
        createQuote(  username,   password,   policy,   leadid,   proposersame,   relationwithinsured, 	isrelationanswer,   isnri,   pmobile,   ppan,   imobile,   ipan,   firstname,   lastname,
                middlename,   day,   month,   year,   gender,   planjourney,   proposerstate,   advisorstatesame,   plan,   sumassured,   smokertype,   planoptions,   increasinglevel,
                ecs,   term,   ppt,   premiumterm,   premiumamount);

        System.out.println("premium amout from excel:"+ premiumamount);
        System.out.println("premium amout from code:"+ createApplPage.getPremiumAmount());
        //Assert.assertEquals(commonUtils.decimalFormatter(premiumamount),commonUtils.decimalFormatter(createApplPage.getPremiumAmount()));

    }
    //@Test(dataProvider = "quoteDataProvider",dataProviderClass = DataProviders.class,description = "Verify the quote generated when plan option is Increasing term assurance",priority = 6)
    public void createquote_increasing_term_assurance_with_level(String username, String password, String policy, String leadid, String proposersame, String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                                                 String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate,
                                                                 String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                                                 String ecs, String term, String ppt, String premiumterm, String premiumamount) throws InterruptedException, IOException {
        createQuote(  username,   password,   policy,   leadid,   proposersame,   relationwithinsured, 	isrelationanswer,   isnri,   pmobile,   ppan,   imobile,   ipan,   firstname,   lastname,
                middlename,   day,   month,   year,   gender,   planjourney,   proposerstate,   advisorstatesame,   plan,   sumassured,   smokertype,   planoptions,   increasinglevel,
                ecs,   term,   ppt,   premiumterm,   premiumamount);

        System.out.println("premium amout from excel:"+ premiumamount);
        System.out.println("premium amout from code:"+ createApplPage.getPremiumAmount());
        //Assert.assertEquals(commonUtils.decimalFormatter(premiumamount),commonUtils.decimalFormatter(createApplPage.getPremiumAmount()));

    }
    //@Test(dataProvider = "quoteDataProvider",dataProviderClass = DataProviders.class,description = "Verify the quote generated when plan option is Increasing term assurance with WOP benefits",priority = 7)
    public void createquote_increasing_term_assurance_with_wop_level(String username, String password, String policy, String leadid, String proposersame, String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                                                     String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate,
                                                                     String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                                                     String ecs, String term, String ppt, String premiumterm, String premiumamount) throws InterruptedException, IOException {
        createQuote(  username,   password,   policy,   leadid,   proposersame,   relationwithinsured, 	isrelationanswer,   isnri,   pmobile,   ppan,   imobile,   ipan,   firstname,   lastname,
                middlename,   day,   month,   year,   gender,   planjourney,   proposerstate,   advisorstatesame,   plan,   sumassured,   smokertype,   planoptions,   increasinglevel,
                ecs,   term,   ppt,   premiumterm,   premiumamount);
        waitUtils.wait5Seconds();
        System.out.println("premium amout from excel:"+ premiumamount);
        System.out.println("premium amout from code:"+ createApplPage.getPremiumAmount());
        Assert.assertEquals(commonUtils.decimalFormatter(premiumamount),commonUtils.decimalFormatter(createApplPage.getPremiumAmount()));

    }
    //@Test(dataProvider = "quoteDataProvider",dataProviderClass = DataProviders.class,description = "Verify the quote generated for a smoker",priority = 8)
    public void createquote_default_values_annual_smoker(String username, String password, String policy, String leadid, String proposersame, String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                                         String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate,
                                                         String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                                         String ecs, String term, String ppt, String premiumterm, String premiumamount) throws InterruptedException, IOException {
        /*createQuote(  username,   password,   policy,   leadid,   proposersame,   relationwithinsured, 	isrelationanswer,   isnri,   pmobile,   ppan,   imobile,   ipan,   firstname,   lastname,
                middlename,   day,   month,   year,   gender,   planjourney,   proposerstate,   advisorstatesame,   plan,   sumassured,   smokertype,   planoptions,   increasinglevel,
                ecs,   term,   ppt,   premiumterm,   premiumamount);*/

        new TestFactory().gotoViewQuote( driver,  username,   password,   policy,   leadid,   proposersame,
                relationwithinsured,  isrelationanswer,   isnri,   pmobile,   ppan,   imobile,   ipan,   firstname,   lastname,
                middlename,   day,   month,   year,   gender,   planjourney,   proposerstate,   advisorstatesame,   plan);
        System.out.println("SMOKER FROM EXCEL ------>"+smokertype);
        createApplPage.chooseSmoker(smokertype);
        waitUtils.wait5Seconds();
        commonUtils.scrollTillEndOfPage(driver);
        Thread.sleep(3000);

        System.out.println("premium amout from excel:"+ premiumamount);
        System.out.println("premium amout from code:"+ createApplPage.getPremiumAmount());
        Assert.assertEquals(commonUtils.decimalFormatter(premiumamount),commonUtils.decimalFormatter(createApplPage.getPremiumAmount()));
    }
    //@Test(dataProvider = "quoteDataProvider",dataProviderClass = DataProviders.class,description = "Verify the quote generated when premium period is single pay",priority = 9)
    public void createquote_default_values_singlepay(String username, String password, String policy, String leadid, String proposersame, String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                                     String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate,
                                                     String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                                     String ecs, String term, String ppt, String premiumterm, String premiumamount) throws InterruptedException, IOException {
        /*createQuote(  username,   password,   policy,   leadid,   proposersame,   relationwithinsured, 	isrelationanswer,   isnri,   pmobile,   ppan,   imobile,   ipan,   firstname,   lastname,
                middlename,   day,   month,   year,   gender,   planjourney,   proposerstate,   advisorstatesame,   plan,   sumassured,   smokertype,   planoptions,   increasinglevel,
                ecs,   term,   ppt,   premiumterm,   premiumamount);*/
        new TestFactory().gotoViewQuote( driver,  username,   password,   policy,   leadid,   proposersame,
                relationwithinsured,  isrelationanswer,   isnri,   pmobile,   ppan,   imobile,   ipan,   firstname,   lastname,
                middlename,   day,   month,   year,   gender,   planjourney,   proposerstate,   advisorstatesame,   plan);
        commonUtils.scrollTillEndOfPage(driver);
        createApplPage.choosePPTDropdown(ppt);
        Thread.sleep(2000);
        System.out.println("premium amout from excel:"+ premiumamount);
        System.out.println("premium amout from code:"+ createApplPage.getPremiumAmount());
        Assert.assertEquals(commonUtils.decimalFormatter(premiumamount),commonUtils.decimalFormatter(createApplPage.getPremiumAmount()));

    }
    //@Test(dataProvider = "quoteDataProvider",dataProviderClass = DataProviders.class,enabled = true,description = "Verify the sum assured validation when minimum value is entered",priority = 10)
    public void createquote_min_sumassured(String username, String password, String policy, String leadid, String proposersame, String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                           String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate,
                                           String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                           String ecs, String term, String ppt, String premiumterm, String premiumamount) throws InterruptedException, IOException {
        new TestFactory().gotoViewQuote( driver,  username,   password,   policy,   leadid,   proposersame,
                  relationwithinsured,  isrelationanswer,   isnri,   pmobile,   ppan,   imobile,   ipan,   firstname,   lastname,
                  middlename,   day,   month,   year,   gender,   planjourney,   proposerstate,   advisorstatesame,   plan);

        createApplPage.clearSumAssuredInputValue();
        createApplPage.inputSumAssured(sumassured);
        Assert.assertTrue(createApplPage.quoteErrorDisplayed());
    }

    //@Test(dataProvider = "quoteDataProvider",dataProviderClass = DataProviders.class,enabled = true,description = "Verify the policy term validation when minimum value is entered",priority = 11)
    public void createquote_min_policyterm(String username, String password, String policy, String leadid, String proposersame, String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                           String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate,
                                           String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                           String ecs, String term, String ppt, String premiumterm, String premiumamount) throws InterruptedException, IOException {
        new TestFactory().gotoViewQuote( driver,  username,   password,   policy,   leadid,   proposersame,
                relationwithinsured,  isrelationanswer,   isnri,   pmobile,   ppan,   imobile,   ipan,   firstname,   lastname,
                middlename,   day,   month,   year,   gender,   planjourney,   proposerstate,   advisorstatesame,   plan);
        commonUtils.scrollToBottom(driver);
        waitUtils.waitForElementToBeVisible(driver,createApplPage.elePolicyTermInput,30,"Policy term input field is not shown");
        createApplPage.inputPolicyTerm(term);
        Assert.assertTrue(createApplPage.quoteErrorDisplayed());
    }

    //@Test(dataProvider = "quoteDataProvider",dataProviderClass = DataProviders.class,enabled = true,description = "Verify the sum assured validation when maximum value is entered",priority = 10)
    public void createquote_max_sumassured(String username, String password, String policy, String leadid, String proposersame, String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                           String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate,
                                           String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                           String ecs, String term, String ppt, String premiumterm, String premiumamount) throws InterruptedException, IOException {
        new TestFactory().gotoViewQuote( driver,  username,   password,   policy,   leadid,   proposersame,
                relationwithinsured,  isrelationanswer,   isnri,   pmobile,   ppan,   imobile,   ipan,   firstname,   lastname,
                middlename,   day,   month,   year,   gender,   planjourney,   proposerstate,   advisorstatesame,   plan);

        createApplPage.clearSumAssuredInputValue();
        createApplPage.inputSumAssured(sumassured);
        Assert.assertTrue(createApplPage.quoteErrorDisplayed());
    }

    //@Test(dataProvider = "quoteDataProvider",dataProviderClass = DataProviders.class,enabled = true,description = "Verify the policy term validation when maximum value is entered",priority = 11)
    public void createquote_max_policyterm(String username, String password, String policy, String leadid, String proposersame, String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                           String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate,
                                           String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                           String ecs, String term, String ppt, String premiumterm, String premiumamount) throws InterruptedException, IOException {
        new TestFactory().gotoViewQuote( driver,  username,   password,   policy,   leadid,   proposersame,
                relationwithinsured,  isrelationanswer,   isnri,   pmobile,   ppan,   imobile,   ipan,   firstname,   lastname,
                middlename,   day,   month,   year,   gender,   planjourney,   proposerstate,   advisorstatesame,   plan);
        commonUtils.scrollToBottom(driver);
        waitUtils.waitUntilVisible(driver,createApplPage.elePolicyTermInput,30);
        createApplPage.inputPolicyTerm(term);
        Assert.assertTrue(createApplPage.quoteErrorDisplayed());
    }

    //@Test(dataProvider = "quoteDataProvider",dataProviderClass = DataProviders.class,description = "Verify illustration download",priority = 12)
    public void download_illustration(String username, String password, String policy, String leadid, String proposersame, String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                      String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate,
                                      String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                      String ecs, String term, String ppt, String premiumterm, String premiumamount) throws InterruptedException, IOException {
        createQuote(  username,   password,   policy,   leadid,   proposersame,   relationwithinsured, 	isrelationanswer,   isnri,   pmobile,   ppan,   imobile,   ipan,   firstname,   lastname,
                middlename,   day,   month,   year,   gender,   planjourney,   proposerstate,   advisorstatesame,   plan,   sumassured,   smokertype,   planoptions,   increasinglevel,
                ecs,   term,   ppt,   premiumterm,   premiumamount);
        commonUtils.scrollTillEndOfPage(driver);
        createApplPage.downloadIllustration();
    }



    public void createQuote(String username, String password, String policy, String leadid, String proposersame, String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                            String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                            String ecs, String term, String ppt, String premiumterm, String premiumamount) throws IOException, InterruptedException {
        new TestFactory().generateQuote( driver,  username,   password,   policy,   leadid,   proposersame,
                relationwithinsured,  isrelationanswer,   isnri,   pmobile,   ppan,   imobile,   ipan,   firstname,   lastname,
                middlename,   day,   month,   year,   gender,   planjourney,   proposerstate,   advisorstatesame,
                plan,  sumassured,   smokertype,   planoptions,   increasinglevel,
                ecs,   term,   ppt,   premiumterm,   premiumamount);
        Thread.sleep(2000);


    }


















/*
* Validate if the user can able to view all the fields
Validate the fields captured have the required validation
Validate fields are Prefilled as per the plan
Validate  Modifying of any of the fileds
Validate for Monthly,Quarterly, payment options ECS is Mandate
Validate Increasing level Plan
Validate sum assured has min of Rs 50,00,000.
Validate the Illustration is generated after plan is selected
Validate the premium value is changed on tap of entering any field
Validate Without Entering Sum Assured generate illustration Should display a message Please enter Sum Assured Amount
Validate Without Entering Sum Assured generate click on Save Please Enter Sum Assured Amout
Validate  Without Selecting ECS select Monthly and click on SAVE Please Select ECS Checkbox message should display
Validate Non Smoker By Default Should Select
Validate without selecting PPT Click on Save Please Select the PPT Message should display
Validate Without Selecting Select Plan Option Click on SAVE
Validate Enter Sum Assured less than 50L Click on Generate Illustration or Save Please select the plan option message should display
Validate Click on View Quote Should Redirect To Previous Page
Validate Click on Add Riders Naviagte to Add Riders Page
Validate the Generate Illustration
Validate The Save After Entering All The Fields
* */

}
