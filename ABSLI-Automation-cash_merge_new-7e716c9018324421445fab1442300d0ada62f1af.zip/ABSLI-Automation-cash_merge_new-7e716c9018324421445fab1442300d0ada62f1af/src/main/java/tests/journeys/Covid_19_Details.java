package tests.journeys;

import com.absli.helpers.dataProviders.DataProviders;
import com.absli.helpers.jsonReaders.ReadJson;
import com.absli.helpers.models.ProposerModel;
import com.absli.listeners.RetryAnalyzer;
import com.absli.listeners.TestLevelDriverCreator;
import com.absli.listeners.TestListener;
import com.absli.pageObjects.*;
import com.absli.utils.CommonUtils;
import com.absli.utils.PropertiesUtils;
import com.absli.utils.WaitUtils;
import io.qameta.allure.Description;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import tests.BaseTest;
import tests.TestFactory;

import java.io.IOException;

@Listeners({TestLevelDriverCreator.class})
public class Covid_19_Details extends BaseTest {
    ProposerModel proposerModel;
    ReadJson jsonObj;
    CreateApplPage createApplPage;
    CommonUtils commonUtils;
    WaitUtils waitUtils;
    PropertiesUtils prop;
    SignInPage signIn;
    EnachRegistrationPage enachPage;
    CaptureEmailIdPage captureEmailIdPage;
    ExistingPolicyPage existingPolicyPage;
    RefusedPolicyPage refusedPolicyPage;
    Covid_19_DetailsPage covid_19_Details_page;

    @BeforeClass
    public void preSetup() throws IOException, InterruptedException {
        driver = new TestLevelDriverCreator(). getDriver();
        commonUtils = new CommonUtils();
        waitUtils = new WaitUtils();
        prop = new PropertiesUtils();
        covid_19_Details_page =new Covid_19_DetailsPage(driver);
    }

    @BeforeMethod
    public void relaunch()  {
        new BaseTest().relaunch();

    }
    @Test(dataProvider = "dataCovid19Provider", dataProviderClass = DataProviders.class, priority = 1)
    @Description("Test case description : verifing the covid symptoms")
    public void verify_covid_19_Details(String username, String password, String policy, String leadid, String proposersame, String propinsurednotsame, String isnri, String pmobile, String ppan, String imobile,
                                     String ipan, String firstname, String lastname,
                                     String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame,
                                     String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                     String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                     String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                     String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                     String clickverify, String renewpremiumscreentitle, String paymentmethod, String drawdate, String fundsource,
                                     String nomineescreentitle, String nomineefirstname, String nomineelastname, String nomineeday,
                                     String nomineemonth, String nomineeyear, String nomineegender, String relationshipwithproposer, String nomineeshare,
                                     String ismwppolicy, String addressscreentitle, String typeofaddress, String addresspincode, String address1, String address2, String address3,
                                     String personalDetailsscreentitle, String cityName, String preferredLanguage, String alernateNumber, String resTelephoneNumber, String emailaddressValidations,
                                     String maritalStatus, String fathersNameOrSpouseName,
                                     String mothersName, String question1,String answer1,String valueToBeEnter,
                                        String question2,String answer2,String valueToBeEnter2,
                                        String question3,String answer3,String valueToBeEnter3,
                                        String question4,String answer4,String valueToBeEnter4,String qualification, String occupation, String employeerName, String nameOfBusinessOrduties,
                                     String typeOfOrganization, String designation, String annualIncome, String policyStatus, String exPolicyscreenTitle, String exNameofInsurer, String exSumAssured,
                                     String expolicyNumber, String exyearOfApplication, String exbasePlan, String exannualpremium, String expolicystatus, String medicalPolicy, String refPolicyScreentitle,
                                     String reNameofInsurer, String reSumAssured, String refreason,
                                     String insurerName1, String sumAssured1, String reason1,
                                     String insurerName2, String sumAssured2, String reason2,
                                     String insurerName3, String sumAssured3, String reason3,
                                     String insurerName4, String sumAssured4, String reason4, String policyPurposeScreen,
                                     String purposeOption1, String purposeOption2, String purposeOption3,String healthDetailsScreen,
                                        String symptomsDetails,String testsDetails,String covidContactDetails,String quarantineDetails,String healthDetails,String pastTravelCountry,
                                        String pastTravelCity,String pastTravelArrivalDay,String pastTravelArraivalMonth,String pastTravelArraivalYear,String pastTravelDepartureDay,
                                        String pastTravelDepartureMonth,String pastTravelDepartureYear,String futureTravelCountry,
                                        String futureTravelCity,String futureTravelDepartureDay,String futureTravelDepartureMonth,String futureTravelDepartureYear,String futureInternedDuration,
                                        String covidVaccinationFirstDoseDay,String covidVaccinationFirstDoseMonth,String covidVaccinationFirstDoseYear,
                                        String covidVaccinationSecondDoseDay,String covidVaccinationSecondDoseMonth,String covidVaccinationSecondDoseYear,
                                        String covidVaccineName,String postVaccineDetails,String covidOccupation,String medicalSpeciality,String exactNatureOfDuties,
                                        String nameOfHealthCareFacility,String addressOfHealthCareFacility,String healthAuthorityRegistered,String covidWardDetails,
                                        String diagnoseDay,String diagnoseMonth,String diagnoseYear,String daignoseTestName,String receivedCovid19Test1,String receivedCovid19Test2,String receivedCovid19Test3,
                                        String admissionDay,String admissionMonth,String admissionYear,String dischargeDay,String dischargeMonth,String dischargeYear,
                                        String covidInfectionDetails,String covidSymptoms1,String covidSymptoms2,String covidSymptoms3,String recoveryDay,String recoveryMonth,String recoveryYear,String testsName,
                                        String testTakenDay,String testTakenMonth,String testTakenYear,String certifiedDetails) throws Exception {

       new TestFactory().gotoRefusedPolicies(driver, username, password, policy, leadid, proposersame, propinsurednotsame, isnri, pmobile
                , ppan, imobile, ipan, firstname, lastname, middlename, day, month, year, gender, planjourney, proposerstate, advisorstatesame, plan, sumassured
                , smokertype, planoptions, increasinglevel, ecs, term, ppt, premiumterm, premiumamount, rider, rideramount, minrider, maxrider, ridererror, click, generateillustrations, clickcontinue, ifsccode
                , bankaccno, accholdername, accounttype, pennyalert, clickverify, renewpremiumscreentitle, paymentmethod, drawdate, fundsource, nomineescreentitle
                , nomineefirstname, nomineelastname, nomineeday, nomineemonth, nomineeyear, nomineegender, relationshipwithproposer, nomineeshare, ismwppolicy, addressscreentitle, typeofaddress
                , addresspincode, address1, address2, address3, personalDetailsscreentitle, cityName, preferredLanguage, alernateNumber, resTelephoneNumber, emailaddressValidations, maritalStatus, fathersNameOrSpouseName, mothersName,question1,answer1,valueToBeEnter,question2,answer2,valueToBeEnter2,question3,answer3,valueToBeEnter3,question4,answer4,valueToBeEnter4, qualification, occupation
                , employeerName, nameOfBusinessOrduties, typeOfOrganization, designation, annualIncome, policyStatus, exPolicyscreenTitle, exNameofInsurer, exSumAssured, expolicyNumber, exyearOfApplication, exbasePlan, exannualpremium, expolicystatus
                , medicalPolicy, refPolicyScreentitle, reNameofInsurer, reSumAssured, refreason, policyPurposeScreen, purposeOption1, purposeOption2, purposeOption3);



                waitUtils.waitForElementToBeVisible(driver, covid_19_Details_page.healthDetailsTitle);
                waitUtils.Asserting("equals", covid_19_Details_page.healthDetailsTitle.getText(),healthDetailsScreen);
                //commonUtils.scrollIntoView(covid_19_Details_page.moduleTitle,driver);
                commonUtils.clickElement(covid_19_Details_page.moduleTitle);
                waitUtils.waitForElementToBeVisible(driver, covid_19_Details_page.symptomsSection);
                commonUtils.scrollIntoView("Symptoms",driver);
                covid_19_Details_page.gotoSection("Symptoms");
                covid_19_Details_page.setSymptomsDetials("Symptoms",symptomsDetails);
                commonUtils.scrollIntoView("Tests",driver);
                waitUtils.waitForElementToBeVisible(driver, covid_19_Details_page.gotoSectionElement("Tests"));
                covid_19_Details_page.valueToBeEnterForTests("Tests",testsDetails);
              //  commonUtils.scrollIntoView("Covid Contact",driver);
                commonUtils.scrollIntoView("Covid Contact",driver);
                covid_19_Details_page.gotoSection("Covid Contact");
                covid_19_Details_page.valueToBeEnterForCovidContact("Covid Contact",covidContactDetails);
                commonUtils.scrollIntoView("Quarantine",driver);
                covid_19_Details_page.gotoSection("Quarantine");
                covid_19_Details_page.textToBeEnter("Quarantine",quarantineDetails);
                commonUtils.scrollIntoView("Past Travel",driver);
                covid_19_Details_page.gotoSection("Past Travel");
                covid_19_Details_page.setPastTravelCountry(pastTravelCountry);
                covid_19_Details_page.setPastTravelCity(pastTravelCity);
                covid_19_Details_page.dateOfArrialDay(pastTravelArrivalDay);
                covid_19_Details_page.dateOfArrivalMonth(pastTravelArraivalMonth);
                covid_19_Details_page.dateOfArrialYear(pastTravelArraivalYear);
                covid_19_Details_page.dateOfDepartureDay(pastTravelDepartureDay);
                covid_19_Details_page.departureMonth(pastTravelDepartureMonth);
                covid_19_Details_page.departureYear(pastTravelDepartureYear);
                commonUtils.selectButtonByName("SAVE",driver);

                commonUtils.scrollIntoView("Future travel",driver);
                covid_19_Details_page.gotoSectionElement("Future travel");
                commonUtils.scrollToElement(driver,covid_19_Details_page.futureTravelCountry);
                covid_19_Details_page.getFutureTravelCountry(futureTravelCountry);
                covid_19_Details_page.getFutureTravelCity(futureTravelCity);
                covid_19_Details_page.futureTravelDay(futureTravelDepartureDay);
                covid_19_Details_page.futureTravelMonth(futureTravelDepartureMonth);
                covid_19_Details_page.futureTravelYear(futureTravelDepartureYear);
                covid_19_Details_page.noOfDays(futureInternedDuration);
                commonUtils.selectButtonByName("SAVE",driver);
                commonUtils.scrollIntoView("Covid Vaccination",driver);
                covid_19_Details_page.gotoSection("Covid Vaccination");
                covid_19_Details_page.vaccinationDay(covidVaccinationFirstDoseDay);
                covid_19_Details_page.vaccinationMonth(covidVaccinationFirstDoseMonth);
                covid_19_Details_page.vaccinationYear(covidVaccinationFirstDoseYear);
                covid_19_Details_page.vaccination2Day(covidVaccinationSecondDoseDay);
                covid_19_Details_page.vaccination2Month(covidVaccinationSecondDoseMonth);
                covid_19_Details_page.vaccination2Year(covidVaccinationSecondDoseYear);

                covid_19_Details_page.setVaccineName(covidVaccineName);
                covid_19_Details_page.postVaccinationExperienced.click();
                covid_19_Details_page.exOnPostVaccination(postVaccineDetails);
                commonUtils.selectButtonByName("SAVE",driver);
                covid_19_Details_page.postVaccinationExperienced.click();
                commonUtils.scrollIntoView("For Health Workers Only",driver);
                covid_19_Details_page.gotoSectionElement("For Health Workers Only");
                covid_19_Details_page.enterOccupation(covidOccupation);
                covid_19_Details_page.enterMedicalSpecialty(medicalSpeciality);
                covid_19_Details_page.exactnatureofduties(exactNatureOfDuties);
                covid_19_Details_page.nameofHealthcarefacility(nameOfHealthCareFacility);
                covid_19_Details_page.addressOfHealthcarefacility(addressOfHealthCareFacility);
                covid_19_Details_page.healthAuthorityyouareregisteredunder(healthAuthorityRegistered);

                covid_19_Details_page.getProvideDetails2.click();
                covid_19_Details_page.provideDetails2(covidWardDetails);
                //commonUtils.selectButtonByName("SAVE",driver);
                commonUtils.scrollIntoView("Recovered from Covid19",driver);
                covid_19_Details_page.gotoSectionElement("Recovered from Covid19");
                covid_19_Details_page.recoveredDay(recoveryDay);
                covid_19_Details_page.recoveredMonth(recoveryMonth);
                covid_19_Details_page.recoveredYear(recoveryYear);

                //commonUtils.selectButtonByName("I don’t know",driver);

                covid_19_Details_page.covidTestOptionToBeSelect(receivedCovid19Test1);
                covid_19_Details_page.covidTestOptionToBeSelect(receivedCovid19Test2);
                covid_19_Details_page.covidTestOptionToBeSelect(receivedCovid19Test3);
                covid_19_Details_page.symptomsOptions(covidSymptoms1);
                covid_19_Details_page.symptomsOptions(covidSymptoms2);
                covid_19_Details_page.symptomsOptions(covidSymptoms3);

                covid_19_Details_page.recoveredFromCovidDay(recoveryDay);
                covid_19_Details_page.recoveredFromCovidMonth(recoveryMonth);
                covid_19_Details_page.recoveredFromCovidYear(recoveryYear);

                covid_19_Details_page.penddingAppointments.click();

                covid_19_Details_page.setCovidTestName(testsName);
                covid_19_Details_page.testTakenDay(testTakenDay);
                covid_19_Details_page.testTakenMonth(testTakenMonth);
                covid_19_Details_page.testTakenYear(testTakenYear);

                //commonUtils.selectButtonByName("SAVE",driver);

                covid_19_Details_page.returnToWorkCertified.click();
                covid_19_Details_page.returnToWorkCertifiedDetails(certifiedDetails);

                commonUtils.selectButtonByName("SAVE & CONTINUE",driver);

                waitUtils.wait5Seconds();

                waitUtils.Asserting("equals",covid_19_Details_page.reviewAndAcceptanceTitle.getText(),"9.0 Review & Acceptance");


    }


    @Test(dataProvider = "dataCovid19Provider", dataProviderClass = DataProviders.class, priority = 1)
    @Description("Test case description : verifing the covid symptoms")
    public void verify_covid_19_Details_MoreValidations(String username, String password, String policy, String leadid, String proposersame, String propinsurednotsame, String isnri, String pmobile, String ppan, String imobile,
                                                        String ipan, String firstname, String lastname,
                                                        String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame,
                                                        String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                                        String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                                        String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                                        String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                                        String clickverify, String renewpremiumscreentitle, String paymentmethod, String drawdate, String fundsource,
                                                        String nomineescreentitle, String nomineefirstname, String nomineelastname, String nomineeday,
                                                        String nomineemonth, String nomineeyear, String nomineegender, String relationshipwithproposer, String nomineeshare,
                                                        String ismwppolicy, String addressscreentitle, String typeofaddress, String addresspincode, String address1, String address2, String address3,
                                                        String personalDetailsscreentitle, String cityName, String preferredLanguage, String alernateNumber, String resTelephoneNumber, String emailaddressValidations,
                                                        String maritalStatus, String fathersNameOrSpouseName,
                                                        String mothersName, String qualification, String occupation, String employeerName, String nameOfBusinessOrduties,
                                                        String typeOfOrganization, String designation, String annualIncome, String policyStatus, String exPolicyscreenTitle, String exNameofInsurer, String exSumAssured,
                                                        String expolicyNumber, String exyearOfApplication, String exbasePlan, String exannualpremium, String expolicystatus, String medicalPolicy, String refPolicyScreentitle,
                                                        String reNameofInsurer, String reSumAssured, String refreason,
                                                        String insurerName1, String sumAssured1, String reason1,
                                                        String insurerName2, String sumAssured2, String reason2,
                                                        String insurerName3, String sumAssured3, String reason3,
                                                        String insurerName4, String sumAssured4, String reason4, String policyPurposeScreen,
                                                        String purposeOption1, String purposeOption2, String purposeOption3,String healthDetailsScreen,
                                                        String symptomsDetails,String testsDetails,String covidContactDetails,String quarantineDetails,String healthDetails,String pastTravelCountry,
                                                        String pastTravelCity,String pastTravelArrivalDay,String pastTravelArraivalMonth,String pastTravelArraivalYear,String pastTravelDepartureDay,
                                                        String pastTravelDepartureMonth,String pastTravelDepartureYear,String futureTravelCountry,
                                                        String futureTravelCity,String futureTravelDepartureDay,String futureTravelDepartureMonth,String futureTravelDepartureYear,String futureInternedDuration,
                                                        String covidVaccinationFirstDoseDay,String covidVaccinationFirstDoseMonth,String covidVaccinationFirstDoseYear,
                                                        String covidVaccinationSecondDoseDay,String covidVaccinationSecondDoseMonth,String covidVaccinationSecondDoseYear,
                                                        String covidVaccineName,String postVaccineDetails,String covidOccupation,String medicalSpeciality,String exactNatureOfDuties,
                                                        String nameOfHealthCareFacility,String addressOfHealthCareFacility,String healthAuthorityRegistered,String covidWardDetails,
                                                        String diagnoseDay,String diagnoseMonth,String diagnoseYear,String daignoseTestName,String receivedCovid19Test1,String receivedCovid19Test2,String receivedCovid19Test3,
                                                        String admissionDay,String admissionMonth,String admissionYear,String dischargeDay,String dischargeMonth,String dischargeYear,
                                                        String covidInfectionDetails,String covidSymptoms1,String covidSymptoms2,String covidSymptoms3,String recoveryDay,String recoveryMonth,String recoveryYear,String testsName,
                                                        String testTakenDay,String testTakenMonth,String testTakenYear,String certifiedDetails) throws Exception {

       /* new TestFactory().gotoRefusedPolicies(driver, username, password, policy, leadid, proposersame, propinsurednotsame, isnri, pmobile
                , ppan, imobile, ipan, firstname, lastname, middlename, day, month, year, gender, planjourney, proposerstate, advisorstatesame, plan, sumassured
                , smokertype, planoptions, increasinglevel, ecs, term, ppt, premiumterm, premiumamount, rider, rideramount, minrider, maxrider, ridererror, click, generateillustrations, clickcontinue, ifsccode
                , bankaccno, accholdername, accounttype, pennyalert, clickverify, renewpremiumscreentitle, paymentmethod, drawdate, fundsource, nomineescreentitle
                , nomineefirstname, nomineelastname, nomineeday, nomineemonth, nomineeyear, nomineegender, relationshipwithproposer, nomineeshare, ismwppolicy, addressscreentitle, typeofaddress
                , addresspincode, address1, address2, address3, personalDetailsscreentitle, cityName, preferredLanguage, alernateNumber, resTelephoneNumber, emailaddressValidations, maritalStatus, fathersNameOrSpouseName, mothersName, qualification, occupation
                , employeerName, nameOfBusinessOrduties, typeOfOrganization, designation, annualIncome, policyStatus, exPolicyscreenTitle, exNameofInsurer, exSumAssured, expolicyNumber, exyearOfApplication, exbasePlan, exannualpremium, expolicystatus
                , medicalPolicy, refPolicyScreentitle, reNameofInsurer, reSumAssured, refreason, policyPurposeScreen, purposeOption1, purposeOption2, purposeOption3);
*/


        waitUtils.waitForElementToBeVisible(driver, covid_19_Details_page.healthDetailsTitle);
        waitUtils.Asserting("equals", covid_19_Details_page.healthDetailsTitle.getText(),healthDetailsScreen);
        //commonUtils.scrollIntoView(covid_19_Details_page.moduleTitle,driver);
        commonUtils.clickElement(covid_19_Details_page.moduleTitle);
        waitUtils.waitForElementToBeVisible(driver, covid_19_Details_page.symptomsSection);
        covid_19_Details_page.gotoSection("Symptoms");
        covid_19_Details_page.setSymptomsDetials("Symptoms",symptomsDetails);
        waitUtils.waitForElementToBeVisible(driver, covid_19_Details_page.gotoSectionElement("Tests"));
        covid_19_Details_page.valueToBeEnterForTests("Tests",testsDetails);
        //  commonUtils.scrollIntoView("Covid Contact",driver);
        covid_19_Details_page.gotoSection("Covid Contact");
        covid_19_Details_page.valueToBeEnterForCovidContact("Covid Contact",covidContactDetails);
        covid_19_Details_page.gotoSection("Quarantine");
        covid_19_Details_page.textToBeEnter("Quarantine",quarantineDetails);
        covid_19_Details_page.gotoSection("Past Travel");
        covid_19_Details_page.setPastTravelCountry(pastTravelCountry);
        covid_19_Details_page.setPastTravelCity(pastTravelCity);
        covid_19_Details_page.dateOfArrialDay(pastTravelArrivalDay);
        covid_19_Details_page.dateOfArrivalMonth(pastTravelArraivalMonth);
        covid_19_Details_page.dateOfArrialYear(pastTravelArraivalYear);
        covid_19_Details_page.dateOfDepartureDay(pastTravelDepartureDay);
        covid_19_Details_page.departureMonth(pastTravelDepartureMonth);
        covid_19_Details_page.departureYear(pastTravelDepartureYear);
        commonUtils.selectButtonByName("SAVE",driver);

        //  commonUtils.scrollIntoView("Future travel",driver);
        covid_19_Details_page.gotoSectionElement("Future travel");
        commonUtils.scrollToElement(driver,covid_19_Details_page.futureTravelCountry);
        covid_19_Details_page.getFutureTravelCountry(futureTravelCountry);
        covid_19_Details_page.getFutureTravelCity(futureTravelCity);
        covid_19_Details_page.futureTravelDay(futureTravelDepartureDay);
        covid_19_Details_page.futureTravelMonth(futureTravelDepartureMonth);
        covid_19_Details_page.futureTravelYear(futureTravelDepartureYear);
        covid_19_Details_page.noOfDays(futureInternedDuration);
        commonUtils.selectButtonByName("SAVE",driver);
        //commonUtils.scrollIntoView("Covid Vaccination",driver);
        covid_19_Details_page.gotoSection("Covid Vaccination");
        covid_19_Details_page.vaccinationDay(covidVaccinationFirstDoseDay);
        covid_19_Details_page.vaccinationMonth(covidVaccinationFirstDoseMonth);
        covid_19_Details_page.vaccinationYear(covidVaccinationFirstDoseYear);
        covid_19_Details_page.vaccination2Day(covidVaccinationSecondDoseDay);
        covid_19_Details_page.vaccination2Month(covidVaccinationSecondDoseMonth);
        covid_19_Details_page.vaccination2Year(covidVaccinationSecondDoseYear);

        covid_19_Details_page.setVaccineName(covidVaccineName);
        covid_19_Details_page.postVaccinationExperienced.click();
        covid_19_Details_page.exOnPostVaccination(postVaccineDetails);
        commonUtils.selectButtonByName("SAVE",driver);
        covid_19_Details_page.postVaccinationExperienced.click();
        covid_19_Details_page.gotoSectionElement("For Health Workers Only");
        covid_19_Details_page.enterOccupation(covidOccupation);
        covid_19_Details_page.enterMedicalSpecialty(medicalSpeciality);
        covid_19_Details_page.exactnatureofduties(exactNatureOfDuties);
        covid_19_Details_page.nameofHealthcarefacility(nameOfHealthCareFacility);
        covid_19_Details_page.addressOfHealthcarefacility(addressOfHealthCareFacility);
        covid_19_Details_page.healthAuthorityyouareregisteredunder(healthAuthorityRegistered);

        covid_19_Details_page.getProvideDetails2.click();
        covid_19_Details_page.provideDetails2(covidWardDetails);
        //commonUtils.selectButtonByName("SAVE",driver);
        covid_19_Details_page.gotoSectionElement("Recovered from Covid19");
        covid_19_Details_page.recoveredDay(recoveryDay);
        covid_19_Details_page.recoveredMonth(recoveryMonth);
        covid_19_Details_page.recoveredYear(recoveryYear);

        //commonUtils.selectButtonByName("I don’t know",driver);

        covid_19_Details_page.covidTestOptionToBeSelect(receivedCovid19Test1);
        covid_19_Details_page.covidTestOptionToBeSelect(receivedCovid19Test2);
        covid_19_Details_page.covidTestOptionToBeSelect(receivedCovid19Test3);
        covid_19_Details_page.symptomsOptions(covidSymptoms1);
        covid_19_Details_page.symptomsOptions(covidSymptoms2);
        covid_19_Details_page.symptomsOptions(covidSymptoms3);

        covid_19_Details_page.recoveredFromCovidDay(recoveryDay);
        covid_19_Details_page.recoveredFromCovidMonth(recoveryMonth);
        covid_19_Details_page.recoveredFromCovidYear(recoveryYear);

        covid_19_Details_page.penddingAppointments.click();

        covid_19_Details_page.setCovidTestName(testsName);
        covid_19_Details_page.testTakenDay(testTakenDay);
        covid_19_Details_page.testTakenMonth(testTakenMonth);
        covid_19_Details_page.testTakenYear(testTakenYear);

        //commonUtils.selectButtonByName("SAVE",driver);

        covid_19_Details_page.returnToWorkCertified.click();
        covid_19_Details_page.returnToWorkCertifiedDetails(certifiedDetails);

        commonUtils.selectButtonByName("SAVE & CONTINUE",driver);

        waitUtils.wait5Seconds();

        waitUtils.Asserting("equals",covid_19_Details_page.reviewAndAcceptanceTitle.getText(),"9.0 Review & Acceptance");


    }
   @Test(dataProvider = "dataCovid19Provider", dataProviderClass = DataProviders.class, priority = 1)
    @Description("Test case description : verifing the covid symptoms")
    public void verify_covid_19_Details_Validations(String username, String password, String policy, String leadid, String proposersame, String propinsurednotsame, String isnri, String pmobile, String ppan, String imobile,
                                                    String ipan, String firstname, String lastname,
                                                    String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame,
                                                    String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                                    String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                                    String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                                    String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                                    String clickverify, String renewpremiumscreentitle, String paymentmethod, String drawdate, String fundsource,
                                                    String nomineescreentitle, String nomineefirstname, String nomineelastname, String nomineeday,
                                                    String nomineemonth, String nomineeyear, String nomineegender, String relationshipwithproposer, String nomineeshare,
                                                    String ismwppolicy, String addressscreentitle, String typeofaddress, String addresspincode, String address1, String address2, String address3,
                                                    String personalDetailsscreentitle, String cityName, String preferredLanguage, String alernateNumber, String resTelephoneNumber, String emailaddressValidations,
                                                    String maritalStatus, String fathersNameOrSpouseName,
                                                    String mothersName, String qualification, String occupation, String employeerName, String nameOfBusinessOrduties,
                                                    String typeOfOrganization, String designation, String annualIncome, String policyStatus, String exPolicyscreenTitle, String exNameofInsurer, String exSumAssured,
                                                    String expolicyNumber, String exyearOfApplication, String exbasePlan, String exannualpremium, String expolicystatus, String medicalPolicy, String refPolicyScreentitle,
                                                    String reNameofInsurer, String reSumAssured, String refreason,
                                                    String insurerName1, String sumAssured1, String reason1,
                                                    String insurerName2, String sumAssured2, String reason2,
                                                    String insurerName3, String sumAssured3, String reason3,
                                                    String insurerName4, String sumAssured4, String reason4, String policyPurposeScreen,
                                                    String purposeOption1, String purposeOption2, String purposeOption3,String healthDetailsScreen,
                                                    String symptomsDetails,String testsDetails,String covidContactDetails,String quarantineDetails,String healthDetails,String pastTravelCountry,
                                                    String pastTravelCity,String pastTravelArrivalDay,String pastTravelArraivalMonth,String pastTravelArraivalYear,String pastTravelDepartureDay,
                                                    String pastTravelDepartureMonth,String pastTravelDepartureYear,String futureTravelCountry,
                                                    String futureTravelCity,String futureTravelDepartureDay,String futureTravelDepartureMonth,String futureTravelDepartureYear,String futureInternedDuration,
                                                    String covidVaccinationFirstDoseDay,String covidVaccinationFirstDoseMonth,String covidVaccinationFirstDoseYear,
                                                    String covidVaccinationSecondDoseDay,String covidVaccinationSecondDoseMonth,String covidVaccinationSecondDoseYear,
                                                    String covidVaccineName,String postVaccineDetails,String covidOccupation,String medicalSpeciality,String exactNatureOfDuties,
                                                    String nameOfHealthCareFacility,String addressOfHealthCareFacility,String healthAuthorityRegistered,String covidWardDetails,
                                                    String diagnoseDay,String diagnoseMonth,String diagnoseYear,String daignoseTestName,String receivedCovid19Test1,String receivedCovid19Test2,String receivedCovid19Test3,
                                                    String admissionDay,String admissionMonth,String admissionYear,String dischargeDay,String dischargeMonth,String dischargeYear,
                                                    String covidInfectionDetails,String covidSymptoms1,String covidSymptoms2,String covidSymptoms3,String recoveryDay,String recoveryMonth,String recoveryYear,String testsName,
                                                    String testTakenDay,String testTakenMonth,String testTakenYear,String certifiedDetails) throws Exception {

       /* new TestFactory().gotoRefusedPolicies(driver, username, password, policy, leadid, proposersame, propinsurednotsame, isnri, pmobile
                , ppan, imobile, ipan, firstname, lastname, middlename, day, month, year, gender, planjourney, proposerstate, advisorstatesame, plan, sumassured
                , smokertype, planoptions, increasinglevel, ecs, term, ppt, premiumterm, premiumamount, rider, rideramount, minrider, maxrider, ridererror, click, generateillustrations, clickcontinue, ifsccode
                , bankaccno, accholdername, accounttype, pennyalert, clickverify, renewpremiumscreentitle, paymentmethod, drawdate, fundsource, nomineescreentitle
                , nomineefirstname, nomineelastname, nomineeday, nomineemonth, nomineeyear, nomineegender, relationshipwithproposer, nomineeshare, ismwppolicy, addressscreentitle, typeofaddress
                , addresspincode, address1, address2, address3, personalDetailsscreentitle, cityName, preferredLanguage, alernateNumber, resTelephoneNumber, emailaddressValidations, maritalStatus, fathersNameOrSpouseName, mothersName, qualification, occupation
                , employeerName, nameOfBusinessOrduties, typeOfOrganization, designation, annualIncome, policyStatus, exPolicyscreenTitle, exNameofInsurer, exSumAssured, expolicyNumber, exyearOfApplication, exbasePlan, exannualpremium, expolicystatus
                , medicalPolicy, refPolicyScreentitle, reNameofInsurer, reSumAssured, refreason, policyPurposeScreen, purposeOption1, purposeOption2, purposeOption3);
*/

        waitUtils.waitForElementToBeVisible(driver, covid_19_Details_page.healthDetailsTitle);
        waitUtils.Asserting("equals", covid_19_Details_page.healthDetailsTitle.getText(),healthDetailsScreen);
        //commonUtils.scrollIntoView(covid_19_Details_page.moduleTitle,driver);
        commonUtils.clickElement(covid_19_Details_page.moduleTitle);
        waitUtils.waitForElementToBeVisible(driver, covid_19_Details_page.symptomsSection);
        covid_19_Details_page.gotoSection("Symptoms");
        covid_19_Details_page.setSymptomsDetials("Symptoms",symptomsDetails);
        waitUtils.waitForElementToBeVisible(driver, covid_19_Details_page.gotoSectionElement("Tests"));
        covid_19_Details_page.valueToBeEnterForTests("Tests",testsDetails);
        //  commonUtils.scrollIntoView("Covid Contact",driver);
        covid_19_Details_page.gotoSection("Covid Contact");
        covid_19_Details_page.valueToBeEnterForCovidContact("Covid Contact",covidContactDetails);
        covid_19_Details_page.gotoSection("Quarantine");
        covid_19_Details_page.textToBeEnter("Quarantine",quarantineDetails);
        covid_19_Details_page.gotoSection("Past Travel");
        covid_19_Details_page.setPastTravelCountry(pastTravelCountry);
        covid_19_Details_page.setPastTravelCity(pastTravelCity);
        covid_19_Details_page.dateOfArrialDay(pastTravelArrivalDay);
        covid_19_Details_page.dateOfArrivalMonth(pastTravelArraivalMonth);
        covid_19_Details_page.dateOfArrialYear(pastTravelArraivalYear);
        covid_19_Details_page.dateOfDepartureDay(pastTravelDepartureDay);
        covid_19_Details_page.departureMonth(pastTravelDepartureMonth);
        covid_19_Details_page.departureYear(pastTravelDepartureYear);
        commonUtils.selectButtonByName("SAVE",driver);

        //  commonUtils.scrollIntoView("Future travel",driver);
        covid_19_Details_page.gotoSectionElement("Future travel");
        commonUtils.scrollToElement(driver,covid_19_Details_page.futureTravelCountry);
        covid_19_Details_page.getFutureTravelCountry(futureTravelCountry);
        covid_19_Details_page.getFutureTravelCity(futureTravelCity);
        covid_19_Details_page.futureTravelDay(futureTravelDepartureDay);
        covid_19_Details_page.futureTravelMonth(futureTravelDepartureMonth);
        covid_19_Details_page.futureTravelYear(futureTravelDepartureYear);
        covid_19_Details_page.noOfDays(futureInternedDuration);
        commonUtils.selectButtonByName("SAVE",driver);
        //commonUtils.scrollIntoView("Covid Vaccination",driver);
        covid_19_Details_page.gotoSection("Covid Vaccination");
        covid_19_Details_page.vaccinationDay(covidVaccinationFirstDoseDay);
        covid_19_Details_page.vaccinationMonth(covidVaccinationFirstDoseMonth);
        covid_19_Details_page.vaccinationYear(covidVaccinationFirstDoseYear);
        covid_19_Details_page.vaccination2Day(covidVaccinationSecondDoseDay);
        covid_19_Details_page.vaccination2Month(covidVaccinationSecondDoseMonth);
        covid_19_Details_page.vaccination2Year(covidVaccinationSecondDoseYear);

        covid_19_Details_page.setVaccineName(covidVaccineName);
        covid_19_Details_page.postVaccinationExperienced.click();
        covid_19_Details_page.exOnPostVaccination(postVaccineDetails);
        commonUtils.selectButtonByName("SAVE",driver);
        covid_19_Details_page.postVaccinationExperienced.click();
        covid_19_Details_page.gotoSectionElement("For Health Workers Only");
        covid_19_Details_page.enterOccupation(covidOccupation);
        covid_19_Details_page.enterMedicalSpecialty(medicalSpeciality);
        covid_19_Details_page.exactnatureofduties(exactNatureOfDuties);
        covid_19_Details_page.nameofHealthcarefacility(nameOfHealthCareFacility);
        covid_19_Details_page.addressOfHealthcarefacility(addressOfHealthCareFacility);
        covid_19_Details_page.healthAuthorityyouareregisteredunder(healthAuthorityRegistered);

        covid_19_Details_page.getProvideDetails2.click();
        covid_19_Details_page.provideDetails2(covidWardDetails);
        //commonUtils.selectButtonByName("SAVE",driver);
        covid_19_Details_page.gotoSectionElement("Recovered from Covid19");
        covid_19_Details_page.recoveredDay(recoveryDay);
        covid_19_Details_page.recoveredMonth(recoveryMonth);
        covid_19_Details_page.recoveredYear(recoveryYear);

        //commonUtils.selectButtonByName("I don’t know",driver);

        covid_19_Details_page.covidTestOptionToBeSelect(receivedCovid19Test1);
        covid_19_Details_page.covidTestOptionToBeSelect(receivedCovid19Test2);
        covid_19_Details_page.covidTestOptionToBeSelect(receivedCovid19Test3);
        covid_19_Details_page.symptomsOptions(covidSymptoms1);
        covid_19_Details_page.symptomsOptions(covidSymptoms2);
        covid_19_Details_page.symptomsOptions(covidSymptoms3);

        covid_19_Details_page.recoveredFromCovidDay(recoveryDay);
        covid_19_Details_page.recoveredFromCovidMonth(recoveryMonth);
        covid_19_Details_page.recoveredFromCovidYear(recoveryYear);

        covid_19_Details_page.penddingAppointments.click();

        covid_19_Details_page.setCovidTestName(testsName);
        covid_19_Details_page.testTakenDay(testTakenDay);
        covid_19_Details_page.testTakenMonth(testTakenMonth);
        covid_19_Details_page.testTakenYear(testTakenYear);

        //commonUtils.selectButtonByName("SAVE",driver);

        covid_19_Details_page.returnToWorkCertified.click();
        covid_19_Details_page.returnToWorkCertifiedDetails(certifiedDetails);

        commonUtils.selectButtonByName("SAVE & CONTINUE",driver);

        waitUtils.wait5Seconds();

        waitUtils.Asserting("equals",covid_19_Details_page.reviewAndAcceptanceTitle.getText(),"9.0 Review & Acceptance");


    }
    @Test(dataProvider = "dataCovid19Provider", dataProviderClass = DataProviders.class, priority = 1)
    @Description("Test case description : verifing the covid symptoms")
    public void verify_covid_19_Details_Date_FieldsValidations(String username, String password, String policy, String leadid, String proposersame, String propinsurednotsame, String isnri, String pmobile, String ppan, String imobile,
                                                          String ipan, String firstname, String lastname,
                                                          String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame,
                                                          String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                                          String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                                          String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                                          String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                                          String clickverify, String renewpremiumscreentitle, String paymentmethod, String drawdate, String fundsource,
                                                          String nomineescreentitle, String nomineefirstname, String nomineelastname, String nomineeday,
                                                          String nomineemonth, String nomineeyear, String nomineegender, String relationshipwithproposer, String nomineeshare,
                                                          String ismwppolicy, String addressscreentitle, String typeofaddress, String addresspincode, String address1, String address2, String address3,
                                                          String personalDetailsscreentitle, String cityName, String preferredLanguage, String alernateNumber, String resTelephoneNumber, String emailaddressValidations,
                                                          String maritalStatus, String fathersNameOrSpouseName,
                                                          String mothersName, String qualification, String occupation, String employeerName, String nameOfBusinessOrduties,
                                                          String typeOfOrganization, String designation, String annualIncome, String policyStatus, String exPolicyscreenTitle, String exNameofInsurer, String exSumAssured,
                                                          String expolicyNumber, String exyearOfApplication, String exbasePlan, String exannualpremium, String expolicystatus, String medicalPolicy, String refPolicyScreentitle,
                                                          String reNameofInsurer, String reSumAssured, String refreason,
                                                          String insurerName1, String sumAssured1, String reason1,
                                                          String insurerName2, String sumAssured2, String reason2,
                                                          String insurerName3, String sumAssured3, String reason3,
                                                          String insurerName4, String sumAssured4, String reason4, String policyPurposeScreen,
                                                          String purposeOption1, String purposeOption2, String purposeOption3,String healthDetailsScreen,
                                                          String symptomsDetails,String testsDetails,String covidContactDetails,String quarantineDetails,String healthDetails,String pastTravelContry,
                                                          String pastTravelCity,String pastTravelArrivalDay,String pastTravelArraivalMonth,String pastTravelArraivalYear,String pastTravelDepartureDay,
                                                          String pastTravelDepartureMonth,String pastTravelDepartureYear,String futureTravelCountry,
                                                          String futureTravelCity,String futureTravelDepartureDay,String futureTravelDepartureMonth,String futureTravelDepartureYear,String futureInternedDuration,
                                                          String covidVaccinationFirstDoseDay,String covidVaccinationFirstDoseMonth,String covidVaccinationFirstDoseYear,
                                                          String covidVaccinationSecondDoseDay,String covidVaccinationSecondDoseMonth,String covidVaccinationSecondDoseYear,
                                                          String covidVaccineName,String postVaccineDetails,String covidOccupation,String medicalSpeciality,String exactNatureOfDuties,
                                                          String nameOfHealthCareFacility,String addressOfHealthCareFacility,String healthAuthorityRegistered,String covidWardDetails,
                                                          String diagnoseDay,String diagnoseMonth,String diagnoseYear,String daignoseTestName,String receivedCovid19Test1,String receivedCovid19Test2,String receivedCovid19Test3,
                                                          String admissionDay,String admissionMonth,String admissionYear,String dischargeDay,String dischargeMonth,String dischargeYear,
                                                          String covidInfectionDetails,String covidSymptoms1,String covidSymptoms2,String covidSymptoms3,String recoveryDay,String recoveryMonth,String recoveryYear,String testsName,
                                                          String testTakenDay,String testTakenMonth,String testTakenYear,String certifiedDetails) throws Exception {
/*

        new TestFactory().gotoRefusedPolicies(driver, username, password, policy, leadid, proposersame, propinsurednotsame, isnri, pmobile
                , ppan, imobile, ipan, firstname, lastname, middlename, day, month, year, gender, planjourney, proposerstate, advisorstatesame, plan, sumassured
                , smokertype, planoptions, increasinglevel, ecs, term, ppt, premiumterm, premiumamount, rider, rideramount, minrider, maxrider, ridererror, click, generateillustrations, clickcontinue, ifsccode
                , bankaccno, accholdername, accounttype, pennyalert, clickverify, renewpremiumscreentitle, paymentmethod, drawdate, fundsource, nomineescreentitle
                , nomineefirstname, nomineelastname, nomineeday, nomineemonth, nomineeyear, nomineegender, relationshipwithproposer, nomineeshare, ismwppolicy, addressscreentitle, typeofaddress
                , addresspincode, address1, address2, address3, personalDetailsscreentitle, cityName, preferredLanguage, alernateNumber, resTelephoneNumber, emailaddressValidations, maritalStatus, fathersNameOrSpouseName, mothersName, qualification, occupation
                , employeerName, nameOfBusinessOrduties, typeOfOrganization, designation, annualIncome, policyStatus, exPolicyscreenTitle, exNameofInsurer, exSumAssured, expolicyNumber, exyearOfApplication, exbasePlan, exannualpremium, expolicystatus
                , medicalPolicy, refPolicyScreentitle, reNameofInsurer, reSumAssured, refreason, policyPurposeScreen, purposeOption1, purposeOption2, purposeOption3);

*/

        waitUtils.waitForElementToBeVisible(driver, covid_19_Details_page.healthDetailsTitle);
        waitUtils.Asserting("equals", covid_19_Details_page.healthDetailsTitle.getText(),healthDetailsScreen);
        //commonUtils.scrollIntoView(covid_19_Details_page.moduleTitle,driver);
        commonUtils.clickElement(covid_19_Details_page.moduleTitle);
        waitUtils.waitForElementToBeVisible(driver, covid_19_Details_page.symptomsSection);
        covid_19_Details_page.gotoSection("Symptoms");
        covid_19_Details_page.setSymptomsDetials("Symptoms",symptomsDetails);
        waitUtils.waitForElementToBeVisible(driver, covid_19_Details_page.gotoSectionElement("Tests"));
        covid_19_Details_page.valueToBeEnterForTests("Tests",testsDetails);
        //  commonUtils.scrollIntoView("Covid Contact",driver);
        covid_19_Details_page.gotoSection("Covid Contact");
        covid_19_Details_page.valueToBeEnterForCovidContact("Covid Contact",covidContactDetails);
        covid_19_Details_page.gotoSection("Quarantine");
        covid_19_Details_page.textToBeEnter("Quarantine",quarantineDetails);
        covid_19_Details_page.gotoSection("Past Travel");
        covid_19_Details_page.setPastTravelCountry(pastTravelContry);
        covid_19_Details_page.setPastTravelCity(pastTravelCity);
        covid_19_Details_page.dateOfArrialDay(pastTravelArrivalDay);
        covid_19_Details_page.dateOfArrivalMonth(pastTravelArraivalMonth);
        covid_19_Details_page.dateOfArrialYear(pastTravelArraivalYear);
        covid_19_Details_page.dateOfDepartureDay(pastTravelDepartureDay);
        covid_19_Details_page.departureMonth(pastTravelDepartureMonth);
        covid_19_Details_page.departureYear(pastTravelDepartureYear);
        commonUtils.selectButtonByName("SAVE",driver);

        //  commonUtils.scrollIntoView("Future travel",driver);
        covid_19_Details_page.gotoSectionElement("Future travel");
        commonUtils.scrollToElement(driver,covid_19_Details_page.futureTravelCountry);
        covid_19_Details_page.getFutureTravelCountry(futureTravelCountry);
        covid_19_Details_page.getFutureTravelCity(futureTravelCity);
        covid_19_Details_page.futureTravelDay(futureTravelDepartureDay);
        covid_19_Details_page.futureTravelMonth(futureTravelDepartureMonth);
        covid_19_Details_page.futureTravelYear(futureTravelDepartureYear);
        covid_19_Details_page.noOfDays(futureInternedDuration);
        commonUtils.selectButtonByName("SAVE",driver);
        //commonUtils.scrollIntoView("Covid Vaccination",driver);
        covid_19_Details_page.gotoSection("Covid Vaccination");
        covid_19_Details_page.vaccinationDay(covidVaccinationFirstDoseDay);
        covid_19_Details_page.vaccinationMonth(covidVaccinationFirstDoseMonth);
        covid_19_Details_page.vaccinationYear(covidVaccinationFirstDoseYear);
        covid_19_Details_page.vaccination2Day(covidVaccinationSecondDoseDay);
        covid_19_Details_page.vaccination2Month(covidVaccinationSecondDoseMonth);
        covid_19_Details_page.vaccination2Year(covidVaccinationSecondDoseYear);

        covid_19_Details_page.setVaccineName(covidVaccineName);
        covid_19_Details_page.postVaccinationExperienced.click();
        covid_19_Details_page.exOnPostVaccination(postVaccineDetails);
        commonUtils.selectButtonByName("SAVE",driver);
        covid_19_Details_page.postVaccinationExperienced.click();
        covid_19_Details_page.gotoSectionElement("For Health Workers Only");
        covid_19_Details_page.enterOccupation(covidOccupation);
        covid_19_Details_page.enterMedicalSpecialty(medicalSpeciality);
        covid_19_Details_page.exactnatureofduties(exactNatureOfDuties);
        covid_19_Details_page.nameofHealthcarefacility(nameOfHealthCareFacility);
        covid_19_Details_page.addressOfHealthcarefacility(addressOfHealthCareFacility);
        covid_19_Details_page.healthAuthorityyouareregisteredunder(healthAuthorityRegistered);

        covid_19_Details_page.getProvideDetails2.click();
        covid_19_Details_page.provideDetails2(covidWardDetails);
        //commonUtils.selectButtonByName("SAVE",driver);
        covid_19_Details_page.gotoSectionElement("Recovered from Covid19");
        covid_19_Details_page.recoveredDay(recoveryDay);
        covid_19_Details_page.recoveredMonth(recoveryMonth);
        covid_19_Details_page.recoveredYear(recoveryYear);

        //commonUtils.selectButtonByName("I don’t know",driver);

        covid_19_Details_page.covidTestOptionToBeSelect(receivedCovid19Test1);
        covid_19_Details_page.covidTestOptionToBeSelect(receivedCovid19Test2);
        covid_19_Details_page.covidTestOptionToBeSelect(receivedCovid19Test3);
        covid_19_Details_page.symptomsOptions(covidSymptoms1);
        covid_19_Details_page.symptomsOptions(covidSymptoms2);
        covid_19_Details_page.symptomsOptions(covidSymptoms3);

        covid_19_Details_page.recoveredFromCovidDay(recoveryDay);
        covid_19_Details_page.recoveredFromCovidMonth(recoveryMonth);
        covid_19_Details_page.recoveredFromCovidYear(recoveryYear);

        covid_19_Details_page.penddingAppointments.click();

        covid_19_Details_page.setCovidTestName(testsName);
        covid_19_Details_page.testTakenDay(testTakenDay);
        covid_19_Details_page.testTakenMonth(testTakenMonth);
        covid_19_Details_page.testTakenYear(testTakenYear);

        //commonUtils.selectButtonByName("SAVE",driver);

        covid_19_Details_page.returnToWorkCertified.click();
        covid_19_Details_page.returnToWorkCertifiedDetails(certifiedDetails);

        commonUtils.selectButtonByName("SAVE & CONTINUE",driver);

        waitUtils.wait5Seconds();

        waitUtils.Asserting("equals",covid_19_Details_page.reviewAndAcceptanceTitle.getText(),"9.0 Review & Acceptance");


        covid_19_Details_page.returnToWorkCertified.click();
        covid_19_Details_page.returnToWorkCertifiedDetails("returnToWorkCertified");

        commonUtils.selectButtonByName("SAVE",driver);


    }
    @Test(dataProvider = "dataCovid19Provider", dataProviderClass = DataProviders.class, priority = 1)
    @Description("Test case description : verifing the covid symptoms")
    public void verify_covid_19_Details_textFields_Validations(String username, String password, String policy, String leadid, String proposersame, String propinsurednotsame, String isnri, String pmobile, String ppan, String imobile,
                                                           String ipan, String firstname, String lastname,
                                                           String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame,
                                                           String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                                           String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                                           String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                                           String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                                           String clickverify, String renewpremiumscreentitle, String paymentmethod, String drawdate, String fundsource,
                                                           String nomineescreentitle, String nomineefirstname, String nomineelastname, String nomineeday,
                                                           String nomineemonth, String nomineeyear, String nomineegender, String relationshipwithproposer, String nomineeshare,
                                                           String ismwppolicy, String addressscreentitle, String typeofaddress, String addresspincode, String address1, String address2, String address3,
                                                           String personalDetailsscreentitle, String cityName, String preferredLanguage, String alernateNumber, String resTelephoneNumber, String emailaddressValidations,
                                                           String maritalStatus, String fathersNameOrSpouseName,
                                                           String mothersName, String qualification, String occupation, String employeerName, String nameOfBusinessOrduties,
                                                           String typeOfOrganization, String designation, String annualIncome, String policyStatus, String exPolicyscreenTitle, String exNameofInsurer, String exSumAssured,
                                                           String expolicyNumber, String exyearOfApplication, String exbasePlan, String exannualpremium, String expolicystatus, String medicalPolicy, String refPolicyScreentitle,
                                                           String reNameofInsurer, String reSumAssured, String refreason,
                                                           String insurerName1, String sumAssured1, String reason1,
                                                           String insurerName2, String sumAssured2, String reason2,
                                                           String insurerName3, String sumAssured3, String reason3,
                                                           String insurerName4, String sumAssured4, String reason4, String policyPurposeScreen,
                                                           String purposeOption1, String purposeOption2, String purposeOption3,String healthDetailsScreen,
                                                           String symptomsDetails,String testsDetails,String covidContactDetails,String quarantineDetails,String healthDetails,String pastTravelContry,
                                                           String pastTravelCity,String pastTravelArrivalDay,String pastTravelArraivalMonth,String pastTravelArraivalYear,String pastTravelDepartureDay,
                                                           String pastTravelDepartureMonth,String pastTravelDepartureYear,String futureTravelCountry,
                                                           String futureTravelCity,String futureTravelDepartureDay,String futureTravelDepartureMonth,String futureTravelDepartureYear,String futureInternedDuration,
                                                           String covidVaccinationFirstDoseDay,String covidVaccinationFirstDoseMonth,String covidVaccinationFirstDoseYear,
                                                           String covidVaccinationSecondDoseDay,String covidVaccinationSecondDoseMonth,String covidVaccinationSecondDoseYear,
                                                           String covidVaccineName,String postVaccineDetails,String covidOccupation,String medicalSpeciality,String exactNatureOfDuties,
                                                           String nameOfHealthCareFacility,String addressOfHealthCareFacility,String healthAuthorityRegistered,String covidWardDetails,
                                                           String diagnoseDay,String diagnoseMonth,String diagnoseYear,String daignoseTestName,String receivedCovid19Test1,String receivedCovid19Test2,String receivedCovid19Test3,
                                                           String admissionDay,String admissionMonth,String admissionYear,String dischargeDay,String dischargeMonth,String dischargeYear,
                                                           String covidInfectionDetails,String covidSymptoms1,String covidSymptoms2,String covidSymptoms3,String recoveryDay,String recoveryMonth,String recoveryYear,String testsName,
                                                           String testTakenDay,String testTakenMonth,String testTakenYear,String certifiedDetails) throws Exception {

     /*   new TestFactory().gotoRefusedPolicies(driver, username, password, policy, leadid, proposersame, propinsurednotsame, isnri, pmobile
                , ppan, imobile, ipan, firstname, lastname, middlename, day, month, year, gender, planjourney, proposerstate, advisorstatesame, plan, sumassured
                , smokertype, planoptions, increasinglevel, ecs, term, ppt, premiumterm, premiumamount, rider, rideramount, minrider, maxrider, ridererror, click, generateillustrations, clickcontinue, ifsccode
                , bankaccno, accholdername, accounttype, pennyalert, clickverify, renewpremiumscreentitle, paymentmethod, drawdate, fundsource, nomineescreentitle
                , nomineefirstname, nomineelastname, nomineeday, nomineemonth, nomineeyear, nomineegender, relationshipwithproposer, nomineeshare, ismwppolicy, addressscreentitle, typeofaddress
                , addresspincode, address1, address2, address3, personalDetailsscreentitle, cityName, preferredLanguage, alernateNumber, resTelephoneNumber, emailaddressValidations, maritalStatus, fathersNameOrSpouseName, mothersName, qualification, occupation
                , employeerName, nameOfBusinessOrduties, typeOfOrganization, designation, annualIncome, policyStatus, exPolicyscreenTitle, exNameofInsurer, exSumAssured, expolicyNumber, exyearOfApplication, exbasePlan, exannualpremium, expolicystatus
                , medicalPolicy, refPolicyScreentitle, reNameofInsurer, reSumAssured, refreason, policyPurposeScreen, purposeOption1, purposeOption2, purposeOption3);
*/
        waitUtils.waitForElementToBeVisible(driver, covid_19_Details_page.healthDetailsTitle);
        waitUtils.Asserting("equals", covid_19_Details_page.healthDetailsTitle.getText(),healthDetailsScreen);
        //commonUtils.scrollIntoView(covid_19_Details_page.moduleTitle,driver);
        commonUtils.clickElement(covid_19_Details_page.moduleTitle);
        waitUtils.waitForElementToBeVisible(driver, covid_19_Details_page.symptomsSection);
        covid_19_Details_page.gotoSection("Symptoms");
        covid_19_Details_page.setSymptomsDetials("Symptoms",symptomsDetails);
        waitUtils.waitForElementToBeVisible(driver, covid_19_Details_page.gotoSectionElement("Tests"));
        covid_19_Details_page.valueToBeEnterForTests("Tests",testsDetails);
        //  commonUtils.scrollIntoView("Covid Contact",driver);
        covid_19_Details_page.gotoSection("Covid Contact");
        covid_19_Details_page.valueToBeEnterForCovidContact("Covid Contact",covidContactDetails);
        covid_19_Details_page.gotoSection("Quarantine");
        covid_19_Details_page.textToBeEnter("Quarantine",quarantineDetails);
        covid_19_Details_page.gotoSection("Past Travel");
        covid_19_Details_page.setPastTravelCountry(pastTravelContry);
        covid_19_Details_page.setPastTravelCity(pastTravelCity);
        covid_19_Details_page.dateOfArrialDay(pastTravelArrivalDay);
        covid_19_Details_page.dateOfArrivalMonth(pastTravelArraivalMonth);
        covid_19_Details_page.dateOfArrialYear(pastTravelArraivalYear);
        covid_19_Details_page.dateOfDepartureDay(pastTravelDepartureDay);
        covid_19_Details_page.departureMonth(pastTravelDepartureMonth);
        covid_19_Details_page.departureYear(pastTravelDepartureYear);
        commonUtils.selectButtonByName("SAVE",driver);

        //  commonUtils.scrollIntoView("Future travel",driver);
        covid_19_Details_page.gotoSectionElement("Future travel");
        commonUtils.scrollToElement(driver,covid_19_Details_page.futureTravelCountry);
        covid_19_Details_page.getFutureTravelCountry(futureTravelCountry);
        covid_19_Details_page.getFutureTravelCity(futureTravelCity);
        covid_19_Details_page.futureTravelDay(futureTravelDepartureDay);
        covid_19_Details_page.futureTravelMonth(futureTravelDepartureMonth);
        covid_19_Details_page.futureTravelYear(futureTravelDepartureYear);
        covid_19_Details_page.noOfDays(futureInternedDuration);
        commonUtils.selectButtonByName("SAVE",driver);
        //commonUtils.scrollIntoView("Covid Vaccination",driver);
        covid_19_Details_page.gotoSection("Covid Vaccination");
        covid_19_Details_page.vaccinationDay(covidVaccinationFirstDoseDay);
        covid_19_Details_page.vaccinationMonth(covidVaccinationFirstDoseMonth);
        covid_19_Details_page.vaccinationYear(covidVaccinationFirstDoseYear);
        covid_19_Details_page.vaccination2Day(covidVaccinationSecondDoseDay);
        covid_19_Details_page.vaccination2Month(covidVaccinationSecondDoseMonth);
        covid_19_Details_page.vaccination2Year(covidVaccinationSecondDoseYear);

        covid_19_Details_page.setVaccineName(covidVaccineName);
        covid_19_Details_page.postVaccinationExperienced.click();
        covid_19_Details_page.exOnPostVaccination(postVaccineDetails);
        commonUtils.selectButtonByName("SAVE",driver);
        covid_19_Details_page.postVaccinationExperienced.click();
        covid_19_Details_page.gotoSectionElement("For Health Workers Only");
        covid_19_Details_page.enterOccupation(covidOccupation);
        covid_19_Details_page.enterMedicalSpecialty(medicalSpeciality);
        covid_19_Details_page.exactnatureofduties(exactNatureOfDuties);
        covid_19_Details_page.nameofHealthcarefacility(nameOfHealthCareFacility);
        covid_19_Details_page.addressOfHealthcarefacility(addressOfHealthCareFacility);
        covid_19_Details_page.healthAuthorityyouareregisteredunder(healthAuthorityRegistered);

        covid_19_Details_page.getProvideDetails2.click();
        covid_19_Details_page.provideDetails2(covidWardDetails);
        //commonUtils.selectButtonByName("SAVE",driver);
        covid_19_Details_page.gotoSectionElement("Recovered from Covid19");
        covid_19_Details_page.recoveredDay(recoveryDay);
        covid_19_Details_page.recoveredMonth(recoveryMonth);
        covid_19_Details_page.recoveredYear(recoveryYear);

        //commonUtils.selectButtonByName("I don’t know",driver);

        covid_19_Details_page.covidTestOptionToBeSelect(receivedCovid19Test1);
        covid_19_Details_page.covidTestOptionToBeSelect(receivedCovid19Test2);
        covid_19_Details_page.covidTestOptionToBeSelect(receivedCovid19Test3);
        covid_19_Details_page.symptomsOptions(covidSymptoms1);
        covid_19_Details_page.symptomsOptions(covidSymptoms2);
        covid_19_Details_page.symptomsOptions(covidSymptoms3);

        covid_19_Details_page.recoveredFromCovidDay(recoveryDay);
        covid_19_Details_page.recoveredFromCovidMonth(recoveryMonth);
        covid_19_Details_page.recoveredFromCovidYear(recoveryYear);

        covid_19_Details_page.penddingAppointments.click();

        covid_19_Details_page.setCovidTestName(testsName);
        covid_19_Details_page.testTakenDay(testTakenDay);
        covid_19_Details_page.testTakenMonth(testTakenMonth);
        covid_19_Details_page.testTakenYear(testTakenYear);

        //commonUtils.selectButtonByName("SAVE",driver);

        covid_19_Details_page.returnToWorkCertified.click();
        covid_19_Details_page.returnToWorkCertifiedDetails(certifiedDetails);

        commonUtils.selectButtonByName("SAVE & CONTINUE",driver);

        waitUtils.wait5Seconds();

        waitUtils.Asserting("equals",covid_19_Details_page.reviewAndAcceptanceTitle.getText(),"9.0 Review & Acceptance");



    }
    @Test(dataProvider = "dataCovid19Provider", dataProviderClass = DataProviders.class, priority = 1)
    @Description("Test case description : verifing the covid symptoms")
    public void verify_covid_19_Details_Morethan100Characters(String username, String password, String policy, String leadid, String proposersame, String propinsurednotsame, String isnri, String pmobile, String ppan, String imobile,
                                                              String ipan, String firstname, String lastname,
                                                              String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame,
                                                              String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                                              String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                                              String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                                              String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                                              String clickverify, String renewpremiumscreentitle, String paymentmethod, String drawdate, String fundsource,
                                                              String nomineescreentitle, String nomineefirstname, String nomineelastname, String nomineeday,
                                                              String nomineemonth, String nomineeyear, String nomineegender, String relationshipwithproposer, String nomineeshare,
                                                              String ismwppolicy, String addressscreentitle, String typeofaddress, String addresspincode, String address1, String address2, String address3,
                                                              String personalDetailsscreentitle, String cityName, String preferredLanguage, String alernateNumber, String resTelephoneNumber, String emailaddressValidations,
                                                              String maritalStatus, String fathersNameOrSpouseName,
                                                              String mothersName, String qualification, String occupation, String employeerName, String nameOfBusinessOrduties,
                                                              String typeOfOrganization, String designation, String annualIncome, String policyStatus, String exPolicyscreenTitle, String exNameofInsurer, String exSumAssured,
                                                              String expolicyNumber, String exyearOfApplication, String exbasePlan, String exannualpremium, String expolicystatus, String medicalPolicy, String refPolicyScreentitle,
                                                              String reNameofInsurer, String reSumAssured, String refreason,
                                                              String insurerName1, String sumAssured1, String reason1,
                                                              String insurerName2, String sumAssured2, String reason2,
                                                              String insurerName3, String sumAssured3, String reason3,
                                                              String insurerName4, String sumAssured4, String reason4, String policyPurposeScreen,
                                                              String purposeOption1, String purposeOption2, String purposeOption3,String healthDetailsScreen,
                                                              String symptomsDetails,String testsDetails,String covidContactDetails,String quarantineDetails,String healthDetails,String pastTravelContry,
                                                              String pastTravelCity,String pastTravelArrivalDay,String pastTravelArraivalMonth,String pastTravelArraivalYear,String pastTravelDepartureDay,
                                                              String pastTravelDepartureMonth,String pastTravelDepartureYear,String futureTravelCountry,
                                                              String futureTravelCity,String futureTravelDepartureDay,String futureTravelDepartureMonth,String futureTravelDepartureYear,String futureInternedDuration,
                                                              String covidVaccinationFirstDoseDay,String covidVaccinationFirstDoseMonth,String covidVaccinationFirstDoseYear,
                                                              String covidVaccinationSecondDoseDay,String covidVaccinationSecondDoseMonth,String covidVaccinationSecondDoseYear,
                                                              String covidVaccineName,String postVaccineDetails,String covidOccupation,String medicalSpeciality,String exactNatureOfDuties,
                                                              String nameOfHealthCareFacility,String addressOfHealthCareFacility,String healthAuthorityRegistered,String covidWardDetails,
                                                              String diagnoseDay,String diagnoseMonth,String diagnoseYear,String daignoseTestName,String receivedCovid19Test1,String receivedCovid19Test2,String receivedCovid19Test3,
                                                              String admissionDay,String admissionMonth,String admissionYear,String dischargeDay,String dischargeMonth,String dischargeYear,
                                                              String covidInfectionDetails,String covidSymptoms1,String covidSymptoms2,String covidSymptoms3,String recoveryDay,String recoveryMonth,String recoveryYear,String testsName,
                                                              String testTakenDay,String testTakenMonth,String testTakenYear,String certifiedDetails) throws Exception {

       /* new TestFactory().gotoRefusedPolicies(driver, username, password, policy, leadid, proposersame, propinsurednotsame, isnri, pmobile
                , ppan, imobile, ipan, firstname, lastname, middlename, day, month, year, gender, planjourney, proposerstate, advisorstatesame, plan, sumassured
                , smokertype, planoptions, increasinglevel, ecs, term, ppt, premiumterm, premiumamount, rider, rideramount, minrider, maxrider, ridererror, click, generateillustrations, clickcontinue, ifsccode
                , bankaccno, accholdername, accounttype, pennyalert, clickverify, renewpremiumscreentitle, paymentmethod, drawdate, fundsource, nomineescreentitle
                , nomineefirstname, nomineelastname, nomineeday, nomineemonth, nomineeyear, nomineegender, relationshipwithproposer, nomineeshare, ismwppolicy, addressscreentitle, typeofaddress
                , addresspincode, address1, address2, address3, personalDetailsscreentitle, cityName, preferredLanguage, alernateNumber, resTelephoneNumber, emailaddressValidations, maritalStatus, fathersNameOrSpouseName, mothersName, qualification, occupation
                , employeerName, nameOfBusinessOrduties, typeOfOrganization, designation, annualIncome, policyStatus, exPolicyscreenTitle, exNameofInsurer, exSumAssured, expolicyNumber, exyearOfApplication, exbasePlan, exannualpremium, expolicystatus
                , medicalPolicy, refPolicyScreentitle, reNameofInsurer, reSumAssured, refreason, policyPurposeScreen, purposeOption1, purposeOption2, purposeOption3);


*/ waitUtils.waitForElementToBeVisible(driver, covid_19_Details_page.healthDetailsTitle);
        waitUtils.Asserting("equals", covid_19_Details_page.healthDetailsTitle.getText(),healthDetailsScreen);
        //commonUtils.scrollIntoView(covid_19_Details_page.moduleTitle,driver);
        commonUtils.clickElement(covid_19_Details_page.moduleTitle);
        waitUtils.waitForElementToBeVisible(driver, covid_19_Details_page.symptomsSection);
        covid_19_Details_page.gotoSection("Symptoms");
        covid_19_Details_page.setSymptomsDetials("Symptoms",symptomsDetails);
        waitUtils.waitForElementToBeVisible(driver, covid_19_Details_page.gotoSectionElement("Tests"));
        covid_19_Details_page.valueToBeEnterForTests("Tests",testsDetails);
        //  commonUtils.scrollIntoView("Covid Contact",driver);
        covid_19_Details_page.gotoSection("Covid Contact");
        covid_19_Details_page.valueToBeEnterForCovidContact("Covid Contact",covidContactDetails);
        covid_19_Details_page.gotoSection("Quarantine");
        covid_19_Details_page.textToBeEnter("Quarantine",quarantineDetails);
        covid_19_Details_page.gotoSection("Past Travel");
        covid_19_Details_page.setPastTravelCountry(pastTravelContry);
        covid_19_Details_page.setPastTravelCity(pastTravelCity);
        covid_19_Details_page.dateOfArrialDay(pastTravelArrivalDay);
        covid_19_Details_page.dateOfArrivalMonth(pastTravelArraivalMonth);
        covid_19_Details_page.dateOfArrialYear(pastTravelArraivalYear);
        covid_19_Details_page.dateOfDepartureDay(pastTravelDepartureDay);
        covid_19_Details_page.departureMonth(pastTravelDepartureMonth);
        covid_19_Details_page.departureYear(pastTravelDepartureYear);
        commonUtils.selectButtonByName("SAVE",driver);

        //  commonUtils.scrollIntoView("Future travel",driver);
        covid_19_Details_page.gotoSectionElement("Future travel");
        commonUtils.scrollToElement(driver,covid_19_Details_page.futureTravelCountry);
        covid_19_Details_page.getFutureTravelCountry(futureTravelCountry);
        covid_19_Details_page.getFutureTravelCity(futureTravelCity);
        covid_19_Details_page.futureTravelDay(futureTravelDepartureDay);
        covid_19_Details_page.futureTravelMonth(futureTravelDepartureMonth);
        covid_19_Details_page.futureTravelYear(futureTravelDepartureYear);
        covid_19_Details_page.noOfDays(futureInternedDuration);
        commonUtils.selectButtonByName("SAVE",driver);
        //commonUtils.scrollIntoView("Covid Vaccination",driver);
        covid_19_Details_page.gotoSection("Covid Vaccination");
        covid_19_Details_page.vaccinationDay(covidVaccinationFirstDoseDay);
        covid_19_Details_page.vaccinationMonth(covidVaccinationFirstDoseMonth);
        covid_19_Details_page.vaccinationYear(covidVaccinationFirstDoseYear);
        covid_19_Details_page.vaccination2Day(covidVaccinationSecondDoseDay);
        covid_19_Details_page.vaccination2Month(covidVaccinationSecondDoseMonth);
        covid_19_Details_page.vaccination2Year(covidVaccinationSecondDoseYear);

        covid_19_Details_page.setVaccineName(covidVaccineName);
        covid_19_Details_page.postVaccinationExperienced.click();
        covid_19_Details_page.exOnPostVaccination(postVaccineDetails);
        commonUtils.selectButtonByName("SAVE",driver);
        covid_19_Details_page.postVaccinationExperienced.click();
        covid_19_Details_page.gotoSectionElement("For Health Workers Only");
        covid_19_Details_page.enterOccupation(covidOccupation);
        covid_19_Details_page.enterMedicalSpecialty(medicalSpeciality);
        covid_19_Details_page.exactnatureofduties(exactNatureOfDuties);
        covid_19_Details_page.nameofHealthcarefacility(nameOfHealthCareFacility);
        covid_19_Details_page.addressOfHealthcarefacility(addressOfHealthCareFacility);
        covid_19_Details_page.healthAuthorityyouareregisteredunder(healthAuthorityRegistered);

        covid_19_Details_page.getProvideDetails2.click();
        covid_19_Details_page.provideDetails2(covidWardDetails);
        //commonUtils.selectButtonByName("SAVE",driver);
        covid_19_Details_page.gotoSectionElement("Recovered from Covid19");
        covid_19_Details_page.recoveredDay(recoveryDay);
        covid_19_Details_page.recoveredMonth(recoveryMonth);
        covid_19_Details_page.recoveredYear(recoveryYear);

        //commonUtils.selectButtonByName("I don’t know",driver);

        covid_19_Details_page.covidTestOptionToBeSelect(receivedCovid19Test1);
        covid_19_Details_page.covidTestOptionToBeSelect(receivedCovid19Test2);
        covid_19_Details_page.covidTestOptionToBeSelect(receivedCovid19Test3);
        covid_19_Details_page.symptomsOptions(covidSymptoms1);
        covid_19_Details_page.symptomsOptions(covidSymptoms2);
        covid_19_Details_page.symptomsOptions(covidSymptoms3);

        covid_19_Details_page.recoveredFromCovidDay(recoveryDay);
        covid_19_Details_page.recoveredFromCovidMonth(recoveryMonth);
        covid_19_Details_page.recoveredFromCovidYear(recoveryYear);

        covid_19_Details_page.penddingAppointments.click();

        covid_19_Details_page.setCovidTestName(testsName);
        covid_19_Details_page.testTakenDay(testTakenDay);
        covid_19_Details_page.testTakenMonth(testTakenMonth);
        covid_19_Details_page.testTakenYear(testTakenYear);

        //commonUtils.selectButtonByName("SAVE",driver);

        covid_19_Details_page.returnToWorkCertified.click();
        covid_19_Details_page.returnToWorkCertifiedDetails(certifiedDetails);

        commonUtils.selectButtonByName("SAVE & CONTINUE",driver);

        waitUtils.wait5Seconds();

        waitUtils.Asserting("equals",covid_19_Details_page.reviewAndAcceptanceTitle.getText(),"9.0 Review & Acceptance");


    }
}
