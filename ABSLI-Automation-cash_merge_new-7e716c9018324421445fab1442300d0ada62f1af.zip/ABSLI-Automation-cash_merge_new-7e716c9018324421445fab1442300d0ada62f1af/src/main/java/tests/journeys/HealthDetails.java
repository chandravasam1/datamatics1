package tests.journeys;

import com.absli.helpers.dataProviders.DataProviders;
import com.absli.helpers.jsonReaders.ReadJson;
import com.absli.listeners.RetryAnalyzer;
import com.absli.listeners.TestLevelDriverCreator;
import com.absli.pageObjects.CreateApplPage;
import com.absli.pageObjects.HealthDetailsPage;
import com.absli.pageObjects.LifestylePage;
import com.absli.pageObjects.SignInPage;
import com.absli.utils.CommonUtils;
import com.absli.utils.PropertiesUtils;
import com.absli.utils.WaitUtils;
import io.qameta.allure.Description;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import tests.BaseTest;
import tests.TestFactory;

import java.io.IOException;

public class HealthDetails extends BaseTest {
    ReadJson jsonObj;
    CreateApplPage createApplPage;
    CommonUtils commonUtils;
    WaitUtils waitUtils;
    PropertiesUtils prop;
    SignInPage signIn;
    HealthDetailsPage healthDetailsPage;
    LifestylePage lifestylePage;

    @BeforeClass
    public void preSetup() throws IOException, InterruptedException {
        driver = new TestLevelDriverCreator().getDriver();
        commonUtils = new CommonUtils();
        waitUtils = new WaitUtils();
        prop = new PropertiesUtils();
        healthDetailsPage = new HealthDetailsPage(driver);
        lifestylePage = new LifestylePage(driver);
    }

    @BeforeMethod
    public void relaunch()  {
        new BaseTest().relaunch();
    }

    @Test(dataProvider = "dataHealthDetailsProvider",dataProviderClass = DataProviders.class,priority = 1,retryAnalyzer = RetryAnalyzer.class)
    @Description("Health details Validation")
    public void Health_Details_Validation(String username, String password, String policy, String leadid, String proposersame,
                                         String relationwithinsured,String isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                         String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                         String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                         String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                         String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                         String clickverify, String renewpremiumscreentitle, String paymentmethod, String drawdate, String fundsource,
                                         String nomineescreentitle, String nomineefirstname, String nomineelastname, String nomineeday,
                                         String nomineemonth, String nomineeyear, String nomineegender, String relationshipwithproposer, String nomineeshare,
                                         String ismwppolicy,
                                         String addressscreentitle, String typeofaddress, String addresspincode, String address1, String address2, String address3,
                                         String personalDetailsscreentitle, String cityName, String preferredLanguage, String alernateNumber, String resTelephoneNumber,
                                         String PersonalEmailId,String PersonalMaritalStatus, String FatherSpouseName,String MotherName, String MaidenName,String Qualification,String Others, String Occupation, String typeOfOccupation, String NameofEmployer, String Designation, String AnnualIncome,
                                         String SpouseAnnualIncome ,String ParentInsuranceCover, String ParentAnnualIncome, String SpouseInsuranceCover, String NarcoticsDetails,String AlcoholQuantity, String Frequency, String NicotineDuration,
                                         String TobaccoQuantityConsumed,String TobaccoYrsConsumed,String HazardousActivitiesOption,String HazardousActivitiesYrs,String HazardousActivitiesType ) throws Exception {

        new TestFactory().gotoHealthDetails(driver, username,  password,  policy,  leadid,  proposersame,
                isnri,  pmobile,  ppan,  firstname,  lastname,
                middlename,  day,  month,  year,  gender,  planjourney,  proposerstate,  advisorstatesame,  plan,  sumassured,  smokertype,  planoptions,  increasinglevel,
                ecs,  term,  ppt,  premiumterm,  premiumamount,
                clickcontinue,  ifsccode,  bankaccno,  accounttype,  pennyalert,
                clickverify, paymentmethod, drawdate, fundsource,
                nomineescreentitle, nomineefirstname, nomineelastname, nomineeday, nomineemonth, nomineeyear, nomineegender, relationshipwithproposer, typeofaddress,  addresspincode,  address1,  address2,  address3,  personalDetailsscreentitle,
                PersonalEmailId,  PersonalMaritalStatus,  FatherSpouseName,
                MotherName,  MaidenName,  Qualification,  Occupation,  SpouseAnnualIncome,  AnnualIncome, addressscreentitle,  nomineeshare, ismwppolicy);

        if(new BaseTest().isWeb()){
            healthDetailsPage.eleFeetDownBtn.click();
            healthDetailsPage.eleFeetUpBtn.click();
            healthDetailsPage.eleInchesDownBtn.click();
            healthDetailsPage.eleInchesUpBtn.click();
        }
        healthDetailsPage.eleWeightChangeYesBtn.click();
        commonUtils.scrollTillEndOfPage(driver);
        lifestylePage.elePersonalDetailsSaveBtn.click();
        Assert.assertTrue(healthDetailsPage.eleEnterWeightError.isDisplayed(),"Error is not displayed when Weight field is empty");
        Assert.assertTrue(healthDetailsPage.eleEnterReasonError.isDisplayed(),"Error is not displayed when Reason field is empty");

    }

    @Test(dataProvider = "dataHealthDetailsProvider",dataProviderClass = DataProviders.class,priority = 2,retryAnalyzer = RetryAnalyzer.class)
    @Description("Health details")
    public void Health_Details(String username, String password, String policy, String leadid, String proposersame,
                                          String relationwithinsured,String isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                          String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                          String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                          String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                          String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                          String clickverify, String renewpremiumscreentitle, String paymentmethod, String drawdate, String fundsource,
                                          String nomineescreentitle, String nomineefirstname, String nomineelastname, String nomineeday,
                                          String nomineemonth, String nomineeyear, String nomineegender, String relationshipwithproposer, String nomineeshare,
                                          String ismwppolicy,
                                          String addressscreentitle, String typeofaddress, String addresspincode, String address1, String address2, String address3,
                                          String personalDetailsscreentitle, String cityName, String preferredLanguage, String alernateNumber, String resTelephoneNumber,
                                          String PersonalEmailId,String PersonalMaritalStatus, String FatherSpouseName,String MotherName, String MaidenName,String Qualification,String Others, String Occupation, String typeOfOccupation, String NameofEmployer, String Designation, String AnnualIncome,
                                          String SpouseAnnualIncome ,String ParentInsuranceCover, String ParentAnnualIncome, String SpouseInsuranceCover, String NarcoticsDetails,String AlcoholQuantity, String Frequency, String NicotineDuration,
                                          String TobaccoQuantityConsumed,String TobaccoYrsConsumed,String HazardousActivitiesOption,String HazardousActivitiesYrs,String HazardousActivitiesType, String HealthWeight, String WeightLossReason ) throws Exception {

        new TestFactory().gotoHealthDetails(driver, username,  password,  policy,  leadid,  proposersame,
                isnri,  pmobile,  ppan,  firstname,  lastname,
                middlename,  day,  month,  year,  gender,  planjourney,  proposerstate,  advisorstatesame,  plan,  sumassured,  smokertype,  planoptions,  increasinglevel,
                ecs,  term,  ppt,  premiumterm,  premiumamount,
                clickcontinue,  ifsccode,  bankaccno,  accounttype,  pennyalert,
                clickverify, paymentmethod, drawdate, fundsource,
                nomineescreentitle, nomineefirstname, nomineelastname, nomineeday, nomineemonth, nomineeyear, nomineegender, relationshipwithproposer, typeofaddress,  addresspincode,  address1,  address2,  address3,  personalDetailsscreentitle,
                PersonalEmailId,  PersonalMaritalStatus,  FatherSpouseName,
                MotherName,  MaidenName,  Qualification,  Occupation,  SpouseAnnualIncome,  AnnualIncome, addressscreentitle,  nomineeshare, ismwppolicy);

        healthDetailsPage.eleFeetDownBtn.click();
        healthDetailsPage.eleFeetUpBtn.click();
        healthDetailsPage.eleInchesDownBtn.click();
        healthDetailsPage.eleInchesUpBtn.click();
        lifestylePage.elePersonalDetailsWeight.sendKeys(HealthWeight);
        healthDetailsPage.eleWeightChangeYesBtn.click();
        commonUtils.scrollTillEndOfPage(driver);
        healthDetailsPage.eleEnterWtLossReason.sendKeys(WeightLossReason);
        lifestylePage.elePersonalDetailsSaveBtn.click();

    }
}
