package tests.journeys;

import com.absli.helpers.dataProviders.DataProviders;
import com.absli.helpers.jsonReaders.ReadJson;
import com.absli.helpers.models.ProposerModel;
import com.absli.listeners.TestLevelDriverCreator;
import com.absli.listeners.TestListener;
import com.absli.pageObjects.CreateApplPage;
import com.absli.pageObjects.SignInPage;
import com.absli.utils.CommonUtils;
import com.absli.utils.ExcelUtils;
import com.absli.utils.PropertiesUtils;
import com.absli.utils.WaitUtils;
import io.qameta.allure.Description;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.*;
import tests.BaseTest;
import tests.TestFactory;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;

public class RenewalPremiumTest extends BaseTest {


    ReadJson jsonObj;
    CreateApplPage createApplPage;
    CommonUtils commonUtils;
    WaitUtils waitUtils;
    PropertiesUtils prop;
    SignInPage signIn;

    @BeforeClass
    public void preSetup() throws IOException, InterruptedException {
        driver = new TestLevelDriverCreator().getDriver();
        commonUtils = new CommonUtils();
        waitUtils = new WaitUtils();
        prop = new PropertiesUtils();
        createApplPage = new CreateApplPage(driver);
    }

    @BeforeMethod
    public void relaunch()  {
        new BaseTest().relaunch();
    }


    @Test(dataProvider = "dataRenewProvider",dataProviderClass = DataProviders.class)
    @Description("Fill Renewal premium details")
    public void fill_renewal_premium_details(String username, String password, String policy, String leadid, String proposersame, String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                    String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                    String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                    String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                    String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert, String clickverify, String renewpremiumscreentitle,String paymentmethod,String drawdate,String fundsource,String nomineescreentitle) throws InterruptedException, IOException {


        new TestFactory().gotoRenewal(driver,  username,   password,   policy,   leadid,   proposersame,
                  relationwithinsured,  isrelationanswer,   isnri,   pmobile,   ppan,   imobile,   ipan,   firstname,   lastname,
                  middlename,   day,   month,   year,   gender,   planjourney,   proposerstate,   advisorstatesame,   plan,   sumassured,   smokertype,   planoptions,   increasinglevel,
                  ecs,   term,   ppt,   premiumterm,   premiumamount,
                  rider,   rideramount,   minrider,   maxrider,   ridererror,   click,   generateillustrations,
                  clickcontinue,  ifsccode,   bankaccno,   accholdername,   accounttype,
                  pennyalert,   clickverify,   renewpremiumscreentitle);

        createApplPage.choosePaymentMethod(paymentmethod);
        createApplPage.chooseDrawDate(drawdate);
        createApplPage.chooseSourceOfFund(fundsource);
        createApplPage.chooseActionButton(createApplPage.eleRenewSaveBtn);
        commonUtils.scrollTillEndOfPage(driver);
        waitUtils.wait2Seconds();
        waitUtils.waitUntilVisible(driver, createApplPage.eleRenewNextBtn, 30);
        Assert.assertTrue(createApplPage.eleRenewNextBtn.isDisplayed(),"Fill renewal screen details failed");
        //Assert.assertEquals(createApplPage.getPremiumValueFromRenewalScreen(),commonUtils.decimalFormatter(premiumamount),"Premium amount shown in renewal screen is different than quote");
        //Assert.assertTrue(createApplPage.getPaymentFreqFromRenewalScreen().contains(premiumterm),"Premium period shown in renewal screen is different than quote");

    }

    @Test(dataProvider = "dataRenewProvider",dataProviderClass = DataProviders.class)
    @Description("Edit Renewal premium details")
    public void edit_renewal_premium_details(String username, String password, String policy, String leadid, String proposersame,
                                             String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                             String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                             String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                             String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                             String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert, String clickverify, String renewpremiumscreentitle,String paymentmethod,String drawdate,String fundsource,String nomineescreentitle) throws InterruptedException, IOException {


        new TestFactory().gotoRenewal(driver,  username,   password,   policy,   leadid,   proposersame,
                relationwithinsured,  isrelationanswer,   isnri,   pmobile,   ppan,   imobile,   ipan,   firstname,   lastname,
                middlename,   day,   month,   year,   gender,   planjourney,   proposerstate,   advisorstatesame,   plan,   sumassured,   smokertype,   planoptions,   increasinglevel,
                ecs,   term,   ppt,   premiumterm,   premiumamount,
                rider,   rideramount,   minrider,   maxrider,   ridererror,   click,   generateillustrations,
                clickcontinue,  ifsccode,   bankaccno,   accholdername,   accounttype,
                pennyalert,   clickverify,   renewpremiumscreentitle);

        createApplPage.choosePaymentMethod(paymentmethod);
        createApplPage.chooseDrawDate(drawdate);
        createApplPage.chooseSourceOfFund(fundsource);
        createApplPage.chooseActionButton(createApplPage.eleRenewSaveBtn);
        commonUtils.scrollTillEndOfPage(driver);
        waitUtils.wait2Seconds();
        waitUtils.waitUntilVisible(driver, createApplPage.eleRenewNextBtn, 30);
        //Assert.assertEquals(createApplPage.getPremiumValueFromRenewalScreen(),commonUtils.decimalFormatter(premiumamount),"Premium amount shown in renewal screen is different than quote");
        //Assert.assertTrue(createApplPage.getPaymentFreqFromRenewalScreen().contains(premiumterm),"Premium period shown in renewal screen is different than quote");
        commonUtils.selectButtonByName("EDIT",driver);
        commonUtils.scrollTopOfPage(driver);
        createApplPage.choosePaymentMethod(paymentmethod);
        createApplPage.chooseSourceOfFund(fundsource);
        commonUtils.scrollTillEndOfPage(driver);

        createApplPage.chooseActionButton(createApplPage.eleRenewSaveBtn);
        commonUtils.scrollTillEndOfPage(driver);
        waitUtils.wait2Seconds();
        waitUtils.waitUntilVisible(driver, createApplPage.eleRenewNextBtn, 30);
        Assert.assertTrue(createApplPage.eleRenewNextBtn.isDisplayed(),"Fill renewal screen details failed");
    }




}
