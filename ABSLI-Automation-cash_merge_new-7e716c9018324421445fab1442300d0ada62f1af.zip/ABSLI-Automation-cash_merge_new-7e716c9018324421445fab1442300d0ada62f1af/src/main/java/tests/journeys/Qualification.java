package tests.journeys;

import com.absli.helpers.dataProviders.DataProviders;
import com.absli.helpers.jsonReaders.ReadJson;
import com.absli.helpers.models.ProposerModel;
import com.absli.listeners.RetryAnalyzer;
import com.absli.listeners.TestLevelDriverCreator;
import com.absli.pageObjects.CreateApplPage;
import com.absli.pageObjects.QualificationPage;
import com.absli.pageObjects.SignInPage;
import com.absli.utils.CommonUtils;
import com.absli.utils.PropertiesUtils;
import com.absli.utils.WaitUtils;
import io.qameta.allure.Description;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import tests.BaseTest;
import tests.TestFactory;


import java.io.IOException;

@Listeners({TestLevelDriverCreator.class})
public class Qualification extends BaseTest{

    ProposerModel proposerModel;
    ReadJson jsonObj;
    CreateApplPage createApplPage;
    CommonUtils commonUtils;
    WaitUtils waitUtils;
    PropertiesUtils prop;
    SignInPage signIn;
    QualificationPage qualificationPage;

    @BeforeClass
    public void preSetup() throws IOException, InterruptedException {
        driver = new TestLevelDriverCreator().getDriver();

        commonUtils = new CommonUtils();
        waitUtils = new WaitUtils();
        prop = new PropertiesUtils();
        createApplPage = new CreateApplPage(driver);
        qualificationPage = new QualificationPage(driver);
    }

    @AfterMethod
    public void relaunch() {
        new BaseTest().relaunch();
    }

    @Test(dataProvider = "dataQualificationProvider",dataProviderClass = DataProviders.class,priority = 1,retryAnalyzer = RetryAnalyzer.class)
    @Description("qualification selection with others option")
    public void qualification(String username, String password, String policy, String leadid, String proposersame,
                              String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                              String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                              String ecs, String term, String ppt, String premiumterm, String premiumamount,
                              String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                              String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                              String clickverify, String renewpremiumscreentitle, String paymentmethod, String drawdate, String fundsource,
                              String nomineescreentitle, String nomineefirstname, String nomineelastname, String nomineeday,
                              String nomineemonth, String nomineeyear, String nomineegender, String relationshipwithproposer, String nomineeshare,
                              String ismwppolicy,
                              String addressscreentitle, String typeofaddress, String addresspincode, String address1, String address2, String address3,
                              String personalDetailsscreentitle, String cityName, String preferredLanguage, String alernateNumber, String resTelephoneNumber,
                              String PersonalEmailId,String PersonalMaritalStatus, String FatherSpouseName,String MotherName, String MaidenName,String Qualification,String Others) throws Exception {


        new TestFactory().gotoQualification(driver, username,  password,  policy,  leadid,  proposersame,
                relationwithinsured,isrelationanswer, isnri, pmobile, ppan, imobile, ipan, firstname, lastname,
                middlename, day, month, year, gender, planjourney, proposerstate, advisorstatesame, plan,sumassured, smokertype, planoptions, increasinglevel,
                ecs, term, ppt, premiumterm, premiumamount,
                rider, rideramount, minrider, maxrider, ridererror, click, generateillustrations,
                clickcontinue, ifsccode, bankaccno, accholdername, accounttype, pennyalert,clickverify
                ,  renewpremiumscreentitle, paymentmethod, drawdate, fundsource,
                nomineescreentitle, nomineefirstname, nomineelastname, nomineeday, nomineemonth, nomineeyear,nomineegender,relationshipwithproposer,typeofaddress, addresspincode, address1, address2, address3, personalDetailsscreentitle, cityName);

        qualificationPage.inputPersonalEmailId(PersonalEmailId);
        waitUtils.waitForElementToBeVisible(driver,qualificationPage.eleFatherSpouseNameInput,20,"Element not visible");
        qualificationPage.chooseMaritalStatus(PersonalMaritalStatus);
        qualificationPage.inputPersonalFatherSpouseName(FatherSpouseName);
        qualificationPage.inputPersonalMotherName(MotherName);
        commonUtils.scrollTillEndOfPage(driver);
        //Assert.assertEquals(qualificationPage.eleQualificationDrpBtn.getText(),"");
        qualificationPage.chooseQualification(Qualification);
        //Assert.assertEquals(qualificationPage.eleQualificationDrpBtn.getText(),Others);
        waitUtils.waitForElementToBeVisible(driver,qualificationPage.eleOthersInput,10,"Other field is not displayed");
        //Assert.assertEquals(qualificationPage.eleQualificationDrpBtn.getText(),"Others");
        qualificationPage.inputOthers(Others);
    }

    //@Test(dataProvider = "dataQualificationProvider",dataProviderClass = DataProviders.class,priority = 2,retryAnalyzer = RetryAnalyzer.class)
    @Description("qualification dropdown list validation")
    public void qualification_list_validation(String username, String password, String policy, String leadid, String proposersame,
                                              String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                              String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                              String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                              String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                              String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                              String clickverify, String renewpremiumscreentitle, String paymentmethod, String drawdate, String fundsource,
                                              String nomineescreentitle, String nomineefirstname, String nomineelastname, String nomineeday,
                                              String nomineemonth, String nomineeyear, String nomineegender, String relationshipwithproposer, String nomineeshare,
                                              String ismwppolicy,
                                              String addressscreentitle, String typeofaddress, String addresspincode, String address1, String address2, String address3,
                                              String personalDetailsscreentitle, String cityName, String preferredLanguage, String alernateNumber, String resTelephoneNumber,
                                              String PersonalEmailId,String PersonalMaritalStatus, String FatherSpouseName,String MotherName, String MaidenName,String Qualification,String Others) throws Exception {


        new TestFactory().gotoQualification(driver, username,  password,  policy,  leadid,  proposersame,
                relationwithinsured,isrelationanswer, isnri, pmobile, ppan, imobile, ipan, firstname, lastname,
                middlename, day, month, year, gender, planjourney, proposerstate, advisorstatesame, plan,sumassured, smokertype, planoptions, increasinglevel,
                ecs, term, ppt, premiumterm, premiumamount,
                rider, rideramount, minrider, maxrider, ridererror, click, generateillustrations,
                clickcontinue, ifsccode, bankaccno, accholdername, accounttype, pennyalert,clickverify
                ,  renewpremiumscreentitle, paymentmethod, drawdate, fundsource,
                nomineescreentitle, nomineefirstname, nomineelastname, nomineeday, nomineemonth, nomineeyear,nomineegender,relationshipwithproposer,typeofaddress, addresspincode, address1, address2, address3, personalDetailsscreentitle, cityName);

        qualificationPage.inputPersonalEmailId(PersonalEmailId);
        waitUtils.waitForElementToBeVisible(driver,qualificationPage.eleFatherSpouseNameInput,20,"Element not visible");
        qualificationPage.chooseMaritalStatus(PersonalMaritalStatus);
        qualificationPage.inputPersonalFatherSpouseName(FatherSpouseName);
        qualificationPage.inputPersonalMotherName(MotherName);
        commonUtils.scrollTillEndOfPage(driver);
        qualificationPage.eleQualificationDrpBtn.click();
        qualificationPage.validateQualificationList();
    }

    //@Test(dataProvider = "dataQualificationProvider",dataProviderClass = DataProviders.class,priority = 3,retryAnalyzer = RetryAnalyzer.class)
    @Description("qualification screen navigation")
    public void qualification_navigation(String username, String password, String policy, String leadid, String proposersame,
                                         String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                         String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                         String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                         String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                         String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                         String clickverify, String renewpremiumscreentitle, String paymentmethod, String drawdate, String fundsource,
                                         String nomineescreentitle, String nomineefirstname, String nomineelastname, String nomineeday,
                                         String nomineemonth, String nomineeyear, String nomineegender, String relationshipwithproposer, String nomineeshare,
                                         String ismwppolicy,
                                         String addressscreentitle, String typeofaddress, String addresspincode, String address1, String address2, String address3,
                                         String personalDetailsscreentitle, String cityName, String preferredLanguage, String alernateNumber, String resTelephoneNumber,
                                         String PersonalEmailId,String PersonalMaritalStatus, String FatherSpouseName,String MotherName, String MaidenName,String Qualification,String Others) throws Exception {


        new TestFactory().gotoQualification(driver, username, password, policy, leadid, proposersame,
                relationwithinsured, isrelationanswer, isnri, pmobile, ppan, imobile, ipan, firstname, lastname,
                middlename, day, month, year, gender, planjourney, proposerstate, advisorstatesame, plan, sumassured, smokertype, planoptions, increasinglevel,
                ecs, term, ppt, premiumterm, premiumamount,
                rider, rideramount, minrider, maxrider, ridererror, click, generateillustrations,
                clickcontinue, ifsccode, bankaccno, accholdername, accounttype, pennyalert, clickverify
                , renewpremiumscreentitle, paymentmethod, drawdate, fundsource,
                nomineescreentitle, nomineefirstname, nomineelastname, nomineeday, nomineemonth, nomineeyear, nomineegender, relationshipwithproposer, typeofaddress, addresspincode, address1, address2, address3, personalDetailsscreentitle, cityName);

        if (isWeb()) {
            driver.navigate().back();
            Assert.assertEquals(createApplPage.validateScreenTitle(addressscreentitle), addressscreentitle, "Failure in navigation to Address Details screen");
            driver.navigate().forward();
            Assert.assertEquals(createApplPage.validateScreenTitle(personalDetailsscreentitle), personalDetailsscreentitle, "Failure in navigation to Personal Details screen");
        }
    }
}

/*Verify The Redirection and Navigation
 * Verify No default option will be selected for qualification
 * Validate if others is selected, user needs a separate field on what is the other qualification
 * Validate the user is able to select from the below options under Qualification
 * */

