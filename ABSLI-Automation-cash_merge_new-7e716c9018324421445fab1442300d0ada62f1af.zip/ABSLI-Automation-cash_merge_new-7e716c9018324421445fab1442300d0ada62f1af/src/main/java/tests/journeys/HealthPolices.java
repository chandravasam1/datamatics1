package tests.journeys;

import com.absli.helpers.jsonReaders.ReadJson;
import com.absli.helpers.models.ProposerModel;
import com.absli.listeners.TestLevelDriverCreator;
import com.absli.listeners.TestListener;
import com.absli.pageObjects.CreateApplPage;
import com.absli.pageObjects.ExistingPolicyPage;
import com.absli.pageObjects.SignInPage;
import com.absli.utils.CommonUtils;
import com.absli.utils.PropertiesUtils;
import com.absli.utils.WaitUtils;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import tests.BaseTest;

import java.io.IOException;

public class HealthPolices extends BaseTest {

        ProposerModel proposerModel;
        ReadJson jsonObj;
        CreateApplPage createApplPage;
        CommonUtils commonUtils;
        WaitUtils waitUtils;
        PropertiesUtils prop;
        SignInPage signIn;
        ExistingPolicyPage existingPolicyPage;

        @BeforeClass
        public void preSetup() throws IOException, InterruptedException {
            driver = new TestLevelDriverCreator().getDriver();
            commonUtils = new CommonUtils();
            waitUtils = new WaitUtils();
            prop = new PropertiesUtils();
        }

    @AfterMethod
    public void relaunch()  {
        new BaseTest().relaunch();
    }
}
