package tests.journeys;

import com.absli.helpers.dataProviders.DataProviders;
import com.absli.helpers.jsonReaders.ReadJson;
import com.absli.listeners.RetryAnalyzer;
import com.absli.listeners.TestLevelDriverCreator;
import com.absli.pageObjects.*;
import com.absli.utils.CommonUtils;
import com.absli.utils.PropertiesUtils;
import com.absli.utils.WaitUtils;
import io.qameta.allure.Description;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import tests.BaseTest;
import tests.TestFactory;

import java.io.IOException;

public class AppSummary extends BaseTest{
    ReadJson jsonObj;
    CreateApplPage createApplPage;
    CommonUtils commonUtils;
    WaitUtils waitUtils;
    PropertiesUtils prop;
    SignInPage signIn;
    CashPage cashPage;
    PaymentSummaryPage paymentSummaryPage;
    AppSummaryPage appSummaryPage;

    @BeforeClass
    public void preSetup() throws IOException, InterruptedException {
        driver = new TestLevelDriverCreator().getDriver();
        commonUtils = new CommonUtils();
        waitUtils = new WaitUtils();
        prop = new PropertiesUtils();
        appSummaryPage = new AppSummaryPage(driver);
    }

    @BeforeMethod
    public void relaunch()  {
        new BaseTest().relaunch();
    }

    @Test(dataProvider = "dataAppSummaryProvider",dataProviderClass = DataProviders.class,priority = 1,retryAnalyzer = RetryAnalyzer.class)
    @Description("App Summary details")
    public void App_Summary(String username, String password, String policy, String leadid, String proposersame,
                                          String relationwithinsured, String isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                          String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                          String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                          String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                          String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                          String clickverify, String renewpremiumscreentitle, String paymentmethod, String drawdate, String fundsource,
                                          String nomineescreentitle, String nomineefirstname, String nomineelastname, String nomineeday,
                                          String nomineemonth, String nomineeyear, String nomineegender, String relationshipwithproposer, String nomineeshare,
                                          String ismwppolicy,
                                          String addressscreentitle, String typeofaddress, String addresspincode, String address1, String address2, String address3,
                                          String personalDetailsscreentitle, String cityName, String preferredLanguage, String alernateNumber, String resTelephoneNumber,
                                          String PersonalEmailId, String PersonalMaritalStatus, String FatherSpouseName, String MotherName, String MaidenName, String Qualification, String Others, String Occupation, String typeOfOccupation, String NameofEmployer, String Designation, String AnnualIncome,
                                          String SpouseAnnualIncome , String ParentInsuranceCover, String ParentAnnualIncome, String SpouseInsuranceCover, String NarcoticsDetails, String AlcoholQuantity, String Frequency, String NicotineDuration,
                                          String TobaccoQuantityConsumed, String TobaccoYrsConsumed, String HazardousActivitiesOption, String HazardousActivitiesYrs, String HazardousActivitiesType, String ChequeNumber, String PaymentModeDate, String PaymentModeMonth, String PaymentModeYear, String IFSCCode, String MICRCODE, String DDNumber, String PolicyNumber, String PolicyAmount) throws Exception {

        new TestFactory().gotoCheque(driver, username, password, policy, leadid, proposersame,
                isnri, pmobile, ppan, firstname, lastname,
                middlename, day, month, year, gender, planjourney, proposerstate, advisorstatesame, plan, sumassured, smokertype, planoptions, increasinglevel,
                ecs, term, ppt, premiumterm, premiumamount,
                clickcontinue, ifsccode, bankaccno, accounttype, pennyalert,
                clickverify, paymentmethod, drawdate, fundsource,
                nomineescreentitle, nomineefirstname, nomineelastname, nomineeday, nomineemonth, nomineeyear, nomineegender, relationshipwithproposer, typeofaddress, addresspincode, address1, address2, address3, personalDetailsscreentitle,
                PersonalEmailId, PersonalMaritalStatus, FatherSpouseName,
                MotherName, MaidenName, Qualification, Occupation, SpouseAnnualIncome, AnnualIncome, addressscreentitle, nomineeshare, ismwppolicy);

        cashPage.eleCashDrpBtn.click();
        cashPage.eleCashSubmitBtn.click();
        Assert.assertEquals(paymentSummaryPage.elePaymentModeTitle.getText(),"10.0 Payment Mode");
        appSummaryPage.eleAppSummaryNavBtn.click();
        Assert.assertEquals(appSummaryPage.eleCustomerProfile.isDisplayed(),"Element is displayed");
        Assert.assertEquals(appSummaryPage.eleSelectPlan.isDisplayed(),"Element is displayed");
        Assert.assertEquals(appSummaryPage.eleInstaVerify.isDisplayed(),"Element is displayed");
        Assert.assertEquals(appSummaryPage.eleBankDetails.isDisplayed(),"Element is displayed");
        Assert.assertEquals(appSummaryPage.eleNominee.isDisplayed(),"Element is displayed");
        Assert.assertEquals(appSummaryPage.eleAddress.isDisplayed(),"Element is displayed");
        Assert.assertEquals(appSummaryPage.elePersonalAndProfessionalInfo.isDisplayed(),"Element is displayed");
        Assert.assertEquals(appSummaryPage.eleMedical.isDisplayed(),"Element is displayed");
        Assert.assertEquals(appSummaryPage.eleReviewAcceptance.isDisplayed(),"Element is displayed");
        Assert.assertEquals(appSummaryPage.elePayment.isDisplayed(),"Element is displayed");
        Assert.assertEquals(appSummaryPage.eleDocuments.isDisplayed(),"Element is displayed");
        Assert.assertEquals(appSummaryPage.eleIAR.isDisplayed(),"Element is displayed");
    }

    @Test(dataProvider = "dataAppSummaryProvider",dataProviderClass = DataProviders.class,priority = 1,retryAnalyzer = RetryAnalyzer.class)
    @Description("App Summary Status")
    public void App_Summary_Status(String username, String password, String policy, String leadid, String proposersame,
                            String relationwithinsured, String isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                            String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                            String ecs, String term, String ppt, String premiumterm, String premiumamount,
                            String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                            String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                            String clickverify, String renewpremiumscreentitle, String paymentmethod, String drawdate, String fundsource,
                            String nomineescreentitle, String nomineefirstname, String nomineelastname, String nomineeday,
                            String nomineemonth, String nomineeyear, String nomineegender, String relationshipwithproposer, String nomineeshare,
                            String ismwppolicy,
                            String addressscreentitle, String typeofaddress, String addresspincode, String address1, String address2, String address3,
                            String personalDetailsscreentitle, String cityName, String preferredLanguage, String alernateNumber, String resTelephoneNumber,
                            String PersonalEmailId, String PersonalMaritalStatus, String FatherSpouseName, String MotherName, String MaidenName, String Qualification, String Others, String Occupation, String typeOfOccupation, String NameofEmployer, String Designation, String AnnualIncome,
                            String SpouseAnnualIncome , String ParentInsuranceCover, String ParentAnnualIncome, String SpouseInsuranceCover, String NarcoticsDetails, String AlcoholQuantity, String Frequency, String NicotineDuration,
                            String TobaccoQuantityConsumed, String TobaccoYrsConsumed, String HazardousActivitiesOption, String HazardousActivitiesYrs, String HazardousActivitiesType, String ChequeNumber, String PaymentModeDate, String PaymentModeMonth, String PaymentModeYear, String IFSCCode, String MICRCODE, String DDNumber, String PolicyNumber, String PolicyAmount) throws Exception {

        new TestFactory().gotoCheque(driver, username, password, policy, leadid, proposersame,
                isnri, pmobile, ppan, firstname, lastname,
                middlename, day, month, year, gender, planjourney, proposerstate, advisorstatesame, plan, sumassured, smokertype, planoptions, increasinglevel,
                ecs, term, ppt, premiumterm, premiumamount,
                clickcontinue, ifsccode, bankaccno, accounttype, pennyalert,
                clickverify, paymentmethod, drawdate, fundsource,
                nomineescreentitle, nomineefirstname, nomineelastname, nomineeday, nomineemonth, nomineeyear, nomineegender, relationshipwithproposer, typeofaddress, addresspincode, address1, address2, address3, personalDetailsscreentitle,
                PersonalEmailId, PersonalMaritalStatus, FatherSpouseName,
                MotherName, MaidenName, Qualification, Occupation, SpouseAnnualIncome, AnnualIncome, addressscreentitle, nomineeshare, ismwppolicy);

        cashPage.eleCashDrpBtn.click();
        cashPage.eleCashSubmitBtn.click();
        Assert.assertEquals(paymentSummaryPage.elePaymentModeTitle.getText(),"10.0 Payment Mode");
        appSummaryPage.eleAppSummaryNavBtn.click();
        Assert.assertEquals(appSummaryPage.eleCustomerProfileStatus.isDisplayed(),"Element is displayed");
        Assert.assertEquals(appSummaryPage.eleSelectPlanStatus.isDisplayed(),"Element is displayed");
        Assert.assertEquals(appSummaryPage.eleInstaVerify.isDisplayed(),"Element is displayed");
        Assert.assertEquals(appSummaryPage.eleBankDetailsStatus.isDisplayed(),"Element is displayed");
        Assert.assertEquals(appSummaryPage.eleNomineeStatus.isDisplayed(),"Element is displayed");
        Assert.assertEquals(appSummaryPage.eleAddressStatus.isDisplayed(),"Element is displayed");
        Assert.assertEquals(appSummaryPage.elePersonalAndProfessionalInfoStatus.isDisplayed(),"Element is displayed");
        Assert.assertEquals(appSummaryPage.eleMedicalStatus.isDisplayed(),"Element is displayed");
        Assert.assertEquals(appSummaryPage.eleReviewAcceptanceStatus.isDisplayed(),"Element is displayed");
        Assert.assertEquals(appSummaryPage.elePaymentStatus.isDisplayed(),"Element is displayed");
        Assert.assertEquals(appSummaryPage.eleDocumentsStatus.isDisplayed(),"Element is displayed");
        Assert.assertEquals(appSummaryPage.eleIARStatus.isDisplayed(),"Element is displayed");
    }

}
