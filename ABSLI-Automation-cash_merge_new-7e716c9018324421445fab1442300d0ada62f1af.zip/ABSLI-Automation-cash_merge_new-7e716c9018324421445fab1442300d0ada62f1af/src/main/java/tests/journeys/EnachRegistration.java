package tests.journeys;


import com.absli.helpers.dataProviders.DataProviders;
import com.absli.helpers.jsonReaders.ReadJson;
import com.absli.listeners.TestLevelDriverCreator;
import com.absli.listeners.TestListener;
import com.absli.pageObjects.CreateApplPage;
import com.absli.pageObjects.EnachRegistrationPage;
import com.absli.pageObjects.SignInPage;
import com.absli.utils.CommonUtils;
import com.absli.utils.PropertiesUtils;
import com.absli.utils.WaitUtils;
import io.qameta.allure.Description;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import tests.BaseTest;
import tests.TestFactory;

import java.io.IOException;

@Listeners({TestLevelDriverCreator.class})
public class EnachRegistration extends BaseTest {

    ReadJson jsonObj;
    CreateApplPage createApplPage;
    CommonUtils commonUtils;
    WaitUtils waitUtils;
    PropertiesUtils prop;
    SignInPage signIn;
    EnachRegistrationPage enachPage;

    @BeforeClass
    public void preSetup() throws IOException, InterruptedException {
        driver = new TestLevelDriverCreator(). getDriver();
        commonUtils = new CommonUtils();
        waitUtils = new WaitUtils();
        prop = new PropertiesUtils();
        enachPage = new EnachRegistrationPage(driver);

    }
    @BeforeMethod
    public void relaunch()  {
        new BaseTest().relaunch();
    }

    @Test(dataProvider = "dataEnachProvider",dataProviderClass = DataProviders.class,priority = 1)
    @Description("Test case description: verify Send link to client")
    public void verify_SendTo_ClientLink(String username, String password, String policy, String leadid, String proposersame, String propinsurednotsame, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                               String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                               String ecs, String term, String ppt, String premiumterm, String premiumamount,
                               String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                               String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                               String clickverify, String renewpremiumscreentitle,String bankname, String mobileno, String pannumber, String emailaddress) throws Exception {

       new TestFactory().gotoEnachRegistration(driver,username,  password,  policy,  leadid,  proposersame,  propinsurednotsame,  isnri,  pmobile,  ppan,  imobile,  ipan,  firstname,  lastname,
                middlename,  day,  month,  year,  gender,  planjourney,  proposerstate,  advisorstatesame,  plan,  sumassured,  smokertype,  planoptions,  increasinglevel,
                ecs,  term,  ppt,  premiumterm,  premiumamount,
                rider,  rideramount,  minrider,  maxrider,  ridererror,  click,  generateillustrations,
                clickcontinue,  ifsccode,  bankaccno,  accholdername,  accounttype,  pennyalert,
                clickverify,renewpremiumscreentitle,bankname,mobileno,pannumber,emailaddress);
        waitUtils.wait5Seconds();
        commonUtils.scrollTillEndOfPage(driver);
        commonUtils.isClickable(enachPage.enachSendLi(), driver);
        enachPage.EnachSendLinktoClient("Send Link To Client");
       waitUtils.wait2Seconds();
        //Assert.assertEquals(commonUtils.alertGetData(driver),"E-NACH link has been successfully sent");
        waitUtils.waitUntilElementIsVisibleByText(driver,30,pennyalert,"E-NACH link not send and alert is not present");
        String actualMessage=commonUtils.WaitForElementPresentandGetText(driver,enachPage.getmessage,10);
        commonUtils.selectButtonByName("OK", driver);
        //String actualMessage=commonUtils.alertGetData(driver);
       waitUtils.Asserting("equals",actualMessage,"E-NACH link has been successfully sent");

    }
    //@Test(dataProvider = "dataEnachProvider",dataProviderClass = DataProviders.class,priority = 2)
    @Description("verify user able to select preferedDraw date")
    public void verify_enach_preferedDrawDate(String username, String password, String policy, String leadid, String proposersame, String propinsurednotsame, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                         String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                         String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                         String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                         String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                         String clickverify, String renewpremiumscreentitle,String bankname,String mobileno,String pannumber,String emailaddress  ) throws Exception {


        new TestFactory().gotoEnachRegistration(driver,username,  password,  policy,  leadid,  proposersame,  propinsurednotsame,  isnri,  pmobile,  ppan,  imobile,  ipan,  firstname,  lastname,
                middlename,  day,  month,  year,  gender,  planjourney,  proposerstate,  advisorstatesame,  plan,  sumassured,  smokertype,  planoptions,  increasinglevel,
                ecs,  term,  ppt,  premiumterm,  premiumamount,
                rider,  rideramount,  minrider,  maxrider,  ridererror,  click,  generateillustrations,
                clickcontinue,  ifsccode,  bankaccno,  accholdername,  accounttype,  pennyalert,
                clickverify,renewpremiumscreentitle,bankname,mobileno,pannumber,emailaddress);

        waitUtils.wait5Seconds();
        commonUtils.selectButtonByName("8th", driver);
        waitUtils.wait5Seconds();
        commonUtils.isClickable(enachPage.enachSendLi(), driver);
        enachPage.EnachSendLinktoClient("Send Link To Client");
        String actualMessage=commonUtils.WaitForElementPresentandGetText(driver,enachPage.getmessage,10);
        commonUtils.selectButtonByName("OK", driver);
        //String actualMessage=commonUtils.alertGetData(driver);
        waitUtils.Asserting("equals",actualMessage,"E-NACH link has been successfully sent");

        commonUtils.selectButtonByName("SAVE",driver);

        waitUtils.Asserting("equals",enachPage.preferedDate.getAttribute("innerText"),"8TH");


    }
  //  @Test(dataProvider = "dataEnachProvider", dataProviderClass = DataProviders.class,priority = 3)
    @Description("Enach registration page")
    public void enach_RegistrationLink(String username, String password, String policy, String leadid, String proposersame, String propinsurednotsame, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                      String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                      String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                      String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                      String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                      String clickverify,String renewpremiumscreentitle, String bankname, String mobileno, String pannumber, String emailaddress) throws Exception {


        new TestFactory().gotoEnachRegistration(driver,username,  password,  policy,  leadid,  proposersame,  propinsurednotsame,  isnri,  pmobile,  ppan,  imobile,  ipan,  firstname,  lastname,
                middlename,  day,  month,  year,  gender,  planjourney,  proposerstate,  advisorstatesame,  plan,  sumassured,  smokertype,  planoptions,  increasinglevel,
                ecs,  term,  ppt,  premiumterm,  premiumamount,
                rider,  rideramount,  minrider,  maxrider,  ridererror,  click,  generateillustrations,
                clickcontinue,  ifsccode,  bankaccno,  accholdername,  accounttype,  pennyalert,
                clickverify,renewpremiumscreentitle,bankname,mobileno,pannumber,emailaddress);

        driver.navigate().refresh();

        commonUtils.isClickable(enachPage.resiterNowlink, driver);
        enachPage.enachRegistrationLink("Register Now");        //
        waitUtils.waitForElementToBeVisible(driver,enachPage.registerPopUp,30,"paymethod-digitalMandate is not present");
         if(enachPage.registerPopUp.isDisplayed()) {
             waitUtils.waitForLoad(driver);
            // commonUtils.scrollTillEndOfPage(driver);
             // enachPage.selectBank.click();
             enachPage.enachReSelectBank();
             enachPage.enachRegistrationSelectBank(bankname);
             commonUtils.scrolltopageend(driver);
             waitUtils.wait2Seconds();
             enachPage.setEnachPhoneNumber(mobileno);
             //enachPage.getEnachPan.click();
             waitUtils.wait2Seconds();
             enachPage.setEnachPanNumber(pannumber);
             //enachPage.getEnachEmail.click();
             waitUtils.wait2Seconds();
             enachPage.setEnachEmailAddress(emailaddress);
             waitUtils.wait2Seconds();
             enachPage.registerAfterSelectBank("Register Now");
             waitUtils.wait10Seconds();
             commonUtils.switchToWindow(driver);
             waitUtils.wait5Seconds();
             commonUtils.scrollTillEndOfPage(driver);
             commonUtils.scrolltopageend(driver);
             waitUtils.waitForElementToBeClickable(driver,enachPage.checkboxClck);
             enachPage.checkboxClick();
             waitUtils.waitForElementToBeClickable(driver, enachPage.clickOnSubmit);
             enachPage.clickOnSub();
         }


    }


    //@Test(dataProvider = "dataEnachProvider", priority = 4)
    @Description("verify page load timeout")
    public void verify_PageLoad_Time(String username, String password, String policy, String leadid, String proposersame, String propinsurednotsame, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                               String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                               String ecs, String term, String ppt, String premiumterm, String premiumamount,
                               String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                               String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                               String clickverify,String renewpremiumscreentitle, String bankname, String mobileno, String pannumber, String emailaddress) throws Exception {


        new TestFactory().gotoEnachRegistration(driver,username,  password,  policy,  leadid,  proposersame,  propinsurednotsame,  isnri,  pmobile,  ppan,  imobile,  ipan,  firstname,  lastname,
                middlename,  day,  month,  year,  gender,  planjourney,  proposerstate,  advisorstatesame,  plan,  sumassured,  smokertype,  planoptions,  increasinglevel,
                ecs,  term,  ppt,  premiumterm,  premiumamount,
                rider,  rideramount,  minrider,  maxrider,  ridererror,  click,  generateillustrations,
                clickcontinue,  ifsccode,  bankaccno,  accholdername,  accounttype,  pennyalert,
                clickverify,renewpremiumscreentitle,bankname,mobileno,pannumber,emailaddress);
        waitUtils.waitForElementToBeClickable(driver, enachPage.resiterNowlink);
        enachPage.enachRegistrationLink("Register Now");        //
        waitUtils.wait10Seconds();
        waitUtils.WaitForElementPresent(driver,enachPage.registerPopUp(),30);

        if(waitUtils.checkIfElementPresent(driver,enachPage.registerPopUp())) {
            //waitUtils.wait10Seconds();
            commonUtils.scrollTillEndOfPage(driver);
            enachPage.enachReSelectBank();
            waitUtils.wait2Seconds();
            enachPage.selectBankFromList(bankname);
            waitUtils.wait5Seconds();
            commonUtils.scrolltopageend(driver);
            waitUtils.wait2Seconds();
            // enachPage.getEnachPhone.click();
            enachPage.setEnachPhoneNumber(mobileno);
            //enachPage.getEnachPan.click();
            enachPage.setEnachPanNumber(pannumber);
            //enachPage.getEnachEmail.click();
            enachPage.setEnachEmailAddress(emailaddress);
            enachPage.registerAfterSelectBank("Register Now");
            waitUtils.wait10Seconds();
            commonUtils.switchToWindow(driver);
            commonUtils.scrollTillEndOfPage(driver);
            enachPage.checkboxClick();
            waitUtils.waitForElementToBeClickable(driver, enachPage.clickOnSubmit);
            enachPage.clickOnSub();
        }

    }

    //@Test(dataProvider = "dataEnachProvider", priority = 5)
    @Description("verify enach Registration Status")
    public void verify_enach_Registration_Status(String username, String password, String policy, String leadid, String proposersame, String propinsurednotsame, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                              String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                              String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                              String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                              String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                              String clickverify,String renewpremiumscreentitle, String bankname, String mobileno, String pannumber, String emailaddress) throws Exception {


        new TestFactory().gotoEnachRegistration(driver,username,  password,  policy,  leadid,  proposersame,  propinsurednotsame,  isnri,  pmobile,  ppan,  imobile,  ipan,  firstname,  lastname,
                middlename,  day,  month,  year,  gender,  planjourney,  proposerstate,  advisorstatesame,  plan,  sumassured,  smokertype,  planoptions,  increasinglevel,
                ecs,  term,  ppt,  premiumterm,  premiumamount,
                rider,  rideramount,  minrider,  maxrider,  ridererror,  click,  generateillustrations,
                clickcontinue,  ifsccode,  bankaccno,  accholdername,  accounttype,  pennyalert,
                clickverify,renewpremiumscreentitle,bankname,mobileno,pannumber,emailaddress);
        commonUtils.isClickable(enachPage.enachSendLink, driver);
        enachPage.EnachSendLinktoClient("Send Link To Client");
    }

   // @Test(dataProvider = "dataEnachProvider", priority = 6)
    @Description("verify enach Registration Status")
    public void verify_enach_sendLinkStatus(String username, String password, String policy, String leadid, String proposersame, String propinsurednotsame, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                          String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                          String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                          String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                          String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                          String clickverify,String renewpremiumscreentitle, String bankname, String mobileno, String pannumber, String emailaddress) throws Exception {


        new TestFactory().gotoEnachRegistration(driver,username,  password,  policy,  leadid,  proposersame,  propinsurednotsame,  isnri,  pmobile,  ppan,  imobile,  ipan,  firstname,  lastname,
                middlename,  day,  month,  year,  gender,  planjourney,  proposerstate,  advisorstatesame,  plan,  sumassured,  smokertype,  planoptions,  increasinglevel,
                ecs,  term,  ppt,  premiumterm,  premiumamount,
                rider,  rideramount,  minrider,  maxrider,  ridererror,  click,  generateillustrations,
                clickcontinue,  ifsccode,  bankaccno,  accholdername,  accounttype,  pennyalert,
                clickverify,renewpremiumscreentitle,bankname,mobileno,pannumber,emailaddress);
        commonUtils.isClickable(enachPage.enachSendLink, driver);
        enachPage.EnachSendLinktoClient("Send Link To Client");
    }

    //@Test(dataProvider = "dataEnachProvider",dataProviderClass = DataProviders.class, priority = 7)
    @Description("verify Renewal Premium  Page navigate to Add Nominee ")
    public void verify_RenewalPremium_Navigation_Status(String username, String password, String policy, String leadid, String proposersame, String propinsurednotsame, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                                     String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                                     String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                                     String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                                     String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                                     String clickverify,String renewpremiumscreentitle, String bankname, String mobileno, String pannumber, String emailaddress) throws Exception {


        new TestFactory().gotoEnachRegistration(driver,username,  password,  policy,  leadid,  proposersame,  propinsurednotsame,  isnri,  pmobile,  ppan,  imobile,  ipan,  firstname,  lastname,
                middlename,  day,  month,  year,  gender,  planjourney,  proposerstate,  advisorstatesame,  plan,  sumassured,  smokertype,  planoptions,  increasinglevel,
                ecs,  term,  ppt,  premiumterm,  premiumamount,
                rider,  rideramount,  minrider,  maxrider,  ridererror,  click,  generateillustrations,
                clickcontinue,  ifsccode,  bankaccno,  accholdername,  accounttype,  pennyalert,
                clickverify,renewpremiumscreentitle,bankname,mobileno,pannumber,emailaddress);
       waitUtils.wait5Seconds();
       //enachPage.directBill
       commonUtils.selectButtonByName("Direct Bill",driver);
       waitUtils.wait2Seconds();
       commonUtils.selectButtonByName("SAVE",driver);
       waitUtils.wait2Seconds();
       String actualMessage= enachPage.getPaymentStatus.getText();
       waitUtils.Asserting("equals",actualMessage,"DIRECT BILL");
       waitUtils.wait2Seconds();
       commonUtils.selectButtonByName("NEXT",driver);
       waitUtils.Asserting("equals",enachPage.titleOfPage.getText(),"ADD NOMINEE");




    }
   // @Test(dataProvider = "dataEnachProvider",priority = 8)
    @Description("verify user able to register multiple times")
    public void verify_Duplicate_marchants(String username, String password, String policy, String leadid, String proposersame, String propinsurednotsame, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                         String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                         String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                         String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                         String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                         String clickverify,String renewpremiumscreentitle, String bankname, String mobileno, String pannumber, String emailaddress) throws Exception {


        new TestFactory().gotoEnachRegistration(driver,username,  password,  policy,  leadid,  proposersame,  propinsurednotsame,  isnri,  pmobile,  ppan,  imobile,  ipan,  firstname,  lastname,
                middlename,  day,  month,  year,  gender,  planjourney,  proposerstate,  advisorstatesame,  plan,  sumassured,  smokertype,  planoptions,  increasinglevel,
                ecs,  term,  ppt,  premiumterm,  premiumamount,
                rider,  rideramount,  minrider,  maxrider,  ridererror,  click,  generateillustrations,
                clickcontinue,  ifsccode,  bankaccno,  accholdername,  accounttype,  pennyalert,
                clickverify,renewpremiumscreentitle,bankname,mobileno,pannumber,emailaddress);
        waitUtils.waitForElementToBeClickable(driver, enachPage.resiterNowlink);
        enachPage.enachRegistrationLink("Register Now");        //
        waitUtils.wait10Seconds();
        waitUtils.WaitForElementPresent(driver, enachPage.registerPopUp(), 30);

        if (waitUtils.checkIfElementPresent(driver, enachPage.registerPopUp())) {
            //waitUtils.wait10Seconds();
            commonUtils.scrollTillEndOfPage(driver);
            //enachPage.enachReSelectBank();
            waitUtils.wait2Seconds();
            enachPage.selectBankFromList(bankname);
            waitUtils.wait10Seconds();
            //commonUtils.scrolltopageend(driver);
           // waitUtils.wait2Seconds();
            // enachPage.getEnachPhone.click();
            enachPage.setEnachPhoneNumber(mobileno);
            //enachPage.getEnachPan.click();
            enachPage.setEnachPanNumber(pannumber);
            //enachPage.getEnachEmail.click();
            enachPage.setEnachEmailAddress(emailaddress);
            enachPage.registerAfterSelectBank("Register Now");
            waitUtils.wait10Seconds();
            waitUtils.Asserting("equals",enachPage.dangerMessage.getText(),"We are unable to process your request! Duplicate Merchant Request No");

        }
    }
}
