package tests.journeys;

import com.absli.helpers.dataProviders.DataProviders;
import com.absli.helpers.jsonReaders.ReadJson;
import com.absli.listeners.RetryAnalyzer;
import com.absli.listeners.TestLevelDriverCreator;
import com.absli.pageObjects.CreateApplPage;
import com.absli.pageObjects.ReviewAcceptPage;
import com.absli.pageObjects.SignInPage;
import com.absli.utils.CommonUtils;
import com.absli.utils.PropertiesUtils;
import com.absli.utils.WaitUtils;
import io.qameta.allure.Description;
import org.jsoup.Connection;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import tests.BaseTest;
import tests.TestFactory;
import java.io.IOException;

@Listeners({TestLevelDriverCreator.class})
public class ReviewAcceptTest extends BaseTest {

    ReadJson jsonObj;
    CreateApplPage createApplPage;
    CommonUtils commonUtils;
    WaitUtils waitUtils;
    PropertiesUtils prop;
    SignInPage signIn;
    ReviewAcceptPage rna;

    @BeforeClass
    public void preSetup() throws IOException, InterruptedException {
        driver = new TestLevelDriverCreator().getDriver();
        commonUtils = new CommonUtils();
        waitUtils = new WaitUtils();
        prop = new PropertiesUtils();
        rna  =  new ReviewAcceptPage(driver);
    }

    @BeforeMethod
    public void relaunch()  {
        new BaseTest().relaunch();
    }

    @Test(dataProvider = "rnaDataProvider",dataProviderClass = DataProviders.class,priority = 1)
    @Description("Verify the information shown in rna page and verify otp")
    public void rna_otp_verification(String username, String password, String policy, String leadid, String proposersame,
                                     String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                     String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                     String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                     String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                     String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                     String clickverify, String renewpremiumscreentitle,String paymentmethod,String drawdate,String fundsource,
                                     String nomineescreentitle,String nomineefirstname,String 	nomineelastname,String 	nomineeday,
                                     String nomineemonth,String 	nomineeyear,String 	nomineegender,String 	relationshipwithproposer,String 	nomineeshare,
                                     String ismwppolicy,String addressscreentitle, String typeofaddress ,String addresspincode ,String address1 ,String address2 ,String address3 ,String personalDetailsscreentitle ,String cityName ,String
                                             preferredLanguage ,String alernateNumber ,String resTelephoneNumber ,String emailaddressValidations ,String maritalStatus ,String
                                             fathersNameOrSpouseName ,String mothersName ,String MaidenName,String qualification ,String occupation ,String employeerName ,String
                                             nameOfBusinessOrduties ,String typeOfOrganization ,String designation ,String annualIncome ,String policyStatus ,String exPolicyscreenTitle ,String exNameofInsurer ,String
                                             exSumAssured ,String expolicyNumber ,String exyearOfApplication ,String exbasePlan ,String exannualpremium ,String medicalPolicy ,String expolicystatus ,String
                                             refPolicyscreenTitle ,String refinsurerName ,String refsumAssured ,String refreason ,String refinsurerName1 ,String refsumAssured1 ,String refreason1 ,String
                                             refinsurerName2 ,String refsumAssured2 ,String refreason2 ,String refinsurerName3 ,String refsumAssured3 ,String refreason3 ,String
                                             refinsurerName4 ,String refsumAssured4 ,String refreason4 ,String policyPurposeScreen ,String purposeOption1 ,String purposeOption2 ,String purposeOption3 ,String
                                             healthDetailsScreen ,String height,String 	weight,String 	weightchange,String symptomsDetails ,String testsDetails ,String covidContactDetails ,String quarantineDetails ,String healthDetails ,String
                                             pastTravelContry ,String pastTravelCity ,String pastTravelArrivalDay ,String pastTravelArraivalMonth ,String pastTravelArraivalYear ,String
                                             pastTravelDepartureDay ,String pastTravelDepartureMonth ,String pastTravelDepartureYear ,String futureTravelCountry ,String futureTravelCity ,String
                                             futureTravelDepartureDay ,String futureTravelDepartureMonth ,String futureTravelDepartureYear ,String futureInternedDuration ,String
                                             covidVaccinationFirstDoseDay ,String covidVaccinationFirstDoseMonth ,String covidVaccinationFirstDoseYear ,String covidVaccinationSecondDoseDay ,String
                                             covidVaccinationSecondDoseMonth ,String covidVaccinationSecondDoseYear ,String covidVaccineName ,String postVaccineDetails ,String
                                             covidOccupation ,String medicalSpeciality ,String exactNatureOfDuties ,String nameOfHealthCareFacility ,String
                                             addressOfHealthCareFacility ,String healthAuthorityRegistered ,String covidWardDetails ,String diagnoseDay ,String
                                             diagnoseMonth ,String diagnoseYear ,String daignoseTestName ,String receivedCovid19Test1 ,String receivedCovid19Test2 ,String receivedCovid19Test3 ,String
                                             admissionDay ,String admissionMonth ,String admissionYear ,String dischargeDay ,String dischargeMonth ,String dischargeYear ,String
                                             covidInfectionDetails ,String covidSymptoms1 ,String covidSymptoms2 ,String covidSymptoms3 ,String recoveryDay ,String recoveryMonth ,String recoveryYear ,String
                                             testsName ,String testTakenDay ,String testTakenMonth ,String testTakenYear ,String certifiedDetails ) throws InterruptedException, IOException {

        new TestFactory().goToRna(driver, username, password, policy, leadid, proposersame, relationwithinsured, isrelationanswer, isnri, pmobile, ppan, imobile, ipan, firstname, lastname,
                middlename, day, month, year, gender, planjourney, proposerstate, advisorstatesame, plan, sumassured, smokertype, planoptions, increasinglevel,
                ecs, term, ppt, premiumterm, premiumamount,
                rider, rideramount, minrider, maxrider, ridererror, click, generateillustrations,
                clickcontinue, ifsccode, bankaccno, accholdername, accounttype, pennyalert,
                clickverify, renewpremiumscreentitle, paymentmethod, drawdate, fundsource,
                nomineescreentitle, nomineefirstname, nomineelastname, nomineeday, nomineemonth, nomineeyear, nomineegender, relationshipwithproposer, nomineeshare,
                ismwppolicy, addressscreentitle, typeofaddress, addresspincode, address1, address2, address3, personalDetailsscreentitle, cityName,
                preferredLanguage, alernateNumber, resTelephoneNumber, emailaddressValidations, maritalStatus,
                fathersNameOrSpouseName, mothersName, MaidenName, qualification, occupation, employeerName,
                nameOfBusinessOrduties, typeOfOrganization, designation, annualIncome, policyStatus, exPolicyscreenTitle, exNameofInsurer,
                exSumAssured, expolicyNumber, exyearOfApplication, exbasePlan, exannualpremium, medicalPolicy, expolicystatus,
                refPolicyscreenTitle, refinsurerName, refsumAssured, refreason, refinsurerName1, refsumAssured1, refreason1,
                refinsurerName2, refsumAssured2, refreason2, refinsurerName3, refsumAssured3, refreason3,
                refinsurerName4, refsumAssured4, refreason4, policyPurposeScreen, purposeOption1, purposeOption2, purposeOption3,
                healthDetailsScreen, height, weight, weightchange, symptomsDetails, testsDetails, covidContactDetails, quarantineDetails, healthDetails,
                pastTravelContry, pastTravelCity, pastTravelArrivalDay, pastTravelArraivalMonth, pastTravelArraivalYear,
                pastTravelDepartureDay, pastTravelDepartureMonth, pastTravelDepartureYear, futureTravelCountry, futureTravelCity,
                futureTravelDepartureDay, futureTravelDepartureMonth, futureTravelDepartureYear, futureInternedDuration,
                covidVaccinationFirstDoseDay, covidVaccinationFirstDoseMonth, covidVaccinationFirstDoseYear, covidVaccinationSecondDoseDay,
                covidVaccinationSecondDoseMonth, covidVaccinationSecondDoseYear, covidVaccineName, postVaccineDetails,
                covidOccupation, medicalSpeciality, exactNatureOfDuties, nameOfHealthCareFacility,
                addressOfHealthCareFacility, healthAuthorityRegistered, covidWardDetails, diagnoseDay,
                diagnoseMonth, diagnoseYear, daignoseTestName, receivedCovid19Test1, receivedCovid19Test2, receivedCovid19Test3,
                admissionDay, admissionMonth, admissionYear, dischargeDay, dischargeMonth, dischargeYear,
                covidInfectionDetails, covidSymptoms1, covidSymptoms2, covidSymptoms3, recoveryDay, recoveryMonth, recoveryYear,
                testsName, testTakenDay, testTakenMonth, testTakenYear, certifiedDetails);

        Assert.assertTrue(rna.eleRnaNavText.isDisplayed());
        System.out.println(("APPLNS NO ------" + rna.eleApplNumberValue.getText()));
        Assert.assertNotNull(rna.eleApplNumberValue.getText());
        System.out.println(("APPLNS sum ------" + rna.eleSumAssuredValue.getText()));
        Assert.assertNotNull(rna.eleSumAssuredValue.getText());
        System.out.println(("APPLNS premium ------" + rna.elePremiumAmountValue.getText()));
        Assert.assertNotNull(rna.elePremiumAmountValue.getText());

        /*commonUtils.chooseActionButton(rna.eleProposerTab);
        System.out.println(("Proposer name ------" + rna.getProposerName()));
        System.out.println(("Proposer mobile ------" + rna.getProposerMobile()));
        rna.getProposerName().contains(firstname);
        rna.getProposerMobile().contains(pmobile);*/

        //click on checkbox
        commonUtils.scrollTillEndOfPage(driver);
        while(!commonUtils.isDisplayed(driver,rna.eleAgreeCheckbox)) {
                commonUtils.scrollTillEndOfPage(driver);
            }
        commonUtils.scrollTillEndOfPage(driver);
        waitUtils.wait2Seconds();
        waitUtils.waitUntilVisible(driver,rna.eleAgreeCheckbox,50);
        commonUtils.chooseActionButton(rna.eleAgreeCheckbox);
        commonUtils.chooseActionButton(rna.eleSendForReviewBtn);
        waitUtils.waitUntilVisible(driver, rna.eleStatusReview, 40);

        if (new BaseTest().isWeb()) {
            waitUtils.waitUntilPageLoad(driver);
        }

        waitUtils.waitUntilVisible(driver,rna.eleStatusReview,40);
        if (new BaseTest().isWeb()) {
            commonUtils.chooseActionButton(rna.eleEnterOtpBtn);
        }
        waitUtils.waitUntilVisible(driver,rna.eleOtpInput,40);
        rna.inputOtp("111111");
        waitUtils.waitUntilVisible(driver,rna.eleStatusAccept,40);
        Assert.assertTrue(rna.eleStatusAccept.isDisplayed(),"Payment screen is not displayed");

        /*commonUtils.chooseActionButton(rna.eleProceedBtn);
        waitUtils.waitUntilVisible(driver,rna.elePaymentNavText,40);
        Assert.assertTrue(rna.elePaymentNavText.isDisplayed(),"Payment screen is not displayed");*/
    }

    //@Test(dataProvider = "rnaDataProvider",dataProviderClass = DataProviders.class,priority = 1,enabled = false)
    @Description("Verify the information shown in rna page")
    public void edit_application(String username, String password, String policy, String leadid, String proposersame,
                                   String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                   String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                   String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                   String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                   String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                   String clickverify, String renewpremiumscreentitle,String paymentmethod,String drawdate,String fundsource,
                                   String nomineescreentitle,String nomineefirstname,String 	nomineelastname,String 	nomineeday,
                                   String nomineemonth,String 	nomineeyear,String 	nomineegender,String 	relationshipwithproposer,String 	nomineeshare,
                                   String ismwppolicy,String addressscreentitle, String typeofaddress ,String addresspincode ,String address1 ,String address2 ,String address3 ,String personalDetailsscreentitle ,String cityName ,String
                                           preferredLanguage ,String alernateNumber ,String resTelephoneNumber ,String emailaddressValidations ,String maritalStatus ,String
                                           fathersNameOrSpouseName ,String mothersName ,String MaidenName,String qualification ,String occupation ,String employeerName ,String
                                           nameOfBusinessOrduties ,String typeOfOrganization ,String designation ,String annualIncome ,String policyStatus ,String exPolicyscreenTitle ,String exNameofInsurer ,String
                                           exSumAssured ,String expolicyNumber ,String exyearOfApplication ,String exbasePlan ,String exannualpremium ,String medicalPolicy ,String expolicystatus ,String
                                           refPolicyscreenTitle ,String refinsurerName ,String refsumAssured ,String refreason ,String refinsurerName1 ,String refsumAssured1 ,String refreason1 ,String
                                           refinsurerName2 ,String refsumAssured2 ,String refreason2 ,String refinsurerName3 ,String refsumAssured3 ,String refreason3 ,String
                                           refinsurerName4 ,String refsumAssured4 ,String refreason4 ,String policyPurposeScreen ,String purposeOption1 ,String purposeOption2 ,String purposeOption3 ,String
                                           healthDetailsScreen ,String height,String 	weight,String 	weightchange,String symptomsDetails ,String testsDetails ,String covidContactDetails ,String quarantineDetails ,String healthDetails ,String
                                           pastTravelContry ,String pastTravelCity ,String pastTravelArrivalDay ,String pastTravelArraivalMonth ,String pastTravelArraivalYear ,String
                                           pastTravelDepartureDay ,String pastTravelDepartureMonth ,String pastTravelDepartureYear ,String futureTravelCountry ,String futureTravelCity ,String
                                           futureTravelDepartureDay ,String futureTravelDepartureMonth ,String futureTravelDepartureYear ,String futureInternedDuration ,String
                                           covidVaccinationFirstDoseDay ,String covidVaccinationFirstDoseMonth ,String covidVaccinationFirstDoseYear ,String covidVaccinationSecondDoseDay ,String
                                           covidVaccinationSecondDoseMonth ,String covidVaccinationSecondDoseYear ,String covidVaccineName ,String postVaccineDetails ,String
                                           covidOccupation ,String medicalSpeciality ,String exactNatureOfDuties ,String nameOfHealthCareFacility ,String
                                           addressOfHealthCareFacility ,String healthAuthorityRegistered ,String covidWardDetails ,String diagnoseDay ,String
                                           diagnoseMonth ,String diagnoseYear ,String daignoseTestName ,String receivedCovid19Test1 ,String receivedCovid19Test2 ,String receivedCovid19Test3 ,String
                                           admissionDay ,String admissionMonth ,String admissionYear ,String dischargeDay ,String dischargeMonth ,String dischargeYear ,String
                                           covidInfectionDetails ,String covidSymptoms1 ,String covidSymptoms2 ,String covidSymptoms3 ,String recoveryDay ,String recoveryMonth ,String recoveryYear ,String
                                           testsName ,String testTakenDay ,String testTakenMonth ,String testTakenYear ,String certifiedDetails ) throws InterruptedException, IOException {

        new TestFactory().goToRna(driver, username,  password,  policy,  leadid,  proposersame,  relationwithinsured,	isrelationanswer,  isnri,  pmobile,  ppan,  imobile,  ipan,  firstname,  lastname,
                middlename,  day,  month,  year,  gender,  planjourney,  proposerstate,  advisorstatesame,  plan,  sumassured,  smokertype,  planoptions,  increasinglevel,
                ecs,  term,  ppt,  premiumterm,  premiumamount,
                rider,  rideramount,  minrider,  maxrider,  ridererror,  click,  generateillustrations,
                clickcontinue,  ifsccode,  bankaccno,  accholdername,  accounttype,  pennyalert,
                clickverify,  renewpremiumscreentitle, paymentmethod, drawdate, fundsource,
                nomineescreentitle,   nomineefirstname, nomineelastname, nomineeday, nomineemonth, nomineeyear, nomineegender, relationshipwithproposer, nomineeshare,
                ismwppolicy, addressscreentitle,typeofaddress ,  addresspincode ,  address1 ,  address2 ,  address3 ,  personalDetailsscreentitle ,  cityName ,
                preferredLanguage ,  alernateNumber ,  resTelephoneNumber ,  emailaddressValidations ,  maritalStatus ,
                fathersNameOrSpouseName ,  mothersName ,  MaidenName,qualification ,  occupation ,  employeerName ,
                nameOfBusinessOrduties ,  typeOfOrganization ,  designation ,  annualIncome ,  policyStatus ,  exPolicyscreenTitle ,  exNameofInsurer ,
                exSumAssured ,  expolicyNumber ,  exyearOfApplication ,  exbasePlan ,  exannualpremium ,  medicalPolicy ,  expolicystatus ,
                refPolicyscreenTitle ,  refinsurerName ,  refsumAssured ,  refreason ,  refinsurerName1 ,  refsumAssured1 ,  refreason1 ,
                refinsurerName2 ,  refsumAssured2 ,  refreason2 ,  refinsurerName3 ,  refsumAssured3 ,  refreason3 ,
                refinsurerName4 ,  refsumAssured4 ,  refreason4 ,  policyPurposeScreen ,  purposeOption1 ,  purposeOption2 ,  purposeOption3 ,
                healthDetailsScreen ,   height, 	weight, 	weightchange,symptomsDetails ,  testsDetails ,  covidContactDetails ,  quarantineDetails ,  healthDetails ,
                pastTravelContry ,  pastTravelCity ,  pastTravelArrivalDay ,  pastTravelArraivalMonth ,  pastTravelArraivalYear ,
                pastTravelDepartureDay ,  pastTravelDepartureMonth ,  pastTravelDepartureYear ,  futureTravelCountry ,  futureTravelCity ,
                futureTravelDepartureDay ,  futureTravelDepartureMonth ,  futureTravelDepartureYear ,  futureInternedDuration ,
                covidVaccinationFirstDoseDay ,  covidVaccinationFirstDoseMonth ,  covidVaccinationFirstDoseYear ,  covidVaccinationSecondDoseDay ,
                covidVaccinationSecondDoseMonth ,  covidVaccinationSecondDoseYear ,  covidVaccineName ,  postVaccineDetails ,
                covidOccupation ,  medicalSpeciality ,  exactNatureOfDuties ,  nameOfHealthCareFacility ,
                addressOfHealthCareFacility ,  healthAuthorityRegistered ,  covidWardDetails ,  diagnoseDay ,
                diagnoseMonth ,  diagnoseYear ,  daignoseTestName ,  receivedCovid19Test1 ,  receivedCovid19Test2 ,  receivedCovid19Test3 ,
                admissionDay ,  admissionMonth ,  admissionYear ,  dischargeDay ,  dischargeMonth ,  dischargeYear ,
                covidInfectionDetails ,  covidSymptoms1 ,  covidSymptoms2 ,  covidSymptoms3 ,  recoveryDay ,  recoveryMonth ,  recoveryYear ,
                testsName ,  testTakenDay ,  testTakenMonth ,  testTakenYear ,  certifiedDetails);

        Assert.assertTrue(rna.eleRnaNavText.isDisplayed());
        System.out.println(("APPLNS NO ------" + rna.eleApplNumberValue.getText()));
        Assert.assertNotNull(rna.eleApplNumberValue.getText());
        System.out.println(("APPLNS sum ------" + rna.eleSumAssuredValue.getText()));
        Assert.assertNotNull(rna.eleSumAssuredValue.getText());
        System.out.println(("APPLNS premium ------" + rna.elePremiumAmountValue.getText()));
        Assert.assertNotNull(rna.elePremiumAmountValue.getText());

        commonUtils.chooseActionButton(rna.eleProposerTab);
        System.out.println(("Proposer name ------" + rna.getProposerName()));
        System.out.println(("Proposer mobile ------" + rna.getProposerMobile()));
        rna.getProposerName().contains(firstname);
        rna.getProposerMobile().contains(pmobile);

        commonUtils.scrollTillEndOfPage(driver);
        commonUtils.chooseActionButton(rna.eleAgreeCheckbox);
        commonUtils.chooseActionButton(rna.eleSendForReviewBtn);
        waitUtils.waitUntilVisible(driver,rna.eleRnaNavText,40);

        if(new BaseTest().isWeb()) {
            waitUtils.waitUntilPageLoad(driver);
        }
        ////
        commonUtils.scrollTillEndOfPage(driver);
        commonUtils.scrollTillEndOfPage(driver);
        commonUtils.chooseActionButton(rna.wlwRnaEditBtn);

        waitUtils.waitUntilVisible(driver,rna.eleRnaEditAlert,30);
        commonUtils.chooseActionButton(rna.eleAlertYesbtn);
        commonUtils.scrollTillEndOfPage(driver);
        commonUtils.chooseActionButton(rna.eleAgreeCheckbox);
        commonUtils.chooseActionButton(rna.eleSendForReviewBtn);

    }



}
