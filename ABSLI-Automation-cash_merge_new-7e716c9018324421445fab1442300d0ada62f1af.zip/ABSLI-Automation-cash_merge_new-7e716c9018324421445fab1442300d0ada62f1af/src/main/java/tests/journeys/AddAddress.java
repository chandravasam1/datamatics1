package tests.journeys;

import com.absli.helpers.dataProviders.DataProviders;
import com.absli.helpers.jsonReaders.ReadJson;
import com.absli.helpers.models.ProposerModel;
import com.absli.listeners.TestLevelDriverCreator;
import com.absli.listeners.TestListener;
import com.absli.pageObjects.CreateApplPage;
import com.absli.pageObjects.SignInPage;
import com.absli.utils.CommonUtils;
import com.absli.utils.PropertiesUtils;
import com.absli.utils.WaitUtils;
import io.qameta.allure.Description;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.annotations.*;
import tests.BaseTest;
import tests.TestFactory;

import java.io.IOException;

@Listeners(TestListener.class)
public class AddAddress extends BaseTest {


    ProposerModel proposerModel;
    ReadJson jsonObj;
    CreateApplPage createApplPage;
    CommonUtils commonUtils;
    WaitUtils waitUtils;
    PropertiesUtils prop;
    SignInPage signIn;

    @BeforeClass
    public void preSetup() throws IOException, InterruptedException {
        driver = new TestLevelDriverCreator().getDriver();
        commonUtils = new CommonUtils();
        waitUtils = new WaitUtils();
        createApplPage = new CreateApplPage(driver);
        prop = new PropertiesUtils();
    }

    @BeforeMethod
    public void relaunch() {
        new BaseTest().relaunch();

    }

    @Test(dataProvider = "dataAddressProvider", dataProviderClass = DataProviders.class, priority = 1)
    @Description("Verify if User is able to navigate to Address screen")
    public void add_address_navigation(String username, String password, String policy, String leadid, String proposersame,
                                       String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                       String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                       String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                       String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                       String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                       String clickverify, String renewpremiumscreentitle, String paymentmethod, String drawdate, String fundsource,
                                       String nomineescreentitle, String nomineefirstname, String nomineelastname, String nomineeday,
                                       String nomineemonth, String nomineeyear, String nomineegender, String relationshipwithproposer, String nomineeshare,
                                       String ismwppolicy,
                                       String addressscreentitle, String typeofaddress, String addresspincode, String address1, String address2, String address3, String personalDetailsscreentitle, String cityName, String preferredLanguage, String alernateNumber, String resTelephoneNumber) throws Exception {
        

        createApplPage.chooseSignAndGoToLeadIdScreen(username, password, policy);
        createApplPage.fillLeadIdAndProceed(leadid, proposersame, isnri);
        createApplPage.captureMobilePanAndProceed(pmobile, ppan);
        createApplPage.prefillDetails(firstname, lastname, middlename, day, month, year, gender);
        createApplPage.choosePlanAndProceedToViewQuote(planjourney, proposerstate, advisorstatesame, plan);
        createApplPage.createQuote(sumassured, smokertype, planoptions, increasinglevel, ecs, term, ppt, premiumterm, premiumamount);

        commonUtils.selectButtonByName("SAVE", driver);
        waitUtils.waitForElementToBeVisible(driver, createApplPage.elePlanSummaryNavText, 30, "Didnt navigate to plan summary screen");
        commonUtils.selectButtonByName(clickcontinue, driver);
        waitUtils.waitForElementToBeVisible(driver,createApplPage.instaVerifyScreenTitle,50,"didn't navigate to the insta verify page");
        createApplPage.skipInstaVerifyPage();
        waitUtils.waitForElementToBeVisible(driver, createApplPage.eleBankNavText, 30, "Didnt navigate to bank details screen");

        createApplPage.inputIfscCode(ifsccode);
        waitUtils.waitForElementToBeVisible(driver, createApplPage.eleIfscVerifyTick, 30, "IFSC code is not validated");
        Assert.assertTrue(createApplPage.eleIfscVerifyTick.isDisplayed(), "Ifsc code is not verified");

        Assert.assertNotNull(createApplPage.elebankName.getText(), "Bank name is not prefilled");
        Assert.assertNotNull(createApplPage.elebranchName.getText(), "Branch name is not prefilled");

        commonUtils.scrollIntoView("Account Details", driver);
        createApplPage.inputAccNo("23243434343");
        createApplPage.chooseAccountType(accounttype);
        commonUtils.scrollIntoView(clickverify, driver);
        commonUtils.selectButtonByName(clickverify, driver);

        waitUtils.waitUntilElementIsVisibleByText(driver, 30, pennyalert, "Account not verified alert is not shown");
        waitUtils.implicitWait(driver, 2000);
        commonUtils.selectButtonByName("OK", driver);
        Assert.assertNotNull(createApplPage.eleInputAccHolderName.getText());
        commonUtils.selectButtonByName("NEXT", driver);
        waitUtils.waitUntilElementIsVisibleByText(driver, 30, "Renewal Premium", "Renewal screen is not displayed");
        Assert.assertEquals(createApplPage.validateScreenTitle(renewpremiumscreentitle), "Renewal Premium", "Failure in navigation to renewal premium screen");


        createApplPage.choosePaymentMethod(paymentmethod);
        createApplPage.chooseDrawDate(drawdate);
        createApplPage.chooseSourceOfFund(fundsource);

        commonUtils.scrollTillEndOfPage(driver);
        //Assert.assertEquals(createApplPage.getPremiumValueFromRenewalScreen(), commonUtils.decimalFormatter(premiumamount), "Premium amount shown in renewal screen is different than quote");
        //Assert.assertTrue(createApplPage.getPaymentFreqFromRenewalScreen().contains(premiumterm), "Premium period shown in renewal screen is different than quote");
        commonUtils.selectButtonByName("SAVE", driver);
        waitUtils.waitUntilElementIsVisibleByText(driver, 40, "NEXT", "Next button is not shown");
        commonUtils.selectButtonByName("NEXT", driver);
        waitUtils.waitUntilElementIsVisibleByText(driver, 30, nomineescreentitle, "Renewal screen is not displayed");
        waitUtils.implicitWait(driver, 100);
        //Assert.assertEquals(createApplPage.validateScreenTitle(nomineescreentitle), nomineescreentitle, "Failure in navigation to renewal premium screen");


        createApplPage.inputFirstName(nomineefirstname);
        createApplPage.inputNomineeLastName(nomineelastname);
        createApplPage.inputNomineeDOB(day, month, year);
        createApplPage.chooseNomineeGender(nomineegender);
        commonUtils.scrollTillEndOfPage(driver);
        Thread.sleep(3000);
        createApplPage.chooseNomineeRelationship(relationshipwithproposer);
        waitUtils.implicitWait(driver, 3000);
        createApplPage.inputNomineeShare(nomineeshare);
        waitUtils.implicitWait(driver, 1000);
        commonUtils.selectButtonByName("SAVE", driver);
        waitUtils.waitUntilElementIsVisibleByText(driver, 30, addressscreentitle, "add address screen is not displayed");
        waitUtils.implicitWait(driver, 100);
        commonUtils.selectButtonByName("NEXT", driver);
        waitUtils.implicitWait(driver, 100);
        commonUtils.selectButtonByName("NEXT", driver);
        Assert.assertEquals(createApplPage.validateScreenTitle(addressscreentitle), addressscreentitle, "Failure in navigation to add address screen");

    }
    @Test(dataProvider = "dataAddressProvider", dataProviderClass = DataProviders.class, priority = 2)
    @Description("Add Address permanent address same as communication address ")
    public void add_address(String username, String password, String policy, String leadid, String proposersame,
                            String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                            String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                            String ecs, String term, String ppt, String premiumterm, String premiumamount,
                            String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                            String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                            String clickverify, String renewpremiumscreentitle, String paymentmethod, String drawdate, String fundsource,
                            String nomineescreentitle, String nomineefirstname, String nomineelastname, String nomineeday,
                            String nomineemonth, String nomineeyear, String nomineegender, String relationshipwithproposer, String nomineeshare,
                            String ismwppolicy,
                            String addressscreentitle, String typeofaddress, String addresspincode, String address1, String address2, String address3, String personalDetailsscreentitle, String cityName, String preferredLanguage, String alernateNumber, String resTelephoneNumber) throws Exception {

        createApplPage.chooseSignAndGoToLeadIdScreen(username, password, policy);
        createApplPage.fillLeadIdAndProceed(leadid, proposersame, isnri);
        createApplPage.captureMobilePanAndProceed(pmobile, ppan);
        createApplPage.prefillDetails(firstname, lastname, middlename, day, month, year, gender);
        createApplPage.choosePlanAndProceedToViewQuote(planjourney, proposerstate, advisorstatesame, plan);
        createApplPage.createQuote(sumassured, smokertype, planoptions, increasinglevel, ecs, term, ppt, premiumterm, premiumamount);

        commonUtils.selectButtonByName("SAVE", driver);
        waitUtils.waitForElementToBeVisible(driver, createApplPage.elePlanSummaryNavText, 30, "Didnt navigate to plan summary screen");
        commonUtils.selectButtonByName(clickcontinue, driver);
        waitUtils.waitForElementToBeVisible(driver,createApplPage.instaVerifyScreenTitle,50,"didn't navigate to the insta verify page");
        createApplPage.skipInstaVerifyPage();
        waitUtils.waitForElementToBeVisible(driver, createApplPage.eleBankNavText, 30, "Didnt navigate to bank details screen");

        createApplPage.inputIfscCode(ifsccode);
        waitUtils.waitForElementToBeVisible(driver, createApplPage.eleIfscVerifyTick, 30, "IFSC code is not validated");
        Assert.assertTrue(createApplPage.eleIfscVerifyTick.isDisplayed(), "Ifsc code is not verified");

        Assert.assertNotNull(createApplPage.elebankName.getText(), "Bank name is not prefilled");
        Assert.assertNotNull(createApplPage.elebranchName.getText(), "Branch name is not prefilled");

        commonUtils.scrollIntoView("Account Details", driver);
        createApplPage.inputAccNo("23243434343");
        createApplPage.chooseAccountType(accounttype);
        commonUtils.scrollIntoView(clickverify, driver);
        commonUtils.selectButtonByName(clickverify, driver);

        waitUtils.waitUntilElementIsVisibleByText(driver, 30, pennyalert, "Account not verified alert is not shown");
        waitUtils.implicitWait(driver, 2000);
        commonUtils.selectButtonByName("OK", driver);
        Assert.assertNotNull(createApplPage.eleInputAccHolderName.getText());
        commonUtils.selectButtonByName("NEXT", driver);
        waitUtils.waitUntilElementIsVisibleByText(driver, 30, "Renewal Premium", "Renewal screen is not displayed");
        Assert.assertEquals(createApplPage.validateScreenTitle(renewpremiumscreentitle), "Renewal Premium", "Failure in navigation to renewal premium screen");


        createApplPage.choosePaymentMethod(paymentmethod);
        createApplPage.chooseDrawDate(drawdate);
        createApplPage.chooseSourceOfFund(fundsource);

        commonUtils.scrollTillEndOfPage(driver);
        //Assert.assertEquals(createApplPage.getPremiumValueFromRenewalScreen(), commonUtils.decimalFormatter(premiumamount), "Premium amount shown in renewal screen is different than quote");
        //Assert.assertTrue(createApplPage.getPaymentFreqFromRenewalScreen().contains(premiumterm), "Premium period shown in renewal screen is different than quote");
        commonUtils.selectButtonByName("SAVE", driver);
        waitUtils.waitUntilElementIsVisibleByText(driver, 40, "NEXT", "Next button is not shown");
        commonUtils.selectButtonByName("NEXT", driver);
        waitUtils.waitUntilElementIsVisibleByText(driver, 30, nomineescreentitle, "Renewal screen is not displayed");
        waitUtils.implicitWait(driver, 100);
        //Assert.assertEquals(createApplPage.validateScreenTitle(nomineescreentitle), nomineescreentitle, "Failure in navigation to renewal premium screen");


        createApplPage.inputFirstName(nomineefirstname);
        createApplPage.inputNomineeLastName(nomineelastname);
        createApplPage.inputNomineeDOB(day, month, year);
        createApplPage.chooseNomineeGender(nomineegender);
        commonUtils.scrollTillEndOfPage(driver);
        Thread.sleep(3000);
        createApplPage.chooseNomineeRelationship(relationshipwithproposer);
        waitUtils.implicitWait(driver, 3000);
        createApplPage.inputNomineeShare(nomineeshare);
        waitUtils.implicitWait(driver, 1000);
        commonUtils.selectButtonByName("SAVE", driver);
        waitUtils.waitUntilElementIsVisibleByText(driver, 30, addressscreentitle, "add address screen is not displayed");
        waitUtils.implicitWait(driver, 100);
        commonUtils.selectButtonByName("NEXT", driver);
        waitUtils.implicitWait(driver, 100);
        commonUtils.selectButtonByName("NEXT", driver);
        //Assert.assertEquals(createApplPage.validateScreenTitle(addressscreentitle), addressscreentitle, "Failure in navigation to add address screen");

        waitUtils.implicitWait(driver, 1000);
        commonUtils.selectButtonByName("NEXT", driver);
        waitUtils.implicitWait(driver, 1000);
        commonUtils.selectButtonByName("NEXT", driver);
        createApplPage.chooseCommunicationAddress(typeofaddress);
        createApplPage.inputPincode(addresspincode);
        waitUtils.waitUntilElementIsVisibleByText(driver, 30, cityName, "City Name is not displayed");
        waitUtils.implicitWait(driver, 1000);
        Assert.assertEquals(createApplPage.getCityNameFromAddAddressScreen(), cityName, "Failure to fetch city name data");

        createApplPage.inputAddress1(address1);
        createApplPage.inputAddress2(address2);
        createApplPage.inputAddress3(address3);
        commonUtils.scrollTillEndOfPage(driver);
        commonUtils.selectButtonByName("SAVE", driver);
        waitUtils.implicitWait(driver, 1000);
        commonUtils.scrollTillEndOfPage(driver);
        commonUtils.selectButtonByName("NEXT", driver);
        //waitUtils.implicitWait(driver, 1000);
        waitUtils.waitUntilElementIsVisibleByText(driver,10,"NEXT","Next button is not visible");
        commonUtils.selectButtonByName("NEXT", driver);
        waitUtils.waitUntilElementIsVisibleByText(driver, 30, personalDetailsscreentitle, "Personal Details screen is not displayed");
        waitUtils.implicitWait(driver, 1000);
        Assert.assertEquals(createApplPage.validateScreenTitle(personalDetailsscreentitle), personalDetailsscreentitle, "Failure in navigation to Personal Details screen");
    }

    @Test(dataProvider = "dataAddressProvider", dataProviderClass = DataProviders.class, priority = 3)
    @Description("Add Address with other communication info ")
    public void add_address_other_communication(String username, String password, String policy, String leadid, String proposersame,
                                                String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                            String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                            String ecs, String term, String ppt, String premiumterm, String premiumamount,
                            String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                            String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                            String clickverify, String renewpremiumscreentitle, String paymentmethod, String drawdate, String fundsource,
                            String nomineescreentitle, String nomineefirstname, String nomineelastname, String nomineeday,
                            String nomineemonth, String nomineeyear, String nomineegender, String relationshipwithproposer, String nomineeshare,
                            String ismwppolicy,
                            String addressscreentitle, String typeofaddress, String addresspincode, String address1, String address2, String address3, String personalDetailsscreentitle, String cityName, String preferredLanguage, String alernateNumber, String resTelephoneNumber) throws Exception {

        createApplPage.chooseSignAndGoToLeadIdScreen(username, password, policy);
        createApplPage.fillLeadIdAndProceed(leadid, proposersame, isnri);
        createApplPage.captureMobilePanAndProceed(pmobile, ppan);
        createApplPage.prefillDetails(firstname, lastname, middlename, day, month, year, gender);
        createApplPage.choosePlanAndProceedToViewQuote(planjourney, proposerstate, advisorstatesame, plan);
        createApplPage.createQuote(sumassured, smokertype, planoptions, increasinglevel, ecs, term, ppt, premiumterm, premiumamount);

        commonUtils.selectButtonByName("SAVE", driver);
        waitUtils.waitForElementToBeVisible(driver, createApplPage.elePlanSummaryNavText, 30, "Didnt navigate to plan summary screen");
        commonUtils.selectButtonByName(clickcontinue, driver);
        waitUtils.waitForElementToBeVisible(driver,createApplPage.instaVerifyScreenTitle,50,"didn't navigate to the insta verify page");
        createApplPage.skipInstaVerifyPage();
        waitUtils.waitForElementToBeVisible(driver, createApplPage.eleBankNavText, 30, "Didnt navigate to bank details screen");

        createApplPage.inputIfscCode(ifsccode);
        waitUtils.waitForElementToBeVisible(driver, createApplPage.eleIfscVerifyTick, 30, "IFSC code is not validated");
        Assert.assertTrue(createApplPage.eleIfscVerifyTick.isDisplayed(), "Ifsc code is not verified");

        Assert.assertNotNull(createApplPage.elebankName.getText(), "Bank name is not prefilled");
        Assert.assertNotNull(createApplPage.elebranchName.getText(), "Branch name is not prefilled");

        commonUtils.scrollIntoView("Account Details", driver);
        createApplPage.inputAccNo("23243434343");
        createApplPage.chooseAccountType(accounttype);
        commonUtils.scrollIntoView(clickverify, driver);
        commonUtils.selectButtonByName(clickverify, driver);

        waitUtils.waitUntilElementIsVisibleByText(driver, 30, pennyalert, "Account not verified alert is not shown");
        waitUtils.implicitWait(driver, 2000);
        commonUtils.selectButtonByName("OK", driver);
        Assert.assertNotNull(createApplPage.eleInputAccHolderName.getText());
        commonUtils.selectButtonByName("NEXT", driver);
        waitUtils.waitUntilElementIsVisibleByText(driver, 30, "Renewal Premium", "Renewal screen is not displayed");
        Assert.assertEquals(createApplPage.validateScreenTitle(renewpremiumscreentitle), "Renewal Premium", "Failure in navigation to renewal premium screen");


        createApplPage.choosePaymentMethod(paymentmethod);
        createApplPage.chooseDrawDate(drawdate);
        createApplPage.chooseSourceOfFund(fundsource);

        commonUtils.scrollTillEndOfPage(driver);
        //Assert.assertEquals(createApplPage.getPremiumValueFromRenewalScreen(), commonUtils.decimalFormatter(premiumamount), "Premium amount shown in renewal screen is different than quote");
        //Assert.assertTrue(createApplPage.getPaymentFreqFromRenewalScreen().contains(premiumterm), "Premium period shown in renewal screen is different than quote");
        commonUtils.selectButtonByName("SAVE", driver);
        waitUtils.waitUntilElementIsVisibleByText(driver, 40, "NEXT", "Next button is not shown");
        commonUtils.selectButtonByName("NEXT", driver);
        waitUtils.waitUntilElementIsVisibleByText(driver, 30, nomineescreentitle, "Renewal screen is not displayed");
        waitUtils.implicitWait(driver, 100);
        //Assert.assertEquals(createApplPage.validateScreenTitle(nomineescreentitle), nomineescreentitle, "Failure in navigation to renewal premium screen");


        createApplPage.inputFirstName(nomineefirstname);
        createApplPage.inputNomineeLastName(nomineelastname);
        createApplPage.inputNomineeDOB(day, month, year);
        createApplPage.chooseNomineeGender(nomineegender);
        commonUtils.scrollTillEndOfPage(driver);
        Thread.sleep(3000);
        createApplPage.chooseNomineeRelationship(relationshipwithproposer);
        waitUtils.implicitWait(driver, 3000);
        createApplPage.inputNomineeShare(nomineeshare);
        waitUtils.implicitWait(driver, 1000);
        commonUtils.selectButtonByName("SAVE", driver);
        waitUtils.waitUntilElementIsVisibleByText(driver, 30, addressscreentitle, "add address screen is not displayed");
        waitUtils.implicitWait(driver, 100);
        commonUtils.selectButtonByName("NEXT", driver);
        waitUtils.implicitWait(driver, 100);
        commonUtils.selectButtonByName("NEXT", driver);
        //Assert.assertEquals(createApplPage.getScreenTitle(), addressscreentitle, "Failure in navigation to add address screen");


        waitUtils.implicitWait(driver, 1000);
        commonUtils.selectButtonByName("NEXT", driver);
        waitUtils.implicitWait(driver, 1000);
        commonUtils.selectButtonByName("NEXT", driver);
        createApplPage.chooseCommunicationAddress(typeofaddress);
        createApplPage.inputPincode(addresspincode);

        createApplPage.inputAddress1(address1);
        createApplPage.inputAddress2(address2);
        createApplPage.inputAddress3(address3);
        //createApplPage.chooseCommunicationInfoPreferredLanguage(preferredLanguage);
        commonUtils.scrollTillEndOfPage(driver);
        commonUtils.selectButtonByName("SAVE", driver);
        waitUtils.implicitWait(driver, 1000);
        commonUtils.scrollTillEndOfPage(driver);
        waitUtils.implicitWait(driver, 1000);
        commonUtils.selectButtonByName("NEXT", driver);
        waitUtils.implicitWait(driver, 1000);
        commonUtils.selectButtonByName("NEXT", driver);
        waitUtils.waitUntilElementIsVisibleByText(driver, 30, personalDetailsscreentitle, "Personal Details screen is not displayed");
        waitUtils.implicitWait(driver, 1000);
        Assert.assertEquals(createApplPage.getScreenTitle(), personalDetailsscreentitle, "Failure in navigation to Personal Details screen");
    }


    @Test(dataProvider = "dataAddressProvider", dataProviderClass = DataProviders.class, priority = 4)
    @Description("Verify if the user is able navigate back to Nominee page and come back ")
    public void add_address_navigation_back(String username, String password, String policy, String leadid, String proposersame,
                                            String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                       String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                       String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                       String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                       String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                       String clickverify, String renewpremiumscreentitle, String paymentmethod, String drawdate, String fundsource,
                                       String nomineescreentitle, String nomineefirstname, String nomineelastname, String nomineeday,
                                       String nomineemonth, String nomineeyear, String nomineegender, String relationshipwithproposer, String nomineeshare,
                                       String ismwppolicy,
                                       String addressscreentitle, String typeofaddress, String addresspincode, String address1, String address2, String address3, String personalDetailsscreentitle, String cityName, String preferredLanguage, String alernateNumber, String resTelephoneNumber) throws Exception {

        createApplPage.chooseSignAndGoToLeadIdScreen(username, password, policy);
        createApplPage.fillLeadIdAndProceed(leadid, proposersame, isnri);
        createApplPage.captureMobilePanAndProceed(pmobile, ppan);
        createApplPage.prefillDetails(firstname, lastname, middlename, day, month, year, gender);
        createApplPage.choosePlanAndProceedToViewQuote(planjourney, proposerstate, advisorstatesame, plan);
        createApplPage.createQuote(sumassured, smokertype, planoptions, increasinglevel, ecs, term, ppt, premiumterm, premiumamount);

        commonUtils.selectButtonByName("SAVE", driver);
        waitUtils.waitForElementToBeVisible(driver, createApplPage.elePlanSummaryNavText, 30, "Didnt navigate to plan summary screen");
        commonUtils.selectButtonByName(clickcontinue, driver);
        waitUtils.waitForElementToBeVisible(driver,createApplPage.instaVerifyScreenTitle,50,"didn't navigate to the insta verify page");
        createApplPage.skipInstaVerifyPage();
        waitUtils.waitForElementToBeVisible(driver, createApplPage.eleBankNavText, 30, "Didnt navigate to bank details screen");

        createApplPage.inputIfscCode(ifsccode);
        waitUtils.waitForElementToBeVisible(driver, createApplPage.eleIfscVerifyTick, 30, "IFSC code is not validated");
        Assert.assertTrue(createApplPage.eleIfscVerifyTick.isDisplayed(), "Ifsc code is not verified");

        Assert.assertNotNull(createApplPage.elebankName.getText(), "Bank name is not prefilled");
        Assert.assertNotNull(createApplPage.elebranchName.getText(), "Branch name is not prefilled");

        commonUtils.scrollIntoView("Account Details", driver);
        createApplPage.inputAccNo("23243434343");
        createApplPage.chooseAccountType(accounttype);
        commonUtils.scrollIntoView(clickverify, driver);
        commonUtils.selectButtonByName(clickverify, driver);

        waitUtils.waitUntilElementIsVisibleByText(driver, 30, pennyalert, "Account not verified alert is not shown");
        waitUtils.implicitWait(driver, 2000);
        commonUtils.selectButtonByName("OK", driver);
        Assert.assertNotNull(createApplPage.eleInputAccHolderName.getText());
        commonUtils.selectButtonByName("NEXT", driver);
        waitUtils.waitUntilElementIsVisibleByText(driver, 30, "Renewal Premium", "Renewal screen is not displayed");
        Assert.assertEquals(createApplPage.validateScreenTitle(renewpremiumscreentitle), "Renewal Premium", "Failure in navigation to renewal premium screen");


        createApplPage.choosePaymentMethod(paymentmethod);
        createApplPage.chooseDrawDate(drawdate);
        createApplPage.chooseSourceOfFund(fundsource);

        commonUtils.scrollTillEndOfPage(driver);
        //Assert.assertEquals(createApplPage.getPremiumValueFromRenewalScreen(), commonUtils.decimalFormatter(premiumamount), "Premium amount shown in renewal screen is different than quote");
        //Assert.assertTrue(createApplPage.getPaymentFreqFromRenewalScreen().contains(premiumterm), "Premium period shown in renewal screen is different than quote");
        commonUtils.selectButtonByName("SAVE", driver);
        waitUtils.waitUntilElementIsVisibleByText(driver, 40, "NEXT", "Next button is not shown");
        commonUtils.selectButtonByName("NEXT", driver);
        waitUtils.waitUntilElementIsVisibleByText(driver, 30, nomineescreentitle, "Renewal screen is not displayed");
        waitUtils.implicitWait(driver, 100);
        //Assert.assertEquals(createApplPage.validateScreenTitle(nomineescreentitle), nomineescreentitle, "Failure in navigation to renewal premium screen");


        createApplPage.inputFirstName(nomineefirstname);
        createApplPage.inputNomineeLastName(nomineelastname);
        createApplPage.inputNomineeDOB(day, month, year);
        createApplPage.chooseNomineeGender(nomineegender);
        commonUtils.scrollTillEndOfPage(driver);
        Thread.sleep(3000);
        createApplPage.chooseNomineeRelationship(relationshipwithproposer);
        waitUtils.implicitWait(driver, 3000);
        createApplPage.inputNomineeShare(nomineeshare);
        waitUtils.implicitWait(driver, 1000);
        commonUtils.selectButtonByName("SAVE", driver);
        waitUtils.waitUntilElementIsVisibleByText(driver, 30, addressscreentitle, "add address screen is not displayed");
        waitUtils.implicitWait(driver, 100);
        commonUtils.selectButtonByName("NEXT", driver);
        waitUtils.implicitWait(driver, 100);
        commonUtils.selectButtonByName("NEXT", driver);
        Assert.assertEquals(createApplPage.getScreenTitle(), addressscreentitle, "Failure in navigation to add address screen");
        createApplPage.navigationBackFromUI();
        waitUtils.implicitWait(driver, 1000);
        commonUtils.selectButtonByName("NEXT",driver);
        waitUtils.implicitWait(driver, 1000);
        commonUtils.selectButtonByName("NEXT",driver);
        Assert.assertEquals(createApplPage.getScreenTitle(), addressscreentitle, "Failure in navigation to add address screen");
    }
}
