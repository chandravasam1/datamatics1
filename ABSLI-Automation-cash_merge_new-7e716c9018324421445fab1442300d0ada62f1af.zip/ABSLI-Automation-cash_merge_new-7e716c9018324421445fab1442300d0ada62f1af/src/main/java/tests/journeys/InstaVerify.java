package tests.journeys;

import com.absli.helpers.dataProviders.DataProviders;
import com.absli.helpers.jsonReaders.ReadJson;
import com.absli.helpers.models.ProposerModel;
import com.absli.listeners.TestLevelDriverCreator;
import com.absli.pageObjects.CreateApplPage;
import com.absli.pageObjects.DocumentsUploadPage;
import com.absli.pageObjects.SignInPage;
import com.absli.utils.CommonUtils;
import com.absli.utils.PropertiesUtils;
import com.absli.utils.WaitUtils;
import io.qameta.allure.Description;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import tests.BaseTest;
import tests.TestFactory;

import java.io.IOException;

@Listeners({TestLevelDriverCreator.class})
public class InstaVerify extends BaseTest {
    ProposerModel proposerModel;
    ReadJson jsonObj;
    CreateApplPage createApplPage;
    CommonUtils commonUtils;
    WaitUtils waitUtils;
    PropertiesUtils prop;
    SignInPage signIn;
    DocumentsUploadPage documentsUploadPage;

    @BeforeClass
    public void preSetup() throws IOException, InterruptedException {
        driver = new TestLevelDriverCreator().getDriver();
        commonUtils = new CommonUtils();
        waitUtils = new WaitUtils();
        prop = new PropertiesUtils();

    }

    @BeforeMethod
    public void relaunch() {
        new BaseTest().relaunch();
    }
    @Test(dataProvider = "dataInstaVerifyProvider",dataProviderClass = DataProviders.class,priority =1)
    @Description("Verification : Insta verification")
    public void verify_insta_photo(String username, String password, String policy, String leadid, String proposersame, String propinsurednotsame, String isnri, String pmobile, String ppan, String imobile,
                                       String ipan, String firstname, String lastname,
                                       String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame,
                                       String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                       String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                       String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                       String clickcontinue) throws Exception {
        new TestFactory().gotoInstaVerify(driver, username, password, policy, leadid, proposersame, propinsurednotsame, isnri, pmobile
                , ppan, imobile, ipan, firstname, lastname, middlename, day, month, year, gender, planjourney, proposerstate, advisorstatesame, plan, sumassured
                , smokertype, planoptions, increasinglevel, ecs, term, ppt, premiumterm, premiumamount, rider, rideramount, minrider, maxrider, ridererror, click, generateillustrations, clickcontinue);

    }
}
