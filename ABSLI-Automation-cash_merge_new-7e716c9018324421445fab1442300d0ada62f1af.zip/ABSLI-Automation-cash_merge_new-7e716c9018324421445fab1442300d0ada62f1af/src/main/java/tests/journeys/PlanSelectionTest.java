/*TEST-259 Plan selection*/
/*TEST-581 / Test-259   select plan journey*/

package tests.journeys;

import com.absli.helpers.dataProviders.DataProviders;
import com.absli.listeners.TestLevelDriverCreator;
import com.absli.listeners.TestListener;
import com.absli.helpers.jsonReaders.ReadJson;
import com.absli.helpers.models.ProposerModel;
import com.absli.pageObjects.CreateApplPage;
import com.absli.utils.CommonUtils;
import com.absli.utils.ExcelUtils;
import com.absli.utils.PropertiesUtils;
import com.absli.utils.WaitUtils;
import io.qameta.allure.Description;
import org.testng.Assert;
import org.testng.annotations.*;
import tests.BaseTest;
import tests.TestFactory;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;

@Listeners({TestLevelDriverCreator.class})
    public class PlanSelectionTest extends BaseTest {
        ProposerModel proposerModel;
        ReadJson jsonObj;
        CreateApplPage createApplPage;
        CommonUtils commonUtils;
        WaitUtils waitUtils;
        PropertiesUtils prop;

        @BeforeClass
        public void preSetup() throws IOException, InterruptedException {
            driver = new TestLevelDriverCreator().getDriver();
            commonUtils = new CommonUtils();
            waitUtils = new WaitUtils();
            prop = new PropertiesUtils();
            createApplPage = new CreateApplPage(driver);
        }

        @BeforeMethod
        public void relaunch()  {
            new BaseTest().relaunch();
        }

        //@Test(dataProvider = "planDataProvider",dataProviderClass = DataProviders.class,description = "verify navigation to plan selection screen",priority = 1)
        @Description("verify navigation to plan selection screen")
        public void verifyNavigationToPlanSelectionScreen(String username, String password, String policy, String leadid, String proposersame,
                                                          String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile,
                                                          String ipan, String firstname, String lastname,
                                                          String middlename, String day, String month, String year, String gender,
                                                          String planjourney, String proposerstate, String advisorstatesame, String plan) throws IOException, InterruptedException {

            new TestFactory().gotoPlanSelection(driver,username,	password,	policy,	leadid,	proposersame,	relationwithinsured,	isrelationanswer,
                    isnri	,pmobile,	ppan	,imobile,	ipan,	firstname,	lastname,	middlename,	day,
                    month,	year,	gender	,planjourney	,proposerstate,	advisorstatesame,	plan);

            Assert.assertTrue(createApplPage.elePlanSelectionNavText.isDisplayed(),"Plan selection screen is not displayed");
        }

        @Test(dataProvider = "planDataProvider",dataProviderClass = DataProviders.class,description = "verify error message when proposer state is not selected",priority = 2)
        @Description("verify error message when proposer state is not selected")
        public void verifyProposerStateWarningWhenNotASelected(String username, String password, String policy, String leadid, String proposersame,
                                                               String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile,
                                                               String ipan, String firstname, String lastname,
                                                               String middlename, String day, String month, String year, String gender,
                                                               String planjourney, String proposerstate, String advisorstatesame, String plan) throws IOException, InterruptedException {

            new TestFactory().gotoPlanSelection(driver,username,	password,	policy,	leadid,	proposersame,	relationwithinsured,	isrelationanswer,
                    isnri	,pmobile,	ppan	,imobile,	ipan,	firstname,	lastname,	middlename,	day,
                    month,	year,	gender	,planjourney	,proposerstate,	advisorstatesame,	plan);

            if(createApplPage.isProposerStateCheckboxSelected()) {
                createApplPage.selectProposerStateSameAsAdvisorCheckbox();
            }
            waitUtils.waitForElementToBeVisible(driver,createApplPage.elePlanSelectionNextbtn);
            createApplPage.chooseActionButton(createApplPage.elePlanSelectionNextbtn);
            Assert.assertTrue(createApplPage.verifyStateRequiredMessage(),"Warning is not shown when proposer state is not selected");
        }

        @Test(dataProvider = "planDataProvider",dataProviderClass = DataProviders.class,description = "verify able to select state when advisor state different",priority = 3)
        @Description("verify able to select state when advisor state different")
        public void verifyStateSelectionWhenAdvisorStateDifferent(String username, String password, String policy, String leadid, String proposersame,
                                                                  String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile,
                                                                  String ipan, String firstname, String lastname,
                                                                  String middlename, String day, String month, String year, String gender,
                                                                  String planjourney, String proposerstate, String advisorstatesame, String plan) throws IOException, InterruptedException {
            new TestFactory().gotoPlanSelection(driver,username,	password,	policy,	leadid,	proposersame,	relationwithinsured,	isrelationanswer,
                    isnri	,pmobile,	ppan	,imobile,	ipan,	firstname,	lastname,	middlename,	day,
                    month,	year,	gender	,planjourney	,proposerstate,	advisorstatesame,	plan);
            Assert.assertTrue(createApplPage.elePlanSelectionNavText.isDisplayed(),"Plan selection screen is not displayed");
            if(createApplPage.isProposerStateCheckboxSelected()) {
                createApplPage.selectProposerStateSameAsAdvisorCheckbox();
            }
            commonUtils.scrollTopOfPage(driver);
            createApplPage.chooseStateFromDropdown(proposerstate);
        }

        @Test(dataProvider = "planDataProvider",dataProviderClass = DataProviders.class,description = "verify error message when plan is not selected",priority = 4)
        @Description("verify error message when plan is not selected")
        public void verifyPlanWarningWhenNotASelected(String username, String password, String policy, String leadid, String proposersame,
                                                      String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile,
                                                      String ipan, String firstname, String lastname,
                                                      String middlename, String day, String month, String year, String gender,
                                                      String planjourney, String proposerstate, String advisorstatesame, String plan) throws IOException, InterruptedException {
            new TestFactory().gotoPlanSelection(driver,username,	password,	policy,	leadid,	proposersame,	relationwithinsured,	isrelationanswer,
                    isnri	,pmobile,	ppan	,imobile,	ipan,	firstname,	lastname,	middlename,	day,
                    month,	year,	gender	,planjourney	,proposerstate,	advisorstatesame,	plan);
            Assert.assertTrue(createApplPage.elePlanSelectionNavText.isDisplayed(),"Plan selection screen is not displayed");
            commonUtils.scrollTillEndOfPage(driver);
            //commonUtils.selectButtonByName("CONTINUE",driver);
            waitUtils.waitForElementToBeVisible(driver,createApplPage.elePlanSelectionNextbtn);
            createApplPage.chooseActionButton(createApplPage.elePlanSelectionNextbtn);
            Assert.assertTrue(createApplPage.elePlanSelectionNavText.isDisplayed(),"Warning is not shown when plan is not selected");
        }


        @Test(dataProvider = "planDataProvider",dataProviderClass = DataProviders.class,description = "verify fill plan details",priority =5)
        @Description("verify fill plan details")
        public void verifyFillingPlanSelectionDetailsScreen(String username, String password, String policy, String leadid, String proposersame,
                                                            String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile,
                                                            String ipan, String firstname, String lastname,
                                                            String middlename, String day, String month, String year, String gender,
                                                            String planjourney, String proposerstate, String advisorstatesame, String plan) throws IOException, InterruptedException {
            new TestFactory().gotoPlanSelection(driver,username,	password,	policy,	leadid,	proposersame,	 relationwithinsured,	isrelationanswer,
                    isnri	,pmobile,	ppan	,imobile,	ipan,	firstname,	lastname,	middlename,	day,
                    month,	year,	gender	,planjourney	,proposerstate,	advisorstatesame,	plan);
            Assert.assertTrue(createApplPage.elePlanSelectionNavText.isDisplayed(),"Plan selection screen is not displayed");

            if(!createApplPage.isProposerStateCheckboxSelected()) {
                createApplPage.selectProposerStateSameAsAdvisorCheckbox();
            }
            commonUtils.scrollTillEndOfPage(driver);
            waitUtils.implicitWait(driver,20000);

            createApplPage.choosePlanFromDropdown(plan);

            waitUtils.waitForElementToBeVisible(driver,createApplPage.elePlanSelectionNextbtn);
            createApplPage.chooseActionButton(createApplPage.elePlanSelectionNextbtn);
            waitUtils.waitForElementToBeVisible(driver, createApplPage.eleViewQuoteNavText);
        }


    }

    /*
    *
Verify The Advisor State
Verify user is able to select the proposer state
Verify  that on choosing that the states are the same, the proposer state is the same
Verify based on the PSM details whether the correct recommended list of products are displayed
Verify  that on choosing to go with Term/health plans, the user is recommended only term and health plans
Verify Products will be displayed along with their Category
Verify that the user is able to select only one plan and proceed
Verify that the user is able to toggle between choosing term or not.
Verify If user is NOT choosing term,  verify that PSM is again asked
Verify If PSM is being done by the user then recommended products will be displayed separately
Verify  If the user wants to opt for products other than the recommended then those will be displayed as per the product category

Verify Without Selecting Proposer State click on Continue
Verify With selecting of Proposer State and without selecting of Select Plan and Entering Emp Id click on Continue
Verify With the  Selecting Proposer State and Emp Id and without selecting of Plan Click on Continue
Verify when user Navigate to Heath and Pure Term Plan, before entering emp id and without  selecting plan an state Continue Should be in Disbale Mode
Verify Enter Wrong Emp id and fill other details Click on Continue
Verify Click on Back Arrow
* */