package tests.journeys;


import com.absli.helpers.dataProviders.DataProviders;
import com.absli.helpers.jsonReaders.ReadJson;
import com.absli.helpers.models.ProposerModel;
import com.absli.listeners.TestLevelDriverCreator;
import com.absli.listeners.TestListener;
import com.absli.pageObjects.CaptureEmailIdPage;
import com.absli.pageObjects.CreateApplPage;
import com.absli.pageObjects.EnachRegistrationPage;
import com.absli.pageObjects.SignInPage;
import com.absli.utils.CommonUtils;
import com.absli.utils.PropertiesUtils;
import com.absli.utils.WaitUtils;
import io.qameta.allure.Description;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import tests.BaseTest;
import tests.TestFactory;

import java.io.IOException;

@Listeners({TestLevelDriverCreator.class})
public class CaptureEmailID extends BaseTest {

    ProposerModel proposerModel;
    ReadJson jsonObj;
    CreateApplPage createApplPage;
    CommonUtils commonUtils;
    WaitUtils waitUtils;
    PropertiesUtils prop;
    SignInPage signIn;
    EnachRegistrationPage enachPage;
    CaptureEmailIdPage captureEmailIdPage;

    @BeforeClass
    public void preSetup() throws IOException, InterruptedException {
        driver = new TestLevelDriverCreator(). getDriver();
        commonUtils = new CommonUtils();
        waitUtils = new WaitUtils();
        prop = new PropertiesUtils();
        captureEmailIdPage=new CaptureEmailIdPage(driver);
    }
    @BeforeMethod
    public void relaunch()  {
        new BaseTest().relaunch();
    }

    @Test(dataProvider = "dataEmailProvider", dataProviderClass = DataProviders.class,priority = 1)
    @Description("Test case description : validating with invalid emailId")
    public void verify_InActive_EmailId(String username, String password, String policy, String leadid, String proposersame, String propinsurednotsame, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                        String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                        String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                        String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                        String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                        String clickverify,String renewpremiumscreentitle,String paymentmethod,String drawdate,String fundsource,
                                        String nomineescreentitle, String nomineefirstname, String nomineelastname, String nomineeday,
                                        String nomineemonth, String nomineeyear, String nomineegender, String relationshipwithproposer, String nomineeshare,
                                        String ismwppolicy,
                                        String addressscreentitle, String typeofaddress, String addresspincode, String address1, String address2, String address3, String personalDetailsscreentitle, String cityName, String preferredLanguage, String alernateNumber, String resTelephoneNumber,String emailaddressValidations,String maritalStatus,String fathersNameOrSpouseName,String mothersName,
                                        String question1,String answer1,String valueToBeEnter,String question2,String answer2,String valueToBeEnter2,String question3,String answer3,String valueToBeEnter3,String question4,String answer4,String valueToBeEnter4,String qualification,
                                        String occupation,String employeerName,String nameOfBusinessOrduties,String typeOfOrganization,String designation,String annualIncome,String ExistingPolicyscreentitle) throws Exception {
        new TestFactory().gotoCapturedEmailID(driver,username,password,policy,leadid,proposersame,propinsurednotsame,isnri,pmobile,ppan,imobile,ipan,firstname,lastname,middlename,day,month,year,gender,planjourney,
                proposerstate,advisorstatesame,plan,sumassured,smokertype,planoptions,increasinglevel,ecs,term,ppt,premiumterm,premiumamount,rider,rideramount,minrider,maxrider,ridererror,click,generateillustrations,
                clickcontinue,ifsccode,bankaccno,accholdername,accounttype,pennyalert,clickverify,renewpremiumscreentitle,paymentmethod,drawdate,fundsource,nomineescreentitle,
                nomineefirstname,nomineelastname,nomineeday,nomineemonth,nomineeyear,nomineegender,relationshipwithproposer,nomineeshare,ismwppolicy,addressscreentitle,typeofaddress,addresspincode,address1,address2,address3,personalDetailsscreentitle,cityName,preferredLanguage,alernateNumber,resTelephoneNumber);

        captureEmailIdPage.setEmailID(emailaddressValidations);
        captureEmailIdPage.setEmailID(emailaddressValidations);
        commonUtils.selectButtonByName(maritalStatus,driver);
        //captureEmailIdPage.setMaritalStatus(maritalStatus);
        captureEmailIdPage.setFatherSpouseName(fathersNameOrSpouseName);
        captureEmailIdPage.setMotherName(mothersName);
        //captureEmailIdPage.setValueToQuestions();
        captureEmailIdPage.setValueToQuestions(question1,answer1,valueToBeEnter);
        captureEmailIdPage.setValueToQuestions2(question2,answer2,valueToBeEnter2);
        captureEmailIdPage.setValueToQuestions3(question3,answer3,valueToBeEnter3);
        captureEmailIdPage.setValueToQuestions4(question4,answer4,valueToBeEnter4);
        waitUtils.waitForElementToBeClickable(driver,captureEmailIdPage.qualificationText);
        commonUtils.scrollToElementAndClick(driver,captureEmailIdPage.qualificationText);
        waitUtils.wait2Seconds();
        System.out.println(qualification);
        waitUtils.WaitForListOfElementPresent(driver,captureEmailIdPage.qualificationsList,10);
        captureEmailIdPage.selectQualificationandoccupationFromList(qualification);
       // captureEmailIdPage.getQualificationFromList(qualification);
        waitUtils.wait2Seconds();
        commonUtils.scrolldown(driver);
        commonUtils.scrollToElementAndClick(driver,captureEmailIdPage.occupationText);
        waitUtils.WaitForListOfElementPresent(driver,captureEmailIdPage.qualificationsList,10);
        captureEmailIdPage.selectQualificationandoccupationFromList(occupation);
        //captureEmailIdPage.getOccupationList(occupation);
        waitUtils.wait2Seconds();
        waitUtils.waitForElementToBeVisible(driver,captureEmailIdPage.employerName);
        captureEmailIdPage.setEmployerName(employeerName);
        captureEmailIdPage.setNameOfBusiness(nameOfBusinessOrduties);
        captureEmailIdPage.organization();
        waitUtils.WaitForListOfElementPresent(driver,captureEmailIdPage.listOfOrgs,10);
        captureEmailIdPage.selectQualificationandoccupationFromList(typeOfOrganization);
       // captureEmailIdPage.getOraNameFromList(typeOfOrganization);
        captureEmailIdPage.setnameOfDesignation(designation);
        captureEmailIdPage.setannualIncome(annualIncome);


        if(captureEmailIdPage.inActiveMesage.isDisplayed()){
            commonUtils.scrollToElement(driver,captureEmailIdPage.inActiveMesage);
            waitUtils.Asserting("contains",captureEmailIdPage.inActiveMesage.getText(),"Unable to verify EMAIL. Please continue with rest of the form");
        }else {

            System.out.println("given email is an active state");
        }
        waitUtils.wait5Seconds();
        commonUtils.selectButtonByName("SAVE & CONTINUE",driver);

    }
//    @Test(dataProvider = "dataEmailProvider",dataProviderClass = DataProviders.class, priority = 2)
    @Description("verify capture emailId")
    public void verify_Emailcontains_dotinthe_address_field(String username, String password, String policy, String leadid, String proposersame, String propinsurednotsame, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                                            String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                                            String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                                            String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                                            String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                                            String clickverify,String renewpremiumscreentitle,String paymentmethod,String drawdate,String fundsource,
                                                            String nomineescreentitle, String nomineefirstname, String nomineelastname, String nomineeday,
                                                            String nomineemonth, String nomineeyear, String nomineegender, String relationshipwithproposer, String nomineeshare,
                                                            String ismwppolicy,
                                                            String addressscreentitle, String typeofaddress, String addresspincode, String address1, String address2, String address3, String personalDetailsscreentitle, String cityName, String preferredLanguage, String alernateNumber, String resTelephoneNumber,String emailaddressValidations,String maritalStatus,String fathersNameOrSpouseName,String mothersName,
                                                            String question1,String answer1,String valueToBeEnter,String question2,String answer2,String valueToBeEnter2,String question3,String answer3,String valueToBeEnter3,String question4,String answer4,String valueToBeEnter4,String qualification,
                                                            String occupation,String employeerName,String nameOfBusinessOrduties,String typeOfOrganization,String designation,String annualIncome,String ExistingPolicyscreentitle) throws Exception {
        new TestFactory().gotoCapturedEmailID(driver,username,password,policy,leadid,proposersame,propinsurednotsame,isnri,pmobile,ppan,imobile,ipan,firstname,lastname,middlename,day,month,year,gender,planjourney,
                proposerstate,advisorstatesame,plan,sumassured,smokertype,planoptions,increasinglevel,ecs,term,ppt,premiumterm,premiumamount,rider,rideramount,minrider,maxrider,ridererror,click,generateillustrations,
                clickcontinue,ifsccode,bankaccno,accholdername,accounttype,pennyalert,clickverify,renewpremiumscreentitle,paymentmethod,drawdate,fundsource,nomineescreentitle,
                nomineefirstname,nomineelastname,nomineeday,nomineemonth,nomineeyear,nomineegender,relationshipwithproposer,nomineeshare,ismwppolicy,addressscreentitle,typeofaddress,addresspincode,address1,address2,address3,personalDetailsscreentitle,cityName,preferredLanguage,alernateNumber,resTelephoneNumber);

        captureEmailIdPage.setEmailID(emailaddressValidations);
        captureEmailIdPage.setEmailID(emailaddressValidations);
        commonUtils.selectButtonByName(maritalStatus,driver);
        //captureEmailIdPage.setMaritalStatus(maritalStatus);
        captureEmailIdPage.setFatherSpouseName(fathersNameOrSpouseName);
        captureEmailIdPage.setMotherName(mothersName);
        captureEmailIdPage.setValueToQuestions(question1,answer1,valueToBeEnter);
        captureEmailIdPage.setValueToQuestions2(question2,answer2,valueToBeEnter2);
        captureEmailIdPage.setValueToQuestions3(question3,answer3,valueToBeEnter3);
        captureEmailIdPage.setValueToQuestions4(question4,answer4,valueToBeEnter4);
        waitUtils.waitForElementToBeClickable(driver,captureEmailIdPage.qualificationText);
        commonUtils.scrollToElementAndClick(driver,captureEmailIdPage.qualificationText);
        waitUtils.wait2Seconds();

        System.out.println(qualification);
        waitUtils.WaitForListOfElementPresent(driver,captureEmailIdPage.qualificationsList,10);
        captureEmailIdPage.selectQualificationandoccupationFromList(qualification);
        // captureEmailIdPage.getQualificationFromList(qualification);
        waitUtils.wait2Seconds();
        commonUtils.scrolldown(driver);
        commonUtils.scrollToElementAndClick(driver,captureEmailIdPage.occupationText);
        waitUtils.WaitForListOfElementPresent(driver,captureEmailIdPage.qualificationsList,10);
        captureEmailIdPage.selectQualificationandoccupationFromList(occupation);
        //captureEmailIdPage.getOccupationList(occupation);
        waitUtils.wait2Seconds();
        waitUtils.waitForElementToBeVisible(driver,captureEmailIdPage.employerName);
        captureEmailIdPage.setEmployerName(employeerName);
        captureEmailIdPage.setNameOfBusiness(nameOfBusinessOrduties);
        captureEmailIdPage.organization();
        waitUtils.WaitForListOfElementPresent(driver,captureEmailIdPage.listOfOrgs,10);
        captureEmailIdPage.selectQualificationandoccupationFromList(typeOfOrganization);
        // captureEmailIdPage.getOraNameFromList(typeOfOrganization);
        captureEmailIdPage.setnameOfDesignation(designation);
        captureEmailIdPage.setannualIncome(annualIncome);
        commonUtils.selectButtonByName("SAVE & CONTINUE",driver);
        waitUtils.wait5Seconds();
        Assert.assertEquals(captureEmailIdPage.validateScreenTitle(ExistingPolicyscreentitle), ExistingPolicyscreentitle, "Failure in navigation to existing policy screen");
        //waitUtils.wait5Seconds();
        /*if(captureEmailIdPage.inActiveMesage.isDisplayed()){
            waitUtils.Asserting("contains",captureEmailIdPage.inActiveMesage.getText(),"Inactive Email ID. Need to add active email ID to proceed");
        }else {

            System.out.println("given email is an active state");
        }*/


    }
   // @Test(dataProvider = "dataEmailProvider",dataProviderClass = DataProviders.class, priority = 4)
    @Description("verify capture emailId")
    public void verify_emailid_filedWith_Plus_sign(String username, String password, String policy, String leadid, String proposersame, String propinsurednotsame, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                                   String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                                   String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                                   String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                                   String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                                   String clickverify,String renewpremiumscreentitle,String paymentmethod,String drawdate,String fundsource,
                                                   String nomineescreentitle, String nomineefirstname, String nomineelastname, String nomineeday,
                                                   String nomineemonth, String nomineeyear, String nomineegender, String relationshipwithproposer, String nomineeshare,
                                                   String ismwppolicy,
                                                   String addressscreentitle, String typeofaddress, String addresspincode, String address1, String address2, String address3, String personalDetailsscreentitle, String cityName, String preferredLanguage, String alernateNumber, String resTelephoneNumber,String emailaddressValidations,String maritalStatus,String fathersNameOrSpouseName,String mothersName,
                                                   String question1,String answer1,String valueToBeEnter,String question2,String answer2,String valueToBeEnter2,String question3,String answer3,String valueToBeEnter3,String question4,String answer4,String valueToBeEnter4,String qualification,
                                                   String occupation,String employeerName,String nameOfBusinessOrduties,String typeOfOrganization,String designation,String annualIncome,String ExistingPolicyscreentitle) throws Exception {
        new TestFactory().gotoCapturedEmailID(driver,username,password,policy,leadid,proposersame,propinsurednotsame,isnri,pmobile,ppan,imobile,ipan,firstname,lastname,middlename,day,month,year,gender,planjourney,
                proposerstate,advisorstatesame,plan,sumassured,smokertype,planoptions,increasinglevel,ecs,term,ppt,premiumterm,premiumamount,rider,rideramount,minrider,maxrider,ridererror,click,generateillustrations,
                clickcontinue,ifsccode,bankaccno,accholdername,accounttype,pennyalert,clickverify,renewpremiumscreentitle,paymentmethod,drawdate,fundsource,nomineescreentitle,
                nomineefirstname,nomineelastname,nomineeday,nomineemonth,nomineeyear,nomineegender,relationshipwithproposer,nomineeshare,ismwppolicy,addressscreentitle,typeofaddress,addresspincode,address1,address2,address3,personalDetailsscreentitle,cityName,preferredLanguage,alernateNumber,resTelephoneNumber);

        captureEmailIdPage.setEmailID(emailaddressValidations);
        captureEmailIdPage.setEmailID(emailaddressValidations);
        commonUtils.selectButtonByName(maritalStatus,driver);
        //captureEmailIdPage.setMaritalStatus(maritalStatus);
        captureEmailIdPage.setFatherSpouseName(fathersNameOrSpouseName);
        captureEmailIdPage.setMotherName(mothersName);
        captureEmailIdPage.setValueToQuestions(question1,answer1,valueToBeEnter);
        captureEmailIdPage.setValueToQuestions2(question2,answer2,valueToBeEnter2);
        captureEmailIdPage.setValueToQuestions3(question3,answer3,valueToBeEnter3);
        captureEmailIdPage.setValueToQuestions4(question4,answer4,valueToBeEnter4);
        waitUtils.waitForElementToBeClickable(driver,captureEmailIdPage.qualificationText);
        commonUtils.scrollToElementAndClick(driver,captureEmailIdPage.qualificationText);
        waitUtils.wait2Seconds();

        System.out.println(qualification);
        waitUtils.WaitForListOfElementPresent(driver,captureEmailIdPage.qualificationsList,10);
        captureEmailIdPage.selectQualificationandoccupationFromList(qualification);
        // captureEmailIdPage.getQualificationFromList(qualification);
        waitUtils.wait2Seconds();
        commonUtils.scrolldown(driver);
        commonUtils.scrollToElementAndClick(driver,captureEmailIdPage.occupationText);
        waitUtils.WaitForListOfElementPresent(driver,captureEmailIdPage.qualificationsList,10);
        captureEmailIdPage.selectQualificationandoccupationFromList(occupation);
        //captureEmailIdPage.getOccupationList(occupation);
        waitUtils.wait2Seconds();
        waitUtils.waitForElementToBeVisible(driver,captureEmailIdPage.employerName);
        captureEmailIdPage.setEmployerName(employeerName);
        captureEmailIdPage.setNameOfBusiness(nameOfBusinessOrduties);
        captureEmailIdPage.organization();
        waitUtils.WaitForListOfElementPresent(driver,captureEmailIdPage.listOfOrgs,10);
        captureEmailIdPage.selectQualificationandoccupationFromList(typeOfOrganization);
        // captureEmailIdPage.getOraNameFromList(typeOfOrganization);
        captureEmailIdPage.setnameOfDesignation(designation);
        captureEmailIdPage.setannualIncome(annualIncome);
        commonUtils.selectButtonByName("SAVE & CONTINUE",driver);
        waitUtils.wait5Seconds();
       /* if(captureEmailIdPage.inActiveMesage.isDisplayed()){
            waitUtils.Asserting("contains",captureEmailIdPage.inActiveMesage.getText(),"Invalid Email");
        }else {

            System.out.println("given email is an active state");
        }*/


    }
  //  @Test(dataProvider = "dataEmailProvider", dataProviderClass = DataProviders.class,priority = 3)
    @Description("verify capture emailId")
    public void verify_Emailcontains_dotwith_subdomain(String username, String password, String policy, String leadid, String proposersame, String propinsurednotsame, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                                       String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                                       String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                                       String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                                       String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                                       String clickverify,String renewpremiumscreentitle,String paymentmethod,String drawdate,String fundsource,
                                                       String nomineescreentitle, String nomineefirstname, String nomineelastname, String nomineeday,
                                                       String nomineemonth, String nomineeyear, String nomineegender, String relationshipwithproposer, String nomineeshare,
                                                       String ismwppolicy,
                                                       String addressscreentitle, String typeofaddress, String addresspincode, String address1, String address2, String address3, String personalDetailsscreentitle, String cityName, String preferredLanguage, String alernateNumber, String resTelephoneNumber,String emailaddressValidations,String maritalStatus,String fathersNameOrSpouseName,String mothersName,
                                                       String question1,String answer1,String valueToBeEnter,String question2,String answer2,String valueToBeEnter2,String question3,String answer3,String valueToBeEnter3,String question4,String answer4,String valueToBeEnter4,String qualification,
                                                       String occupation,String employeerName,String nameOfBusinessOrduties,String typeOfOrganization,String designation,String annualIncome,String ExistingPolicyscreentitle) throws Exception {
        new TestFactory().gotoCapturedEmailID(driver,username,password,policy,leadid,proposersame,propinsurednotsame,isnri,pmobile,ppan,imobile,ipan,firstname,lastname,middlename,day,month,year,gender,planjourney,
                proposerstate,advisorstatesame,plan,sumassured,smokertype,planoptions,increasinglevel,ecs,term,ppt,premiumterm,premiumamount,rider,rideramount,minrider,maxrider,ridererror,click,generateillustrations,
                clickcontinue,ifsccode,bankaccno,accholdername,accounttype,pennyalert,clickverify,renewpremiumscreentitle,paymentmethod,drawdate,fundsource,nomineescreentitle,
                nomineefirstname,nomineelastname,nomineeday,nomineemonth,nomineeyear,nomineegender,relationshipwithproposer,nomineeshare,ismwppolicy,addressscreentitle,typeofaddress,addresspincode,address1,address2,address3,personalDetailsscreentitle,cityName,preferredLanguage,alernateNumber,resTelephoneNumber);

        captureEmailIdPage.setEmailID(emailaddressValidations);
        captureEmailIdPage.setEmailID(emailaddressValidations);
        commonUtils.selectButtonByName(maritalStatus,driver);
        //captureEmailIdPage.setMaritalStatus(maritalStatus);
        captureEmailIdPage.setFatherSpouseName(fathersNameOrSpouseName);
        captureEmailIdPage.setMotherName(mothersName);
        captureEmailIdPage.setValueToQuestions(question1,answer1,valueToBeEnter);
        captureEmailIdPage.setValueToQuestions2(question2,answer2,valueToBeEnter2);
        captureEmailIdPage.setValueToQuestions3(question3,answer3,valueToBeEnter3);
        captureEmailIdPage.setValueToQuestions4(question4,answer4,valueToBeEnter4);
        waitUtils.waitForElementToBeClickable(driver,captureEmailIdPage.qualificationText);
        commonUtils.scrollToElementAndClick(driver,captureEmailIdPage.qualificationText);
        waitUtils.wait2Seconds();

        System.out.println(qualification);
        waitUtils.WaitForListOfElementPresent(driver,captureEmailIdPage.qualificationsList,10);
        captureEmailIdPage.selectQualificationandoccupationFromList(qualification);
        // captureEmailIdPage.getQualificationFromList(qualification);
        waitUtils.wait2Seconds();
        commonUtils.scrolldown(driver);
        commonUtils.scrollToElementAndClick(driver,captureEmailIdPage.occupationText);
        waitUtils.WaitForListOfElementPresent(driver,captureEmailIdPage.qualificationsList,10);
        captureEmailIdPage.selectQualificationandoccupationFromList(occupation);
        //captureEmailIdPage.getOccupationList(occupation);
        waitUtils.wait2Seconds();
        waitUtils.waitForElementToBeVisible(driver,captureEmailIdPage.employerName);
        captureEmailIdPage.setEmployerName(employeerName);
        captureEmailIdPage.setNameOfBusiness(nameOfBusinessOrduties);
        captureEmailIdPage.organization();
        waitUtils.WaitForListOfElementPresent(driver,captureEmailIdPage.listOfOrgs,10);
        captureEmailIdPage.selectQualificationandoccupationFromList(typeOfOrganization);
        // captureEmailIdPage.getOraNameFromList(typeOfOrganization);
        captureEmailIdPage.setnameOfDesignation(designation);
        captureEmailIdPage.setannualIncome(annualIncome);
        commonUtils.selectButtonByName("SAVE & CONTINUE",driver);
        waitUtils.wait5Seconds();
        if(captureEmailIdPage.inActiveMesage.isDisplayed()){
            waitUtils.Asserting("contains",captureEmailIdPage.inActiveMesage.getText(),"Invalid Email");
        }else {

            System.out.println("given email is an active state");
        }


    }

  // @Test(dataProvider = "dataEmailProvider",dataProviderClass = DataProviders.class, priority = 5)
    @Description("verify capture emailId")
    public void verify_EmilId_Ipaddress_format(String username, String password, String policy, String leadid, String proposersame, String propinsurednotsame, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                               String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                               String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                               String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                               String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                               String clickverify,String renewpremiumscreentitle,String paymentmethod,String drawdate,String fundsource,
                                               String nomineescreentitle, String nomineefirstname, String nomineelastname, String nomineeday,
                                               String nomineemonth, String nomineeyear, String nomineegender, String relationshipwithproposer, String nomineeshare,
                                               String ismwppolicy,
                                               String addressscreentitle, String typeofaddress, String addresspincode, String address1, String address2, String address3, String personalDetailsscreentitle, String cityName, String preferredLanguage, String alernateNumber, String resTelephoneNumber,String emailaddressValidations,String maritalStatus,String fathersNameOrSpouseName,String mothersName,
                                               String question1,String answer1,String valueToBeEnter,String question2,String answer2,String valueToBeEnter2,String question3,String answer3,String valueToBeEnter3,String question4,String answer4,String valueToBeEnter4,String qualification,
                                               String occupation,String employeerName,String nameOfBusinessOrduties,String typeOfOrganization,String designation,String annualIncome,String ExistingPolicyscreentitle) throws Exception {
        new TestFactory().gotoCapturedEmailID(driver,username,password,policy,leadid,proposersame,propinsurednotsame,isnri,pmobile,ppan,imobile,ipan,firstname,lastname,middlename,day,month,year,gender,planjourney,
                proposerstate,advisorstatesame,plan,sumassured,smokertype,planoptions,increasinglevel,ecs,term,ppt,premiumterm,premiumamount,rider,rideramount,minrider,maxrider,ridererror,click,generateillustrations,
                clickcontinue,ifsccode,bankaccno,accholdername,accounttype,pennyalert,clickverify,renewpremiumscreentitle,paymentmethod,drawdate,fundsource,nomineescreentitle,
                nomineefirstname,nomineelastname,nomineeday,nomineemonth,nomineeyear,nomineegender,relationshipwithproposer,nomineeshare,ismwppolicy,addressscreentitle,typeofaddress,addresspincode,address1,address2,address3,personalDetailsscreentitle,cityName,preferredLanguage,alernateNumber,resTelephoneNumber);

        captureEmailIdPage.setEmailID(emailaddressValidations);
        captureEmailIdPage.setEmailID(emailaddressValidations);
        commonUtils.selectButtonByName(maritalStatus,driver);
        //captureEmailIdPage.setMaritalStatus(maritalStatus);
        captureEmailIdPage.setFatherSpouseName(fathersNameOrSpouseName);
        captureEmailIdPage.setMotherName(mothersName);
        captureEmailIdPage.setValueToQuestions(question1,answer1,valueToBeEnter);
        captureEmailIdPage.setValueToQuestions2(question2,answer2,valueToBeEnter2);
        captureEmailIdPage.setValueToQuestions3(question3,answer3,valueToBeEnter3);
        captureEmailIdPage.setValueToQuestions4(question4,answer4,valueToBeEnter4);
        waitUtils.waitForElementToBeClickable(driver,captureEmailIdPage.qualificationText);
        commonUtils.scrollToElementAndClick(driver,captureEmailIdPage.qualificationText);
        waitUtils.wait2Seconds();

        System.out.println(qualification);
        waitUtils.WaitForListOfElementPresent(driver,captureEmailIdPage.qualificationsList,10);
        captureEmailIdPage.selectQualificationandoccupationFromList(qualification);
        // captureEmailIdPage.getQualificationFromList(qualification);
        waitUtils.wait2Seconds();
        commonUtils.scrolldown(driver);
        commonUtils.scrollToElementAndClick(driver,captureEmailIdPage.occupationText);
        waitUtils.WaitForListOfElementPresent(driver,captureEmailIdPage.qualificationsList,10);
        captureEmailIdPage.selectQualificationandoccupationFromList(occupation);
        //captureEmailIdPage.getOccupationList(occupation);
        waitUtils.wait2Seconds();
        waitUtils.waitForElementToBeVisible(driver,captureEmailIdPage.employerName);
        captureEmailIdPage.setEmployerName(employeerName);
        captureEmailIdPage.setNameOfBusiness(nameOfBusinessOrduties);
        captureEmailIdPage.organization();
        waitUtils.WaitForListOfElementPresent(driver,captureEmailIdPage.listOfOrgs,10);
        captureEmailIdPage.selectQualificationandoccupationFromList(typeOfOrganization);
        // captureEmailIdPage.getOraNameFromList(typeOfOrganization);
        captureEmailIdPage.setnameOfDesignation(designation);
        captureEmailIdPage.setannualIncome(annualIncome);
        commonUtils.selectButtonByName("SAVE & CONTINUE",driver);
        waitUtils.wait5Seconds();
        if(captureEmailIdPage.inActiveMesage.isDisplayed()){
            waitUtils.Asserting("contains",captureEmailIdPage.inActiveMesage.getText(),"Invalid Email");
        }else {

            System.out.println("given email is an active state");
        }


    }

 //@Test(dataProvider = "dataEmailProvider", dataProviderClass = DataProviders.class,priority = 6)
    @Description("verify capture emailId")
    public void verify_EmailId_bracketsIP_format(String username, String password, String policy, String leadid, String proposersame, String propinsurednotsame, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                                 String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                                 String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                                 String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                                 String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                                 String clickverify,String renewpremiumscreentitle,String paymentmethod,String drawdate,String fundsource,
                                                 String nomineescreentitle, String nomineefirstname, String nomineelastname, String nomineeday,
                                                 String nomineemonth, String nomineeyear, String nomineegender, String relationshipwithproposer, String nomineeshare,
                                                 String ismwppolicy,
                                                 String addressscreentitle, String typeofaddress, String addresspincode, String address1, String address2, String address3, String personalDetailsscreentitle, String cityName, String preferredLanguage, String alernateNumber, String resTelephoneNumber,String emailaddressValidations,String maritalStatus,String fathersNameOrSpouseName,String mothersName,
                                                 String question1,String answer1,String valueToBeEnter,String question2,String answer2,String valueToBeEnter2,String question3,String answer3,String valueToBeEnter3,String question4,String answer4,String valueToBeEnter4,String qualification,
                                                 String occupation,String employeerName,String nameOfBusinessOrduties,String typeOfOrganization,String designation,String annualIncome,String ExistingPolicyscreentitle) throws Exception {
        new TestFactory().gotoCapturedEmailID(driver,username,password,policy,leadid,proposersame,propinsurednotsame,isnri,pmobile,ppan,imobile,ipan,firstname,lastname,middlename,day,month,year,gender,planjourney,
                proposerstate,advisorstatesame,plan,sumassured,smokertype,planoptions,increasinglevel,ecs,term,ppt,premiumterm,premiumamount,rider,rideramount,minrider,maxrider,ridererror,click,generateillustrations,
                clickcontinue,ifsccode,bankaccno,accholdername,accounttype,pennyalert,clickverify,renewpremiumscreentitle,paymentmethod,drawdate,fundsource,nomineescreentitle,
                nomineefirstname,nomineelastname,nomineeday,nomineemonth,nomineeyear,nomineegender,relationshipwithproposer,nomineeshare,ismwppolicy,addressscreentitle,typeofaddress,addresspincode,address1,address2,address3,personalDetailsscreentitle,cityName,preferredLanguage,alernateNumber,resTelephoneNumber);

        captureEmailIdPage.setEmailID(emailaddressValidations);
        captureEmailIdPage.setEmailID(emailaddressValidations);
        commonUtils.selectButtonByName(maritalStatus,driver);
        //captureEmailIdPage.setMaritalStatus(maritalStatus);
        captureEmailIdPage.setFatherSpouseName(fathersNameOrSpouseName);
        captureEmailIdPage.setMotherName(mothersName);
        captureEmailIdPage.setValueToQuestions(question1,answer1,valueToBeEnter);
        captureEmailIdPage.setValueToQuestions2(question2,answer2,valueToBeEnter2);
        captureEmailIdPage.setValueToQuestions3(question3,answer3,valueToBeEnter3);
        captureEmailIdPage.setValueToQuestions4(question4,answer4,valueToBeEnter4);
        waitUtils.waitForElementToBeClickable(driver,captureEmailIdPage.qualificationText);
        commonUtils.scrollToElementAndClick(driver,captureEmailIdPage.qualificationText);
        waitUtils.wait2Seconds();

        System.out.println(qualification);
        waitUtils.WaitForListOfElementPresent(driver,captureEmailIdPage.qualificationsList,10);
        captureEmailIdPage.selectQualificationandoccupationFromList(qualification);
        // captureEmailIdPage.getQualificationFromList(qualification);
        waitUtils.wait2Seconds();
        commonUtils.scrolldown(driver);
        commonUtils.scrollToElementAndClick(driver,captureEmailIdPage.occupationText);
        waitUtils.WaitForListOfElementPresent(driver,captureEmailIdPage.qualificationsList,10);
        captureEmailIdPage.selectQualificationandoccupationFromList(occupation);
        //captureEmailIdPage.getOccupationList(occupation);
        waitUtils.wait2Seconds();
        waitUtils.waitForElementToBeVisible(driver,captureEmailIdPage.employerName);
        captureEmailIdPage.setEmployerName(employeerName);
        captureEmailIdPage.setNameOfBusiness(nameOfBusinessOrduties);
        captureEmailIdPage.organization();
        waitUtils.WaitForListOfElementPresent(driver,captureEmailIdPage.listOfOrgs,10);
        captureEmailIdPage.selectQualificationandoccupationFromList(typeOfOrganization);
        // captureEmailIdPage.getOraNameFromList(typeOfOrganization);
        captureEmailIdPage.setnameOfDesignation(designation);
        captureEmailIdPage.setannualIncome(annualIncome);
        commonUtils.selectButtonByName("SAVE & CONTINUE",driver);
        waitUtils.wait5Seconds();
        if(captureEmailIdPage.inActiveMesage.isDisplayed()){
            waitUtils.Asserting("contains",captureEmailIdPage.inActiveMesage.getText(),"Invalid Email");
        }else {

            System.out.println("given email is an active state");
        }


    }

   //@Test(dataProvider = "dataEmailProvider", dataProviderClass = DataProviders.class,priority = 7)
    @Description("verify capture emailId")
    public void verify_EmailId_quotes(String username, String password, String policy, String leadid, String proposersame, String propinsurednotsame, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                      String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                      String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                      String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                      String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                      String clickverify,String renewpremiumscreentitle,String paymentmethod,String drawdate,String fundsource,
                                      String nomineescreentitle, String nomineefirstname, String nomineelastname, String nomineeday,
                                      String nomineemonth, String nomineeyear, String nomineegender, String relationshipwithproposer, String nomineeshare,
                                      String ismwppolicy,
                                      String addressscreentitle, String typeofaddress, String addresspincode, String address1, String address2, String address3, String personalDetailsscreentitle, String cityName, String preferredLanguage, String alernateNumber, String resTelephoneNumber,String emailaddressValidations,String maritalStatus,String fathersNameOrSpouseName,String mothersName,
                                      String question1,String answer1,String valueToBeEnter,String question2,String answer2,String valueToBeEnter2,String question3,String answer3,String valueToBeEnter3,String question4,String answer4,String valueToBeEnter4,String qualification,
                                      String occupation,String employeerName,String nameOfBusinessOrduties,String typeOfOrganization,String designation,String annualIncome,String ExistingPolicyscreentitle) throws Exception {
        new TestFactory().gotoCapturedEmailID(driver,username,password,policy,leadid,proposersame,propinsurednotsame,isnri,pmobile,ppan,imobile,ipan,firstname,lastname,middlename,day,month,year,gender,planjourney,
                proposerstate,advisorstatesame,plan,sumassured,smokertype,planoptions,increasinglevel,ecs,term,ppt,premiumterm,premiumamount,rider,rideramount,minrider,maxrider,ridererror,click,generateillustrations,
                clickcontinue,ifsccode,bankaccno,accholdername,accounttype,pennyalert,clickverify,renewpremiumscreentitle,paymentmethod,drawdate,fundsource,nomineescreentitle,
                nomineefirstname,nomineelastname,nomineeday,nomineemonth,nomineeyear,nomineegender,relationshipwithproposer,nomineeshare,ismwppolicy,addressscreentitle,typeofaddress,addresspincode,address1,address2,address3,personalDetailsscreentitle,cityName,preferredLanguage,alernateNumber,resTelephoneNumber);

        captureEmailIdPage.setEmailID(emailaddressValidations);
        captureEmailIdPage.setEmailID(emailaddressValidations);
        commonUtils.selectButtonByName(maritalStatus,driver);
        //captureEmailIdPage.setMaritalStatus(maritalStatus);
        captureEmailIdPage.setFatherSpouseName(fathersNameOrSpouseName);
        captureEmailIdPage.setMotherName(mothersName);
        captureEmailIdPage.setValueToQuestions(question1,answer1,valueToBeEnter);
        captureEmailIdPage.setValueToQuestions2(question2,answer2,valueToBeEnter2);
        captureEmailIdPage.setValueToQuestions3(question3,answer3,valueToBeEnter3);
        captureEmailIdPage.setValueToQuestions4(question4,answer4,valueToBeEnter4);
        waitUtils.waitForElementToBeClickable(driver,captureEmailIdPage.qualificationText);
        commonUtils.scrollToElementAndClick(driver,captureEmailIdPage.qualificationText);
        waitUtils.wait2Seconds();

        System.out.println(qualification);
        waitUtils.WaitForListOfElementPresent(driver,captureEmailIdPage.qualificationsList,10);
        captureEmailIdPage.selectQualificationandoccupationFromList(qualification);
        // captureEmailIdPage.getQualificationFromList(qualification);
        waitUtils.wait2Seconds();
        commonUtils.scrolldown(driver);
        commonUtils.scrollToElementAndClick(driver,captureEmailIdPage.occupationText);
        waitUtils.WaitForListOfElementPresent(driver,captureEmailIdPage.qualificationsList,10);
        captureEmailIdPage.selectQualificationandoccupationFromList(occupation);
        //captureEmailIdPage.getOccupationList(occupation);
        waitUtils.wait2Seconds();
        waitUtils.waitForElementToBeVisible(driver,captureEmailIdPage.employerName);
        captureEmailIdPage.setEmployerName(employeerName);
        captureEmailIdPage.setNameOfBusiness(nameOfBusinessOrduties);
        captureEmailIdPage.organization();
        waitUtils.WaitForListOfElementPresent(driver,captureEmailIdPage.listOfOrgs,10);
        captureEmailIdPage.selectQualificationandoccupationFromList(typeOfOrganization);
        // captureEmailIdPage.getOraNameFromList(typeOfOrganization);
        captureEmailIdPage.setnameOfDesignation(designation);
        captureEmailIdPage.setannualIncome(annualIncome);
        commonUtils.selectButtonByName("SAVE & CONTINUE",driver);
        waitUtils.wait5Seconds();
        if(captureEmailIdPage.inActiveMesage.isDisplayed()){
            waitUtils.Asserting("contains",captureEmailIdPage.inActiveMesage.getText(),"Invalid Email");
        }else {

            System.out.println("given email is an active state");
        }


    }
  //  @Test(dataProvider = "dataEmailProvider",dataProviderClass = DataProviders.class, priority = 8)
    @Description("verify capture emailId")
    public void verify_EmailId_digits(String username, String password, String policy, String leadid, String proposersame, String propinsurednotsame, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                      String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                      String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                      String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                      String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                      String clickverify,String renewpremiumscreentitle,String paymentmethod,String drawdate,String fundsource,
                                      String nomineescreentitle, String nomineefirstname, String nomineelastname, String nomineeday,
                                      String nomineemonth, String nomineeyear, String nomineegender, String relationshipwithproposer, String nomineeshare,
                                      String ismwppolicy,
                                      String addressscreentitle, String typeofaddress, String addresspincode, String address1, String address2, String address3, String personalDetailsscreentitle, String cityName, String preferredLanguage, String alernateNumber, String resTelephoneNumber,String emailaddressValidations,String maritalStatus,String fathersNameOrSpouseName,String mothersName,
                                      String question1,String answer1,String valueToBeEnter,String question2,String answer2,String valueToBeEnter2,String question3,String answer3,String valueToBeEnter3,String question4,String answer4,String valueToBeEnter4,String qualification,
                                      String occupation,String employeerName,String nameOfBusinessOrduties,String typeOfOrganization,String designation,String annualIncome,String ExistingPolicyscreentitle) throws Exception {
        new TestFactory().gotoCapturedEmailID(driver,username,password,policy,leadid,proposersame,propinsurednotsame,isnri,pmobile,ppan,imobile,ipan,firstname,lastname,middlename,day,month,year,gender,planjourney,
                proposerstate,advisorstatesame,plan,sumassured,smokertype,planoptions,increasinglevel,ecs,term,ppt,premiumterm,premiumamount,rider,rideramount,minrider,maxrider,ridererror,click,generateillustrations,
                clickcontinue,ifsccode,bankaccno,accholdername,accounttype,pennyalert,clickverify,renewpremiumscreentitle,paymentmethod,drawdate,fundsource,nomineescreentitle,
                nomineefirstname,nomineelastname,nomineeday,nomineemonth,nomineeyear,nomineegender,relationshipwithproposer,nomineeshare,ismwppolicy,addressscreentitle,typeofaddress,addresspincode,address1,address2,address3,personalDetailsscreentitle,cityName,preferredLanguage,alernateNumber,resTelephoneNumber);

        captureEmailIdPage.setEmailID(emailaddressValidations);
        captureEmailIdPage.setEmailID(emailaddressValidations);
        commonUtils.selectButtonByName(maritalStatus,driver);
        //captureEmailIdPage.setMaritalStatus(maritalStatus);
        captureEmailIdPage.setFatherSpouseName(fathersNameOrSpouseName);
        captureEmailIdPage.setMotherName(mothersName);
        captureEmailIdPage.setValueToQuestions(question1,answer1,valueToBeEnter);
        captureEmailIdPage.setValueToQuestions2(question2,answer2,valueToBeEnter2);
        captureEmailIdPage.setValueToQuestions3(question3,answer3,valueToBeEnter3);
        captureEmailIdPage.setValueToQuestions4(question4,answer4,valueToBeEnter4);
        waitUtils.waitForElementToBeClickable(driver,captureEmailIdPage.qualificationText);
        commonUtils.scrollToElementAndClick(driver,captureEmailIdPage.qualificationText);
        waitUtils.wait2Seconds();

        System.out.println(qualification);
        waitUtils.WaitForListOfElementPresent(driver,captureEmailIdPage.qualificationsList,10);
        captureEmailIdPage.selectQualificationandoccupationFromList(qualification);
        // captureEmailIdPage.getQualificationFromList(qualification);
        waitUtils.wait2Seconds();
        commonUtils.scrolldown(driver);
        commonUtils.scrollToElementAndClick(driver,captureEmailIdPage.occupationText);
        waitUtils.WaitForListOfElementPresent(driver,captureEmailIdPage.qualificationsList,10);
        captureEmailIdPage.selectQualificationandoccupationFromList(occupation);
        //captureEmailIdPage.getOccupationList(occupation);
        waitUtils.wait2Seconds();
        waitUtils.waitForElementToBeVisible(driver,captureEmailIdPage.employerName);
        captureEmailIdPage.setEmployerName(employeerName);
        captureEmailIdPage.setNameOfBusiness(nameOfBusinessOrduties);
        captureEmailIdPage.organization();
        waitUtils.WaitForListOfElementPresent(driver,captureEmailIdPage.listOfOrgs,10);
        captureEmailIdPage.selectQualificationandoccupationFromList(typeOfOrganization);
        // captureEmailIdPage.getOraNameFromList(typeOfOrganization);
        captureEmailIdPage.setnameOfDesignation(designation);
        captureEmailIdPage.setannualIncome(annualIncome);
        commonUtils.selectButtonByName("SAVE & CONTINUE",driver);
        waitUtils.wait5Seconds();


    }
   //@Test(dataProvider = "dataEmailProvider", dataProviderClass = DataProviders.class,priority = 9)
    @Description("verify capture emailId")
    public void verify_EmailId_Underscore(String username, String password, String policy, String leadid, String proposersame, String propinsurednotsame, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                          String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                          String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                          String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                          String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                          String clickverify,String renewpremiumscreentitle,String paymentmethod,String drawdate,String fundsource,
                                          String nomineescreentitle, String nomineefirstname, String nomineelastname, String nomineeday,
                                          String nomineemonth, String nomineeyear, String nomineegender, String relationshipwithproposer, String nomineeshare,
                                          String ismwppolicy,
                                          String addressscreentitle, String typeofaddress, String addresspincode, String address1, String address2, String address3, String personalDetailsscreentitle, String cityName, String preferredLanguage, String alernateNumber, String resTelephoneNumber,String emailaddressValidations,String maritalStatus,String fathersNameOrSpouseName,String mothersName,
                                          String question1,String answer1,String valueToBeEnter,String question2,String answer2,String valueToBeEnter2,String question3,String answer3,String valueToBeEnter3,String question4,String answer4,String valueToBeEnter4,String qualification,
                                          String occupation,String employeerName,String nameOfBusinessOrduties,String typeOfOrganization,String designation,String annualIncome,String ExistingPolicyscreentitle) throws Exception {
        new TestFactory().gotoCapturedEmailID(driver,username,password,policy,leadid,proposersame,propinsurednotsame,isnri,pmobile,ppan,imobile,ipan,firstname,lastname,middlename,day,month,year,gender,planjourney,
                proposerstate,advisorstatesame,plan,sumassured,smokertype,planoptions,increasinglevel,ecs,term,ppt,premiumterm,premiumamount,rider,rideramount,minrider,maxrider,ridererror,click,generateillustrations,
                clickcontinue,ifsccode,bankaccno,accholdername,accounttype,pennyalert,clickverify,renewpremiumscreentitle,paymentmethod,drawdate,fundsource,nomineescreentitle,
                nomineefirstname,nomineelastname,nomineeday,nomineemonth,nomineeyear,nomineegender,relationshipwithproposer,nomineeshare,ismwppolicy,addressscreentitle,typeofaddress,addresspincode,address1,address2,address3,personalDetailsscreentitle,cityName,preferredLanguage,alernateNumber,resTelephoneNumber);


        captureEmailIdPage.setEmailID(emailaddressValidations);
        captureEmailIdPage.setEmailID(emailaddressValidations);
        commonUtils.selectButtonByName(maritalStatus,driver);
        //captureEmailIdPage.setMaritalStatus(maritalStatus);
        captureEmailIdPage.setFatherSpouseName(fathersNameOrSpouseName);
        captureEmailIdPage.setMotherName(mothersName);
        captureEmailIdPage.setValueToQuestions(question1,answer1,valueToBeEnter);
        captureEmailIdPage.setValueToQuestions2(question2,answer2,valueToBeEnter2);
        captureEmailIdPage.setValueToQuestions3(question3,answer3,valueToBeEnter3);
        captureEmailIdPage.setValueToQuestions4(question4,answer4,valueToBeEnter4);
        waitUtils.waitForElementToBeClickable(driver,captureEmailIdPage.qualificationText);
        commonUtils.scrollToElementAndClick(driver,captureEmailIdPage.qualificationText);
        waitUtils.wait2Seconds();

        System.out.println(qualification);
        waitUtils.WaitForListOfElementPresent(driver,captureEmailIdPage.qualificationsList,10);
        captureEmailIdPage.selectQualificationandoccupationFromList(qualification);
        // captureEmailIdPage.getQualificationFromList(qualification);
        waitUtils.wait2Seconds();
        commonUtils.scrolldown(driver);
        commonUtils.scrollToElementAndClick(driver,captureEmailIdPage.occupationText);
        waitUtils.WaitForListOfElementPresent(driver,captureEmailIdPage.qualificationsList,10);
        captureEmailIdPage.selectQualificationandoccupationFromList(occupation);
        //captureEmailIdPage.getOccupationList(occupation);
        waitUtils.wait2Seconds();
        waitUtils.waitForElementToBeVisible(driver,captureEmailIdPage.employerName);
        captureEmailIdPage.setEmployerName(employeerName);
        captureEmailIdPage.setNameOfBusiness(nameOfBusinessOrduties);
        captureEmailIdPage.organization();
        waitUtils.WaitForListOfElementPresent(driver,captureEmailIdPage.listOfOrgs,10);
        captureEmailIdPage.selectQualificationandoccupationFromList(typeOfOrganization);
        // captureEmailIdPage.getOraNameFromList(typeOfOrganization);
        captureEmailIdPage.setnameOfDesignation(designation);
        captureEmailIdPage.setannualIncome(annualIncome);
        commonUtils.selectButtonByName("SAVE & CONTINUE",driver);
        waitUtils.wait5Seconds();
        if(captureEmailIdPage.inActiveMesage.isDisplayed()){
            waitUtils.Asserting("contains",captureEmailIdPage.inActiveMesage.getText(),"Invalid Email");
        }else {

            System.out.println("given email is an active state");
        }


    }
   // @Test(dataProvider = "dataEmailProvider", dataProviderClass = DataProviders.class,priority = 10)
    @Description("verify capture emailId")
    public void verify_EmailId_Domain_name(String username, String password, String policy, String leadid, String proposersame, String propinsurednotsame, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                           String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                           String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                           String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                           String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                           String clickverify,String renewpremiumscreentitle,String paymentmethod,String drawdate,String fundsource,
                                           String nomineescreentitle, String nomineefirstname, String nomineelastname, String nomineeday,
                                           String nomineemonth, String nomineeyear, String nomineegender, String relationshipwithproposer, String nomineeshare,
                                           String ismwppolicy,
                                           String addressscreentitle, String typeofaddress, String addresspincode, String address1, String address2, String address3, String personalDetailsscreentitle, String cityName, String preferredLanguage, String alernateNumber, String resTelephoneNumber,String emailaddressValidations,String maritalStatus,String fathersNameOrSpouseName,String mothersName,
                                           String question1,String answer1,String valueToBeEnter,String question2,String answer2,String valueToBeEnter2,String question3,String answer3,String valueToBeEnter3,String question4,String answer4,String valueToBeEnter4,String qualification,
                                           String occupation,String employeerName,String nameOfBusinessOrduties,String typeOfOrganization,String designation,String annualIncome,String ExistingPolicyscreentitle) throws Exception {
        new TestFactory().gotoCapturedEmailID(driver,username,password,policy,leadid,proposersame,propinsurednotsame,isnri,pmobile,ppan,imobile,ipan,firstname,lastname,middlename,day,month,year,gender,planjourney,
                proposerstate,advisorstatesame,plan,sumassured,smokertype,planoptions,increasinglevel,ecs,term,ppt,premiumterm,premiumamount,rider,rideramount,minrider,maxrider,ridererror,click,generateillustrations,
                clickcontinue,ifsccode,bankaccno,accholdername,accounttype,pennyalert,clickverify,renewpremiumscreentitle,paymentmethod,drawdate,fundsource,nomineescreentitle,
                nomineefirstname,nomineelastname,nomineeday,nomineemonth,nomineeyear,nomineegender,relationshipwithproposer,nomineeshare,ismwppolicy,addressscreentitle,typeofaddress,addresspincode,address1,address2,address3,personalDetailsscreentitle,cityName,preferredLanguage,alernateNumber,resTelephoneNumber);

        captureEmailIdPage.setEmailID(emailaddressValidations);
        captureEmailIdPage.setEmailID(emailaddressValidations);
        commonUtils.selectButtonByName(maritalStatus,driver);
        //captureEmailIdPage.setMaritalStatus(maritalStatus);
        captureEmailIdPage.setFatherSpouseName(fathersNameOrSpouseName);
        captureEmailIdPage.setMotherName(mothersName);
        captureEmailIdPage.setValueToQuestions(question1,answer1,valueToBeEnter);
        captureEmailIdPage.setValueToQuestions2(question2,answer2,valueToBeEnter2);
        captureEmailIdPage.setValueToQuestions3(question3,answer3,valueToBeEnter3);
        captureEmailIdPage.setValueToQuestions4(question4,answer4,valueToBeEnter4);
        waitUtils.waitForElementToBeClickable(driver,captureEmailIdPage.qualificationText);
        commonUtils.scrollToElementAndClick(driver,captureEmailIdPage.qualificationText);
        waitUtils.wait2Seconds();

        System.out.println(qualification);
        waitUtils.WaitForListOfElementPresent(driver,captureEmailIdPage.qualificationsList,10);
        captureEmailIdPage.selectQualificationandoccupationFromList(qualification);
        // captureEmailIdPage.getQualificationFromList(qualification);
        waitUtils.wait2Seconds();
        commonUtils.scrolldown(driver);
        commonUtils.scrollToElementAndClick(driver,captureEmailIdPage.occupationText);
        waitUtils.WaitForListOfElementPresent(driver,captureEmailIdPage.qualificationsList,10);
        captureEmailIdPage.selectQualificationandoccupationFromList(occupation);
        //captureEmailIdPage.getOccupationList(occupation);
        waitUtils.wait2Seconds();
        waitUtils.waitForElementToBeVisible(driver,captureEmailIdPage.employerName);
        captureEmailIdPage.setEmployerName(employeerName);
        captureEmailIdPage.setNameOfBusiness(nameOfBusinessOrduties);
        captureEmailIdPage.organization();
        waitUtils.WaitForListOfElementPresent(driver,captureEmailIdPage.listOfOrgs,10);
        captureEmailIdPage.selectQualificationandoccupationFromList(typeOfOrganization);
        // captureEmailIdPage.getOraNameFromList(typeOfOrganization);
        captureEmailIdPage.setnameOfDesignation(designation);
        captureEmailIdPage.setannualIncome(annualIncome);
        commonUtils.selectButtonByName("SAVE & CONTINUE",driver);
        waitUtils.wait5Seconds();
        if(captureEmailIdPage.inActiveMesage.isDisplayed()){
            waitUtils.Asserting("contains",captureEmailIdPage.inActiveMesage.getText(),"Invalid Email");
        }else {

            System.out.println("given email is an active state");
        }


    }
  //  @Test(dataProvider = "dataEmailProvider",dataProviderClass = DataProviders.class, priority = 11)
    @Description("verify capture emailId")
    public void verify_EmailId_garbage(String username, String password, String policy, String leadid, String proposersame, String propinsurednotsame, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                       String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                       String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                       String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                       String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                       String clickverify,String renewpremiumscreentitle,String paymentmethod,String drawdate,String fundsource,
                                       String nomineescreentitle, String nomineefirstname, String nomineelastname, String nomineeday,
                                       String nomineemonth, String nomineeyear, String nomineegender, String relationshipwithproposer, String nomineeshare,
                                       String ismwppolicy,
                                       String addressscreentitle, String typeofaddress, String addresspincode, String address1, String address2, String address3, String personalDetailsscreentitle, String cityName, String preferredLanguage, String alernateNumber, String resTelephoneNumber,String emailaddressValidations,String maritalStatus,String fathersNameOrSpouseName,String mothersName,
                                       String question1,String answer1,String valueToBeEnter,String question2,String answer2,String valueToBeEnter2,String question3,String answer3,String valueToBeEnter3,String question4,String answer4,String valueToBeEnter4,String qualification,
                                       String occupation,String employeerName,String nameOfBusinessOrduties,String typeOfOrganization,String designation,String annualIncome,String ExistingPolicyscreentitle) throws Exception {
        new TestFactory().gotoCapturedEmailID(driver,username,password,policy,leadid,proposersame,propinsurednotsame,isnri,pmobile,ppan,imobile,ipan,firstname,lastname,middlename,day,month,year,gender,planjourney,
                proposerstate,advisorstatesame,plan,sumassured,smokertype,planoptions,increasinglevel,ecs,term,ppt,premiumterm,premiumamount,rider,rideramount,minrider,maxrider,ridererror,click,generateillustrations,
                clickcontinue,ifsccode,bankaccno,accholdername,accounttype,pennyalert,clickverify,renewpremiumscreentitle,paymentmethod,drawdate,fundsource,nomineescreentitle,
                nomineefirstname,nomineelastname,nomineeday,nomineemonth,nomineeyear,nomineegender,relationshipwithproposer,nomineeshare,ismwppolicy,addressscreentitle,typeofaddress,addresspincode,address1,address2,address3,personalDetailsscreentitle,cityName,preferredLanguage,alernateNumber,resTelephoneNumber);

        captureEmailIdPage.setEmailID(emailaddressValidations);
        captureEmailIdPage.setEmailID(emailaddressValidations);
        commonUtils.selectButtonByName(maritalStatus,driver);
        //captureEmailIdPage.setMaritalStatus(maritalStatus);
        captureEmailIdPage.setFatherSpouseName(fathersNameOrSpouseName);
        captureEmailIdPage.setMotherName(mothersName);
        captureEmailIdPage.setValueToQuestions(question1,answer1,valueToBeEnter);
        captureEmailIdPage.setValueToQuestions2(question2,answer2,valueToBeEnter2);
        captureEmailIdPage.setValueToQuestions3(question3,answer3,valueToBeEnter3);
        captureEmailIdPage.setValueToQuestions4(question4,answer4,valueToBeEnter4);
        waitUtils.waitForElementToBeClickable(driver,captureEmailIdPage.qualificationText);
        commonUtils.scrollToElementAndClick(driver,captureEmailIdPage.qualificationText);
        waitUtils.wait2Seconds();

        System.out.println(qualification);
        waitUtils.WaitForListOfElementPresent(driver,captureEmailIdPage.qualificationsList,10);
        captureEmailIdPage.selectQualificationandoccupationFromList(qualification);
        // captureEmailIdPage.getQualificationFromList(qualification);
        waitUtils.wait2Seconds();
        commonUtils.scrolldown(driver);
        commonUtils.scrollToElementAndClick(driver,captureEmailIdPage.occupationText);
        waitUtils.WaitForListOfElementPresent(driver,captureEmailIdPage.qualificationsList,10);
        captureEmailIdPage.selectQualificationandoccupationFromList(occupation);
        //captureEmailIdPage.getOccupationList(occupation);
        waitUtils.wait2Seconds();
        waitUtils.waitForElementToBeVisible(driver,captureEmailIdPage.employerName);
        captureEmailIdPage.setEmployerName(employeerName);
        captureEmailIdPage.setNameOfBusiness(nameOfBusinessOrduties);
        captureEmailIdPage.organization();
        waitUtils.WaitForListOfElementPresent(driver,captureEmailIdPage.listOfOrgs,10);
        captureEmailIdPage.selectQualificationandoccupationFromList(typeOfOrganization);
        // captureEmailIdPage.getOraNameFromList(typeOfOrganization);
        captureEmailIdPage.setnameOfDesignation(designation);
        captureEmailIdPage.setannualIncome(annualIncome);
        commonUtils.selectButtonByName("SAVE & CONTINUE",driver);
        waitUtils.wait5Seconds();
        if(captureEmailIdPage.inActiveMesage.isDisplayed()){
            waitUtils.Asserting("contains",captureEmailIdPage.inActiveMesage.getText(),"Invalid Email");
        }else {

            System.out.println("given email is an active state");
        }


    }
  // @Test(dataProvider = "dataEmailProvider", dataProviderClass = DataProviders.class,priority = 12)
    @Description("verify capture emailId")
    public void verify_EmailId_missingUserName(String username, String password, String policy, String leadid, String proposersame, String propinsurednotsame, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                               String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                               String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                               String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                               String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                               String clickverify,String renewpremiumscreentitle,String paymentmethod,String drawdate,String fundsource,
                                               String nomineescreentitle, String nomineefirstname, String nomineelastname, String nomineeday,
                                               String nomineemonth, String nomineeyear, String nomineegender, String relationshipwithproposer, String nomineeshare,
                                               String ismwppolicy,
                                               String addressscreentitle, String typeofaddress, String addresspincode, String address1, String address2, String address3, String personalDetailsscreentitle, String cityName, String preferredLanguage, String alernateNumber, String resTelephoneNumber,String emailaddressValidations,String maritalStatus,String fathersNameOrSpouseName,String mothersName,
                                               String question1,String answer1,String valueToBeEnter,String question2,String answer2,String valueToBeEnter2,String question3,String answer3,String valueToBeEnter3,String question4,String answer4,String valueToBeEnter4,String qualification,
                                               String occupation,String employeerName,String nameOfBusinessOrduties,String typeOfOrganization,String designation,String annualIncome,String ExistingPolicyscreentitle) throws Exception {
        new TestFactory().gotoCapturedEmailID(driver,username,password,policy,leadid,proposersame,propinsurednotsame,isnri,pmobile,ppan,imobile,ipan,firstname,lastname,middlename,day,month,year,gender,planjourney,
                proposerstate,advisorstatesame,plan,sumassured,smokertype,planoptions,increasinglevel,ecs,term,ppt,premiumterm,premiumamount,rider,rideramount,minrider,maxrider,ridererror,click,generateillustrations,
                clickcontinue,ifsccode,bankaccno,accholdername,accounttype,pennyalert,clickverify,renewpremiumscreentitle,paymentmethod,drawdate,fundsource,nomineescreentitle,
                nomineefirstname,nomineelastname,nomineeday,nomineemonth,nomineeyear,nomineegender,relationshipwithproposer,nomineeshare,ismwppolicy,addressscreentitle,typeofaddress,addresspincode,address1,address2,address3,personalDetailsscreentitle,cityName,preferredLanguage,alernateNumber,resTelephoneNumber);

        captureEmailIdPage.setEmailID(emailaddressValidations);
        captureEmailIdPage.setEmailID(emailaddressValidations);
        commonUtils.selectButtonByName(maritalStatus,driver);
        //captureEmailIdPage.setMaritalStatus(maritalStatus);
        captureEmailIdPage.setFatherSpouseName(fathersNameOrSpouseName);
        captureEmailIdPage.setMotherName(mothersName);
        captureEmailIdPage.setValueToQuestions(question1,answer1,valueToBeEnter);
        captureEmailIdPage.setValueToQuestions2(question2,answer2,valueToBeEnter2);
        captureEmailIdPage.setValueToQuestions3(question3,answer3,valueToBeEnter3);
        captureEmailIdPage.setValueToQuestions4(question4,answer4,valueToBeEnter4);
        waitUtils.waitForElementToBeClickable(driver,captureEmailIdPage.qualificationText);
        commonUtils.scrollToElementAndClick(driver,captureEmailIdPage.qualificationText);
        waitUtils.wait2Seconds();

        System.out.println(qualification);
        waitUtils.WaitForListOfElementPresent(driver,captureEmailIdPage.qualificationsList,10);
        captureEmailIdPage.selectQualificationandoccupationFromList(qualification);
        // captureEmailIdPage.getQualificationFromList(qualification);
        waitUtils.wait2Seconds();
        commonUtils.scrolldown(driver);
        commonUtils.scrollToElementAndClick(driver,captureEmailIdPage.occupationText);
        waitUtils.WaitForListOfElementPresent(driver,captureEmailIdPage.qualificationsList,10);
        captureEmailIdPage.selectQualificationandoccupationFromList(occupation);
        //captureEmailIdPage.getOccupationList(occupation);
        waitUtils.wait2Seconds();
        waitUtils.waitForElementToBeVisible(driver,captureEmailIdPage.employerName);
        captureEmailIdPage.setEmployerName(employeerName);
        captureEmailIdPage.setNameOfBusiness(nameOfBusinessOrduties);
        captureEmailIdPage.organization();
        waitUtils.WaitForListOfElementPresent(driver,captureEmailIdPage.listOfOrgs,10);
        captureEmailIdPage.selectQualificationandoccupationFromList(typeOfOrganization);
        // captureEmailIdPage.getOraNameFromList(typeOfOrganization);
        captureEmailIdPage.setnameOfDesignation(designation);
        captureEmailIdPage.setannualIncome(annualIncome);
        commonUtils.selectButtonByName("SAVE & CONTINUE",driver);
        waitUtils.wait5Seconds();
        if(captureEmailIdPage.inActiveMesage.isDisplayed()){
            waitUtils.Asserting("contains",captureEmailIdPage.inActiveMesage.getText(),"Invalid Email");
        }else {

            System.out.println("given email is an active state");
        }


    }
  // @Test(dataProvider = "dataEmailProvider", dataProviderClass = DataProviders.class,priority = 14)
    @Description("verify capture emailId")
    public void verify_EmailId_Twosigns(String username, String password, String policy, String leadid, String proposersame, String propinsurednotsame, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                        String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                        String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                        String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                        String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                        String clickverify,String renewpremiumscreentitle,String paymentmethod,String drawdate,String fundsource,
                                        String nomineescreentitle, String nomineefirstname, String nomineelastname, String nomineeday,
                                        String nomineemonth, String nomineeyear, String nomineegender, String relationshipwithproposer, String nomineeshare,
                                        String ismwppolicy,
                                        String addressscreentitle, String typeofaddress, String addresspincode, String address1, String address2, String address3, String personalDetailsscreentitle, String cityName, String preferredLanguage, String alernateNumber, String resTelephoneNumber,String emailaddressValidations,String maritalStatus,String fathersNameOrSpouseName,String mothersName,
                                        String question1,String answer1,String valueToBeEnter,String question2,String answer2,String valueToBeEnter2,String question3,String answer3,String valueToBeEnter3,String question4,String answer4,String valueToBeEnter4,String qualification,
                                        String occupation,String employeerName,String nameOfBusinessOrduties,String typeOfOrganization,String designation,String annualIncome,String ExistingPolicyscreentitle) throws Exception {
        new TestFactory().gotoCapturedEmailID(driver,username,password,policy,leadid,proposersame,propinsurednotsame,isnri,pmobile,ppan,imobile,ipan,firstname,lastname,middlename,day,month,year,gender,planjourney,
                proposerstate,advisorstatesame,plan,sumassured,smokertype,planoptions,increasinglevel,ecs,term,ppt,premiumterm,premiumamount,rider,rideramount,minrider,maxrider,ridererror,click,generateillustrations,
                clickcontinue,ifsccode,bankaccno,accholdername,accounttype,pennyalert,clickverify,renewpremiumscreentitle,paymentmethod,drawdate,fundsource,nomineescreentitle,
                nomineefirstname,nomineelastname,nomineeday,nomineemonth,nomineeyear,nomineegender,relationshipwithproposer,nomineeshare,ismwppolicy,addressscreentitle,typeofaddress,addresspincode,address1,address2,address3,personalDetailsscreentitle,cityName,preferredLanguage,alernateNumber,resTelephoneNumber);

        captureEmailIdPage.setEmailID(emailaddressValidations);
        captureEmailIdPage.setEmailID(emailaddressValidations);
        commonUtils.selectButtonByName(maritalStatus,driver);
        //captureEmailIdPage.setMaritalStatus(maritalStatus);
        captureEmailIdPage.setFatherSpouseName(fathersNameOrSpouseName);
        captureEmailIdPage.setMotherName(mothersName);
        captureEmailIdPage.setValueToQuestions(question1,answer1,valueToBeEnter);
        captureEmailIdPage.setValueToQuestions2(question2,answer2,valueToBeEnter2);
        captureEmailIdPage.setValueToQuestions3(question3,answer3,valueToBeEnter3);
        captureEmailIdPage.setValueToQuestions4(question4,answer4,valueToBeEnter4);
        waitUtils.waitForElementToBeClickable(driver,captureEmailIdPage.qualificationText);
        commonUtils.scrollToElementAndClick(driver,captureEmailIdPage.qualificationText);
        waitUtils.wait2Seconds();

        System.out.println(qualification);
        waitUtils.WaitForListOfElementPresent(driver,captureEmailIdPage.qualificationsList,10);
        captureEmailIdPage.selectQualificationandoccupationFromList(qualification);
        // captureEmailIdPage.getQualificationFromList(qualification);
        waitUtils.wait2Seconds();
        commonUtils.scrolldown(driver);
        commonUtils.scrollToElementAndClick(driver,captureEmailIdPage.occupationText);
        waitUtils.WaitForListOfElementPresent(driver,captureEmailIdPage.qualificationsList,10);
        captureEmailIdPage.selectQualificationandoccupationFromList(occupation);
        //captureEmailIdPage.getOccupationList(occupation);
        waitUtils.wait2Seconds();
        waitUtils.waitForElementToBeVisible(driver,captureEmailIdPage.employerName);
        captureEmailIdPage.setEmployerName(employeerName);
        captureEmailIdPage.setNameOfBusiness(nameOfBusinessOrduties);
        captureEmailIdPage.organization();
        waitUtils.WaitForListOfElementPresent(driver,captureEmailIdPage.listOfOrgs,10);
        captureEmailIdPage.selectQualificationandoccupationFromList(typeOfOrganization);
        // captureEmailIdPage.getOraNameFromList(typeOfOrganization);
        captureEmailIdPage.setnameOfDesignation(designation);
        captureEmailIdPage.setannualIncome(annualIncome);
        commonUtils.selectButtonByName("SAVE & CONTINUE",driver);
        waitUtils.wait5Seconds();
        if(captureEmailIdPage.inActiveMesage.isDisplayed()){
            waitUtils.Asserting("contains",captureEmailIdPage.inActiveMesage.getText(),"Invalid Email");
        }else {

            System.out.println("given email is an active state");
        }
    }
    //@Test(dataProvider = "dataEmailProvider",dataProviderClass = DataProviders.class, priority = 13)
    @Description("verify capture emailId")
    public void verify_EmailId_text(String username, String password, String policy, String leadid, String proposersame, String propinsurednotsame, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                    String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                    String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                    String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                    String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                    String clickverify,String renewpremiumscreentitle,String paymentmethod,String drawdate,String fundsource,
                                    String nomineescreentitle, String nomineefirstname, String nomineelastname, String nomineeday,
                                    String nomineemonth, String nomineeyear, String nomineegender, String relationshipwithproposer, String nomineeshare,
                                    String ismwppolicy,
                                    String addressscreentitle, String typeofaddress, String addresspincode, String address1, String address2, String address3, String personalDetailsscreentitle, String cityName, String preferredLanguage, String alernateNumber, String resTelephoneNumber,String emailaddressValidations,String maritalStatus,String fathersNameOrSpouseName,String mothersName,
                                    String question1,String answer1,String valueToBeEnter,String question2,String answer2,String valueToBeEnter2,String question3,String answer3,String valueToBeEnter3,String question4,String answer4,String valueToBeEnter4,String qualification,
                                    String occupation,String employeerName,String nameOfBusinessOrduties,String typeOfOrganization,String designation,String annualIncome,String ExistingPolicyscreentitle) throws Exception {
        new TestFactory().gotoCapturedEmailID(driver,username,password,policy,leadid,proposersame,propinsurednotsame,isnri,pmobile,ppan,imobile,ipan,firstname,lastname,middlename,day,month,year,gender,planjourney,
                proposerstate,advisorstatesame,plan,sumassured,smokertype,planoptions,increasinglevel,ecs,term,ppt,premiumterm,premiumamount,rider,rideramount,minrider,maxrider,ridererror,click,generateillustrations,
                clickcontinue,ifsccode,bankaccno,accholdername,accounttype,pennyalert,clickverify,renewpremiumscreentitle,paymentmethod,drawdate,fundsource,nomineescreentitle,
                nomineefirstname,nomineelastname,nomineeday,nomineemonth,nomineeyear,nomineegender,relationshipwithproposer,nomineeshare,ismwppolicy,addressscreentitle,typeofaddress,addresspincode,address1,address2,address3,personalDetailsscreentitle,cityName,preferredLanguage,alernateNumber,resTelephoneNumber);

        captureEmailIdPage.setEmailID(emailaddressValidations);
        captureEmailIdPage.setEmailID(emailaddressValidations);
        commonUtils.selectButtonByName(maritalStatus,driver);
        //captureEmailIdPage.setMaritalStatus(maritalStatus);
        captureEmailIdPage.setFatherSpouseName(fathersNameOrSpouseName);
        captureEmailIdPage.setMotherName(mothersName);
        captureEmailIdPage.setValueToQuestions(question1,answer1,valueToBeEnter);
        captureEmailIdPage.setValueToQuestions2(question2,answer2,valueToBeEnter2);
        captureEmailIdPage.setValueToQuestions3(question3,answer3,valueToBeEnter3);
        captureEmailIdPage.setValueToQuestions4(question4,answer4,valueToBeEnter4);
        waitUtils.waitForElementToBeClickable(driver,captureEmailIdPage.qualificationText);
        commonUtils.scrollToElementAndClick(driver,captureEmailIdPage.qualificationText);
        waitUtils.wait2Seconds();

        System.out.println(qualification);
        waitUtils.WaitForListOfElementPresent(driver,captureEmailIdPage.qualificationsList,10);
        captureEmailIdPage.selectQualificationandoccupationFromList(qualification);
        // captureEmailIdPage.getQualificationFromList(qualification);
        waitUtils.wait2Seconds();
        commonUtils.scrolldown(driver);
        commonUtils.scrollToElementAndClick(driver,captureEmailIdPage.occupationText);
        waitUtils.WaitForListOfElementPresent(driver,captureEmailIdPage.qualificationsList,10);
        captureEmailIdPage.selectQualificationandoccupationFromList(occupation);
        //captureEmailIdPage.getOccupationList(occupation);
        waitUtils.wait2Seconds();
        waitUtils.waitForElementToBeVisible(driver,captureEmailIdPage.employerName);
        captureEmailIdPage.setEmployerName(employeerName);
        captureEmailIdPage.setNameOfBusiness(nameOfBusinessOrduties);
        captureEmailIdPage.organization();
        waitUtils.WaitForListOfElementPresent(driver,captureEmailIdPage.listOfOrgs,10);
        captureEmailIdPage.selectQualificationandoccupationFromList(typeOfOrganization);
        // captureEmailIdPage.getOraNameFromList(typeOfOrganization);
        captureEmailIdPage.setnameOfDesignation(designation);
        captureEmailIdPage.setannualIncome(annualIncome);
        commonUtils.selectButtonByName("SAVE & CONTINUE",driver);
        waitUtils.wait5Seconds();

        if(captureEmailIdPage.inActiveMesage.isDisplayed()){
            waitUtils.Asserting("contains",captureEmailIdPage.inActiveMesage.getText(),"Invalid Email");
        }else {

            System.out.println("given email is an active state");
        }


    }

   // @Test(dataProvider = "dataEmailProvider",dataProviderClass = DataProviders.class, priority = 15)
    @Description("verify capture emailId")
    public void verify_EmailId_MultipleDots(String username, String password, String policy, String leadid, String proposersame, String propinsurednotsame, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                            String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                            String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                            String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                            String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                            String clickverify,String renewpremiumscreentitle,String paymentmethod,String drawdate,String fundsource,
                                            String nomineescreentitle, String nomineefirstname, String nomineelastname, String nomineeday,
                                            String nomineemonth, String nomineeyear, String nomineegender, String relationshipwithproposer, String nomineeshare,
                                            String ismwppolicy,
                                            String addressscreentitle, String typeofaddress, String addresspincode, String address1, String address2, String address3, String personalDetailsscreentitle, String cityName, String preferredLanguage, String alernateNumber, String resTelephoneNumber,String emailaddressValidations,String maritalStatus,String fathersNameOrSpouseName,String mothersName,
                                            String question1,String answer1,String valueToBeEnter,String question2,String answer2,String valueToBeEnter2,String question3,String answer3,String valueToBeEnter3,String question4,String answer4,String valueToBeEnter4,String qualification,
                                            String occupation,String employeerName,String nameOfBusinessOrduties,String typeOfOrganization,String designation,String annualIncome,String ExistingPolicyscreentitle) throws Exception {
        new TestFactory().gotoCapturedEmailID(driver,username,password,policy,leadid,proposersame,propinsurednotsame,isnri,pmobile,ppan,imobile,ipan,firstname,lastname,middlename,day,month,year,gender,planjourney,
                proposerstate,advisorstatesame,plan,sumassured,smokertype,planoptions,increasinglevel,ecs,term,ppt,premiumterm,premiumamount,rider,rideramount,minrider,maxrider,ridererror,click,generateillustrations,
                clickcontinue,ifsccode,bankaccno,accholdername,accounttype,pennyalert,clickverify,renewpremiumscreentitle,paymentmethod,drawdate,fundsource,nomineescreentitle,
                nomineefirstname,nomineelastname,nomineeday,nomineemonth,nomineeyear,nomineegender,relationshipwithproposer,nomineeshare,ismwppolicy,addressscreentitle,typeofaddress,addresspincode,address1,address2,address3,personalDetailsscreentitle,cityName,preferredLanguage,alernateNumber,resTelephoneNumber);

        captureEmailIdPage.setEmailID(emailaddressValidations);
        captureEmailIdPage.setEmailID(emailaddressValidations);
        commonUtils.selectButtonByName(maritalStatus,driver);
        //captureEmailIdPage.setMaritalStatus(maritalStatus);
        captureEmailIdPage.setFatherSpouseName(fathersNameOrSpouseName);
        captureEmailIdPage.setMotherName(mothersName);
        captureEmailIdPage.setValueToQuestions(question1,answer1,valueToBeEnter);
        captureEmailIdPage.setValueToQuestions2(question2,answer2,valueToBeEnter2);
        captureEmailIdPage.setValueToQuestions3(question3,answer3,valueToBeEnter3);
        captureEmailIdPage.setValueToQuestions4(question4,answer4,valueToBeEnter4);
        waitUtils.waitForElementToBeClickable(driver,captureEmailIdPage.qualificationText);
        commonUtils.scrollToElementAndClick(driver,captureEmailIdPage.qualificationText);
        waitUtils.wait2Seconds();

        System.out.println(qualification);
        waitUtils.WaitForListOfElementPresent(driver,captureEmailIdPage.qualificationsList,10);
        captureEmailIdPage.selectQualificationandoccupationFromList(qualification);
        // captureEmailIdPage.getQualificationFromList(qualification);
        waitUtils.wait2Seconds();
        commonUtils.scrolldown(driver);
        commonUtils.scrollToElementAndClick(driver,captureEmailIdPage.occupationText);
        waitUtils.WaitForListOfElementPresent(driver,captureEmailIdPage.qualificationsList,10);
        captureEmailIdPage.selectQualificationandoccupationFromList(occupation);
        //captureEmailIdPage.getOccupationList(occupation);
        waitUtils.wait2Seconds();
        waitUtils.waitForElementToBeVisible(driver,captureEmailIdPage.employerName);
        captureEmailIdPage.setEmployerName(employeerName);
        captureEmailIdPage.setNameOfBusiness(nameOfBusinessOrduties);
        captureEmailIdPage.organization();
        waitUtils.WaitForListOfElementPresent(driver,captureEmailIdPage.listOfOrgs,10);
        captureEmailIdPage.selectQualificationandoccupationFromList(typeOfOrganization);
        // captureEmailIdPage.getOraNameFromList(typeOfOrganization);
        captureEmailIdPage.setnameOfDesignation(designation);
        captureEmailIdPage.setannualIncome(annualIncome);
        commonUtils.selectButtonByName("SAVE & CONTINUE",driver);
        waitUtils.wait5Seconds();
        if(captureEmailIdPage.inActiveMesage.isDisplayed()){
            waitUtils.Asserting("contains",captureEmailIdPage.inActiveMesage.getText(),"Invalid Email");
        }else {

            System.out.println("given email is an active state");
        }


    }

  // @Test(dataProvider = "dataEmailProvider", dataProviderClass = DataProviders.class,priority = 16)
    @Description("verify capture emailId")
    public void verify_EmailId_missing_domain(String username, String password, String policy, String leadid, String proposersame, String propinsurednotsame, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                              String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                              String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                              String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                              String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                              String clickverify,String renewpremiumscreentitle,String paymentmethod,String drawdate,String fundsource,
                                              String nomineescreentitle, String nomineefirstname, String nomineelastname, String nomineeday,
                                              String nomineemonth, String nomineeyear, String nomineegender, String relationshipwithproposer, String nomineeshare,
                                              String ismwppolicy,
                                              String addressscreentitle, String typeofaddress, String addresspincode, String address1, String address2, String address3, String personalDetailsscreentitle, String cityName, String preferredLanguage, String alernateNumber, String resTelephoneNumber,String emailaddressValidations,String maritalStatus,String fathersNameOrSpouseName,String mothersName,
                                              String question1,String answer1,String valueToBeEnter,String question2,String answer2,String valueToBeEnter2,String question3,String answer3,String valueToBeEnter3,String question4,String answer4,String valueToBeEnter4,String qualification,
                                              String occupation,String employeerName,String nameOfBusinessOrduties,String typeOfOrganization,String designation,String annualIncome,String ExistingPolicyscreentitle) throws Exception {
        new TestFactory().gotoCapturedEmailID(driver,username,password,policy,leadid,proposersame,propinsurednotsame,isnri,pmobile,ppan,imobile,ipan,firstname,lastname,middlename,day,month,year,gender,planjourney,
                proposerstate,advisorstatesame,plan,sumassured,smokertype,planoptions,increasinglevel,ecs,term,ppt,premiumterm,premiumamount,rider,rideramount,minrider,maxrider,ridererror,click,generateillustrations,
                clickcontinue,ifsccode,bankaccno,accholdername,accounttype,pennyalert,clickverify,renewpremiumscreentitle,paymentmethod,drawdate,fundsource,nomineescreentitle,
                nomineefirstname,nomineelastname,nomineeday,nomineemonth,nomineeyear,nomineegender,relationshipwithproposer,nomineeshare,ismwppolicy,addressscreentitle,typeofaddress,addresspincode,address1,address2,address3,personalDetailsscreentitle,cityName,preferredLanguage,alernateNumber,resTelephoneNumber);

        captureEmailIdPage.setEmailID(emailaddressValidations);
        captureEmailIdPage.setEmailID(emailaddressValidations);
        commonUtils.selectButtonByName(maritalStatus,driver);
        //captureEmailIdPage.setMaritalStatus(maritalStatus);
        captureEmailIdPage.setFatherSpouseName(fathersNameOrSpouseName);
        captureEmailIdPage.setMotherName(mothersName);
        captureEmailIdPage.setValueToQuestions(question1,answer1,valueToBeEnter);
        captureEmailIdPage.setValueToQuestions2(question2,answer2,valueToBeEnter2);
        captureEmailIdPage.setValueToQuestions3(question3,answer3,valueToBeEnter3);
        captureEmailIdPage.setValueToQuestions4(question4,answer4,valueToBeEnter4);
        waitUtils.waitForElementToBeClickable(driver,captureEmailIdPage.qualificationText);
        commonUtils.scrollToElementAndClick(driver,captureEmailIdPage.qualificationText);
        waitUtils.wait2Seconds();

        System.out.println(qualification);
        waitUtils.WaitForListOfElementPresent(driver,captureEmailIdPage.qualificationsList,10);
        captureEmailIdPage.selectQualificationandoccupationFromList(qualification);
        // captureEmailIdPage.getQualificationFromList(qualification);
        waitUtils.wait2Seconds();
        commonUtils.scrolldown(driver);
        commonUtils.scrollToElementAndClick(driver,captureEmailIdPage.occupationText);
        waitUtils.WaitForListOfElementPresent(driver,captureEmailIdPage.qualificationsList,10);
        captureEmailIdPage.selectQualificationandoccupationFromList(occupation);
        //captureEmailIdPage.getOccupationList(occupation);
        waitUtils.wait2Seconds();
        waitUtils.waitForElementToBeVisible(driver,captureEmailIdPage.employerName);
        captureEmailIdPage.setEmployerName(employeerName);
        captureEmailIdPage.setNameOfBusiness(nameOfBusinessOrduties);
        captureEmailIdPage.organization();
        waitUtils.WaitForListOfElementPresent(driver,captureEmailIdPage.listOfOrgs,10);
        captureEmailIdPage.selectQualificationandoccupationFromList(typeOfOrganization);
        // captureEmailIdPage.getOraNameFromList(typeOfOrganization);
        captureEmailIdPage.setnameOfDesignation(designation);
        captureEmailIdPage.setannualIncome(annualIncome);
        commonUtils.selectButtonByName("SAVE & CONTINUE",driver);
        waitUtils.wait5Seconds();
        if(captureEmailIdPage.inActiveMesage.isDisplayed()){
            waitUtils.Asserting("contains",captureEmailIdPage.inActiveMesage.getText(),"Invalid Email");
        }else {

            System.out.println("given email is an active state");
        }


    }
     //@Test(dataProvider = "dataEmailProvider", dataProviderClass = DataProviders.class,priority = 17)
    @Description("verify capture emailId")
    public void verify_Active_EmailId(String username, String password, String policy, String leadid, String proposersame, String propinsurednotsame, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                      String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                      String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                      String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                      String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                      String clickverify,String renewpremiumscreentitle,String paymentmethod,String drawdate,String fundsource,
                                      String nomineescreentitle, String nomineefirstname, String nomineelastname, String nomineeday,
                                      String nomineemonth, String nomineeyear, String nomineegender, String relationshipwithproposer, String nomineeshare,
                                      String ismwppolicy,
                                      String addressscreentitle, String typeofaddress, String addresspincode, String address1, String address2, String address3, String personalDetailsscreentitle, String cityName, String preferredLanguage, String alernateNumber, String resTelephoneNumber,String emailaddressValidations,String maritalStatus,String fathersNameOrSpouseName,String mothersName,
                                      String question1,String answer1,String valueToBeEnter,String question2,String answer2,String valueToBeEnter2,String question3,String answer3,String valueToBeEnter3,String question4,String answer4,String valueToBeEnter4,String qualification,
                                      String occupation,String employeerName,String nameOfBusinessOrduties,String typeOfOrganization,String designation,String annualIncome,String existingPolicyscreentitle) throws Exception {

      new TestFactory().gotoCapturedEmailID(driver,username,password,policy,leadid,proposersame,propinsurednotsame,isnri,pmobile,ppan,imobile,ipan,firstname,lastname,middlename,day,month,year,gender,planjourney,
                proposerstate,advisorstatesame,plan,sumassured,smokertype,planoptions,increasinglevel,ecs,term,ppt,premiumterm,premiumamount,rider,rideramount,minrider,maxrider,ridererror,click,generateillustrations,
                clickcontinue,ifsccode,bankaccno,accholdername,accounttype,pennyalert,clickverify,renewpremiumscreentitle,paymentmethod,drawdate,fundsource,nomineescreentitle,
                nomineefirstname,nomineelastname,nomineeday,nomineemonth,nomineeyear,nomineegender,relationshipwithproposer,nomineeshare,ismwppolicy,addressscreentitle,typeofaddress,addresspincode,address1,address2,address3,personalDetailsscreentitle,cityName,preferredLanguage,alernateNumber,resTelephoneNumber);
       // captureEmailIdPage.setEmailID(emailaddressValidations);
        captureEmailIdPage.setEmailID(emailaddressValidations);
        commonUtils.selectButtonByName(maritalStatus,driver);
        //captureEmailIdPage.setMaritalStatus(maritalStatus);
        captureEmailIdPage.setFatherSpouseName(fathersNameOrSpouseName);
        captureEmailIdPage.setMotherName(mothersName);
        waitUtils.wait2Seconds();

         captureEmailIdPage.setValueToQuestions(question1,answer1,valueToBeEnter);
         waitUtils.wait2Seconds();
         captureEmailIdPage.setValueToQuestions2(question2,answer2,valueToBeEnter2);
         waitUtils.wait2Seconds();
         captureEmailIdPage.setValueToQuestions3(question3,answer3,valueToBeEnter3);
         waitUtils.wait2Seconds();
         captureEmailIdPage.setValueToQuestions4(question4,answer4,valueToBeEnter4);
        waitUtils.waitForElementToBeClickable(driver,captureEmailIdPage.qualificationText);
        commonUtils.scrollToElementAndClick(driver,captureEmailIdPage.qualificationText);
        waitUtils.wait2Seconds();

        //System.out.println(qualification);
        waitUtils.WaitForListOfElementPresent(driver,captureEmailIdPage.qualificationsList,10);
        captureEmailIdPage.selectQualificationandoccupationFromList(qualification);
        // captureEmailIdPage.getQualificationFromList(qualification);
        waitUtils.wait2Seconds();
        commonUtils.scrolldown(driver);
        commonUtils.scrollToElementAndClick(driver,captureEmailIdPage.occupationText);
        waitUtils.WaitForListOfElementPresent(driver,captureEmailIdPage.qualificationsList,10);
        captureEmailIdPage.selectQualificationandoccupationFromList(occupation);
        //captureEmailIdPage.getOccupationList(occupation);
        waitUtils.wait2Seconds();
        waitUtils.waitForElementToBeVisible(driver,captureEmailIdPage.employerName);
        captureEmailIdPage.setEmployerName(employeerName);
        waitUtils.wait2Seconds();
        captureEmailIdPage.setNameOfBusiness(nameOfBusinessOrduties);
        waitUtils.wait2Seconds();
        captureEmailIdPage.organization();
        waitUtils.WaitForListOfElementPresent(driver,captureEmailIdPage.listOfOrgs,10);
        captureEmailIdPage.selectQualificationandoccupationFromList(typeOfOrganization);
        // captureEmailIdPage.getOraNameFromList(typeOfOrganization);
        captureEmailIdPage.setnameOfDesignation(designation);
        waitUtils.wait2Seconds();
        captureEmailIdPage.setannualIncome(annualIncome);
        waitUtils.wait2Seconds();
        commonUtils.selectButtonByName("SAVE & CONTINUE",driver);
        waitUtils.wait5Seconds();
        Assert.assertEquals(captureEmailIdPage.validateScreenTitle(existingPolicyscreentitle), existingPolicyscreentitle, "Failure in navigation to existing policy screen");

    }


}