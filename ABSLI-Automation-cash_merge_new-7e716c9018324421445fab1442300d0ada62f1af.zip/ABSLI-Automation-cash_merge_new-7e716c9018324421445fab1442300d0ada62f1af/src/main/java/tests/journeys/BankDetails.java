package tests.journeys;

import com.absli.helpers.dataProviders.DataProviders;
import com.absli.helpers.jsonReaders.ReadJson;
import com.absli.helpers.models.ConfigParentPojo;
import com.absli.helpers.models.ProposerModel;
import com.absli.listeners.TestLevelDriverCreator;
import com.absli.listeners.TestListener;
import com.absli.pageObjects.CreateApplPage;
import com.absli.pageObjects.SignInPage;
import com.absli.utils.CommonUtils;
import com.absli.utils.ExcelUtils;
import com.absli.utils.PropertiesUtils;
import com.absli.utils.WaitUtils;
import io.qameta.allure.Description;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.*;
import tests.BaseTest;
import tests.TestFactory;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;

@Listeners({TestLevelDriverCreator.class})
public class BankDetails extends BaseTest {

    ProposerModel proposerModel;
    ReadJson jsonObj;
    CreateApplPage createApplPage;
    CommonUtils commonUtils;
    WaitUtils waitUtils;
    PropertiesUtils prop;
    SignInPage signIn;

    @BeforeClass
    public void preSetup() throws IOException, InterruptedException {
        driver = new TestLevelDriverCreator().getDriver();
        commonUtils = new CommonUtils();
        waitUtils = new WaitUtils();
        prop = new PropertiesUtils();
        createApplPage = new CreateApplPage(driver);

    }

    @BeforeMethod
    public void relaunch()  {
        new BaseTest().relaunch();
    }


    //@Test(dataProvider = "dataBankProvider",dataProviderClass = DataProviders.class)
    @Description("verify bank account")
    public void verify_bank_account(String username, String password, String policy, String leadid, String proposersame,
                                    String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                    String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                    String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                    String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                    String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert, String clickverify, String renewpremiumscreentitle) throws InterruptedException, IOException {

        new TestFactory().gotoBank(driver, username,  password,  policy,  leadid,  proposersame,
                 relationwithinsured,	isrelationanswer,  isnri,  pmobile,  ppan,  imobile,  ipan,  firstname,  lastname,
                 middlename,  day,  month,  year,  gender,  planjourney,  proposerstate,  advisorstatesame,  plan,  sumassured,  smokertype,  planoptions,  increasinglevel,
                 ecs,  term,  ppt,  premiumterm,  premiumamount,
                 rider,  rideramount,  minrider,  maxrider,  ridererror,  click,  generateillustrations,
                 clickcontinue);
        createApplPage.inputIfscCode(ifsccode);
        Assert.assertTrue(createApplPage.eleIfscVerifyTick.isDisplayed(), "Ifsc code is not verified");

        Assert.assertNotNull(createApplPage.elebankName.getText(), "Bank name is not prefilled");
        Assert.assertNotNull(createApplPage.elebranchName.getText(), "Branch name is not prefilled");

        commonUtils.scrollIntoView("Account Details",driver);
        createApplPage.inputAccNo(bankaccno);
        waitUtils.implicitWait(driver,100);
        createApplPage.chooseAccountType(accounttype);
        commonUtils.scrollIntoView(clickverify, driver);
        commonUtils.selectButtonByName(clickverify, driver);
        Thread.sleep(3000);
        waitUtils.waitUntilElementIsVisibleByText(driver, 30, pennyalert, "Account not verified alert is not shown");
        commonUtils.selectButtonByName("OK", driver);
        waitUtils.waitUntilVisible(driver,createApplPage.eleInputAccHolderName,40);
        Assert.assertNotNull(createApplPage.eleInputAccHolderName.getText());
    }

    //@Test(dataProvider = "dataBankProvider",dataProviderClass = DataProviders.class)
    @Description("penny testing")
    public void penny_testing(String username, String password, String policy, String leadid, String proposersame, String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                              String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                              String ecs, String term, String ppt, String premiumterm, String premiumamount,
                              String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                              String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert, String clickverify, String renewpremiumscreentitle) throws InterruptedException, IOException {

        new TestFactory().gotoBank(driver, username,  password,  policy,  leadid,  proposersame,
                relationwithinsured,	isrelationanswer,  isnri,  pmobile,  ppan,  imobile,  ipan,  firstname,  lastname,
                middlename,  day,  month,  year,  gender,  planjourney,  proposerstate,  advisorstatesame,  plan,  sumassured,  smokertype,  planoptions,  increasinglevel,
                ecs,  term,  ppt,  premiumterm,  premiumamount,
                rider,  rideramount,  minrider,  maxrider,  ridererror,  click,  generateillustrations,
                clickcontinue);

        createApplPage.inputIfscCode("HDFC0000133");
        Assert.assertTrue(createApplPage.eleIfscVerifyTick.isDisplayed(), "Ifsc code is not verified");

        Assert.assertNotNull(createApplPage.elebankName.getText(), "Bank name is not prefilled");
        Assert.assertNotNull(createApplPage.elebranchName.getText(), "Branch name is not prefilled");

        commonUtils.scrollIntoView("Account Details",driver);
        createApplPage.inputAccNo("50100022859343");
        createApplPage.chooseAccountType(accounttype);

        createApplPage.chooseActionButton(createApplPage.eleVerifyBtn);
        if (commonUtils.isDisplayed(driver,createApplPage.eleBankAlertOkBtn)) {
            createApplPage.chooseActionButton(createApplPage.eleBankAlertOkBtn);
        }
        waitUtils.waitForElementToBeVisible(driver, createApplPage.eleInputAccHolderName);
        Assert.assertNotNull(createApplPage.eleInputAccHolderName.getText());
        //commonUtils.scrollTillEndOfPage(driver);
        //waitUtils.waitForElementToBeVisible(driver, createApplPage.eleBankNextBtn);
        //createApplPage.chooseActionButton(createApplPage.eleBankNextBtn);
        //waitUtils.waitForElementToBeVisible(driver, createApplPage.eleRenewNavText);
        /*commonUtils.scrollIntoView(clickverify, driver);
        commonUtils.selectButtonByName(clickverify, driver);

        waitUtils.waitUntilElementIsVisibleByText(driver, 50, "The Bank account is verified", "Account verified alert is not shown");
        Assert.assertTrue(createApplPage.isAlertShown());*/

        /*
        commonUtils.selectButtonByName("OK", driver);
        Assert.assertNotNull(createApplPage.eleInputAccHolderName.getText());
        commonUtils.selectButtonByName("NEXT", driver);
        waitUtils.waitUntilElementIsVisibleByText(driver, 30, "Renewal Premium", "Renewal screen is not displayed");
        Assert.assertEquals(createApplPage.getScreenTitle(), "Renewal Premium", "Failure in navigation to renewal premium screen");
*/
    }

    @Test(dataProvider = "dataBankProvider", dataProviderClass = DataProviders.class)
    @Description("verify for invalid ifsc code and account number")
    public void invalid_ifsc_code(String username, String password, String policy, String leadid, String proposersame, String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                     String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                     String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                     String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                     String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert, String clickverify, String renewpremiumscreentitle) throws InterruptedException, IOException {

        new TestFactory().gotoBank(driver, username,  password,  policy,  leadid,  proposersame,
                relationwithinsured,	isrelationanswer,  isnri,  pmobile,  ppan,  imobile,  ipan,  firstname,  lastname,
                middlename,  day,  month,  year,  gender,  planjourney,  proposerstate,  advisorstatesame,  plan,  sumassured,  smokertype,  planoptions,  increasinglevel,
                ecs,  term,  ppt,  premiumterm,  premiumamount,
                rider,  rideramount,  minrider,  maxrider,  ridererror,  click,  generateillustrations,
                clickcontinue);

        String ifscTestText = "";
        createApplPage.inputIfscCode(ifscTestText);
        Assert.assertFalse(commonUtils.isDisplayed(driver,createApplPage.elebankName),"Bank ifsc code accepts empty values");

        String ifscCodeMaxLength = new ReadJson().getConfigValues().getIfscCode().getMinLength();
        System.out.println("Max length========="+ifscCodeMaxLength);

        if(ifsccode.length() < Integer.valueOf(ifscCodeMaxLength)) {
            createApplPage.inputIfscCode(ifsccode);
            if(new BaseTest().isAndroid()) {
                Assert.assertFalse(commonUtils.isDisplayed(driver,createApplPage.elebankName),"Bank ifsc code accepts empty values");
            } else {
                Assert.assertTrue(createApplPage.eleIfscErrorMessage.isDisplayed(), "Error message is not displayed for invalid ifsc cdode :");
            }
        }
        else {
            Assert.assertTrue(createApplPage.isAlertShown());
            commonUtils.selectButtonByName("OK",driver);

        }

    }

    //@Test(dataProvider = "dataBankProvider", dataProviderClass = DataProviders.class)
    @Description("verify for invalid ifsc code and account number")
    public void invalid_bank_accountno(String username, String password, String policy, String leadid, String proposersame, String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                  String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                  String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                  String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                  String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert, String clickverify, String renewpremiumscreentitle) throws InterruptedException, IOException {

        new TestFactory().gotoBank(driver, username,  password,  policy,  leadid,  proposersame,
                relationwithinsured,	isrelationanswer,  isnri,  pmobile,  ppan,  imobile,  ipan,  firstname,  lastname,
                middlename,  day,  month,  year,  gender,  planjourney,  proposerstate,  advisorstatesame,  plan,  sumassured,  smokertype,  planoptions,  increasinglevel,
                ecs,  term,  ppt,  premiumterm,  premiumamount,
                rider,  rideramount,  minrider,  maxrider,  ridererror,  click,  generateillustrations,
                clickcontinue);
        createApplPage.inputIfscCode(ifsccode);
        Assert.assertTrue(createApplPage.eleIfscVerifyTick.isDisplayed(), "Ifsc code is not verified");

        commonUtils.scrollIntoView("Account Details",driver);
        /*String accNoTestText = "";
        createApplPage.inputAccNo(accNoTestText);
        Assert.assertNotEquals(createApplPage.getScreenTitle(),renewpremiumscreentitle.trim(), "Error message is not displayed for invalid ifsc cdode");
*/
        createApplPage.inputAccNo(bankaccno);
        commonUtils.chooseActionButton(createApplPage.eleVerifyBtn);
        Assert.assertTrue(createApplPage.eleAccNoErrorMessage.isDisplayed(), "Error message is not displayed for invalid bank account no");
    }


}