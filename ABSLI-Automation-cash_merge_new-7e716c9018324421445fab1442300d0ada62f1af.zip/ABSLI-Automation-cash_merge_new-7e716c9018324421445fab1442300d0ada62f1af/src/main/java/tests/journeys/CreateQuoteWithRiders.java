package tests.journeys;

        import com.absli.helpers.dataProviders.DataProviders;
        import com.absli.listeners.RetryAnalyzer;
        import com.absli.listeners.TestLevelDriverCreator;
        import com.absli.listeners.TestListener;
        import com.absli.helpers.jsonReaders.ReadJson;
        import com.absli.helpers.models.ProposerModel;
        import com.absli.pageObjects.CreateApplPage;
        import com.absli.utils.CommonUtils;
        import com.absli.utils.ExcelUtils;
        import com.absli.utils.PropertiesUtils;
        import com.absli.utils.WaitUtils;
        import org.openqa.selenium.JavascriptExecutor;
        import org.openqa.selenium.WebDriver;
        import org.openqa.selenium.WebElement;
        import org.testng.Assert;
        import org.testng.ITestContext;
        import org.testng.ITestResult;
        import org.testng.annotations.*;
        import org.testng.xml.XmlTest;
        import tests.BaseTest;
        import tests.TestFactory;

        import java.io.IOException;
        import java.lang.reflect.Method;
        import java.util.ArrayList;
        import java.util.Iterator;

public class CreateQuoteWithRiders extends BaseTest {
    ProposerModel proposerModel;
    ReadJson jsonObj;
    CreateApplPage createApplPage;
    CommonUtils commonUtils;
    WaitUtils waitUtils;
    PropertiesUtils prop;

    @BeforeClass
    public void preSetup() throws IOException, InterruptedException {
        driver = new TestLevelDriverCreator().getDriver();
        commonUtils = new CommonUtils();
        waitUtils = new WaitUtils();
        prop = new PropertiesUtils();
        createApplPage = new CreateApplPage(driver);
    }

    @BeforeMethod
    public void relaunch()  {
        new BaseTest().relaunch();
    }



    //@Test(dataProvider = "riderDataProvider",dataProviderClass = DataProviders.class,priority = 2)
    public void add_riders_min_amount_validation(String username, String password, String policy, String leadid, String proposersame, String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                                 String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate,
                                                 String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                                 String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                                 String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                                 String clickcontinue) throws InterruptedException, IOException {

        createQuote(  username,   password,   policy,   leadid,   proposersame,   relationwithinsured, 	isrelationanswer,   isnri,   pmobile,   ppan,   imobile,   ipan,   firstname,   lastname,
                  middlename,   day,   month,   year,   gender,   planjourney,   proposerstate,   advisorstatesame,   plan,   sumassured,   smokertype,   planoptions,   increasinglevel,
                  ecs,   term,   ppt,   premiumterm,   premiumamount,
                  rider,   rideramount,   minrider,   maxrider,   ridererror,   click,   generateillustrations,
                  clickcontinue);

        add_rider( rideramount, rider);
        Assert.assertTrue(createApplPage.verifyRiderErrorMessage(rider),"Rider input amount min error is not displayed");
    }
    //@Test(dataProvider = "riderDataProvider",dataProviderClass = DataProviders.class,priority = 3)
    public void add_riders_max_amount_validation(String username, String password, String policy, String leadid, String proposersame, String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                                 String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate,
                                                 String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                                 String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                                 String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                                 String clickcontinue) throws InterruptedException, IOException {
        /* maximum amount validations
         * */
        createQuote(  username,   password,   policy,   leadid,   proposersame,   relationwithinsured, 	isrelationanswer,   isnri,   pmobile,   ppan,   imobile,   ipan,   firstname,   lastname,
                middlename,   day,   month,   year,   gender,   planjourney,   proposerstate,   advisorstatesame,   plan,   sumassured,   smokertype,   planoptions,   increasinglevel,
                ecs,   term,   ppt,   premiumterm,   premiumamount,
                rider,   rideramount,   minrider,   maxrider,   ridererror,   click,   generateillustrations,
                clickcontinue);

        add_rider( rideramount, rider);
        Assert.assertTrue(createApplPage.verifyRiderErrorMessage(rider),"Rider input amount min error is not displayed");

    }

    //@Test(dataProvider = "riderDataProvider",dataProviderClass = DataProviders.class,priority = 1)
    public void add_riders(String username, String password, String policy, String leadid, String proposersame, String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                           String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate,
                           String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                           String ecs, String term, String ppt, String premiumterm, String premiumamount,
                           String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                           String clickcontinue) throws InterruptedException, IOException {
        //commonUtils.scrollTopOfPage(driver);
        createQuote(  username,   password,   policy,   leadid,   proposersame,   relationwithinsured, 	isrelationanswer,   isnri,   pmobile,   ppan,   imobile,   ipan,   firstname,   lastname,
                middlename,   day,   month,   year,   gender,   planjourney,   proposerstate,   advisorstatesame,   plan,   sumassured,   smokertype,   planoptions,   increasinglevel,
                ecs,   term,   ppt,   premiumterm,   premiumamount,
                rider,   rideramount,   minrider,   maxrider,   ridererror,   click,   generateillustrations,
                clickcontinue);

        add_rider( rideramount, rider);
        waitUtils.waitForElementToBeVisible(driver,createApplPage.eleViewQuoteNavText);
        Assert.assertTrue(createApplPage.eleViewQuoteNavText.isDisplayed());
    }


    ////@Test(enabled = true,dataProvider = "riderDataProvider",dataProviderClass = DataProviders.class,priority = 4)
    public void add_riders_adbplus_add(String username, String password, String policy, String leadid, String proposersame, String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                       String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate,
                                       String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                       String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                       String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                       String clickcontinue) throws InterruptedException, IOException {

        String newRider = "Accidental Death and Disability";
        rider = newRider;
        createQuote(  username,   password,   policy,   leadid,   proposersame,   relationwithinsured, 	isrelationanswer,   isnri,   pmobile,   ppan,   imobile,   ipan,   firstname,   lastname,
                middlename,   day,   month,   year,   gender,   planjourney,   proposerstate,   advisorstatesame,   plan,   sumassured,   smokertype,   planoptions,   increasinglevel,
                ecs,   term,   ppt,   premiumterm,   premiumamount,
                rider,   rideramount,   minrider,   maxrider,   ridererror,   click,   generateillustrations,
                clickcontinue);
        //createApplPage.selectRider(rider);
        createApplPage.inputRiderAmount(rideramount,newRider);
        waitUtils.implicitWait(driver,2000);


        //createApplPage.selectRider("ADB Plus");
        commonUtils.scrollTillEndOfPage(driver);
        Assert.assertFalse(createApplPage.isRiderEnabled("ADB Plus"));

        commonUtils.scrollTopOfPage(driver);
        waitUtils.implicitWait(driver,20000);
        createApplPage.unSelectRider(newRider);
        commonUtils.scrollTillEndOfPage(driver);
        waitUtils.implicitWait(driver,20000);
        Assert.assertTrue(createApplPage.isRiderEnabled("ADB Plus"));
    }

    //@Test(dataProvider = "riderDataProvider",dataProviderClass = DataProviders.class,priority = 13)
    public void download_illustration_with_add_rider(String username, String password, String policy, String leadid, String proposersame, String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                                     String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate,
                                                     String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                                     String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                                     String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                                     String clickcontinue) throws InterruptedException, IOException {

        createQuote(  username,   password,   policy,   leadid,   proposersame,   relationwithinsured, 	isrelationanswer,   isnri,   pmobile,   ppan,   imobile,   ipan,   firstname,   lastname,
                middlename,   day,   month,   year,   gender,   planjourney,   proposerstate,   advisorstatesame,   plan,   sumassured,   smokertype,   planoptions,   increasinglevel,
                ecs,   term,   ppt,   premiumterm,   premiumamount,
                rider,   rideramount,   minrider,   maxrider,   ridererror,   click,   generateillustrations,
                clickcontinue);

        add_rider( rideramount, rider);
        waitUtils.waitForElementToBeVisible(driver,createApplPage.eleViewQuoteNavText,30,"Quote screen is not displayed");

        commonUtils.scrollToBottom(driver);
        createApplPage.downloadIllustration();
    }

    public void createQuote(String username, String password, String policy, String leadid, String proposersame, String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                            String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                            String ecs, String term, String ppt, String premiumterm, String premiumamount,
                            String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                            String clickcontinue) throws IOException, InterruptedException {
        new TestFactory().gotoViewQuoteAndGenerate( driver,  username,   password,   policy,   leadid,   proposersame,
                relationwithinsured,  isrelationanswer,   isnri,   pmobile,   ppan,   imobile,   ipan,   firstname,   lastname,
                middlename,   day,   month,   year,   gender,   planjourney,   proposerstate,   advisorstatesame,
                plan,  sumassured,   smokertype,   planoptions,   increasinglevel,
                ecs,   term,   ppt,   premiumterm,   premiumamount);
        commonUtils.scrollTillEndOfPage(driver);
        System.out.println("premium amout from excel:"+ premiumamount);
        System.out.println("premium amout from code:"+ createApplPage.getPremiumAmount());
        //Assert.assertEquals(commonUtils.decimalFormatter(premiumamount),createApplPage.getPremiumAmount());
        waitUtils.implicitWait(driver,20000);
        createApplPage.chooseRiderButton();
        commonUtils.scrollTopOfPage(driver);
        createApplPage.selectRider(rider);
    }

    //@Test(dataProvider = "riderDataProvider",dataProviderClass = DataProviders.class,priority = 1)
    public void add_riders_validation_without_amount(String username, String password, String policy, String leadid, String proposersame, String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                           String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate,
                           String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                           String ecs, String term, String ppt, String premiumterm, String premiumamount,
                           String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                           String clickcontinue) throws InterruptedException, IOException {
        //commonUtils.scrollTopOfPage(driver);
        createQuote(  username,   password,   policy,   leadid,   proposersame,   relationwithinsured, 	isrelationanswer,   isnri,   pmobile,   ppan,   imobile,   ipan,   firstname,   lastname,
                middlename,   day,   month,   year,   gender,   planjourney,   proposerstate,   advisorstatesame,   plan,   sumassured,   smokertype,   planoptions,   increasinglevel,
                ecs,   term,   ppt,   premiumterm,   premiumamount,
                rider,   rideramount,   minrider,   maxrider,   ridererror,   click,   generateillustrations,
                clickcontinue);
        add_rider( rideramount, rider);
        Assert.assertTrue(createApplPage.eleRidersNavText.isDisplayed());
    }

    public void add_rider(String riderAmout,String riderName) {
        waitUtils.implicitWait(driver,30000);
        createApplPage.inputRiderAmount(createApplPage.getRiderMinAmount(riderAmout),riderName);
        commonUtils.scrollTillEndOfPage(driver);
        waitUtils.waitUntilVisible(driver,createApplPage.eleRiderAddBtn,30);
        createApplPage.chooseActionButton(createApplPage.eleRiderAddBtn);

    }


















/*
* Validate if the user can able to view all the fields
Validate the fields captured have the required validation
Validate fields are Prefilled as per the plan
Validate  Modifying of any of the fileds
Validate for Monthly,Quarterly, payment options ECS is Mandate
Validate Increasing level Plan
Validate sum assured has min of Rs 50,00,000.
Validate the Illustration is generated after plan is selected
Validate the premium value is changed on tap of entering any field
Validate Without Entering Sum Assured generate illustration Should display a message Please enter Sum Assured Amount
Validate Without Entering Sum Assured generate click on Save Please Enter Sum Assured Amout
Validate  Without Selecting ECS select Monthly and click on SAVE Please Select ECS Checkbox message should display
Validate Non Smoker By Default Should Select
Validate without selecting PPT Click on Save Please Select the PPT Message should display
Validate Without Selecting Select Plan Option Click on SAVE
Validate Enter Sum Assured less than 50L Click on Generate Illustration or Save Please select the plan option message should display
Validate Click on View Quote Should Redirect To Previous Page
Validate Click on Add Riders Naviagte to Add Riders Page
Validate the Generate Illustration
Validate The Save After Entering All The Fields
* */

}
