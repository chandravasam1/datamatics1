package tests.journeys;
import com.absli.helpers.dataProviders.DataProviders;
import com.absli.helpers.jsonReaders.ReadJson;
import com.absli.helpers.models.ConfigPojo;
import com.absli.helpers.models.ProposerModel;
import com.absli.listeners.*;
import com.absli.pageObjects.CreateApplPage;
import com.absli.pageObjects.SignInPage;
import com.absli.utils.CommonUtils;
import com.absli.utils.ExcelUtils;
import com.absli.utils.PropertiesUtils;
import com.absli.utils.WaitUtils;
import io.qameta.allure.Description;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.*;
import tests.BaseTest;
import tests.TestFactory;

import java.io.IOException;
import java.lang.reflect.Method;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;

@Listeners({TestLevelDriverCreator.class})
public class NomineeTest extends BaseTest {


    ProposerModel proposerModel;
    ReadJson jsonObj;
    CreateApplPage createApplPage;
    CommonUtils commonUtils;
    WaitUtils waitUtils;
    PropertiesUtils prop;
    SignInPage signIn;

    @BeforeClass
    public void preSetup() throws IOException, InterruptedException {
        driver = new TestLevelDriverCreator().getDriver();
        createApplPage = new CreateApplPage(driver);
        commonUtils = new CommonUtils();
        waitUtils = new WaitUtils();
        prop = new PropertiesUtils();
    }

    @BeforeMethod
    public void relaunch()  {
        new BaseTest().relaunch();
    }

    @AfterMethod
    public void logOut() {
        if(new BaseTest().isWeb()) {
            commonUtils.scrollTopOfPage(driver);
            waitUtils.wait2Seconds();
            signIn.logOut();
        }
    }

    @Test(dataProvider = "dataNomineeProvider",dataProviderClass = DataProviders.class)
    @Description("Add nominee")
    public void add_nominee(String username, String password, String policy, String leadid, String proposersame,
                            String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                             String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                             String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                             String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                             String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert, 
                                            String clickverify, String renewpremiumscreentitle,String paymentmethod,String drawdate,String fundsource,
                                            String nomineescreentitle,String nomineefirstname,String 	nomineelastname,String 	nomineeday,
                                            String nomineemonth,String 	nomineeyear,String 	nomineegender,String 	relationshipwithproposer,String 	nomineeshare,
                                            String ismwppolicy,String addressscreentitle) throws InterruptedException, IOException {

        new TestFactory().gotoNominee( driver, username,  password,  policy,  leadid,  proposersame,  relationwithinsured,	isrelationanswer,  isnri,  pmobile,  ppan,  imobile,  ipan,  firstname,  lastname,
                 middlename,  day,  month,  year,  gender,  planjourney,  proposerstate,  advisorstatesame,  plan,  sumassured,  smokertype,  planoptions,  increasinglevel,
                 ecs,  term,  ppt,  premiumterm,  premiumamount,
                 rider,  rideramount,  minrider,  maxrider,  ridererror,  click,  generateillustrations,
                 clickcontinue,  ifsccode,  bankaccno,  accholdername,  accounttype,  pennyalert,
                 clickverify,  renewpremiumscreentitle, paymentmethod, drawdate, fundsource,
                 nomineescreentitle);

        Assert.assertTrue(createApplPage.eleNomineeNavText.isDisplayed());
        createApplPage.addNominee(nomineefirstname,nomineelastname,nomineeday,nomineemonth,nomineeyear,nomineegender,relationshipwithproposer,nomineeshare,ismwppolicy);
        Thread.sleep(500);
        waitUtils.fluentWaitUntilElementVisible(driver,createApplPage.eleFormNext,60);
        createApplPage.nextForm();
        createApplPage.nextForm();
        waitUtils.waitUntilVisible(driver, createApplPage.eleAddressNavText, 30);
        Assert.assertTrue(createApplPage.eleAddressNavText.isDisplayed(),"Address screen is not displayed");

    }

    ////@Test(dataProvider = "dataNomineeProvider",dataProviderClass = DataProviders.class,priority = 1)
    @Description("add_multiple_nominees")
    public void add_multiple_nominees(String username, String password, String policy, String leadid, String proposersame,
                                      String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                            String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                            String ecs, String term, String ppt, String premiumterm, String premiumamount,
                            String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                            String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                            String clickverify, String renewpremiumscreentitle,String paymentmethod,String drawdate,String fundsource,
                            String nomineescreentitle,String nomineefirstname,String 	nomineelastname,String 	nomineeday,
                            String nomineemonth,String 	nomineeyear,String 	nomineegender,String 	relationshipwithproposer,String 	nomineeshare,
                            String ismwppolicy,String addressscreentitle) throws InterruptedException, IOException {

        new TestFactory().gotoNominee( driver, username,  password,  policy,  leadid,  proposersame,  relationwithinsured,	isrelationanswer,  isnri,  pmobile,  ppan,  imobile,  ipan,  firstname,  lastname,
                middlename,  day,  month,  year,  gender,  planjourney,  proposerstate,  advisorstatesame,  plan,  sumassured,  smokertype,  planoptions,  increasinglevel,
                ecs,  term,  ppt,  premiumterm,  premiumamount,
                rider,  rideramount,  minrider,  maxrider,  ridererror,  click,  generateillustrations,
                clickcontinue,  ifsccode,  bankaccno,  accholdername,  accounttype,  pennyalert,
                clickverify,  renewpremiumscreentitle, paymentmethod, drawdate, fundsource,
                nomineescreentitle);

        Assert.assertTrue(createApplPage.eleNomineeNavText.isDisplayed());

        createApplPage.addNominee(nomineefirstname,nomineelastname,nomineeday,nomineemonth,nomineeyear,nomineegender,relationshipwithproposer,nomineeshare,ismwppolicy);
        createApplPage.unCollapse();
    }

    // Need to uncomment once the nominee issue is fixed where even for new appln nominee is already added
    //@Test(dataProvider = "dataNomineeProvider",dataProviderClass = DataProviders.class)
    @Description("gender_validation_in_case_of_nominee_relationship")
    public void gender_validation_in_case_of_nominee_relationship(String username, String password, String policy, String leadid, String proposersame,
                                                                  String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                                    String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                                    String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                                    String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                                    String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                                    String clickverify, String renewpremiumscreentitle,String paymentmethod,String drawdate,String fundsource,
                                                    String nomineescreentitle,String nomineefirstname,String 	nomineelastname,String 	nomineeday,
                                                    String nomineemonth,String 	nomineeyear,String 	nomineegender,String 	relationshipwithproposer,String 	nomineeshare,
                                                    String ismwppolicy,String addressscreentitle) throws InterruptedException, IOException {

        new TestFactory().gotoNominee( driver, username,  password,  policy,  leadid,  proposersame,  relationwithinsured,	isrelationanswer,  isnri,  pmobile,  ppan,  imobile,  ipan,  firstname,  lastname,
                middlename,  day,  month,  year,  gender,  planjourney,  proposerstate,  advisorstatesame,  plan,  sumassured,  smokertype,  planoptions,  increasinglevel,
                ecs,  term,  ppt,  premiumterm,  premiumamount,
                rider,  rideramount,  minrider,  maxrider,  ridererror,  click,  generateillustrations,
                clickcontinue,  ifsccode,  bankaccno,  accholdername,  accounttype,  pennyalert,
                clickverify,  renewpremiumscreentitle, paymentmethod, drawdate, fundsource,
                nomineescreentitle);

        Assert.assertTrue(createApplPage.eleNomineeNavText.isDisplayed());

        createApplPage.addNominee(nomineefirstname,nomineelastname,nomineeday,nomineemonth,nomineeyear,nomineegender,relationshipwithproposer,nomineeshare,ismwppolicy);

        //Assert.assertTrue(createApplPage.eleNomineeShareError.isDisplayed(),"Nominee share error is not shown");
    }

    ////@Test(dataProvider = "dataNomineeProvider",dataProviderClass = DataProviders.class,priority = 1)
    @Description("Edit nominee")
    public void edit_nominee(String username, String password, String policy, String leadid, String proposersame,
                             String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                            String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                            String ecs, String term, String ppt, String premiumterm, String premiumamount,
                            String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                            String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                            String clickverify, String renewpremiumscreentitle,String paymentmethod,String drawdate,String fundsource,
                            String nomineescreentitle,String nomineefirstname,String 	nomineelastname,String 	nomineeday,
                            String nomineemonth,String 	nomineeyear,String 	nomineegender,String 	relationshipwithproposer,String 	nomineeshare,
                            String ismwppolicy,String addressscreentitle) throws InterruptedException, IOException {

        new TestFactory().gotoNominee( driver, username,  password,  policy,  leadid,  proposersame,   relationwithinsured,	isrelationanswer,  isnri,  pmobile,  ppan,  imobile,  ipan,  firstname,  lastname,
                middlename,  day,  month,  year,  gender,  planjourney,  proposerstate,  advisorstatesame,  plan,  sumassured,  smokertype,  planoptions,  increasinglevel,
                ecs,  term,  ppt,  premiumterm,  premiumamount,
                rider,  rideramount,  minrider,  maxrider,  ridererror,  click,  generateillustrations,
                clickcontinue,  ifsccode,  bankaccno,  accholdername,  accounttype,  pennyalert,
                clickverify,  renewpremiumscreentitle, paymentmethod, drawdate, fundsource,
                nomineescreentitle);

        Assert.assertTrue(createApplPage.eleNomineeNavText.isDisplayed());

        createApplPage.addNominee(nomineefirstname,nomineelastname,nomineeday,nomineemonth,nomineeyear,nomineegender,relationshipwithproposer,nomineeshare,ismwppolicy);


        waitUtils.waitForElementToBeVisible(driver,createApplPage.eleEditBtn,30,"error");
        waitUtils.implicitWait(driver,100);
        commonUtils.selectButtonByName("EDIT",driver);
        commonUtils.scrollTopOfPage(driver);
        waitUtils.implicitWait(driver,30000);
        createApplPage.inputFirstName(nomineefirstname);
        commonUtils.scrollTillEndOfPage(driver);
        //createApplPage.saveForm();
        commonUtils.selectButtonByName("SAVE",driver);
    }



}


/*
* nominee_share_validations
nominee_mandatory_fields_validation
nominee_name_validations
nominee_dob_validations
nominee_dob_validations
add_multiple_nominees
nominee_share_100%_in_case_of_multiple_nominees
gender_validation_in_case_of_nominee_relationship
* */