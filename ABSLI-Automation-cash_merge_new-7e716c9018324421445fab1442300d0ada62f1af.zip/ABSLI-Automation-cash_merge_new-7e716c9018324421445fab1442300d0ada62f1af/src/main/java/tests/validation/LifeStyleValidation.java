package tests.validation;
import com.absli.helpers.dataProviders.DataProviders;
import com.absli.helpers.jsonReaders.ReadJson;
import com.absli.helpers.jsonReaders.readLoginJson;
import com.absli.listeners.TestLevelDriverCreator;
import com.absli.pageObjects.CreateApplPage;
import com.absli.pageObjects.LifestylePage;
import com.absli.pageObjects.SignInPage;
import com.absli.utils.CommonUtils;
import com.absli.utils.ExcelUtils;
import com.absli.utils.PropertiesUtils;
import com.absli.utils.WaitUtils;
import io.qameta.allure.Description;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.*;
import tests.BaseTest;
import org.testng.Assert;
import tests.TestFactory;

import java.io.IOException;


@Listeners({TestLevelDriverCreator.class})

public class LifeStyleValidation extends BaseTest{
    ReadJson jsonObj;
    CreateApplPage createApplPage;
    CommonUtils commonUtils;
    WaitUtils waitUtils;
    PropertiesUtils prop;
    SignInPage signIn;
    LifestylePage lifestylePage;

    @BeforeClass
    public void preSetup() throws Exception {
        driver = new TestLevelDriverCreator().getDriver();

        jsonObj = new ReadJson();
        signIn = new SignInPage(driver);
        commonUtils = new CommonUtils();
        waitUtils = new WaitUtils();
        prop = new PropertiesUtils();
        createApplPage = new CreateApplPage(driver);
        lifestylePage = new LifestylePage(driver);

        new BaseTest().relaunch();

        new TestFactory().gotoLifestyle(driver,getData("username"), getData("password"), getData("policy"), getData("leadid"), getData("proposersame"),
                getData("isnri"), getData("pmobile"), getData("ppan"), getData("firstname"), getData("lastname"),
                getData("middlename"), getData("day"), getData("month"), getData("year"), getData("gender"), getData("planjourney"), getData("proposerstate"), getData("advisorstatesame"), getData("plan"), getData("sumassured"), getData("smokertype"), getData("planoptions"), getData("increasinglevel"),
                getData("ecs"), getData("term"), getData("ppt"), getData("premiumterm"), getData("premiumamount"),
                getData("clickcontinue"), getData("ifsccode"), getData("bankaccno"), getData("accounttype"), getData("pennyalert"),
                getData("clickverify"),getData("paymentmethod"),getData("drawdate"),getData("fundsource"),
                getData("nomineescreentitle"),getData("nomineefirstname"),getData("nomineelastname"),getData("nomineeday"),getData("nomineemonth"),getData("nomineeyear"),getData("nomineegender"),getData("relationshipwithproposer"),getData("typeofaddress"), getData("addresspincode"), getData("address1"), getData("address2"), getData("address3"), getData("personalDetailsscreentitle"),
                getData("PersonalEmailId"), getData("PersonalMaritalStatus"), getData("FatherSpouseName"),
                getData("MotherName"), getData("MaidenName"), getData("Qualification"), getData("Occupation "), getData("SpouseAnnualIncome"), getData("AnnualIncome"),getData("addressscreentitle"), getData("nomineeshare"),getData("ismwppolicy"));
    }
    @AfterMethod
    public void relaunch()  {
        commonUtils.scrollTopOfPage(driver);
        waitUtils.wait2Seconds();
    }
    @Test(dataProvider = "dataLifeStyleValidationProvider",dataProviderClass = DataProviders.class,priority = 1)
    @Description("lifeStyle_Narcotics_mandatory_fields_validation")
    public void lifeStyle_Narcotics_mandatory_fields_validation(String username, String password, String policy, String leadid, String proposersame,
                                                    String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                                    String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                                    String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                                    String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                                    String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                                    String clickverify, String renewpremiumscreentitle,String paymentmethod,String drawdate,String fundsource,
                                                    String nomineescreentitle,String nomineefirstname,String 	nomineelastname,String 	nomineeday,
                                                    String nomineemonth,String 	nomineeyear,String 	nomineegender,String 	relationshipwithproposer,String 	nomineeshare,
                                                    String ismwppolicy,String addressscreentitle) throws InterruptedException, IOException {

        lifestylePage.eleNarcoticsYesBtn.click();
        commonUtils.scrollToElement(driver,lifestylePage.eleNarcoticsSaveBtn);
        Assert.assertTrue(lifestylePage.eleNarcoticsMentionDetailsError.isDisplayed(),"Error is not displayed when Mention Details is empty");

    }

    @Test(dataProvider = "dataLifeStyleValidationProvider",dataProviderClass = DataProviders.class,priority = 1)
    @Description("lifeStyle_AlcoholConsumption_mandatory_fields_validation")
    public void lifeStyle_AlcoholConsumption_mandatory_fields_validation(String username, String password, String policy, String leadid, String proposersame,
                                                      String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                                      String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                                      String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                                      String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                                      String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                                      String clickverify, String renewpremiumscreentitle,String paymentmethod,String drawdate,String fundsource,
                                                      String nomineescreentitle,String nomineefirstname,String 	nomineelastname,String 	nomineeday,
                                                      String nomineemonth,String 	nomineeyear,String 	nomineegender,String 	relationshipwithproposer,String 	nomineeshare,
                                                      String ismwppolicy,String addressscreentitle) throws InterruptedException, IOException {

        lifestylePage.eleAlcoholConsumptionYesBtn.click();
        commonUtils.scrollToElementAndClick(driver, lifestylePage.eleTypeAlcoholConsumedBeer);
        commonUtils.scrollToElement(driver,lifestylePage.eleAlcoholConsumptionSaveBtn);
        Assert.assertTrue(lifestylePage.eleAlcoholConsumptionQtError.isDisplayed(),"Error is not displayed when Alcohol Consumption Quantity is empty");
        Assert.assertTrue(lifestylePage.eleAlcoholConsumptionFrqError.isDisplayed(),"Error is not displayed when Alcohol Consumption Quantity is not selected");
    }
    @Test(dataProvider = "dataLifeStyleValidationProvider",dataProviderClass = DataProviders.class,priority = 1)
    @Description("lifeStyle_Nicotine_mandatory_fields_validation")
    public void lifeStyle_Nicotine_mandatory_fields_validation(String username, String password, String policy, String leadid, String proposersame,
                                                      String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                                      String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                                      String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                                      String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                                      String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                                      String clickverify, String renewpremiumscreentitle,String paymentmethod,String drawdate,String fundsource,
                                                      String nomineescreentitle,String nomineefirstname,String 	nomineelastname,String 	nomineeday,
                                                      String nomineemonth,String 	nomineeyear,String 	nomineegender,String 	relationshipwithproposer,String 	nomineeshare,
                                                      String ismwppolicy,String addressscreentitle) throws InterruptedException, IOException {

        lifestylePage.eleNicotineYesBtn.click();
        lifestylePage.eleFormOfTobaccoCigarette.click();
        lifestylePage.eleNicotineSaveBtn.click();
        Assert.assertTrue(lifestylePage.eleNicotineDurationError.isDisplayed(),"Error is not displayed when Duration of months is not selected");
        Assert.assertTrue(lifestylePage.eleNicotineQtError.isDisplayed(),"Error is not displayed when Quantity is empty");
        Assert.assertTrue(lifestylePage.eleNicotineFrqError.isDisplayed(),"Error is not displayed when Frequency is not selected");
    }
    @Test(dataProvider = "dataLifeStyleValidationProvider",dataProviderClass = DataProviders.class,priority = 1)
    @Description("lifeStyle_HazardousActivities_mandatory_fields_validation")
    public void lifeStyle_HazardousActivities_mandatory_fields_validation(String username, String password, String policy, String leadid, String proposersame,
                                                      String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                                      String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                                      String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                                      String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                                      String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                                      String clickverify, String renewpremiumscreentitle,String paymentmethod,String drawdate,String fundsource,
                                                      String nomineescreentitle,String nomineefirstname,String 	nomineelastname,String 	nomineeday,
                                                      String nomineemonth,String 	nomineeyear,String 	nomineegender,String 	relationshipwithproposer,String 	nomineeshare,
                                                      String ismwppolicy,String addressscreentitle) throws InterruptedException, IOException {


        lifestylePage.eleHazardousActivitiesYesBtn.click();
        lifestylePage.eleHazardousActivitiesSaveBtn.click();
        Assert.assertTrue(lifestylePage.eleHazardousActivitiesOpt1Error.isDisplayed(),"Error is not displayed when is empty");
        Assert.assertTrue(lifestylePage.eleHazardousActivitiesYrsError.isDisplayed(),"Error is not displayed when is empty");
        Assert.assertTrue(lifestylePage.eleHazardousActivitiesOpt2Error.isDisplayed(),"Error is not displayed when is empty");

    }

    public String getData(String cell) throws IOException {
        String data = new ExcelUtils().getCellData(new PropertiesUtils().getProperties("testExcelSheet"),
                "lifeStyle_mandatory_fields_validation",new PropertiesUtils().getProperties("lifeStyleValidationSheetName"),cell);
        return data;
    }

}
