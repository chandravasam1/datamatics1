package tests.validation;

import com.absli.helpers.dataProviders.DataProviders;
import com.absli.helpers.jsonReaders.ReadJson;
import com.absli.listeners.TestLevelDriverCreator;
import com.absli.pageObjects.CreateApplPage;
import com.absli.pageObjects.DashboardPage;
import com.absli.pageObjects.SignInPage;
import com.absli.utils.CommonUtils;
import com.absli.utils.ExcelUtils;
import com.absli.utils.PropertiesUtils;
import com.absli.utils.WaitUtils;
import io.qameta.allure.Description;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import tests.BaseTest;
import tests.TestFactory;

import java.io.IOException;

@Listeners({TestLevelDriverCreator.class})
public class PrefillInsuredValidation extends BaseTest {

    ReadJson jsonObj;
    CreateApplPage createApplPage;
    CommonUtils commonUtils;
    WaitUtils waitUtils;
    SignInPage signIn;
    DashboardPage dashPage;
    public WebDriver driver =null;

    @BeforeClass
    public void preSetup() throws IOException, InterruptedException {
        driver = new TestLevelDriverCreator().getDriver();
        jsonObj = new ReadJson();
        commonUtils = new CommonUtils();
        dashPage = new DashboardPage(driver);
        signIn = new SignInPage(driver);
        waitUtils = new WaitUtils();
        createApplPage = new CreateApplPage(driver);
        new BaseTest().relaunch();

        insured(  getData("username"),    getData("password"),    getData("policy"),    getData("leadid"),    getData("proposersame"),
                getData("relationwithinsured"),   getData("isrelationanswer"),    getData("isnri"),    getData("pmobile"),
                getData("ppan"),    getData("imobile"),
                getData("ipan"),  getData("firstname"),  	getData("lastname"),
                getData("middlename"),	  getData("day"),	  getData("month"),	  getData("year"),   getData("gender"));
    }


    @Test(dataProvider = "majorDiffPrefillDataProvider",dataProviderClass = DataProviders.class,description = "verify navigation to prefill details screen")
    @Description("verify navigation to prefill details screen")
    public void verifyNavigationTo_Insured_PrefillScreen(String username,String   password,String   policy,String   leadid,String   proposersame,
                                                         String relationwithinsured, String isrelationanswer, String  isnri, String  pmobile,  String ppan,  String imobile,
                                                         String ipan,String firstname,String 	lastname,
                                                         String middlename,	String day,	String month,	String year, String gender,String ifirstname,String 	ilastname,
                                                         String 	imiddlename,String 	iday,String 	imonth,String 	iyear,String 	igender) throws IOException, InterruptedException {

        Assert.assertTrue(createApplPage.eleInsuredFirstnameInputField.isDisplayed(),"Prefill details screen is not displayed");

    }

    @Test(dataProvider = "majorDiffPrefillDataProvider",dataProviderClass = DataProviders.class,description = "verify min_DOB_validations_Insured")
    @Description("verify min_DOB_validations_Insured")
    public void min_DOB_validations_Insured(String username,String   password,String   policy,String   leadid,String   proposersame,
                                            String relationwithinsured, String isrelationanswer, String  isnri, String  pmobile,  String ppan,  String imobile,
                                            String ipan,String firstname,String 	lastname,
                                            String middlename,	String day,	String month,	String year, String gender,String ifirstname,String 	ilastname,
                                            String 	imiddlename,String 	iday,String 	imonth,String 	iyear,String 	igender) throws IOException, InterruptedException {


        commonUtils.scrollTillEndOfPage(driver);

        createApplPage.fillDOB(iday, imonth, iyear,"insured");
        commonUtils.clickIfEnabled(driver,createApplPage.elePrefillInsuredNextBtn);
        //createApplPage.dismissPrefillScreenAlerts();
        waitUtils.waitUntilVisible(driver,createApplPage.eleDOBMinDayErrorMsg,30);
        Assert.assertTrue(createApplPage.eleDOBMinDayErrorMsg.isDisplayed(),"DOB day error is not shown");
        Assert.assertTrue(createApplPage.eleDOBMinMonthErrorMsg.isDisplayed(),"DOB month error is not shown");
        Assert.assertTrue(createApplPage.eleDOBMinYearErrorMsg.isDisplayed(),"DOB month error is not shown");


    }

    @Test(dataProvider = "majorDiffPrefillDataProvider",dataProviderClass = DataProviders.class,description = "verify max DOB validations for insured")
    @Description("verify max DOB validations for insured")
    public void max_DOB_validations_Insured(String username,String   password,String   policy,String   leadid,String   proposersame,
                                            String relationwithinsured, String isrelationanswer, String  isnri, String  pmobile,  String ppan,  String imobile,
                                            String ipan,String firstname,String 	lastname,
                                            String middlename,	String day,	String month,	String year, String gender,String ifirstname,String 	ilastname,
                                            String 	imiddlename,String 	iday,String 	imonth,String 	iyear,String 	igender) throws IOException, InterruptedException {

        commonUtils.scrollTillEndOfPage(driver);

        createApplPage.fillDOB(iday, imonth, iyear,"insured");
        commonUtils.scrollTillEndOfPage(driver);
        commonUtils.clickIfEnabled(driver,createApplPage.elePrefillInsuredNextBtn);
        //createApplPage.chooseActionButton(createApplPage.elePrefillInsuredNextBtn);
        //createApplPage.dismissPrefillScreenAlerts();
        Assert.assertFalse(createApplPage.verifyEnterDOBDayErrorShown(),"DOB day error is not shown");
        Assert.assertFalse(createApplPage.verifyEnterDOBMonthErrorShown(),"DOB month error is not shown");
        Assert.assertTrue(createApplPage.eleDOBFutureYearErrorMsg.isDisplayed(),"DOB month error is not shown");


    }

    @Test(dataProvider = "majorDiffPrefillDataProvider",dataProviderClass = DataProviders.class,description = "verify dob_year_less_than_1940_validations_Insured")
    @Description("verify dob_year_less_than_1940_validations_Insured")
    public void dob_year_less_than_1940_validations_Insured(String username,String   password,String   policy,String   leadid,String   proposersame,
                                                            String relationwithinsured, String isrelationanswer, String  isnri, String  pmobile,  String ppan,  String imobile,
                                                            String ipan,String firstname,String 	lastname,
                                                            String middlename,	String day,	String month,	String year, String gender,String ifirstname,String 	ilastname,
                                                            String 	imiddlename,String 	iday,String 	imonth,String 	iyear,String 	igender) throws IOException, InterruptedException {

        commonUtils.scrollTillEndOfPage(driver);

        createApplPage.fillDOB(iday, imonth, iyear,"insured");
        createApplPage.chooseActionButton(createApplPage.elePrefillInsuredSaveBtn);
        Thread.sleep(3000);
        //createApplPage.dismissPrefillScreenAlerts();
        Assert.assertTrue(createApplPage.eleDOBMinYearErrorMsg.isDisplayed(),"DOB day error is not shown");

    }

    public String getData(String cell) throws IOException {
        return new ExcelUtils().getCellData(new PropertiesUtils().getProperties("testExcelSheet"),
                "verifyNavigationTo_Insured_PrefillScreen",new PropertiesUtils().getProperties("majorDiffValidationSheetName"),cell);
    }

    public void insured(String username,String   password,String   policy,String   leadid,String   proposersame,
                        String relationwithinsured,String  isrelationanswer,String   isnri,String   pmobile,String   ppan,String   imobile,
                        String  ipan,String firstname,String 	lastname,
                        String middlename,	String day,	String month,	String year, String gender) throws IOException, InterruptedException {

        new TestFactory().chooseSignInNavigateToPrefillScreen( driver, username,  password,  policy,  leadid,  proposersame,
                relationwithinsured, isrelationanswer,  isnri,  pmobile,  ppan,  imobile,
                ipan);
        waitUtils.waitForElementToBeVisible(driver,createApplPage.eleFirstnameInputField);
        if (!createApplPage.isVerifiedTick()) {
            createApplPage.fillFirstName(lastname,"proposer");
            createApplPage.fillLastName(lastname,"proposer");
            createApplPage.fillMiddleName(middlename,"proposer");
            commonUtils.scrollTillEndOfPage(driver);
            createApplPage.selectGender(gender,"proposer");
            waitUtils.implicitWait(driver, 20000);
        }
        //Assert.assertTrue(createApplPage.eleVerifiedTick.isDisplayed(),"Verified tick is not shown");
        //commonUtils.scrollTillEndOfPage(driver);
        //Assert.assertEquals(createApplPage.getFirstName(),firstname,"Firstname Prefilled doesn't match with the custoemer firstname");
        //Assert.assertEquals(createApplPage.getLastName(),lastname,"Lastname Prefilled doesn't match with the custoemer lastname");
        commonUtils.scrollTillEndOfPage(driver);
        createApplPage.fillDOB(day, month, year,"proposer");
        //Assert.assertTrue(createApplPage.verifyGenderIsSelected(gender),"Incorrect gender is populated");
        commonUtils.scrollTopOfPage(driver);
        createApplPage.chooseInsuredTab();
        waitUtils.fluentWaitUntilElementVisible(driver,createApplPage.eleInsuredFirstnameInputField,80);
        Thread.sleep(1000);
    }

    /*
        1. verify pan and
        Validate As a Sales Person, I would like the details to be prefilled based on the PAN
Validate Details of the form will come in a 'Editable' state
Validate  that the DOB is also entered when user saving the information
Validate user choose to edit the name
Validate New Name as per NSDL records
Validate if Name is as per Nsdl records should stored in DB and backend
Validate Mandatory field
Validate gender from NSDL needs to be prefilled based on salutation
Validate user can change prefilled gender
Validate If PAN API service is down or not available
Validate In case PAN is of a company, then only details displayed
Validate in case the PAN is from Non-Individual
Validate  If the user chooses to edit the name,message to be shown
Validate Click on Back
Validate if NSDL is down
    * */


}



