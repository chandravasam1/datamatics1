package tests.validation;

import com.absli.connector.pCloudy.PcloudyConnector;
import com.absli.helpers.dataProviders.DataProviders;
import com.absli.helpers.jsonReaders.ReadJson;
import com.absli.helpers.models.ProposerModel;
import com.absli.listeners.RetryAnalyzer;
import com.absli.listeners.TestLevelDriverCreator;
import com.absli.pageObjects.CreateApplPage;
import com.absli.pageObjects.SignInPage;
import com.absli.utils.CommonUtils;
import com.absli.utils.ExcelUtils;
import com.absli.utils.PropertiesUtils;
import com.absli.utils.WaitUtils;
import io.qameta.allure.Description;
import org.openqa.selenium.Keys;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import tests.BaseTest;
import tests.TestFactory;

import java.io.IOException;
import java.text.ParseException;

@Listeners({TestLevelDriverCreator.class})
public class NomineeValidation extends BaseTest {

    ReadJson jsonObj;
    CreateApplPage createApplPage;
    CommonUtils commonUtils;
    WaitUtils waitUtils;
    PropertiesUtils prop;
    SignInPage signIn;

    @BeforeClass
    public void preSetup() throws IOException, InterruptedException {
        driver = new TestLevelDriverCreator().getDriver();

        jsonObj = new ReadJson();
        signIn = new SignInPage(driver);
        commonUtils = new CommonUtils();
        waitUtils = new WaitUtils();
        prop = new PropertiesUtils();
        createApplPage = new CreateApplPage(driver);

        new BaseTest().relaunch();

        new TestFactory().gotoNominee(driver, getData("username"),getData("password"),
                getData("policy"),getData("leadid"),getData("proposersame"),getData("relationwithinsured"),
                getData("isrelationanswer"),getData("isnri"),getData("pmobile"), getData("ppan"), getData("imobile"), getData("ipan"), getData("firstname"), getData("lastname"),
                getData("middlename"), getData("day"), getData("month"), getData("year"), getData("gender"), getData("planjourney"), getData("proposerstate"), getData("advisorstatesame"), getData("plan"), getData("sumassured"), getData("smokertype"), getData("planoptions"), getData("increasinglevel"),
                getData("ecs"), getData("term"), getData("ppt"), getData("premiumterm"), getData("premiumamount"),
                getData("rider"), getData("rideramount"), getData("minrider"), getData("maxrider"), getData("ridererror"), getData("click"), getData("generateillustrations"),
                getData("clickcontinue"), getData("ifsccode"), getData("bankaccno"), getData("accholdername"), getData("accounttype"), getData("pennyalert"),
                getData("clickverify"), getData("renewpremiumscreentitle"),getData("paymentmethod"),getData("drawdate"),getData("fundsource"),
                getData("nomineescreentitle"));

        Assert.assertTrue(createApplPage.eleNomineeNavText.isDisplayed(),"Nominee screen is not displayed");
    }

    @AfterMethod
    public void relaunch()  {
            commonUtils.scrollTopOfPage(driver);
            waitUtils.wait2Seconds();
            //waitUtils.waitUntilVisible(driver,createApplPage.eleNomineeFirstNameInput,40);
    }

    @Test(dataProvider = "dataNomineeValidationProvider",dataProviderClass = DataProviders.class)
    @Description("nominee_mandatory_fields_validation")
    public void nominee_mandatory_fields_validation(String username, String password, String policy, String leadid, String proposersame,
                                                    String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                                    String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                                    String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                                    String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                                    String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                                    String clickverify, String renewpremiumscreentitle,String paymentmethod,String drawdate,String fundsource,
                                                    String nomineescreentitle,String nomineefirstname,String 	nomineelastname,String 	nomineeday,
                                                    String nomineemonth,String 	nomineeyear,String 	nomineegender,String 	relationshipwithproposer,String 	nomineeshare,
                                                    String ismwppolicy,String addressscreentitle) throws InterruptedException, IOException {

        commonUtils.scrollTillEndOfPage(driver);
        createApplPage.saveForm();
        commonUtils.scrollTopOfPage(driver);
        waitUtils.waitForElementToBeVisible(driver, createApplPage.eleNomineeFirstNameError,30, "add address screen is not displayed");

        Assert.assertTrue(createApplPage.eleNomineeFirstNameError.isDisplayed(),"Error is not displayed when firstname is empty");
        Assert.assertTrue(createApplPage.eleNomineeLastNameError.isDisplayed(),"Error is not displayed when lastname is empty");
        if(new BaseTest().isWeb()) {
            commonUtils.scrollIntoViewForWeb(createApplPage.eleNomineeDayInput, driver);
        }
        Assert.assertTrue(createApplPage.eleNomineeDOBDayError.isDisplayed(),"Error is not displayed when dob is empty");
        Assert.assertTrue(createApplPage.eleNomineeDOBMonthError.isDisplayed(),"Error is not displayed when dob is empty");
        Assert.assertTrue(createApplPage.eleNomineeDOBYearError.isDisplayed(),"Error is not displayed when dob is empty");
        commonUtils.scrollTillEndOfPage(driver);
        Assert.assertTrue(createApplPage.eleNomineeRelationshipError.isDisplayed(),"Error is not displayed when nominee share is empty");
        Assert.assertTrue(createApplPage.eleNomineeShareError.isDisplayed(),"Error is not displayed when relationship is empty");

    }

    @Test(dataProvider = "dataNomineeValidationProvider",dataProviderClass = DataProviders.class)
    @Description("Nominee firstname / lastname validations")
    public void nominee_name_validations(String username, String password, String policy, String leadid, String proposersame,
                                         String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                         String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                         String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                         String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                         String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                         String clickverify, String renewpremiumscreentitle,String paymentmethod,String drawdate,String fundsource,
                                         String nomineescreentitle,String nomineefirstname,String 	nomineelastname,String 	nomineeday,
                                         String nomineemonth,String 	nomineeyear,String 	nomineegender,String 	relationshipwithproposer,String 	nomineeshare,
                                         String ismwppolicy,String addressscreentitle) throws InterruptedException, IOException {

        createApplPage.inputFirstName(nomineefirstname);
        createApplPage.inputNomineeLastName(nomineelastname);

        String  nameLength = new ReadJson().getConfigValues().getNomineeFirstName().getMaxLength();
        if(!createApplPage.getNomineeFirstName().isEmpty()) {
            if (createApplPage.getNomineeFirstName().length() > Integer.valueOf(nameLength)) {
                Assert.assertTrue(createApplPage.eleNomineeFirstNameError.isDisplayed(),"Nominee firstname error is not shown");
            }
        }

        nameLength = new ReadJson().getConfigValues().getNomineeLastName().getMaxLength();
        if(!createApplPage.getNomineeLastName().isEmpty()) {
            if (createApplPage.getNomineeLastName().length() > Integer.valueOf(nameLength)) {
                Assert.assertTrue(createApplPage.eleNomineeLastNameError.isDisplayed(),"Nominee firstname error is not shown");
            }
        }
    }

    @Test(dataProvider = "dataNomineeValidationProvider",dataProviderClass = DataProviders.class)
    @Description("Nominee dob validations")
    public void nominee_min_dob_validations(String username, String password, String policy, String leadid, String proposersame,
                                            String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                            String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                            String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                            String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                            String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                            String clickverify, String renewpremiumscreentitle,String paymentmethod,String drawdate,String fundsource,
                                            String nomineescreentitle,String nomineefirstname,String 	nomineelastname,String 	nomineeday,
                                            String nomineemonth,String 	nomineeyear,String 	nomineegender,String 	relationshipwithproposer,String 	nomineeshare,
                                            String ismwppolicy,String addressscreentitle) throws InterruptedException, IOException, ParseException {

        waitUtils.waitForElementToBeVisible(driver,createApplPage.eleNomineeDayInput,30,"DOB field is not displayed");


        commonUtils.scrollToBottom(driver);
        createApplPage.inputNomineeDOB(nomineeday,nomineemonth,nomineeyear);
        //commonUtils.scrollTillEndOfPage(driver);
        //createApplPage.saveForm();

        Assert.assertTrue(createApplPage.eleNomineeMinDOBMonthError.isDisplayed());
        Assert.assertTrue(createApplPage.eleNomineeMinDOBDayError.isDisplayed());
        Assert.assertTrue(createApplPage.eleNomineeMinDOBYearError.isDisplayed());

    }
    @Test(dataProvider = "dataNomineeValidationProvider",dataProviderClass = DataProviders.class)
    @Description("Nominee dob validations")
    public void nominee_max_dob_validations(String username, String password, String policy, String leadid, String proposersame,
                                            String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                            String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                            String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                            String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                            String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                            String clickverify, String renewpremiumscreentitle,String paymentmethod,String drawdate,String fundsource,
                                            String nomineescreentitle,String nomineefirstname,String 	nomineelastname,String 	nomineeday,
                                            String nomineemonth,String 	nomineeyear,String 	nomineegender,String 	relationshipwithproposer,String 	nomineeshare,
                                            String ismwppolicy,String addressscreentitle) throws InterruptedException, IOException, ParseException {


        waitUtils.waitForElementToBeVisible(driver,createApplPage.eleNomineeDayInput,30,"DOB field is not displayed");

        commonUtils.scrollToBottom(driver);
        createApplPage.inputNomineeDOB(nomineeday,nomineemonth,String.valueOf(commonUtils.getCurrentYear()+1));
        //commonUtils.scrollTillEndOfPage(driver);
        //createApplPage.saveForm();

        Assert.assertTrue(createApplPage.eleNomineeMaxDOBYearError.isDisplayed());

    }

    @Test(dataProvider = "dataNomineeValidationProvider",dataProviderClass = DataProviders.class)
    @Description("Nominee dob validations")
    public void nominee_dob_year_less_than_validations(String username, String password, String policy, String leadid, String proposersame,
                                                       String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                                       String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                                       String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                                       String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                                       String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                                       String clickverify, String renewpremiumscreentitle,String paymentmethod,String drawdate,String fundsource,
                                                       String nomineescreentitle,String nomineefirstname,String 	nomineelastname,String 	nomineeday,
                                                       String nomineemonth,String 	nomineeyear,String 	nomineegender,String 	relationshipwithproposer,String 	nomineeshare,
                                                       String ismwppolicy,String addressscreentitle) throws InterruptedException, IOException, ParseException {

        waitUtils.waitForElementToBeVisible(driver,createApplPage.eleNomineeDayInput,30,"DOB field is not displayed");

        commonUtils.scrollToBottom(driver);
        createApplPage.inputNomineeDOB(nomineeday,nomineemonth,nomineeyear);
        if(new BaseTest().isWeb()) {
            commonUtils.scrollIntoViewForWeb(createApplPage.eleNomineeDayInput,driver);
            createApplPage.eleNomineeYearInput.sendKeys(Keys.ENTER);
        }
        //commonUtils.scrollTillEndOfPage(driver);
        //createApplPage.saveForm();
        Assert.assertTrue(createApplPage.eleNomineeMinDOBYearError.isDisplayed());

    }



    @Test(dataProvider = "dataNomineeValidationProvider",dataProviderClass = DataProviders.class)
    @Description("nominee_share_more_than_100_percent")
    public void nominee_share_more_than_100_percent(String username, String password, String policy, String leadid, String proposersame,
                                                    String relationwithinsured,String	isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                                    String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                                    String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                                    String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                                    String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                                    String clickverify, String renewpremiumscreentitle,String paymentmethod,String drawdate,String fundsource,
                                                    String nomineescreentitle,String nomineefirstname,String 	nomineelastname,String 	nomineeday,
                                                    String nomineemonth,String 	nomineeyear,String 	nomineegender,String 	relationshipwithproposer,String 	nomineeshare,
                                                    String ismwppolicy,String addressscreentitle) throws InterruptedException, IOException {

        createApplPage.addNominee(nomineefirstname,nomineelastname,nomineeday,nomineemonth,nomineeyear,nomineegender,relationshipwithproposer,nomineeshare,ismwppolicy);

        Assert.assertTrue(createApplPage.eleNomineeShareError.isDisplayed(),"Nominee share error is not shown");
    }


    public String getData(String cell) throws IOException {
         String data = new ExcelUtils().getCellData(new PropertiesUtils().getProperties("testExcelSheet"),
                "nominee_mandatory_fields_validation",new PropertiesUtils().getProperties("nomineeValSheetName"),cell);
         return data;
    }



}


/*
* nominee_share_validations
nominee_mandatory_fields_validation
nominee_name_validations
nominee_dob_validations
nominee_dob_validations
add_multiple_nominees
nominee_share_100%_in_case_of_multiple_nominees
gender_validation_in_case_of_nominee_relationship
* */
