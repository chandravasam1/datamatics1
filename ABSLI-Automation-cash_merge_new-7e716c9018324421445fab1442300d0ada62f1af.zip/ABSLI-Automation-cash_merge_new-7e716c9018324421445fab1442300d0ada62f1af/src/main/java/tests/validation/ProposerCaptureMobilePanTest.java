/* Test - 6  Capture Mobile No*/
/*Test - 15 Capture Pan  */
package tests.validation;

import com.absli.helpers.dataProviders.DataProviders;
import com.absli.listeners.TestLevelDriverCreator;
import com.absli.listeners.TestListener;
import com.absli.helpers.jsonReaders.ReadJson;
import com.absli.helpers.models.ProposerModel;
import com.absli.pageObjects.CreateApplPage;
import com.absli.pageObjects.DashboardPage;
import com.absli.pageObjects.SignInPage;
import com.absli.utils.CommonUtils;
import com.absli.utils.ExcelUtils;
import com.absli.utils.PropertiesUtils;
import com.absli.utils.WaitUtils;
import io.qameta.allure.Description;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.*;
import tests.BaseTest;
import tests.TestFactory;

import java.io.IOException;
import static com.absli.logger.LoggingManager.*;

@Listeners({TestLevelDriverCreator.class})
public class ProposerCaptureMobilePanTest extends BaseTest {

        ProposerModel proposerModel;
        ReadJson jsonObj;
        SignInPage signIn;
        CreateApplPage createApplPage;
        CommonUtils commonUtils;
        WaitUtils waitUtils;
        DashboardPage dashPage;
        WebDriver driver=null;


    @BeforeClass
        public void preSetup() throws IOException, InterruptedException {
            driver = new TestLevelDriverCreator().getDriver();
            jsonObj = new ReadJson();
            dashPage = new DashboardPage(driver);

            signIn = new SignInPage(driver);
            createApplPage = new CreateApplPage(driver);
            commonUtils = new CommonUtils();
            waitUtils = new WaitUtils();
            new BaseTest().relaunch();
            new TestFactory().chooseSignInNavigateToMobilePanScreen(driver, getData("username"),getData("password"),
                getData("policy"),getData("leadid"),getData("proposersame"),getData("relationwithinsured"),
                getData("isrelationanswer"),getData("isnri"));
    }

    @AfterMethod
    public void relaunch() {
        commonUtils.scrollTopOfPage(driver);
        waitUtils.waitForElementToBeVisible(driver,createApplPage.eleProposerMobileNoInputField);
        createApplPage.clearMobile("proposer");
    }

    //@BeforeMethod
    public void before() {
        try {
            new TestFactory().chooseSignInNavigateToMobilePanScreen(driver, getData("username"),getData("password"),
                    getData("policy"),getData("leadid"),getData("proposersame"),getData("relationwithinsured"),
                    getData("isrelationanswer"),getData("isnri"));
        }catch (Exception e) {
            //
        }
    }

    @Test(dataProvider = "dataMobilePanProvider",dataProviderClass = DataProviders.class,description = "Verify Navigation to capture mobile screen" ,priority = 1)
    @Description("Verify Navigation to capture mobile screen")
    public void navigateToCaptureMobilePageTest(String username, String password, String policy, String leadid, String proposersame, String  relationwithinsured,String isrelationanswer,String isnri,String pmobile,String 	ppan,String 	imobile,String 	ipan) throws InterruptedException, IOException {
        Assert.assertTrue(createApplPage.isCaptureMobileScreenDisplayed(), "Capture Mobile number screen is not displayed");
    }

        @Test(enabled = true,dataProvider = "dataMobilePanProvider",dataProviderClass = DataProviders.class,description = "Verify user is able to enter mobile no")
        @Description("Verify user is able to enter mobile no")
        public void enterMobileNo(String username, String password, String policy, String leadid, String proposersame, String  relationwithinsured,String isrelationanswer,String isnri,String pmobile,String 	ppan,String 	imobile,String 	ipan) throws IOException, InterruptedException {

            createApplPage.verifyMobileNoFieldIsVisible("proposer");
            createApplPage.inputMobileNo("proposer",pmobile);
            Assert.assertNotNull(createApplPage.getMobileNo("proposer"));
        }

        @Test(enabled = true,dataProvider = "dataMobilePanProvider",dataProviderClass = DataProviders.class,description = "Verify proposer mobile no validations for mobile no start with 0 == ")
        @Description("Verify proposer mobile no validations for mobile no start with 0 == ")
        public void mobileNoValidationRulesStartWithZeroToFive(String username, String password, String policy, String leadid, String proposersame,
                                                               String  relationwithinsured,String isrelationanswer, String isnri,String pmobile,String 	ppan,String 	imobile,String 	ipan) throws IOException, InterruptedException {
            createApplPage.verifyMobileNoFieldIsVisible("proposer");
            //Assert.assertTrue(createApplPage.verifyMobilePanNextButtonIsDisabled(),"Mobile Pan page Next button is enabled when no values are entered");

            logMessage("Test for mobile no start with 0 == ");
            createApplPage.inputMobileNo("proposer", pmobile);
            commonUtils.enterKey(createApplPage.eleProposerMobileNoInputField,driver);
            createApplPage.selectPanMobileNextButton();
            Assert.assertTrue(createApplPage.verifyInvalidMobileNoErrorMessage(), "Error message is not shown for invalid mobile no input");
        }

        @Test(enabled = true,dataProvider = "dataMobilePanProvider",dataProviderClass = DataProviders.class,description = "Verify proposer mobile no validations for mobile no start with consecutive numbers == ")
        @Description("Verify proposer mobile no validations for mobile no start with consecutive numbers ==")
        public void mobileNoValidationRulesStartWithConsecutiveNum(String username, String password, String policy, String leadid, String proposersame,
                                                                   String  relationwithinsured,String isrelationanswer, String isnri,String pmobile,String 	ppan,String 	imobile,String 	ipan) throws IOException, InterruptedException {
            logMessage("Test for mobile no start consecutive numbers == ");
            createApplPage.inputMobileNo("proposer", pmobile);
            commonUtils.enterKey(createApplPage.eleProposerMobileNoInputField,driver);
            createApplPage.selectPanMobileNextButton();

            Assert.assertTrue(createApplPage.verifyInvalidMobileNoErrorMessage(), "Error message is not shown for invalid mobile no input");
        }
        @Test(enabled = true,dataProvider = "dataMobilePanProvider",dataProviderClass = DataProviders.class,description = "Verify proposer mobile no validations for mobile no with sequential numbers == ")
        @Description("Verify proposer mobile no validations for mobile no start with swquential numbers ==")
        public void mobileNoValidationRulesStartWithSequentialNum(String username, String password, String policy, String leadid, String proposersame,
                                                                  String  relationwithinsured,String isrelationanswer, String isnri,String pmobile,String 	ppan,String 	imobile,String 	ipan) throws IOException, InterruptedException {

            logMessage("Test for mobile no start sequential numbers == ");
            createApplPage.inputMobileNo("proposer", pmobile);
            commonUtils.enterKey(createApplPage.eleProposerMobileNoInputField,driver);
            createApplPage.selectPanMobileNextButton();
            Assert.assertTrue(createApplPage.verifyInvalidMobileNoErrorMessage(), "Error message is not shown for invalid mobile no input");
        }
        @Test(enabled = true,dataProvider = "dataMobilePanProvider",dataProviderClass = DataProviders.class,description = "Verify proposer mobile no validations for mobile no with non numbers == ")
        @Description("Verify proposer mobile no validations for mobile no start with non numbers ==")
        public void mobileNoValidationRulesStartWithNonNum(String username, String password, String policy, String leadid, String proposersame,
                                                           String  relationwithinsured,String isrelationanswer, String isnri,String pmobile,String 	ppan,String 	imobile,String 	ipan) throws IOException, InterruptedException {

            logMessage("Test for mobile no with non numeric == ");
            createApplPage.inputMobileNo("proposer", pmobile);
            commonUtils.enterKey(createApplPage.eleProposerMobileNoInputField,driver);
            createApplPage.selectPanMobileNextButton();
            Assert.assertTrue(createApplPage.verifyMobileErrorMessage(), "Error message is not shown for invalid mobile no input");
        }
        @Test(enabled = true,dataProvider = "dataMobilePanProvider",dataProviderClass = DataProviders.class,description = "Verify proposer mobile no validations for mobile no with min digits == ")
        @Description("Verify proposer mobile no validations for mobile no start with min digits ==")
        public void mobileNoValidationRulesStartWithMinDigits(String username, String password, String policy, String leadid, String proposersame,
                                                              String  relationwithinsured,String isrelationanswer, String isnri,String pmobile,String 	ppan,String 	imobile,String 	ipan) throws IOException, InterruptedException {

            logMessage("Test for mobile no with min digits == ");
            String minDigitMobileNo = createApplPage.getMobileNoWithLessThanMinDigits();
            logMessage(minDigitMobileNo);
            createApplPage.inputMobileNo("proposer", minDigitMobileNo);
            commonUtils.enterKey(createApplPage.eleProposerMobileNoInputField,driver);
            createApplPage.selectPanMobileNextButton();
            Assert.assertTrue(createApplPage.verifyMinDigitsMobileErrorMessage(), "Error message is not shown for invalid mobile no input");
        }
        @Test(enabled = true,dataProvider = "dataMobilePanProvider",dataProviderClass = DataProviders.class,description = "Verify proposer mobile no validations for mobile no with max digits == ")
        @Description("Verify proposer mobile no validations for mobile no start with max digits ==")
        public void mobileNoValidationRulesStartWithMaxDigits(String username, String password, String policy, String leadid, String proposersame,
                                                              String  relationwithinsured,String isrelationanswer, String isnri,String pmobile,String 	ppan,String 	imobile,String 	ipan) throws IOException, InterruptedException {
            logMessage("Test for mobile no with max digits == ");
            String maxDigitMobileNo = createApplPage.getMobileNoWithMaxDigits();
            logMessage(maxDigitMobileNo);
            createApplPage.inputMobileNo("proposer",maxDigitMobileNo);
            commonUtils.enterKey(createApplPage.eleProposerMobileNoInputField,driver);
            createApplPage.selectPanMobileNextButton();
            Assert.assertFalse(createApplPage.verifyInvalidMobileNoErrorMessage(),"Error message is not shown for invalid mobile no input");
        }

        @Test(enabled = true,dataProvider = "dataMobilePanProvider",dataProviderClass = DataProviders.class,description = "Verify error message for invalid pan")
        @Description("Verify error message for invalid pan")
        public void verifyInvalidPanNoValidation(String username, String password, String policy, String leadid, String proposersame,
                                                 String  relationwithinsured,String isrelationanswer, String isnri,String pmobile,String 	ppan,String 	imobile,String 	ipan) throws IOException, InterruptedException {
              logMessage(" == > Verify error message for invalid pan");
            createApplPage.inputPan("proposer", ppan);
            commonUtils.enterKey(createApplPage.eleProposerPanInputField,driver);
            createApplPage.selectPanMobileNextButton();
            Assert.assertTrue(createApplPage.verifyInvalidPanErrorMessage(), "Error message is not shown when pan is invalid");
        }
        @Test(enabled = true,dataProvider = "dataMobilePanProvider",dataProviderClass = DataProviders.class,description = "Verify error message for min chars pan")
        @Description("Verify error message for min chars pan")
        public void verifyPanNoValidationForMinChars(String username, String password, String policy, String leadid, String proposersame,
                                                     String  relationwithinsured,String isrelationanswer, String isnri,String pmobile,String 	ppan,String 	imobile,String 	ipan) throws IOException, InterruptedException {
            logMessage("==> Verify error message for pan when less than required characters are entered");
            createApplPage.inputPan("proposer", ppan);
            commonUtils.enterKey(createApplPage.eleProposerPanInputField,driver);
            createApplPage.selectPanMobileNextButton();
            Assert.assertTrue(createApplPage.verifyMinCharPanErrorMessage(), "Error message is not shown when pan is invalid");
        }
        @Test(enabled = true,dataProvider = "dataMobilePanProvider",dataProviderClass = DataProviders.class,description = "Verify error message for max chars pan")
        @Description("Verify error message for max chars pan")
        public void verifyPanNoValidationForMaxChars(String username, String password, String policy, String leadid, String proposersame,
                                                     String  relationwithinsured,String isrelationanswer, String isnri,String pmobile,String 	ppan,String 	imobile,String 	ipan) throws IOException, InterruptedException {
            logMessage("==> Verify error message for pan when more than required characters are entered");
            createApplPage.inputPan("proposer",ppan);
            commonUtils.enterKey(createApplPage.eleProposerPanInputField,driver);
            createApplPage.selectPanMobileNextButton();
            Assert.assertFalse(createApplPage.verifyInvalidPanErrorMessage(),"Pan field accepts more than max characters");
        }

    public String getData(String cell) throws IOException {
        return new ExcelUtils().getCellData(new PropertiesUtils().getProperties("testExcelSheet"),
                "enterMobileNo",new PropertiesUtils().getProperties("captureMobilePanSheetName"),cell);
    }


}


