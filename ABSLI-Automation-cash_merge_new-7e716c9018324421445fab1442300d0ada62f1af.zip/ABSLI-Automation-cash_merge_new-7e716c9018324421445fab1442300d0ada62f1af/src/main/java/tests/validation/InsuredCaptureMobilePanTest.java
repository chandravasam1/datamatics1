package tests.validation;
/* Test - 6  Capture Mobile No*/
/*Test - 15 Capture Pan  */

import com.absli.helpers.dataProviders.DataProviders;
import com.absli.listeners.TestLevelDriverCreator;
import com.absli.listeners.TestListener;
import com.absli.helpers.jsonReaders.ReadJson;
import com.absli.helpers.models.ProposerModel;
import com.absli.pageObjects.CreateApplPage;
import com.absli.pageObjects.DashboardPage;
import com.absli.pageObjects.SignInPage;
import com.absli.utils.CommonUtils;
import com.absli.utils.ExcelUtils;
import com.absli.utils.PropertiesUtils;
import com.absli.utils.WaitUtils;
import io.qameta.allure.Description;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.*;
import tests.BaseTest;
import tests.TestFactory;

import java.io.IOException;

import static com.absli.logger.LoggingManager.logMessage;

@Listeners({TestLevelDriverCreator.class})
public class InsuredCaptureMobilePanTest extends BaseTest {

    ProposerModel proposerModel;
    ReadJson jsonObj;
    CreateApplPage createApplPage;
    CommonUtils commonUtils;
    WaitUtils waitUtils;
    SignInPage signIn;
    DashboardPage dashPage;


    @BeforeClass
    public void preSetup() throws IOException, InterruptedException {
        driver = new TestLevelDriverCreator().getDriver();
        jsonObj = new ReadJson();
        createApplPage = new CreateApplPage(driver);
        dashPage = new DashboardPage(driver);
        signIn = new SignInPage(driver);
        commonUtils = new CommonUtils();
        waitUtils = new WaitUtils();

        new BaseTest().relaunch();
        comTest(driver, getData("username"),getData("password"),
                getData("policy"),getData("leadid"),getData("proposersame"),getData("relationwithinsured"),
                getData("isrelationanswer"),getData("isnri"),getData("pmobile"),getData("ppan"),getData("imobile"),getData("ipan"));
    }

    @AfterMethod
    public void relaunch()  {
        commonUtils.scrollTopOfPage(driver);
        waitUtils.waitForElementToBeVisible(driver,createApplPage.eleInsuredMobileNoInputField);
        createApplPage.clearMobile("insured");
    }

    @Test(enabled = true,dataProvider = "dataInsuredMobilePanProvider",dataProviderClass = DataProviders.class,description = "Verify Insured mobile no validations for mobile no start with 0 == ")
    @Description("Verify Insured mobile no validations for mobile no start with 0")
    public void insuredMobileNoValidationRulesStartWithZeroToFive(String username, String password, String policy, String leadid, String proposersame,
                                                                  String  relationwithinsured,String isrelationanswer,String isnri,String pmobile,String 	ppan,String 	imobile,String 	ipan) throws IOException, InterruptedException {
        logMessage("Test for mobile no start with 0 == ");
        Thread.sleep(3000);
        createApplPage.inputMobileNo("insured", imobile);
        commonUtils.enterKey(createApplPage.eleInsuredMobileNoInputField,driver);
        createApplPage.selectPanMobileNextButton();
        waitUtils.implicitWait(driver,30000);
        Assert.assertTrue(createApplPage.verifyInvalidMobileNoErrorMessage(), "Error message is not shown for invalid mobile no input");
    }

    @Test(enabled = true,dataProvider = "dataInsuredMobilePanProvider",dataProviderClass = DataProviders.class,description = "Verify Insured mobile no validations for mobile no start consecutive numbers")
    @Description("Verify Insured mobile no validations for mobile no start with 1")
    public void insuredMobileNoValidationRulesStartWithConsecutiveNum(String username, String password, String policy, String leadid, String proposersame,
                                                                      String  relationwithinsured,String isrelationanswer,String isnri,String pmobile,String 	ppan,String 	imobile,String 	ipan) throws IOException, InterruptedException {

        createApplPage.inputMobileNo("insured", imobile);
        commonUtils.enterKey(createApplPage.eleInsuredMobileNoInputField,driver);
        createApplPage.selectPanMobileNextButton();
        Assert.assertTrue(createApplPage.verifyInvalidMobileNoErrorMessage(), "Error message is not shown for invalid mobile no input");
    }
    @Test(enabled = true,dataProvider = "dataInsuredMobilePanProvider",dataProviderClass = DataProviders.class,description = "Verify Insured mobile no validations for mobile no start sequential numbers")
    @Description("Verify Insured mobile no validations for mobile no start sequential numbers")
    public void insuredMobileNoValidationRulesStartWithSequentialNum(String username, String password, String policy, String leadid, String proposersame,
                                                                     String  relationwithinsured,String isrelationanswer,String isnri,String pmobile,String 	ppan,String 	imobile,String 	ipan) throws IOException, InterruptedException {
        createApplPage.inputMobileNo("insured", imobile);
        commonUtils.enterKey(createApplPage.eleInsuredMobileNoInputField,driver);
        createApplPage.selectPanMobileNextButton();
        Assert.assertTrue(createApplPage.verifyInvalidMobileNoErrorMessage(), "Error message is not shown for invalid mobile no input");
    }
    @Test(enabled = true,dataProvider = "dataInsuredMobilePanProvider",dataProviderClass = DataProviders.class,description = "Verify Insured mobile no validations for mobile no non numbers")
    @Description("Verify Insured mobile no validations for mobile non numbers")
    public void insuredMobileNoValidationRulesStartWithNonNum(String username, String password, String policy, String leadid, String proposersame,
                                                              String  relationwithinsured,String isrelationanswer,String isnri,String pmobile,String 	ppan,String 	imobile,String 	ipan) throws IOException, InterruptedException {
        createApplPage.inputMobileNo("insured", imobile);
        commonUtils.enterKey(createApplPage.eleInsuredMobileNoInputField,driver);
        createApplPage.selectPanMobileNextButton();
        Assert.assertTrue(createApplPage.verifyMobileErrorMessage(), "Error message is not shown for invalid mobile no input");
    }
    @Test(enabled = true,dataProvider = "dataInsuredMobilePanProvider",dataProviderClass = DataProviders.class,description = "Verify Insured mobile no validations for mobile with minimum digits")
    @Description("Verify Insured mobile no validations for mobile with minimum digits")
    public void insuredMobileNoValidationRulesStartWithMinDigits(String username, String password, String policy, String leadid, String proposersame,
                                                                 String  relationwithinsured,String isrelationanswer,String isnri,String pmobile,String 	ppan,String 	imobile,String 	ipan) throws IOException, InterruptedException {
        String minDigitMobileNo = createApplPage.getMobileNoWithLessThanMinDigits();
        logMessage(minDigitMobileNo);
        createApplPage.inputMobileNo("insured", minDigitMobileNo);
        commonUtils.enterKey(createApplPage.eleInsuredMobileNoInputField,driver);
        createApplPage.selectPanMobileNextButton();
        Assert.assertTrue(createApplPage.verifyMinDigitsMobileErrorMessage(), "Error message is not shown for invalid mobile no input");
    }
    @Test(enabled = true,dataProvider = "dataInsuredMobilePanProvider",dataProviderClass = DataProviders.class,description = "Verify Insured mobile no validations for mobile with max digits")
    @Description("Verify Insured mobile no validations for mobile with max digits")
    public void insuredMobileNoValidationRulesStartWithMaxDigits(String username, String password, String policy, String leadid, String proposersame,
                                                                 String  relationwithinsured,String isrelationanswer,String isnri,String pmobile,String 	ppan,String 	imobile,String 	ipan) throws IOException, InterruptedException {
        String maxDigitMobileNo = createApplPage.getMobileNoWithMaxDigits();
        logMessage(maxDigitMobileNo);
        createApplPage.inputMobileNo("insured",maxDigitMobileNo);
        commonUtils.enterKey(createApplPage.eleInsuredMobileNoInputField,driver);
        createApplPage.selectPanMobileNextButton();
        Assert.assertFalse(createApplPage.verifyInvalidMobileNoErrorMessage(),"Error message is not shown for invalid mobile no input");
    }


    @Test(enabled = true,dataProvider = "dataInsuredMobilePanProvider",dataProviderClass = DataProviders.class,description = "Verify error message for invalid pan")
    @Description("Verify error message for invalid pan")
    public void insuredVerifyInvalidPanNoValidation(String username, String password, String policy, String leadid, String proposersame,
                                                    String  relationwithinsured,String isrelationanswer,String isnri,String pmobile,String 	ppan,String 	imobile,String 	ipan) throws IOException, InterruptedException {
        createApplPage.inputPan("insured", ipan);
        commonUtils.enterKey(createApplPage.eleInsuredPanInputField,driver);
        createApplPage.selectPanMobileNextButton();
        Assert.assertTrue(createApplPage.verifyInvalidPanErrorMessage(), "Error message is not shown when pan is invalid");
    }
    @Test(enabled = true,dataProvider = "dataInsuredMobilePanProvider",dataProviderClass = DataProviders.class,description = "Verify error message for pan when less than required characters are entered")
    @Description("Verify error message for pan when less than required characters are entered")
    public void insuredVerifyPanNoValidationForMinChars(String username, String password, String policy, String leadid, String proposersame,
                                                        String  relationwithinsured,String isrelationanswer,String isnri,String pmobile,String 	ppan,String 	imobile,String 	ipan) throws IOException, InterruptedException {
        logMessage("==> Verify error message for pan when less than required characters are entered");
        createApplPage.inputPan("insured", ipan);
        commonUtils.enterKey(createApplPage.eleInsuredPanInputField,driver);
        createApplPage.selectPanMobileNextButton();
        Assert.assertTrue(createApplPage.verifyMinCharPanErrorMessage(), "Error message is not shown when pan is invalid");
    }
    @Test(enabled = true,dataProvider = "dataInsuredMobilePanProvider",dataProviderClass = DataProviders.class,description = "Verify error message for pan when more than required characters are entered")
    @Description("Verify error message for pan when more than required characters are entered")
    public void insuredVerifyPanNoValidationForMaxChars(String username, String password, String policy, String leadid, String proposersame,
                                                        String  relationwithinsured,String isrelationanswer,String isnri,String pmobile,String 	ppan,String 	imobile,String 	ipan) throws IOException, InterruptedException {
        logMessage("==> Verify error message for pan when more than required characters are entered");
        createApplPage.inputPan("insured",ipan);
        commonUtils.enterKey(createApplPage.eleInsuredPanInputField,driver);
        createApplPage.selectPanMobileNextButton();
        Assert.assertFalse(createApplPage.verifyInvalidPanErrorMessage(),"Pan field accepts more than max characters");
    }


    public void comTest(WebDriver driver, String username, String password, String policy, String leadid, String proposersame,
                        String relationwithinsured, String isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan) throws IOException, InterruptedException {
        new TestFactory().chooseSignInNavigateToInsuredMobilePanScreen(this.driver, username,  password,  policy,  leadid,  proposersame,
                relationwithinsured, isrelationanswer,  isnri,pmobile, 	ppan, 	imobile, 	ipan);
        createApplPage.verifyMobileNoFieldIsVisible("insured");

    }

    public String getData(String cell) throws IOException {
        return new ExcelUtils().getCellData(new PropertiesUtils().getProperties("testExcelSheet"),
                "insuredMobileNoValidationRulesStartWithZeroToFive",new PropertiesUtils().getProperties("insuredCaptureMobilePanSheetName"),cell);
    }


}


