package tests.validation;

import com.absli.helpers.dataProviders.DataProviders;
import com.absli.helpers.jsonReaders.ReadJson;
import com.absli.listeners.TestLevelDriverCreator;
import com.absli.pageObjects.CreateApplPage;
import com.absli.pageObjects.DashboardPage;
import com.absli.pageObjects.SignInPage;
import com.absli.utils.CommonUtils;
import com.absli.utils.ExcelUtils;
import com.absli.utils.PropertiesUtils;
import com.absli.utils.WaitUtils;
import io.qameta.allure.Description;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.*;
import tests.BaseTest;
import tests.TestFactory;

import java.io.IOException;


@Listeners({TestLevelDriverCreator.class})
public class PrefillProposerValidation extends BaseTest {

    ReadJson jsonObj;
    CreateApplPage createApplPage;
    CommonUtils commonUtils;
    WaitUtils waitUtils;
    SignInPage signIn;
    DashboardPage dashPage;
    WebDriver driver = null;

    @BeforeClass
    public void preSetup() throws IOException, InterruptedException {
        driver = new TestLevelDriverCreator().getDriver();
        jsonObj = new ReadJson();
        commonUtils = new CommonUtils();
        dashPage = new DashboardPage(driver);
        signIn = new SignInPage(driver);
        waitUtils = new WaitUtils();
        createApplPage = new CreateApplPage(driver);
        new TestFactory().chooseSignInNavigateToPrefillScreen( driver, getData("username"),  getData("password"),  getData("policy"), getData("leadid"),  getData("proposersame"),
                getData("relationwithinsured"), getData("isrelationanswer"),  getData("isnri"),  getData("pmobile"),  getData("ppan"),  getData("imobile"),
                getData("ipan"));
        waitUtils.waitForElementToBeVisible(driver,createApplPage.eleFirstnameInputField);
    }

    @Test(dataProvider = "majorSamePrefillDataProvider",dataProviderClass = DataProviders.class,description = "verify navigation to prefill details screen")
    @Description("verify navigation to prefill details screen")
    public void verifyNavigationTo_Proposer_PrefillScreen(String username,String   password,String   policy,String   leadid,String   proposersame,
                                                          String relationwithinsured, String isrelationanswer, String  isnri, String  pmobile,  String ppan,  String imobile,
                                                          String ipan,String firstname,String 	lastname,
                                                          String middlename,	String day,	String month,	String year, String gender) throws IOException, InterruptedException {
        Assert.assertTrue(createApplPage.verifyFirstnameFieldIsVisible("proposer"),"Prefill details screen is not displayed");
    }

    @Test(dataProvider = "majorSamePrefillDataProvider",dataProviderClass = DataProviders.class,description = "Verify error for min DOB")
    @Description("Verify error for min DOB")
    public void min_DOB_validations_Proposer(String username,String   password,String   policy,String   leadid,String   proposersame,
                                             String relationwithinsured, String isrelationanswer, String  isnri, String  pmobile,  String ppan,  String imobile,
                                             String ipan,String firstname,String 	lastname,
                                             String middlename,	String day,	String month,	String year, String gender) throws IOException, InterruptedException {

        commonUtils.scrollTillEndOfPage(driver);
        createApplPage.fillDOB(day, month, year,"proposer");
        commonUtils.clickIfEnabled(driver,createApplPage.elePrefillProposerSaveBtn);
        //createApplPage.dismissPrefillScreenAlerts();
        Assert.assertTrue(createApplPage.eleDOBDayErrorMsg.isDisplayed(),"DOB day error is not shown");
        Assert.assertTrue(createApplPage.eleDOBMonthErrorMsg.isDisplayed(),"DOB month error is not shown");
        Assert.assertTrue(createApplPage.eleDOBYearErrorMsg.isDisplayed(),"DOB month error is not shown");


    }

    @Test(dataProvider = "majorSamePrefillDataProvider",dataProviderClass = DataProviders.class,description = "Verify error for maximum DOB")
    @Description("Verify error for max DOB")
    public void max_DOB_validations_Proposer(String username,String   password,String   policy,String   leadid,String   proposersame,
                                             String relationwithinsured, String isrelationanswer, String  isnri, String  pmobile,  String ppan,  String imobile,
                                             String ipan,String firstname,String 	lastname,
                                             String middlename,	String day,	String month,	String year, String gender) throws IOException, InterruptedException {


        createApplPage.fillDOB(day, month, year,"proposer");
        commonUtils.scrollTillEndOfPage(driver);
        commonUtils.clickIfEnabled(driver,createApplPage.elePrefillProposerSaveBtn);
        //createApplPage.chooseActionButton(createApplPage.elePrefillInsuredNextBtn);
        //createApplPage.dismissPrefillScreenAlerts();
        Assert.assertFalse(createApplPage.verifyEnterDOBDayErrorShown(),"DOB day error is not shown");
        Assert.assertFalse(createApplPage.verifyEnterDOBMonthErrorShown(),"DOB month error is not shown");
        Assert.assertTrue(createApplPage.eleDOBYearErrorMsg.isDisplayed(),"DOB month error is not shown");


    }

    @Test(dataProvider = "majorSamePrefillDataProvider",dataProviderClass = DataProviders.class,description = "verify error when year is less than 1940")
    @Description("verify error when year is less than 1940")
    public void dob_year_less_than_1940_validations_Proposer(String username,String   password,String   policy,String   leadid,String   proposersame,
                                                             String relationwithinsured, String isrelationanswer, String  isnri, String  pmobile,  String ppan,  String imobile,
                                                             String ipan,String firstname,String 	lastname,
                                                             String middlename,	String day,	String month,	String year, String gender) throws IOException, InterruptedException {

        commonUtils.scrollTillEndOfPage(driver);
        createApplPage.fillDOB(day, month, year,"proposer");
        commonUtils.clickIfEnabled(driver,createApplPage.elePrefillProposerSaveBtn);
        Assert.assertTrue(createApplPage.eleDOBYearErrorMsg.isDisplayed(),"DOB day error is not shown");

    }

    @Test(dataProvider = "majorSamePrefillDataProvider",dataProviderClass = DataProviders.class,description = "verify error when proposer age less than 18 years")
    @Description("verify error when proposer age less than 18 years")
    public void proposer_age_less_than_18_validation(String username,String   password,String   policy,String   leadid,String   proposersame,
                                                     String relationwithinsured, String isrelationanswer, String  isnri, String  pmobile,  String ppan,  String imobile,
                                                     String ipan,String firstname,String 	lastname,
                                                     String middlename,	String day,	String month,	String year, String gender) throws IOException, InterruptedException {
        commonUtils.scrollTillEndOfPage(driver);
        createApplPage.fillDOB(day, month, year,"proposer");
        commonUtils.clickIfEnabled(driver,createApplPage.elePrefillNextBtn);
        Assert.assertTrue(createApplPage.eleDOBAgeErrorMsg.isDisplayed(),"DOB day error is not shown");
    }

    public String getData(String cell) throws IOException {
        return new ExcelUtils().getCellData(new PropertiesUtils().getProperties("testExcelSheet"),
                "verifyNavigationTo_Proposer_PrefillScreen",new PropertiesUtils().getProperties("majorSameValidationSheetName"),cell);
    }

    /*
        1. verify pan and
        Validate As a Sales Person, I would like the details to be prefilled based on the PAN
Validate Details of the form will come in a 'Editable' state
Validate  that the DOB is also entered when user saving the information
Validate user choose to edit the name
Validate New Name as per NSDL records
Validate if Name is as per Nsdl records should stored in DB and backend
Validate Mandatory field
Validate gender from NSDL needs to be prefilled based on salutation
Validate user can change prefilled gender
Validate If PAN API service is down or not available
Validate In case PAN is of a company, then only details displayed
Validate in case the PAN is from Non-Individual
Validate  If the user chooses to edit the name,message to be shown
Validate Click on Back
Validate if NSDL is down
    * */


}


