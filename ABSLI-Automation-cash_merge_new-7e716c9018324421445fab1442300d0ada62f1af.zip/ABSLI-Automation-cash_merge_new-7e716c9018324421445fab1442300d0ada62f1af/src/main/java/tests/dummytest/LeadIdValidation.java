package tests.dummytest;

import com.absli.helpers.jsonReaders.readLoginJson;
        import com.absli.listeners.TestLevelDriverCreator;
        import com.absli.pageObjects.CreateApplPage;
        import com.absli.utils.CommonUtils;
import com.absli.utils.ExcelUtils;
import com.absli.utils.PropertiesUtils;
        import io.qameta.allure.Description;
        import org.openqa.selenium.WebDriver;
import org.testng.annotations.*;
import tests.BaseTest;
        import org.testng.Assert;
import tests.TestFactory;

import java.io.IOException;


@Listeners({TestLevelDriverCreator.class})
public class LeadIdValidation extends BaseTest {

    readLoginJson jsonObj;
    CommonUtils commonUtils;
    CreateApplPage createApplPage;
    WebDriver driver=null;
    PropertiesUtils prop = new PropertiesUtils();


    @BeforeClass
    public void preSetup() throws InterruptedException {
        driver = new TestLevelDriverCreator().getDriver();
        jsonObj = new readLoginJson();
        createApplPage = new CreateApplPage(driver);
        commonUtils = new CommonUtils();
        new BaseTest().relaunch();
        //createApplPage.signInAndNavigateToCaptureLeadIdScreen();
    }

    @AfterMethod
    public void relaunch()  {
        new BaseTest().relaunch();
    }

    @BeforeMethod
    public void before() {
        try {
            new BaseTest().relaunch();
            new TestFactory().chooseSignInNavigateToLeadIdScreen(driver, getData("username"),getData("password"),getData("policy"));
        }catch (Exception e) {
            //
        }
    }
    @Test(description = "Verify lead id input",priority = 1)
    @Description("Verify lead id validation when its empty")
    public void leadIdInputTest() throws InterruptedException {
        createApplPage.inputLeadId("1234556787877887");
    }

    @Test(description = "Verify lead id error message when its empty",priority = 3)
    @Description("Verify lead id validation when its empty")
    public void leadIdErrorValidationWhenEmptyTest() throws InterruptedException {
        createApplPage.inputLeadId("");
        commonUtils.enterKey(createApplPage.eleLeadIdInput,driver);
        createApplPage.selectNextButton();
        Assert.assertTrue(createApplPage.verifyLeadIdErrorMessageShown(),"Lead id error message not shown when incorrect lead Id is entered");
        //System.out.println("==========="+ Messages.valueOf("EMPTY_LEAD_ID_MSG").getMessage());
        //Assert.assertEquals(createApplPage.getErrorMessage(), Messages.valueOf("EMPTY_LEAD_ID_MSG").getMessage(),"Error messages do not match from front end and enums");
    }

    @Test(description = "Verify lead id error message when less than 14 characters are entered",priority = 4)
    @Description("Verify lead id validation when leass than 14 characters are entered")
    public void leadIdValidationLessCharTest() throws InterruptedException {
        createApplPage.inputLeadId("123456");
        commonUtils.enterKey(createApplPage.eleLeadIdInput,driver);
        createApplPage.selectNextButton();
        Assert.assertTrue(createApplPage.verifyLeadIdErrorMessageShown(),"Lead id error message not shown when incorrect lead Id is entered");
        //System.out.println("==========="+ Messages.valueOf("MIN_CHAR_LEAD_MSG").getMessage());
        //Assert.assertEquals(createApplPage.getErrorMessage(), Messages.valueOf("MIN_CHAR_LEAD_MSG").getMessage(),"Error messages do not match from front end and enums");

    }
    //@Test(description = "Verify validation when lead id has more than 14 characters",priority = 5)
    @Description("Verify lead id validation when more than 14 characters are entered")
    public void leadIdValidationMaxCharsTest() throws InterruptedException {
        createApplPage.inputLeadId("123456789123456789");
        createApplPage.leadIdOutOfFocus();
        Assert.assertFalse(createApplPage.verifyLeadIdErrorMessageShown(),"Lead id error is shown rather it shouldn't when alphabets are entered for lead Id");
    }

    //@Test(description = "Verify lead id validation when all 14 alphabets are entered",priority = 6)
    @Description("Verify lead id validation when all 14 alphabets are entered")
    public void leadIdValidationAlphaCharsTest() throws InterruptedException {
        createApplPage.inputLeadId("abcdefghijklmnk");
        createApplPage.leadIdOutOfFocus();
        Assert.assertFalse(createApplPage.verifyLeadIdErrorMessageShown(),"Lead id error is shown rather it shouldn't when alphabets are entered for lead Id");
    }
    //@Test(description = "Verify lead id validation when lead id contains '-'",priority = 7)
    @Description("Verify lead id validation when all 14 alphabets are entered")
    public void leadIdValidationWithHiphunTest() throws InterruptedException {
        createApplPage.inputLeadId("abcdefghi-jklmn");
        createApplPage.leadIdOutOfFocus();
        Assert.assertFalse(createApplPage.verifyLeadIdErrorMessageShown(),"Lead id error is shown rather it shouldn't when valid lead Id is entered");
    }

    public String getData(String cell) throws IOException {
        return new ExcelUtils().getCellData(prop.getProperties("testExcelSheet"),
                "enterMobileNo",prop.getProperties("captureMobilePanSheetName"),cell);
    }


}



