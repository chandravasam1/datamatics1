package tests.dummytest;
/* Test - 6  Capture Mobile No*/
/*Test - 15 Capture Pan  */

        import com.absli.helpers.dataProviders.DataProviders;
        import com.absli.listeners.TestLevelDriverCreator;
        import com.absli.listeners.TestListener;
        import com.absli.helpers.jsonReaders.ReadJson;
        import com.absli.helpers.models.ProposerModel;
        import com.absli.pageObjects.CreateApplPage;
        import com.absli.utils.CommonUtils;
        import com.absli.utils.ExcelUtils;
        import com.absli.utils.PropertiesUtils;
        import com.absli.utils.WaitUtils;
        import io.qameta.allure.Description;
        import org.openqa.selenium.WebDriver;
        import org.testng.Assert;
        import org.testng.annotations.BeforeClass;
        import org.testng.annotations.BeforeMethod;
        import org.testng.annotations.Listeners;
        import org.testng.annotations.Test;
        import tests.BaseTest;
        import tests.TestFactory;

        import java.io.IOException;
        import static com.absli.logger.LoggingManager.*;

@Listeners({TestLevelDriverCreator.class})
public class ProposerMobilePanValidation extends BaseTest {

    ProposerModel proposerModel;
    ReadJson jsonObj;
    CreateApplPage createApplPage;
    CommonUtils commonUtils;
    WaitUtils waitUtils;

    @BeforeClass
    public void preSetup() throws IOException, InterruptedException {
        driver = new TestLevelDriverCreator().getDriver();
        jsonObj = new ReadJson();
        createApplPage = new CreateApplPage(driver);
        commonUtils = new CommonUtils();
        waitUtils = new WaitUtils();
    }

    @BeforeMethod
    public void relaunch()  {
        new BaseTest().relaunch();
    }

    @Test(dataProvider = "dataMobilePanProvider",dataProviderClass = DataProviders.class,description = "Verify Navigation to capture mobile screen" ,priority = 1)
    @Description("Verify Navigation to capture mobile screen")
    public void navigateToCaptureMobilePageTest(String username, String password, String policy, String leadid, String proposersame, String  relationwithinsured,String isrelationanswer,String isnri,String pmobile,String 	ppan,String 	imobile,String 	ipan) throws InterruptedException, IOException {
        /*createApplPage.inputLeadId("12345678912345");
        createApplPage.selectIsProposerInsuredSameQst("YES");
        commonUtils.scrollToBottom(driver);
        createApplPage.selectIsNriQst("YES");
        createApplPage.selectNextButton();*/
        new TestFactory().chooseSignInNavigateToMobilePanScreen(driver, username,  password,  policy,  leadid,  proposersame,
                relationwithinsured, isrelationanswer,  isnri);
        Assert.assertTrue(createApplPage.isCaptureMobileScreenDisplayed(), "Capture Mobile number screen is not displayed");
    }

    @Test(enabled = true,dataProvider = "dataMobilePanProvider",dataProviderClass = DataProviders.class,description = "Verify user is able to enter mobile no",priority = 2)
    @Description("Verify user is able to enter mobile no")
    public void enterMobileNo(String username, String password, String policy, String leadid, String proposersame, String  relationwithinsured,String isrelationanswer,String isnri,String pmobile,String 	ppan,String 	imobile,String 	ipan) throws IOException, InterruptedException {
        new TestFactory().chooseSignInNavigateToMobilePanScreen(driver, username,  password,  policy,  leadid,  proposersame,
                relationwithinsured, isrelationanswer,  isnri);

        createApplPage.verifyMobileNoFieldIsVisible("proposer");
        createApplPage.inputMobileNo("proposer",pmobile);
        Assert.assertNotNull(createApplPage.getMobileNo("proposer"));
    }

    @Test(enabled = true,dataProvider = "dataMobilePanProvider",dataProviderClass = DataProviders.class,description = "Verify proposer mobile no validations for mobile no start with 0 == ",priority = 3)
    @Description("Verify proposer mobile no validations for mobile no start with 0 == ")
    public void mobileNoValidationRulesStartWithZeroToFive(String username, String password, String policy, String leadid, String proposersame,
                                                           String  relationwithinsured,String isrelationanswer, String isnri,String pmobile,String 	ppan,String 	imobile,String 	ipan) throws IOException, InterruptedException {
        new TestFactory().chooseSignInNavigateToMobilePanScreen(driver, username,  password,  policy,  leadid,  proposersame,
                relationwithinsured, isrelationanswer,  isnri);

        createApplPage.verifyMobileNoFieldIsVisible("proposer");
        //Assert.assertTrue(createApplPage.verifyMobilePanNextButtonIsDisabled(),"Mobile Pan page Next button is enabled when no values are entered");

        logMessage("Test for mobile no start with 0 == ");
        //proposerModel = jsonObj.readProposerJson().getDataByTestCase("mobilenostartwithzero");
        createApplPage.inputMobileNo("proposer", pmobile);
        commonUtils.enterKey(createApplPage.eleProposerMobileNoInputField,driver);
        createApplPage.selectPanMobileNextButton();
        Assert.assertTrue(createApplPage.verifyInvalidMobileNoErrorMessage(), "Error message is not shown for invalid mobile no input");
    }

    @Test(enabled = true,dataProvider = "dataMobilePanProvider",dataProviderClass = DataProviders.class,description = "Verify proposer mobile no validations for mobile no start with consecutive numbers == ",priority = 4)
    @Description("Verify proposer mobile no validations for mobile no start with consecutive numbers ==")
    public void mobileNoValidationRulesStartWithConsecutiveNum(String username, String password, String policy, String leadid, String proposersame,
                                                               String  relationwithinsured,String isrelationanswer, String isnri,String pmobile,String 	ppan,String 	imobile,String 	ipan) throws IOException, InterruptedException {
        new TestFactory().chooseSignInNavigateToMobilePanScreen(driver, username,  password,  policy,  leadid,  proposersame,
                relationwithinsured, isrelationanswer,  isnri);

        logMessage("Test for mobile no start consecutive numbers == ");
        proposerModel = jsonObj.readProposerJson().getDataByTestCase("mobilenostartconsecutivenumbers");
        createApplPage.inputMobileNo("proposer", proposerModel.getMobileNo());
        commonUtils.enterKey(createApplPage.eleProposerMobileNoInputField,driver);
        createApplPage.selectPanMobileNextButton();

        Assert.assertTrue(createApplPage.verifyInvalidMobileNoErrorMessage(), "Error message is not shown for invalid mobile no input");
    }
    @Test(enabled = true,dataProvider = "dataMobilePanProvider",dataProviderClass = DataProviders.class,description = "Verify proposer mobile no validations for mobile no with sequential numbers == ",priority = 5)
    @Description("Verify proposer mobile no validations for mobile no start with swquential numbers ==")
    public void mobileNoValidationRulesStartWithSequentialNum(String username, String password, String policy, String leadid, String proposersame,
                                                              String  relationwithinsured,String isrelationanswer, String isnri,String pmobile,String 	ppan,String 	imobile,String 	ipan) throws IOException, InterruptedException {
        new TestFactory().chooseSignInNavigateToMobilePanScreen(driver, username,  password,  policy,  leadid,  proposersame,
                relationwithinsured, isrelationanswer,  isnri);

        logMessage("Test for mobile no start sequential numbers == ");
        proposerModel = jsonObj.readProposerJson().getDataByTestCase("mobilenostartseqnumbers");
        createApplPage.inputMobileNo("proposer", proposerModel.getMobileNo());
        commonUtils.enterKey(createApplPage.eleProposerMobileNoInputField,driver);
        createApplPage.selectPanMobileNextButton();
        Assert.assertTrue(createApplPage.verifyInvalidMobileNoErrorMessage(), "Error message is not shown for invalid mobile no input");
    }
    @Test(enabled = true,dataProvider = "dataMobilePanProvider",dataProviderClass = DataProviders.class,description = "Verify proposer mobile no validations for mobile no with non numbers == ",priority = 6)
    @Description("Verify proposer mobile no validations for mobile no start with non numbers ==")
    public void mobileNoValidationRulesStartWithNonNum(String username, String password, String policy, String leadid, String proposersame,
                                                       String  relationwithinsured,String isrelationanswer, String isnri,String pmobile,String 	ppan,String 	imobile,String 	ipan) throws IOException, InterruptedException {
        new TestFactory().chooseSignInNavigateToMobilePanScreen(driver, username,  password,  policy,  leadid,  proposersame,
                relationwithinsured, isrelationanswer,  isnri);

        logMessage("Test for mobile no with non numeric == ");
        proposerModel = jsonObj.readProposerJson().getDataByTestCase("MobileNoWithNonNumeric");
        createApplPage.inputMobileNo("proposer", proposerModel.getMobileNo());
        commonUtils.enterKey(createApplPage.eleProposerMobileNoInputField,driver);
        createApplPage.selectPanMobileNextButton();
        Assert.assertTrue(createApplPage.verifyMobileErrorMessage(), "Error message is not shown for invalid mobile no input");
    }
    @Test(enabled = true,dataProvider = "dataMobilePanProvider",dataProviderClass = DataProviders.class,description = "Verify proposer mobile no validations for mobile no with min digits == ",priority = 7)
    @Description("Verify proposer mobile no validations for mobile no start with min digits ==")
    public void mobileNoValidationRulesStartWithMinDigits(String username, String password, String policy, String leadid, String proposersame,
                                                          String  relationwithinsured,String isrelationanswer, String isnri,String pmobile,String 	ppan,String 	imobile,String 	ipan) throws IOException, InterruptedException {
        new TestFactory().chooseSignInNavigateToMobilePanScreen(driver, username,  password,  policy,  leadid,  proposersame,
                relationwithinsured, isrelationanswer,  isnri);

        logMessage("Test for mobile no with min digits == ");
        String minDigitMobileNo = createApplPage.getMobileNoWithLessThanMinDigits();
        logMessage(minDigitMobileNo);
        createApplPage.inputMobileNo("proposer", minDigitMobileNo);
        commonUtils.enterKey(createApplPage.eleProposerMobileNoInputField,driver);
        createApplPage.selectPanMobileNextButton();
        Assert.assertTrue(createApplPage.verifyMinDigitsMobileErrorMessage(), "Error message is not shown for invalid mobile no input");
    }
    @Test(enabled = true,dataProvider = "dataMobilePanProvider",dataProviderClass = DataProviders.class,description = "Verify proposer mobile no validations for mobile no with max digits == ",priority = 8)
    @Description("Verify proposer mobile no validations for mobile no start with max digits ==")
    public void mobileNoValidationRulesStartWithMaxDigits(String username, String password, String policy, String leadid, String proposersame,
                                                          String  relationwithinsured,String isrelationanswer, String isnri,String pmobile,String 	ppan,String 	imobile,String 	ipan) throws IOException, InterruptedException {
        new TestFactory().chooseSignInNavigateToMobilePanScreen(driver, username,  password,  policy,  leadid,  proposersame,
                relationwithinsured, isrelationanswer,  isnri);

        logMessage("Test for mobile no with max digits == ");
        String maxDigitMobileNo = createApplPage.getMobileNoWithMaxDigits();
        logMessage(maxDigitMobileNo);
        createApplPage.inputMobileNo("proposer",maxDigitMobileNo);
        commonUtils.enterKey(createApplPage.eleProposerMobileNoInputField,driver);
        createApplPage.selectPanMobileNextButton();
        Assert.assertFalse(createApplPage.verifyInvalidMobileNoErrorMessage(),"Error message is not shown for invalid mobile no input");
    }

    @Test(enabled = true,dataProvider = "dataMobilePanProvider",dataProviderClass = DataProviders.class,description = "Verify user is able to enter pan no",priority = 12)
    @Description("Verify user is able to enter pan no")
    public void enterPanNo(String username, String password, String policy, String leadid, String proposersame,
                           String  relationwithinsured,String isrelationanswer, String isnri,String pmobile,String 	ppan,String 	imobile,String 	ipan) throws IOException, InterruptedException {
        new TestFactory().chooseSignInNavigateToMobilePanScreen(driver, username,  password,  policy,  leadid,  proposersame,
                relationwithinsured, isrelationanswer,  isnri);

        proposerModel = jsonObj.readProposerJson().getDataByTestCase("validpan");
        createApplPage.inputPan("proposer",proposerModel.getPan());
    }

    @Test(enabled = true,dataProvider = "dataMobilePanProvider",dataProviderClass = DataProviders.class,description = "Verify error message for invalid pan",priority = 13)
    @Description("Verify error message for invalid pan")
    public void verifyInvalidPanNoValidation(String username, String password, String policy, String leadid, String proposersame,
                                             String  relationwithinsured,String isrelationanswer, String isnri,String pmobile,String 	ppan,String 	imobile,String 	ipan) throws IOException, InterruptedException {
        new TestFactory().chooseSignInNavigateToMobilePanScreen(driver, username,  password,  policy,  leadid,  proposersame,
                relationwithinsured, isrelationanswer,  isnri);

        logMessage(" == > Verify error message for invalid pan");
        proposerModel = jsonObj.readProposerJson().getDataByTestCase("invalidpan");
        createApplPage.inputPan("proposer", proposerModel.getPan());
        commonUtils.enterKey(createApplPage.eleProposerPanInputField,driver);
        createApplPage.selectPanMobileNextButton();
        Assert.assertTrue(createApplPage.verifyInvalidPanErrorMessage(), "Error message is not shown when pan is invalid");
    }
    @Test(enabled = true,dataProvider = "dataMobilePanProvider",dataProviderClass = DataProviders.class,description = "Verify error message for min chars pan",priority = 14)
    @Description("Verify error message for min chars pan")
    public void verifyPanNoValidationForMinChars(String username, String password, String policy, String leadid, String proposersame,
                                                 String  relationwithinsured,String isrelationanswer, String isnri,String pmobile,String 	ppan,String 	imobile,String 	ipan) throws IOException, InterruptedException {
        new TestFactory().chooseSignInNavigateToMobilePanScreen(driver, username,  password,  policy,  leadid,  proposersame,
                relationwithinsured, isrelationanswer,  isnri);

        logMessage("==> Verify error message for pan when less than required characters are entered");
        proposerModel = jsonObj.readProposerJson().getDataByTestCase("minpan");
        createApplPage.inputPan("proposer", proposerModel.getPan());
        commonUtils.enterKey(createApplPage.eleProposerPanInputField,driver);
        createApplPage.selectPanMobileNextButton();
        Assert.assertTrue(createApplPage.verifyMinCharPanErrorMessage(), "Error message is not shown when pan is invalid");
    }
    @Test(enabled = true,dataProvider = "dataMobilePanProvider",dataProviderClass = DataProviders.class,description = "Verify error message for max chars pan",priority = 15)
    @Description("Verify error message for max chars pan")
    public void verifyPanNoValidationForMaxChars(String username, String password, String policy, String leadid, String proposersame,
                                                 String  relationwithinsured,String isrelationanswer, String isnri,String pmobile,String 	ppan,String 	imobile,String 	ipan) throws IOException, InterruptedException {
        new TestFactory().chooseSignInNavigateToMobilePanScreen(driver, username,  password,  policy,  leadid,  proposersame,
                relationwithinsured, isrelationanswer,  isnri);

        logMessage("==> Verify error message for pan when more than required characters are entered");
        proposerModel = jsonObj.readProposerJson().getDataByTestCase("maxpan");
        createApplPage.inputPan("proposer",proposerModel.getPan());
        commonUtils.enterKey(createApplPage.eleProposerPanInputField,driver);
        createApplPage.selectPanMobileNextButton();
        Assert.assertFalse(createApplPage.verifyInvalidPanErrorMessage(),"Pan field accepts more than max characters");
    }
    //@Test(enabled = true,dataProvider = "dataMobilePanProvider",dataProviderClass = DataProviders.class,description = "Verify navigation to prefill data screen",priority = 16)
    @Description("Verify navigation to prefill data screen")
    public void verifyNavigationToPrefillDetails(String username, String password, String policy, String leadid, String proposersame,
                                                 String  relationwithinsured,String isrelationanswer, String isnri,String pmobile,String 	ppan,String 	imobile,String 	ipan) throws IOException, InterruptedException {
        new TestFactory().chooseSignInNavigateToMobilePanScreen(driver, username,  password,  policy,  leadid,  proposersame,
                relationwithinsured, isrelationanswer,  isnri);

        ProposerModel proposerModelPan = jsonObj.readProposerJson().getDataByTestCase("validpan");
        ProposerModel proposerModelMob = jsonObj.readProposerJson().getDataByTestCase("validmobile");
        createApplPage.inputMobileNo("proposer",proposerModelMob.getMobileNo());
        createApplPage.inputPan("proposer",proposerModelPan.getPan());
        commonUtils.enterKey(createApplPage.eleProposerPanInputField,driver);
        createApplPage.selectPanMobileNextButton();
        if(createApplPage.isAlertShown()){
            createApplPage.acceptAlert();
        }
        waitUtils.waitForElementToBeVisible(driver,createApplPage.eleFirstnameInputField);
        Assert.assertTrue(createApplPage.verifyFirstnameFieldIsVisible("proposer"),"Prefill details screen is not displayed");
    }

    public String getMobileData(String cell) throws IOException {
        return new ExcelUtils().getCellData(new PropertiesUtils().getProperties("testExcelSheet"),
                "enterMobileNo",new PropertiesUtils().getProperties("captureMobilePanSheetName"),cell);
    }

    public String getPanData(String cell) throws IOException {
        return new ExcelUtils().getCellData(new PropertiesUtils().getProperties("testExcelSheet"),
                "enterPanNo",new PropertiesUtils().getProperties("captureMobilePanSheetName"),cell);
    }

}


