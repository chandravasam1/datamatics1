package tests.flows;

import com.absli.listeners.TestListener;
import com.absli.helpers.jsonReaders.ReadJson;
import com.absli.helpers.models.ProposerModel;
import com.absli.pageObjects.CreateApplPage;
import com.absli.utils.CommonUtils;
import com.absli.utils.WaitUtils;
import io.qameta.allure.Description;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import tests.BaseTest;

import java.io.IOException;

@Listeners(TestListener.class)
public class ProposerInsuredAreSame extends BaseTest {
    ProposerModel proposerModel;
    ReadJson jsonObj;
    CreateApplPage createApplPage;
    CommonUtils commonUtils;
    WaitUtils waitUtils;

    @BeforeClass
    public void preSetup() throws IOException, InterruptedException {
        jsonObj = new ReadJson();
        commonUtils = new CommonUtils();
        waitUtils = new WaitUtils();
        createApplPage = new CreateApplPage(driver);
        createApplPage.signInAndNavigateToCaptureLeadIdScreen();
        proposerModel = jsonObj.readProposerJson().getDataByTestCase("validcustomerprofile");
    }

    @Test(description = "verify navigation to prefill details screen",priority = 1)
    @Description("verify navigation to prefill details screen")
    public void verifyNavigationToPrefillScreen() throws IOException {
        createApplPage.fillLeadIdChooseNextWhenProposerInsuredAreSame();
        ProposerModel customerProposerModel = jsonObj.readProposerJson().getDataByTestCase("validcustomerprofile");
        createApplPage.inputMobileNo("proposer",customerProposerModel.getMobileNo());
        createApplPage.inputPan("proposer",customerProposerModel.getPan());
        createApplPage.selectPanMobileNextButton();
        waitUtils.waitForElementToBeVisible(driver,createApplPage.eleFirstnameInputField);
        Assert.assertTrue(createApplPage.verifyFirstnameFieldIsVisible("proposer"),"Prefill details screen is not displayed");
    }

   /* @Test(description = "verify prefill details based on pan",priority = 3)
    @Description("verify prefill details based on pan")
    public void prefillDetailsBasedOnPan() throws IOException {

        Assert.assertTrue(createApplPage.eleVerifiedTick.isDisplayed(),"Verified tick is not shown");
        commonUtils.scrollTillEndOfPage(driver);
        waitUtils.implicitWait(driver,20000);
        waitUtils.waitForElementToBeVisible(driver,createApplPage.eleFirstnameInputField);
        Assert.assertEquals(createApplPage.getFirstName(),proposerModel.getFirstName(),"Firstname Prefilled doesn't match with the custoemer firstname");
        Assert.assertEquals(createApplPage.getLastName(),proposerModel.getLastName(),"Lastname Prefilled doesn't match with the custoemer lastname");
        commonUtils.scrollTillEndOfPage(driver);
        Assert.assertTrue(createApplPage.verifyGenderIsSelected(),"Incorrect gender is populated");

    }

    @Test(description = "verify edit verified firstname",priority = 4)
    @Description("verify edit verified firstname")
    public void editFirstname() throws IOException {

        Assert.assertTrue(createApplPage.eleVerifiedTick.isDisplayed(),"Verified tick is not shown");
        commonUtils.scrollTillEndOfPage(driver);
        waitUtils.waitForElementToBeVisible(driver,createApplPage.eleFirstnameInputField);
        createApplPage.fillFirstName("test");
        createApplPage.enterDOB(proposerModel);
        waitUtils.implicitWait(driver,30000);
        createApplPage.selectButtonByText("Save");
        Assert.assertTrue(createApplPage.verifyEditNameAlertDisplayed());
        createApplPage.selectButtonByText("CANCEL");
    }

    @Test(description = "verify mandatory fields validation",priority = 5)
    @Description("verify mandatory fields validation")
    public void verifyMandatoryFieldsValidation() throws IOException {
        createApplPage.clearAllPrefilDetailsFieldValues();
        createApplPage.selectButtonByText("Save");
        Assert.assertTrue(createApplPage.verifyEnterDOBDayErrorShown(),"Prefill details mobile no doesn't match with the custoemer mobile");
        Assert.assertTrue(createApplPage.verifyEnterFirstNameErrorIsShown(),"Prefill details mobile no doesn't match with the custoemer mobile");
        Assert.assertTrue(createApplPage.verifyEnterLastNameErrorIsShown(),"Prefill details mobile no doesn't match with the custoemer mobile");
        commonUtils.scrollTillEndOfPage(driver);
        Assert.assertTrue(createApplPage.verifyEnterDOBYearErrorShown(),"Error is shown for prefilling details manually");
        Assert.assertTrue(createApplPage.verifyEnterDOBMonthErrorShown(),"Error is shown for prefilling details manually");
        Assert.assertTrue(createApplPage.verifyEnterDOBDayErrorShown(),"Error is shown for prefilling details manually");
    }


    @Test(description = "verify fill details manually when NSDL api is down",priority = 6)
    @Description("verify fill details manually when NSDL api is down")
    public void editDetailsManually() throws IOException {
        ProposerModel customerProposerModel = jsonObj.readProposerJson().getDataByTestCase("validcustomerprofile");
        createApplPage.fillFirstName(customerProposerModel.getFirstName());
        createApplPage.fillLastName(customerProposerModel.getLastName());
        createApplPage.fillMiddleName(customerProposerModel.getMiddleName());
        createApplPage.enterDOB(customerProposerModel);
        createApplPage.selectGender(customerProposerModel.getGender());
        Assert.assertFalse(createApplPage.verifyEnterDOBDayErrorShown(),"Error is shown for prefilling details manually");
        Assert.assertFalse(createApplPage.verifyEnterLastNameErrorIsShown(),"Error is shown for prefilling details manually");
        Assert.assertFalse(createApplPage.verifyEnterFirstNameErrorIsShown(),"Error is shown for prefilling details manually");

    }*/

    /*
        1. verify pan and
        Validate As a Sales Person, I would like the details to be prefilled based on the PAN
Validate Details of the form will come in a 'Editable' state
Validate  that the DOB is also entered when user saving the information
Validate user choose to edit the name
Validate New Name as per NSDL records
Validate if Name is as per Nsdl records should stored in DB and backend
Validate Mandatory field
Validate gender from NSDL needs to be prefilled based on salutation
Validate user can change prefilled gender
Validate If PAN API service is down or not available
Validate In case PAN is of a company, then only details displayed
Validate in case the PAN is from Non-Individual
Validate  If the user chooses to edit the name,message to be shown
Validate Click on Back
Validate if NSDL is down
    * */


}
