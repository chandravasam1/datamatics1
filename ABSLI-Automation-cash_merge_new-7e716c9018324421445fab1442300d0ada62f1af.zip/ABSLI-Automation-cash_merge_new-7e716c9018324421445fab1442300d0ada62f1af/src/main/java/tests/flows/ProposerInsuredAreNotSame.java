/* Test - 6  Capture Mobile No*/
/*Test - 15 Capture Pan  */
package tests.flows;
import com.absli.helpers.jsonReaders.ReadJson;
import com.absli.helpers.models.ProposerModel;
import com.absli.pageObjects.CreateApplPage;
import io.qameta.allure.Description;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import tests.BaseTest;

import java.io.IOException;

public class ProposerInsuredAreNotSame extends BaseTest {

        ProposerModel proposerModel;
        ReadJson jsonObj;
        CreateApplPage createApplPage;

        @BeforeClass
        public void preSetup() throws IOException, InterruptedException {
            jsonObj = new ReadJson();
            createApplPage = new CreateApplPage(driver);
            createApplPage.signInAndNavigateToCaptureLeadIdScreen();
            createApplPage.fillLeadIdChooseNextWhenProposerInsuredAreNotSame("Father","YES");
            createApplPage.fillProposerMobilePanChooseInsuredTab();
            createApplPage.verifyMobileNoFieldIsVisible("insured");
        }

        @Test(enabled = true,description = "Verify insured proposer flow",priority = 1)
        @Description("Verify insured proposer flow")
        public void enterInsuredMobileNoTest() throws IOException {
            ProposerModel proposerModelPan = jsonObj.readProposerJson().getDataByTestCase("validpan");
            ProposerModel proposerModelMob = jsonObj.readProposerJson().getDataByTestCase("validmobile");
            createApplPage.inputMobileNo("insured",proposerModelMob.getMobileNo());
            createApplPage.inputPan("insured",proposerModelPan.getPan());
            createApplPage.selectPanMobileNextButton();
            Assert.assertTrue(createApplPage.verifyFirstnameFieldIsVisible("insured"),"Prefill details screen is not displayed");
        }

    }




