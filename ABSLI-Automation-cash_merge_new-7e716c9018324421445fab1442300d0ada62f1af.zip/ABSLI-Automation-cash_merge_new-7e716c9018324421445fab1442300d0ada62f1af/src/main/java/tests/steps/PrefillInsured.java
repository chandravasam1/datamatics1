package tests.steps;

import com.absli.helpers.dataProviders.DataProviders;
import com.absli.helpers.jsonReaders.ReadJson;
import com.absli.helpers.models.ProposerModel;
import com.absli.listeners.TestLevelDriverCreator;
import com.absli.listeners.TestListener;
import com.absli.pageObjects.CreateApplPage;
import com.absli.pageObjects.DashboardPage;
import com.absli.pageObjects.SignInPage;
import com.absli.utils.CommonUtils;
import com.absli.utils.WaitUtils;
import io.qameta.allure.Description;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.*;
import tests.BaseTest;
import tests.TestFactory;
import java.io.IOException;

@Listeners({TestLevelDriverCreator.class})
public class PrefillInsured extends BaseTest {

    ReadJson jsonObj;
    CreateApplPage createApplPage;
    CommonUtils commonUtils;
    WaitUtils waitUtils;
    SignInPage signIn;
    DashboardPage dashPage;
    public WebDriver driver =null;

    @BeforeClass
    public void preSetup() throws IOException, InterruptedException {
        driver = new TestLevelDriverCreator().getDriver();
        commonUtils = new CommonUtils();
        waitUtils = new WaitUtils();
        createApplPage = new CreateApplPage(driver);
    }

    @BeforeMethod
    public void launch()  {
        new BaseTest().relaunch();
    }

    //@AfterClass
    public void relaunch()  {
        new BaseTest().relaunch();
    }

    

    @Test(dataProvider = "majorDiffPrefillDataProvider",dataProviderClass = DataProviders.class,description = "verify prefill details based on pan",priority = 3)
    @Description("verify prefill details based on pan")
    public void prefill_Insured_DetailsBasedOnPan(String username,String   password,String   policy,String   leadid,String   proposersame,
                                                  String relationwithinsured, String isrelationanswer, String  isnri, String  pmobile,  String ppan,  String imobile,
                                                  String ipan,String firstname,String 	lastname,
                                                  String middlename,	String day,	String month,	String year, String gender,String ifirstname,String 	ilastname,
                                                  String 	imiddlename,String 	iday,String 	imonth,String 	iyear,String 	igender) throws IOException, InterruptedException {

        new TestFactory().chooseSignInNavigateToPrefillScreen( driver, username,  password,  policy,  leadid,  proposersame,
                relationwithinsured, isrelationanswer,  isnri,  pmobile,  ppan,  imobile,
                ipan);

        Assert.assertTrue(createApplPage.isVerified(),"Verified tick is not shown in proposer tab");
        commonUtils.scrollTillEndOfPage(driver);
        waitUtils.waitForElementToBeVisible(driver,createApplPage.eleFirstnameInputField);
        Assert.assertEquals(createApplPage.getFirstName(),firstname,"Firstname Prefilled doesn't match with the custoemer firstname");
        Assert.assertEquals(createApplPage.getLastName(),lastname,"Lastname Prefilled doesn't match with the custoemer lastname");
        commonUtils.scrollTillEndOfPage(driver);
        createApplPage.fillDOB(day, month, year,"proposer");
        Assert.assertTrue(createApplPage.verifyGenderIsSelected(gender),"Incorrect gender is populated");
        commonUtils.scrollTopOfPage(driver);
        createApplPage.chooseInsuredTab();
        waitUtils.waitForElementToBeVisible(driver,createApplPage.eleInsuredFirstnameInputField);

        Assert.assertEquals(createApplPage.getFirstName(),ifirstname,"Firstname Prefilled doesn't match with the custoemer firstname");
        Assert.assertEquals(createApplPage.getLastName(),ilastname,"Lastname Prefilled doesn't match with the custoemer lastname");
        commonUtils.scrollTillEndOfPage(driver);
        //Assert.assertTrue(createApplPage.verifyGenderIsSelected(igender),"Incorrect gender is populated");
    }

    @Test(dataProvider = "majorDiffPrefillDataProvider",dataProviderClass = DataProviders.class,description = "verify editing verified firstname",priority = 4)
    @Description("verify editing verified firstname")
    public void edit_Insured_Firstname(String username,String   password,String   policy,String   leadid,String   proposersame,
                                       String relationwithinsured, String isrelationanswer, String  isnri, String  pmobile,  String ppan,  String imobile,
                                       String ipan,String firstname,String 	lastname,
                                       String middlename,	String day,	String month,	String year, String gender,String ifirstname,String 	ilastname,
                                       String 	imiddlename,String 	iday,String 	imonth,String 	iyear,String 	igender) throws IOException, InterruptedException {


        insured(  username,    password,    policy,    leadid,    proposersame,
                relationwithinsured,   isrelationanswer,    isnri,    pmobile,    ppan,    imobile,
                ipan,  firstname,  	lastname,
                middlename,	  day,	  month,	  year,   gender);

        createApplPage.fillFirstName("test","insured");
        if (!createApplPage.isVerifiedTick()) {
            createApplPage.fillLastName(lastname,"insured");
            createApplPage.fillMiddleName(middlename,"insured");
            commonUtils.scrollTillEndOfPage(driver);
            createApplPage.selectGender(gender,"insured");
        }
        commonUtils.scrollTillEndOfPage(driver);
        createApplPage.fillDOB(day,month,year,"insured");
        createApplPage.chooseActionButton(createApplPage.elePrefillInsuredSaveBtn);
        Assert.assertTrue(createApplPage.verifyEditNameAlertDisplayed());
        commonUtils.selectButtonByName("CANCEL",driver);
    }

    @Test(dataProvider = "majorDiffPrefillDataProvider",dataProviderClass = DataProviders.class,description = "verify mandatory fields validation",priority = 5)
    @Description("verify mandatory fields validation")
    public void verify_Insured_MandatoryFieldsValidation(String username,String   password,String   policy,String   leadid,String   proposersame,
                                                         String relationwithinsured, String isrelationanswer, String  isnri, String  pmobile,  String ppan,  String imobile,
                                                         String ipan,String firstname,String 	lastname,
                                                         String middlename,	String day,	String month,	String year, String gender,String ifirstname,String 	ilastname,
                                                         String 	imiddlename,String 	iday,String 	imonth,String 	iyear,String 	igender) throws IOException, InterruptedException {

        insured(  username,    password,    policy,    leadid,    proposersame,
                relationwithinsured,   isrelationanswer,    isnri,    pmobile,    ppan,    imobile,
                ipan,  firstname,  	lastname,
                middlename,	  day,	  month,	  year,   gender);

        createApplPage.clearAllPrefilDetailsFieldValues("insured");
        commonUtils.scrollTillEndOfPage(driver);
        //createApplPage.selectButtonByText("Save");
        createApplPage.chooseActionButton(createApplPage.elePrefillInsuredSaveBtn);
        if (!createApplPage.isVerifiedTick()) {
            Assert.assertTrue(createApplPage.verifyEnterFirstNameErrorIsShown(),"Prefill details error is not shown for firstname when its empty");
            Assert.assertTrue(createApplPage.verifyEnterLastNameErrorIsShown(),"Prefill details error is not shown for lastname when its empty");
        }
        commonUtils.scrollTillEndOfPage(driver);
        Assert.assertTrue(createApplPage.verifyEnterDOBYearErrorShown(),"Error is not shown when day is empty");
        Assert.assertTrue(createApplPage.verifyEnterDOBMonthErrorShown(),"Error is not shown when month is empty");
        Assert.assertTrue(createApplPage.verifyEnterDOBDayErrorShown(),"Error is not shown when year is empty");
    }


    @Test(dataProvider = "majorDiffPrefillDataProvider",dataProviderClass = DataProviders.class,description = "verify fill details manually when NSDL api is down",priority = 6)
    @Description("verify fill details manually when NSDL api is down")
    public void edit_Insured_DetailsManually(String username,String   password,String   policy,String   leadid,String   proposersame,
                                             String relationwithinsured, String isrelationanswer, String  isnri, String  pmobile,  String ppan,  String imobile,
                                             String ipan,String firstname,String 	lastname,
                                             String middlename,	String day,	String month,	String year, String gender,String ifirstname,String 	ilastname,
                                             String 	imiddlename,String 	iday,String 	imonth,String 	iyear,String 	igender) throws IOException, InterruptedException {


        insured(  username,    password,    policy,    leadid,    proposersame,
                relationwithinsured,   isrelationanswer,    isnri,    pmobile,    ppan,    imobile,
                ipan,  firstname,  	lastname,
                middlename,	  day,	  month,	  year,   gender);

        createApplPage.fillFirstName(ifirstname,"insured");
        createApplPage.fillLastName(ilastname,"insured");
        createApplPage.fillMiddleName(imiddlename,"insured");
        createApplPage.fillDOB(iday, imonth, iyear,"insured");
        createApplPage.selectGender(igender,"insured");
        Assert.assertFalse(createApplPage.verifyEnterDOBDayErrorShown(),"Error is shown for prefilling details manually");
        Assert.assertFalse(createApplPage.verifyEnterLastNameErrorIsShown(),"Error is shown for prefilling details manually");
        Assert.assertFalse(createApplPage.verifyEnterFirstNameErrorIsShown(),"Error is shown for prefilling details manually");

    }

    @Test(dataProvider = "majorDiffPrefillDataProvider",dataProviderClass = DataProviders.class,description = "verify Minor scenario for insured",priority = 3)
    @Description("verify Minor scenario for insured")
    public void verifyMinorInsured(String username,String   password,String   policy,String   leadid,String   proposersame,
                                   String relationwithinsured, String isrelationanswer, String  isnri, String  pmobile,  String ppan,  String imobile,
                                   String ipan,String firstname,String 	lastname,
                                   String middlename,	String day,	String month,	String year, String gender,String ifirstname,String 	ilastname,
                                   String 	imiddlename,String 	iday,String 	imonth,String 	iyear,String 	igender) throws IOException, InterruptedException {


        insured(  username,    password,    policy,    leadid,    proposersame,
                relationwithinsured,   isrelationanswer,    isnri,    pmobile,    ppan,    imobile,
                ipan,  firstname,  	lastname,
                middlename,	  day,	  month,	  year,   gender);

        createApplPage.fillFirstName(ifirstname,"insured");
        createApplPage.fillLastName(ilastname,"insured");
        createApplPage.fillMiddleName(imiddlename,"insured");
        commonUtils.scrollTillEndOfPage(driver);

        createApplPage.fillDOB(iday, imonth, iyear,"insured");
        createApplPage.selectGender(igender,"insured");
        createApplPage.chooseActionButton(createApplPage.elePrefillInsuredSaveBtn);
        createApplPage.dismissPrefillScreenAlerts();
    }

    public void insured(String username,String   password,String   policy,String   leadid,String   proposersame,
                        String relationwithinsured,String  isrelationanswer,String   isnri,String   pmobile,String   ppan,String   imobile,
                        String  ipan,String firstname,String 	lastname,
                        String middlename,	String day,	String month,	String year, String gender) throws IOException, InterruptedException {

        new TestFactory().chooseSignInNavigateToPrefillScreen( driver, username,  password,  policy,  leadid,  proposersame,
                relationwithinsured, isrelationanswer,  isnri,  pmobile,  ppan,  imobile,
                ipan);
        waitUtils.waitForElementToBeVisible(driver,createApplPage.eleFirstnameInputField);
        if (!createApplPage.isVerifiedTick()) {
            createApplPage.fillFirstName(lastname,"proposer");
            createApplPage.fillLastName(lastname,"proposer");
            createApplPage.fillMiddleName(middlename,"proposer");
            commonUtils.scrollTillEndOfPage(driver);
            createApplPage.selectGender(gender,"proposer");
            waitUtils.implicitWait(driver, 20000);
        }
        //Assert.assertTrue(createApplPage.eleVerifiedTick.isDisplayed(),"Verified tick is not shown");
        //commonUtils.scrollTillEndOfPage(driver);
        //Assert.assertEquals(createApplPage.getFirstName(),firstname,"Firstname Prefilled doesn't match with the custoemer firstname");
        //Assert.assertEquals(createApplPage.getLastName(),lastname,"Lastname Prefilled doesn't match with the custoemer lastname");
        commonUtils.scrollTillEndOfPage(driver);
        createApplPage.fillDOB(day, month, year,"proposer");
        //Assert.assertTrue(createApplPage.verifyGenderIsSelected(gender),"Incorrect gender is populated");
        commonUtils.scrollTopOfPage(driver);
        createApplPage.chooseInsuredTab();
        waitUtils.fluentWaitUntilElementVisible(driver,createApplPage.eleInsuredFirstnameInputField,80);
        Thread.sleep(1000);
    }

    /*
        1. verify pan and
        Validate As a Sales Person, I would like the details to be prefilled based on the PAN
Validate Details of the form will come in a 'Editable' state
Validate  that the DOB is also entered when user saving the information
Validate user choose to edit the name
Validate New Name as per NSDL records
Validate if Name is as per Nsdl records should stored in DB and backend
Validate Mandatory field
Validate gender from NSDL needs to be prefilled based on salutation
Validate user can change prefilled gender
Validate If PAN API service is down or not available
Validate In case PAN is of a company, then only details displayed
Validate in case the PAN is from Non-Individual
Validate  If the user chooses to edit the name,message to be shown
Validate Click on Back
Validate if NSDL is down
    * */


}


