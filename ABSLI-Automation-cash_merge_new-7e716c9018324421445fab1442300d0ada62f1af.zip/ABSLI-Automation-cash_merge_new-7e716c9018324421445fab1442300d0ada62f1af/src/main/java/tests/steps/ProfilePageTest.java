package tests.steps;
import com.absli.helpers.dataProviders.DataProviders;
import com.absli.listeners.TestLevelDriverCreator;
import com.absli.listeners.TestListener;
import com.absli.helpers.models.LoginModel;
import com.absli.helpers.jsonReaders.readLoginJson;
import com.absli.pageObjects.DashboardPage;
import com.absli.pageObjects.ProfilePage;
import com.absli.pageObjects.SignInPage;
import com.absli.utils.CommonUtils;
import jdk.jfr.Description;
import org.testng.Assert;
import org.testng.annotations.*;
import tests.BaseTest;
import tests.TestFactory;

import java.io.IOException;

public class ProfilePageTest extends BaseTest {

    SignInPage signIn;
    DashboardPage dashPage;
    ProfilePage profilePage;
    LoginModel loginModel;
    readLoginJson jsonObj;
    CommonUtils commonUtils;

    @BeforeClass
    public void preSetup() throws IOException, InterruptedException {
        driver = new TestLevelDriverCreator().getDriver();
         signIn = new SignInPage(driver);
         dashPage = new DashboardPage(driver);
         profilePage = new ProfilePage(driver);
         commonUtils = new CommonUtils();
         jsonObj = new readLoginJson();
    }

    @BeforeMethod
    public void relaunch()  {
        new BaseTest().relaunch();
    }


    @Test(dataProvider = "dataProfileInProvider",dataProviderClass = DataProviders.class,description = "verify profile screen UI elements and prefilled data")
    @Description("verify profile screen UI elements and prefilled data")
    public void ProfileScreenVerifyUIPageTest(String username,String password) throws InterruptedException, IOException {
        new TestFactory().chooseSignInNavigateToDashboard(driver,username,password);
        dashPage.clickOnHamburgerMenu();
        dashPage.clickOnProfileMenu();
        Assert.assertTrue(signIn.elementIsDisplayed(dashPage.eleProfileTitle));
        Assert.assertNotNull(profilePage.eleProfileBranchCodeText.getText());
        Assert.assertNotNull(profilePage.eleProfileBranchNameText.getText());
        Assert.assertNotNull(profilePage.eleProfileReportingManagerText.getText());
        commonUtils.scrollTillEndOfPage(driver);
        Assert.assertNotNull(profilePage.eleProfileMobileText.getText());
        Assert.assertNotNull(profilePage.eleProfileEmailText.getText());

    }
}
