package tests.steps;

import com.absli.helpers.dataProviders.DataProviders;
import com.absli.helpers.jsonReaders.ReadJson;
import com.absli.helpers.models.ProposerModel;
import com.absli.listeners.TestLevelDriverCreator;
import com.absli.listeners.TestListener;
import com.absli.pageObjects.CreateApplPage;
import com.absli.pageObjects.DashboardPage;
import com.absli.pageObjects.SignInPage;
import com.absli.utils.CommonUtils;
import com.absli.utils.WaitUtils;
import io.qameta.allure.Description;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.*;
import tests.BaseTest;
import tests.TestFactory;
import java.io.IOException;

@Listeners({TestLevelDriverCreator.class})
public class PrefillProposer extends BaseTest {

    CreateApplPage createApplPage;
    CommonUtils commonUtils;
    WaitUtils waitUtils;
    WebDriver driver = null;

    @BeforeClass
    public void preSetup() throws IOException, InterruptedException {
        driver = new TestLevelDriverCreator().getDriver();
        commonUtils = new CommonUtils();
        waitUtils = new WaitUtils();
        createApplPage = new CreateApplPage(driver);
    }

    @BeforeMethod
    public void before()  {
        new BaseTest().relaunch();
    }


    //@Test(dataProvider = "majorSamePrefillDataProvider",dataProviderClass = DataProviders.class,description = "verify prefill details based on pan",priority = 3)
    @Description("verify prefill details based on pan")
    public void prefill_Proposer_DetailsBasedOnPan(String username,String   password,String   policy,String   leadid,String   proposersame,
                                                   String relationwithinsured, String isrelationanswer, String  isnri, String  pmobile,  String ppan,  String imobile,
                                                   String ipan,String firstname,String 	lastname,
                                                   String middlename,	String day,	String month,	String year, String gender) throws IOException, InterruptedException {

        new TestFactory().chooseSignInNavigateToPrefillScreen( driver, username,  password,  policy,  leadid,  proposersame,
                relationwithinsured, isrelationanswer,  isnri,  pmobile,  ppan,  imobile, ipan);
        Assert.assertTrue(createApplPage.isVerified(),"Verified tick is not shown");
        commonUtils.scrollTillEndOfPage(driver);
        waitUtils.waitForElementToBeVisible(driver,createApplPage.eleFirstnameInputField);
        Assert.assertEquals(createApplPage.getFirstName(),firstname,"Firstname Prefilled doesn't match with the custoemer firstname");
        Assert.assertEquals(createApplPage.getLastName(),lastname,"Lastname Prefilled doesn't match with the custoemer lastname");
        commonUtils.scrollTillEndOfPage(driver);
        Assert.assertTrue(createApplPage.verifyGenderIsSelected(gender),"Incorrect gender is populated");

    }

    //@Test(dataProvider = "majorSamePrefillDataProvider",dataProviderClass = DataProviders.class,description = "verify edit verified firstname",priority = 4)
    @Description("verify edit verified firstname")
    public void edit_Proposer_Firstname(String username,String   password,String   policy,String   leadid,String   proposersame,
                                        String relationwithinsured, String isrelationanswer, String  isnri, String  pmobile,  String ppan,  String imobile,
                                        String ipan,String firstname,String 	lastname,
                                        String middlename,	String day,	String month,	String year, String gender) throws IOException, InterruptedException {

        new TestFactory().chooseSignInNavigateToPrefillScreen( driver, username,  password,  policy,  leadid,  proposersame,
                relationwithinsured, isrelationanswer,  isnri,  pmobile,  ppan,  imobile,
                ipan);
        if(new BaseTest().isIOS()) {
            commonUtils.scrollIntoView(createApplPage.eleFirstnameInputField,driver);
        } else {
            commonUtils.scrollTillEndOfPage(driver);

        }
        waitUtils.waitForElementToBeVisible(driver,createApplPage.eleFirstnameInputField);
        createApplPage.fillFirstName("test","proposer");
        if (!createApplPage.isVerified()) {
            createApplPage.fillLastName(lastname,"proposer");
            createApplPage.fillMiddleName(middlename,"proposer");
            commonUtils.scrollTillEndOfPage(driver);
            createApplPage.selectGender(gender,"proposer");
        }
        createApplPage.fillDOB(day,month,year,"proposer");
        createApplPage.clickProceedGoToPlanSelection();
        Assert.assertTrue(createApplPage.verifyEditNameAlertDisplayed());
        createApplPage.dismissPrefillScreenAlerts();
    }

    @Test(dataProvider = "majorSamePrefillDataProvider",dataProviderClass = DataProviders.class,description = "verify mandatory fields validation",priority = 5)
    @Description("verify mandatory fields validation")
    public void verify_Proposer_MandatoryFieldsValidation(String username,String   password,String   policy,String   leadid,String   proposersame,
                                                          String relationwithinsured, String isrelationanswer, String  isnri, String  pmobile,  String ppan,  String imobile,
                                                          String ipan,String firstname,String 	lastname,
                                                          String middlename,	String day,	String month,	String year, String gender) throws IOException, InterruptedException {
        new TestFactory().chooseSignInNavigateToPrefillScreen( driver, username,  password,  policy,  leadid,  proposersame,
                relationwithinsured, isrelationanswer,  isnri,  pmobile,  ppan,  imobile,
                ipan);
        createApplPage.clearAllPrefilDetailsFieldValues("proposer");
        createApplPage.clickProceedGoToPlanSelection();
        Assert.assertTrue(createApplPage.verifyEnterFirstNameErrorIsShown(),"Error for empty firstname is not shown in prefill screen");
        Assert.assertTrue(createApplPage.verifyEnterLastNameErrorIsShown(),"Error for empty lastname is not shown in prefill screen");
        commonUtils.scrollTillEndOfPage(driver);
        Assert.assertTrue(createApplPage.verifyEnterDOBYearErrorShown(),"Error for empty year is not shown in prefill screen");
        Assert.assertTrue(createApplPage.verifyEnterDOBMonthErrorShown(),"Error for empty month is not shown in prefill screen");
        Assert.assertTrue(createApplPage.verifyEnterDOBDayErrorShown(),"Error for empty day is not shown in prefill screen");
    }


    //@Test(dataProvider = "majorSamePrefillDataProvider",dataProviderClass = DataProviders.class,description = "verify fill details manually when NSDL api is down",priority = 6)
    @Description("verify fill details manually when NSDL api is down")
    public void edit_Proposer_DetailsManually(String username,String   password,String   policy,String   leadid,String   proposersame,
                                              String relationwithinsured, String isrelationanswer, String  isnri, String  pmobile,  String ppan,  String imobile,
                                              String ipan,String firstname,String 	lastname,
                                              String middlename,	String day,	String month,	String year, String gender) throws IOException, InterruptedException {
        new TestFactory().chooseSignInNavigateToPrefillScreen( driver, username,  password,  policy,  leadid,  proposersame,
                relationwithinsured, isrelationanswer,  isnri,  pmobile,  ppan,  imobile,
                ipan);
        createApplPage.fillFirstName(firstname,"proposer");
        createApplPage.fillLastName(lastname,"proposer");
        createApplPage.fillMiddleName(middlename,"proposer");
        commonUtils.scrollTillEndOfPage(driver);
        createApplPage.fillDOB(day, month, year,"proposer");
        createApplPage.selectGender(gender,"proposer");
        Assert.assertFalse(createApplPage.verifyEnterDOBDayErrorShown(),"Error is shown for prefilling details manually");
        Assert.assertFalse(createApplPage.verifyEnterLastNameErrorIsShown(),"Error is shown for prefilling details manually");
        Assert.assertFalse(createApplPage.verifyEnterFirstNameErrorIsShown(),"Error is shown for prefilling details manually");

    }
    
    /*
        1. verify pan and
        Validate As a Sales Person, I would like the details to be prefilled based on the PAN
Validate Details of the form will come in a 'Editable' state
Validate  that the DOB is also entered when user saving the information
Validate user choose to edit the name
Validate New Name as per NSDL records
Validate if Name is as per Nsdl records should stored in DB and backend
Validate Mandatory field
Validate gender from NSDL needs to be prefilled based on salutation
Validate user can change prefilled gender
Validate If PAN API service is down or not available
Validate In case PAN is of a company, then only details displayed
Validate in case the PAN is from Non-Individual
Validate  If the user chooses to edit the name,message to be shown
Validate Click on Back
Validate if NSDL is down
    * */


}

