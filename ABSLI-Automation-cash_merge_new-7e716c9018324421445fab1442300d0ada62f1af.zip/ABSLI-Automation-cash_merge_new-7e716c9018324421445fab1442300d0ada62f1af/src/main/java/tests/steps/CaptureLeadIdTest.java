package tests.steps;

import com.absli.enums.ScrollDirection;
import com.absli.listeners.SuiteLevelDriverCreator;
import com.absli.listeners.TestLevelDriverCreator;
import com.absli.listeners.TestListener;
import com.absli.helpers.jsonReaders.readLoginJson;
import com.absli.pageObjects.CreateApplPage;
import com.absli.pageObjects.DashboardPage;
import com.absli.pageObjects.SignInPage;
import com.absli.utils.CommonUtils;
import com.absli.utils.ExcelUtils;
import com.absli.utils.PropertiesUtils;
import com.absli.utils.WaitUtils;
import io.qameta.allure.Description;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.*;
import tests.BaseTest;
import tests.TestFactory;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class CaptureLeadIdTest extends BaseTest {

    readLoginJson jsonObj;
    CommonUtils commonUtils;
    SignInPage signIn;
    DashboardPage dashPage;
    CreateApplPage createApplPage;
    WebDriver driver = null;
    WaitUtils waitUtils;
    PropertiesUtils prop = new PropertiesUtils();
    List<String> data = new ArrayList<>();

    @BeforeClass
    public void preSetup() throws IOException, InterruptedException {
        driver = new TestLevelDriverCreator().getDriver();
        jsonObj = new readLoginJson();
        ExcelUtils excel = new ExcelUtils();
        createApplPage = new CreateApplPage(driver);
        commonUtils = new CommonUtils();
        waitUtils = new WaitUtils();
    }

    @AfterMethod
    public void relaunch()  {
        new BaseTest().relaunch();
    }

    @BeforeMethod
    public void before() {
        new BaseTest().relaunch();
        try {
            new TestFactory().chooseSignInNavigateToLeadIdScreen(driver, getData("username"),getData("password"),getData("policy"));
        }catch (Exception e) {
            //
        }
    }


    @Test(description = "Verify proposer insured are not same",priority = 8)
    @Description("Verify proposer insured are not same")
    public void proposerInsurerAreNotSameTest() throws InterruptedException {
        createApplPage.inputLeadId("abcdefghi-jklmn");
        commonUtils.enterKey(createApplPage.eleLeadIdInput, driver);
        createApplPage.selectIsProposerInsuredSameQst("NO");

        commonUtils.scrollTillEndOfPage(driver);

        //spouse
        createApplPage.selectRelationFromList("Spouse", "YES");
        new WaitUtils().implicitWait(driver, 100);
        //commonUtils.scrollTillEndOfPage(driver);
        Assert.assertTrue(createApplPage.verifyJointPolicyTextIsShown(), "On selection of Spouse relation joint policy text label is not shown");
        Thread.sleep(1000);
        //Father
        createApplPage.selectRelationFromList("Father", "YES");
        new WaitUtils().implicitWait(driver, 100);
        Assert.assertTrue(createApplPage.verifyIsInsuredMinorLabelDisplayed(), "For relation type 'Father' minor label is not shown");
        Thread.sleep(1000);

        createApplPage.selectRelationFromList("Mother", "YES");
        new WaitUtils().implicitWait(driver, 100);
        Assert.assertTrue(createApplPage.verifyIsInsuredMinorLabelDisplayed(), "For relation type 'Mother' minor label is not shown");
        Thread.sleep(1000);

        createApplPage.selectRelationFromList("Grandfather", "YES");
        new WaitUtils().implicitWait(driver, 100);
        Assert.assertTrue(createApplPage.verifyIsInsuredMinorLabelDisplayed(), "For relation type 'Grandfather' minor label is not shown");
        Thread.sleep(1000);

        createApplPage.selectRelationFromList("Grandmother", "YES");
        new WaitUtils().implicitWait(driver, 100);
        Assert.assertTrue(createApplPage.verifyIsInsuredMinorLabelDisplayed(), "For relation type 'Grandmother' minor label is not shown");
        Thread.sleep(1000);

        createApplPage.selectRelationFromList("Legal guardian", "YES");
        new WaitUtils().implicitWait(driver, 100);
        Assert.assertTrue(createApplPage.verifyIsInsuredMinorLabelDisplayed(), "For relation type 'Legal guardian' minor label is not shown");
    }


    public String getData(String cell) throws IOException {
        return new ExcelUtils().getCellData(prop.getProperties("testExcelSheet"),
                "enterMobileNo",prop.getProperties("captureMobilePanSheetName"),cell);
    }



}

