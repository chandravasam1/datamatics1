package tests.steps;

import com.absli.helpers.dataProviders.DataProviders;
import com.absli.helpers.models.DeviceContext;
import com.absli.listeners.SuiteLevelDriverCreator;
import com.absli.listeners.TestLevelDriverCreator;
import com.absli.listeners.TestListener;
import com.absli.helpers.models.LoginModel;
import com.absli.pageObjects.SignInPage;
import com.absli.runner.TestRunner;
import com.absli.utils.CommonUtils;
import com.absli.utils.ExcelUtils;
import com.absli.utils.PropertiesUtils;
import com.absli.utils.WaitUtils;
import com.ssts.util.reporting.ExecutionResult;
import com.ssts.util.reporting.SingleRunReport;
import jdk.jfr.Description;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.*;
import java.io.IOException;


import com.absli.helpers.jsonReaders.readLoginJson;
import tests.BaseTest;

@Listeners(TestLevelDriverCreator.class)
public class SignInPageTest extends BaseTest {

    SignInPage signIn;
    readLoginJson jsonObj;
    WaitUtils waitUtils;
    PropertiesUtils prop;
    WebDriver driver;
    CommonUtils comUtils;

    @BeforeClass
    public void preSetup() throws IOException {
        driver = new TestLevelDriverCreator().getDriver();
        signIn = new SignInPage(driver);
         jsonObj = new readLoginJson();
         waitUtils = new WaitUtils();
         prop = new PropertiesUtils();
        comUtils = new CommonUtils();
         relaunch();
    }

    //@Test(enabled = true,description = "Sign in screen UI verification",priority = 1)
    @Description("Sign in screen UI verification")
    public void signInUIVerification() throws InterruptedException {

        Assert.assertTrue(signIn.verifyPasswordFieldIsDisplayed());
        Assert.assertTrue(signIn.elementIsDisplayed(signIn.eleSignInUsername));
        Assert.assertTrue(signIn.elementIsDisplayed(signIn.eleSignInButton));
    }

    //@Test(enabled = false,dataProvider = "dataSignInProvider",dataProviderClass = DataProviders.class, description = "Sign in functionality when userID/password are invalid",priority = 2)
    @Description("Sign in functionality when userID/password is empty")
    public void signInWithInvalidCredentials(String username,String password) throws InterruptedException {
        signIn.signIn("","");
        Assert.assertTrue(signIn.elementIsDisplayed(signIn.eleSignInPasswordErrorMessage));
        Assert.assertTrue(signIn.elementIsDisplayed(signIn.eleSignInUserIdErrorMessage));
        signIn.signIn(username,password);
        Assert.assertFalse(signIn.verifyDashboardIsDisplayed(),"User logged in inspite of incorrect credentials");


    }
    //@Test(enabled = true,dataProvider = "dataSignInProvider",dataProviderClass = DataProviders.class,description = "testing Username should accept max 10 characters",priority = 3)
    @Description("testing Username should accept max 10 characters")
    public void signInWithMaxUsername(String username,String password) throws InterruptedException, IOException {
        signIn.enterText(signIn.eleSignInUsername,username);
        Assert.assertFalse(signIn.verifyUsernameErrorIsDisplayed(),"Username accepts more than 10 chars");
    }

    //@Test(description = "testing password should accept max 50 characters",dataProvider = "dataSignInProvider",dataProviderClass = DataProviders.class,priority = 4)
    @Description("testing password should accept max 50 characters")
    public void signInWithMaxPassword(String username,String password) throws InterruptedException, IOException {
        signIn.inputPassword(password);
        waitUtils.waitUntilVisible(driver,signIn.eleSignInButton,30);
        Assert.assertFalse(signIn.verifyPasswordErrorIsDisplayed(),"Password accepts more than 50 chars");
    }

    ////@Test(enabled = false,description = "testing the password masking",priority = 9)
    @Description("testing the password masking")
    public void signInPasswordMask() throws InterruptedException, IOException {
        LoginModel model = jsonObj.readJson().getDataByTestCase("validlogin");
        signIn.inputPassword(model.getPassword());
        signIn.clickElement(signIn.eleSignPasswordEyeIcon);
        Thread.sleep(2000);
        String str = signIn.getPlainTextPassword();
        System.out.println("Password- text-------"+str);
        System.out.println("Password- model -------"+model.getPassword());
        signIn.clickElement(signIn.eleSignPasswordEyeIcon);
        Assert.assertEquals(str,model.getPassword(),"The password shown after unmasking is not correct");
    }
    //To do : need to add logout code
   @Test(enabled = true,dataProvider = "dataSignInProvider",dataProviderClass = DataProviders.class,description = "testing the sign in page visually",priority = 29)
    @Description("Login page test")
    public void signInSuccess(String username,String password) throws InterruptedException, IOException {
        signIn.signIn("username",password);
        waitUtils.waitUntilVisible(driver,signIn.eleDashboardTitle,30);
        Assert.assertTrue(comUtils.isDisplayed(driver,signIn.eleDashboardTitle),"Dashboard screen is not shown");
    }

    //To do : need to add logout code
    ////@Test(enabled = false,dataProvider = "dataSignInProvider",description = "testing the sign in success with remember me checkbox selected",priority = 30)
    @Description("testing the sign in success with remember me checkbox selected")
    public void signInWithRememberMe(String username,String password) throws InterruptedException, IOException {
        signIn.clickOnRememberMe();
        signIn.signIn(username,password);
        Thread.sleep(1000);
        Assert.assertTrue(signIn.elementIsDisplayed(signIn.eleDashboardTitle),"Dashboard screen is not shown");
        //relaunch();
    }



    /*
    *signInWithInvalidCredentials
signInWithMaxUsername
signInWithMaxPassword
signInSuccess
signInWithRememberMe
signInUIVerification
    *     * */

}
