package tests;

import com.absli.pageObjects.*;
import com.absli.utils.CommonUtils;
import com.absli.utils.WaitUtils;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.ios.IOSElement;
import org.openqa.selenium.*;
import org.testng.Assert;

import java.io.IOException;

public class TestFactory{
    CreateApplPage createApplPage;
    WaitUtils waitUtils = new WaitUtils();
    CommonUtils commonUtils = new CommonUtils();
    CaptureEmailIdPage captureEmailIdPage;
    ExistingPolicyPage existingPolicyPage;
    RefusedPolicyPage refusedPolicyPage;
    Covid_19_DetailsPage covid_19_Details_page;
    PersonalInfoPage perInfo;
    HealthPoliciesPage healthPage;
    ReviewAcceptPage rna;
    InstaVerifyPage ivPage;
    QualificationPage qualificationPage;
    OccupationPage occupationPage;
    LifestylePage lifestylePage;
    AppSummaryPage appSummaryPage;
    PaymentSummaryPage paymentSummaryPage;
    CashPage cashPage;
    ChequePage chequePage;
    WinBackPage winBackPage;
    HealthDetailsPage healthDetailsPage;

    public static Boolean INSTA_VERIFY_FLAG = false;

    public void chooseSignInNavigateToDashboard(WebDriver driver,String username, String password) throws InterruptedException, IOException {
        createApplPage = new CreateApplPage(driver);
        /*healthPage = new HealthPoliciesPage(driver);
        captureEmailIdPage=new CaptureEmailIdPage(driver);
        existingPolicyPage=new ExistingPolicyPage(driver);
        refusedPolicyPage=new RefusedPolicyPage(driver);
        covid_19_Details_page =new Covid_19_DetailsPage(driver);*/
        createApplPage.chooseSignInGoToDashboard(username,password);
        //rna = new ReviewAcceptPage(driver);


    }

    public CreateApplPage chooseSignInNavigateToLeadIdScreen(WebDriver driver, String username, String password, String policy) throws InterruptedException, IOException {
        createApplPage = new CreateApplPage(driver);
        createApplPage.chooseSignAndGoToLeadIdScreen(username, password, policy);
        return createApplPage;
    }

    public void chooseSignInNavigateToMobilePanScreen(WebDriver driver,String username, String password, String policy, String leadid, String proposersame,
                                                      String relationwithinsured,String isrelationanswer, String isnri) throws InterruptedException, IOException {
        createApplPage = new CreateApplPage(driver);
        createApplPage.chooseSignAndGoToLeadIdScreen(username, password, policy);
        createApplPage.fillLeadIdAndProceedTo(leadid, proposersame, relationwithinsured,isrelationanswer,isnri);
    }

    public void chooseSignInNavigateToInsuredMobilePanScreen(WebDriver driver,String username, String password, String policy, String leadid, String proposersame,
                                                      String relationwithinsured,String isrelationanswer, String isnri,String pmobile,String  	ppan, String 	imobile, String 	ipan) throws InterruptedException, IOException {
        createApplPage = new CreateApplPage(driver);
        createApplPage.chooseSignAndGoToLeadIdScreen(username, password, policy);
        createApplPage.fillLeadIdAndProceedTo(leadid, proposersame, relationwithinsured,isrelationanswer,isnri);
        createApplPage.inputMobileNo("proposer", pmobile);
        createApplPage.inputPan("proposer", ppan);

        if(proposersame.equalsIgnoreCase("no")) {
            commonUtils.scrollTopOfPage(driver);
            createApplPage.chooseInsuredTab();
            //createApplPage.verifyMobileNoFieldIsVisible("insured");
        }
    }

    public void chooseSignInNavigateToPrefillScreen(WebDriver driver,String username, String password, String policy, String leadid, String proposersame,
                                                    String relationwithinsured,String isrelationanswer, String isnri, String pmobile, String ppan, String imobile,
                                                    String ipan) throws InterruptedException, IOException {
        createApplPage = new CreateApplPage(driver);
        createApplPage.chooseSignAndGoToLeadIdScreen(username, password, policy);
        createApplPage.fillLeadIdAndProceedTo(leadid, proposersame, relationwithinsured,isrelationanswer,isnri);
        createApplPage.captureMobilePanAndProceed1(pmobile, ppan,proposersame,imobile,ipan);
        //createApplPage.captureMobilePanAndProceed(pmobile, ppan);


    }


    public void gotoPlanSelection(WebDriver driver,String username, String password, String policy, String leadid, String proposersame,
                                  String relationwithinsured,String isrelationanswer, String isnri, String pmobile, String ppan, String imobile,
                                     String ipan, String firstname, String lastname,
                                     String middlename, String day, String month, String year, String gender,
                                     String planjourney, String proposerstate, String advisorstatesame, String plan) throws InterruptedException, IOException {

        createApplPage = new CreateApplPage(driver);
        createApplPage.chooseSignAndGoToLeadIdScreen(username, password, policy);
        createApplPage.fillLeadIdAndProceedTo(leadid, proposersame, relationwithinsured,isrelationanswer,isnri);
        createApplPage.captureMobilePanAndProceed(pmobile, ppan);
        createApplPage.prefillDetails(firstname, lastname, middlename, day, month, year, gender);
        System.out.println(planjourney);
        waitUtils.implicitWait(driver,20000);
        createApplPage.choosePlan(planjourney);
        //createApplPage.choosePlanSelectProceedButton();
        waitUtils.waitForElementToBeVisible(driver,createApplPage.elePlanSelectionNavText);
    }

    public void gotoViewQuote(WebDriver driver,String username, String password, String policy, String leadid, String proposersame,
                              String relationwithinsured,String isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                               String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan) throws IOException, InterruptedException {
        createApplPage = new CreateApplPage(driver);

        createApplPage.chooseSignAndGoToLeadIdScreen(username, password, policy);
        createApplPage.fillLeadIdAndProceedTo(leadid, proposersame, relationwithinsured,isrelationanswer,isnri);
        createApplPage.captureMobilePanAndProceed(pmobile, ppan);
        createApplPage.prefillDetails(firstname, lastname, middlename, day, month, year, gender);
        System.out.println(planjourney);
        createApplPage.choosePlan(planjourney);
        waitUtils.waitForElementToBeVisible(driver,createApplPage.elePlanSelectionNavText);
        createApplPage.fillPlanDetails(planjourney,proposerstate,advisorstatesame,plan);
    }


    public void gotoViewQuoteAndGenerate(WebDriver driver,String username, String password, String policy, String leadid, String proposersame,
                              String relationwithinsured,String isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                              String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame,
                                         String plan,String sumassured, String smokertype, String planoptions, String increasinglevel,
                                         String ecs, String term, String ppt, String premiumterm, String premiumamount) throws IOException, InterruptedException {
        createApplPage = new CreateApplPage(driver);

        createApplPage.chooseSignAndGoToLeadIdScreen(username, password, policy);
        createApplPage.fillLeadIdAndProceed(leadid, proposersame, isnri);
        createApplPage.captureMobilePanAndProceed(pmobile, ppan);
        createApplPage.prefillDetails(firstname, lastname, middlename, day, month, year, gender);
        createApplPage.choosePlanAndProceedToViewQuote(planjourney, proposerstate, advisorstatesame, plan);
        createApplPage.fillQuote(sumassured,smokertype,planoptions,increasinglevel,ecs,term,ppt,premiumterm,premiumamount);

        /*createApplPage.createQuote(sumassured, smokertype, planoptions, increasinglevel, ecs, term, ppt, premiumterm, premiumamount);

        commonUtils.selectButtonByName("SAVE", driver);
        waitUtils.waitForElementToBeVisible(driver, createApplPage.elePlanSummaryNavText, 30, "Didnt navigate to plan summary screen");
        commonUtils.selectButtonByName("CONTINUE", driver);
        waitUtils.waitForElementToBeVisible(driver, createApplPage.eleBankNavText, 30, "Didnt navigate to bank details screen");
*/

    }

    public void generateQuote(WebDriver driver,String username, String password, String policy, String leadid, String proposersame,
                                         String relationwithinsured,String isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                         String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame,
                                         String plan,String sumassured, String smokertype, String planoptions, String increasinglevel,
                                         String ecs, String term, String ppt, String premiumterm, String premiumamount) throws IOException, InterruptedException {
        createApplPage = new CreateApplPage(driver);

        createApplPage.chooseSignAndGoToLeadIdScreen(username, password, policy);
        createApplPage.fillLeadIdAndProceed(leadid, proposersame, isnri);
        createApplPage.captureMobilePanAndProceed(pmobile, ppan);
        createApplPage.prefillDetails(firstname, lastname, middlename, day, month, year, gender);
        createApplPage.choosePlanAndProceedToViewQuote(planjourney, proposerstate, advisorstatesame, plan);
        createApplPage.fillQuote(sumassured,smokertype,planoptions,increasinglevel,ecs,term,ppt,premiumterm,premiumamount);

    }
    public void gotoBank(WebDriver driver,String username, String password, String policy, String leadid, String proposersame,
                         String relationwithinsured,String isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                            String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                            String ecs, String term, String ppt, String premiumterm, String premiumamount,
                            String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                            String clickcontinue) throws InterruptedException, IOException {

        createApplPage = new CreateApplPage(driver);
        createApplPage.chooseSignAndGoToLeadIdScreen(username, password, policy);
        createApplPage.fillLeadIdAndProceedTo(leadid, proposersame, relationwithinsured,isrelationanswer,isnri);
        if(new BaseTest().isWeb()) {
            waitUtils.waitUntilPageLoad(driver);
        }
        createApplPage.captureMobilePanAndProceed(pmobile, ppan);
        if(new BaseTest().isWeb()) {
            waitUtils.waitUntilPageLoad(driver);
        }
        createApplPage.prefillDetails(firstname, lastname, middlename, day, month, year, gender);
        System.out.println(planjourney);
        waitUtils.wait2Seconds();
        createApplPage.choosePlan(planjourney);
        waitUtils.waitForElementToBeVisible(driver,createApplPage.elePlanSelectionNavText);

        createApplPage.fillPlanDetails(planjourney,proposerstate,advisorstatesame,plan);
        if(new BaseTest().isWeb()) {
            waitUtils.waitUntilPageLoad(driver);
        }

        createApplPage.createQuote(sumassured,smokertype,planoptions,increasinglevel,ecs,term,ppt,premiumterm,premiumamount);
        waitUtils.wait1Seconds();
        waitUtils.waitForElementToBeClickable(driver,createApplPage.eleQuoteSummaryContinueBtn,50);
        commonUtils.clickElement(createApplPage.eleQuoteSummaryContinueBtn);

        //commonUtils.elementFoundAndClicked(createApplPage.eleQuoteSummaryContinueBtn);

        ivPage = new InstaVerifyPage(driver);
        commonUtils.scrollTopOfPage(driver);
        waitUtils.waitUntilVisible(driver,ivPage.instaVerifyScreenTitle,50);

        if(INSTA_VERIFY_FLAG == false) {
            waitUtils.waitForElementToBeVisible(driver, ivPage.instaVerifyScreenTitle);
            commonUtils.chooseActionButton(ivPage.photoVerificationTab);
            waitUtils.waitForElementToBeVisible(driver, ivPage.photoVerificationText);
            if(new BaseTest().isWeb()) {
                //commonUtils.scrollToElementAndClick(driver,ivPage.eleInstVerifyDoItLaterBtn);
                commonUtils.scrollToElement(driver,ivPage.eleInstVerifyDoItLaterBtn);
                waitUtils.waitUntilVisible(driver,ivPage.eleInstVerifyDoItLaterBtn,30);
                ivPage.eleInstVerifyDoItLaterBtn.click();
            } else {
                commonUtils.chooseActionButton(ivPage.eleInstVerifyDoItLaterBtn);

            }
        } else {
            try {
                ivPage.instaVerifyPage();
            } catch (Exception e){
                //
            }
        }
        waitUtils.waitForElementToBeVisible(driver, createApplPage.eleBankNavText);
        Assert.assertTrue(createApplPage.eleBankNavText.isDisplayed(),"Bank page is not shown");
    }
    public void gotoRenewal(WebDriver driver,String username, String password, String policy, String leadid, String proposersame,
                            String relationwithinsured,String isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                               String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                               String ecs, String term, String ppt, String premiumterm, String premiumamount,
                               String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                               String clickcontinue,String ifsccode, String bankaccno, String accholdername, String accounttype,
                            String pennyalert, String clickverify, String renewpremiumscreentitle) throws IOException, InterruptedException {

        createApplPage = new CreateApplPage(driver);
        createApplPage.chooseSignAndGoToLeadIdScreen(username, password, policy);
        createApplPage.fillLeadIdAndProceedTo(leadid, proposersame, relationwithinsured,isrelationanswer,isnri);
        if(new BaseTest().isWeb()) {
            waitUtils.waitUntilPageLoad(driver);
        }
        createApplPage.captureMobilePanAndProceed(pmobile, ppan);
        if(new BaseTest().isWeb()) {
            waitUtils.waitUntilPageLoad(driver);
        }
        createApplPage.prefillDetails(firstname, lastname, middlename, day, month, year, gender);
        System.out.println(planjourney);
        waitUtils.wait2Seconds();
        createApplPage.choosePlan(planjourney);
        waitUtils.waitForElementToBeVisible(driver,createApplPage.elePlanSelectionNavText);

        createApplPage.fillPlanDetails(planjourney,proposerstate,advisorstatesame,plan);
        if(new BaseTest().isWeb()) {
            waitUtils.waitUntilPageLoad(driver);
        }

        createApplPage.createQuote(sumassured,smokertype,planoptions,increasinglevel,ecs,term,ppt,premiumterm,premiumamount);
        waitUtils.waitUntilVisible(driver,createApplPage.eleQuoteSummaryContinueBtn,50);
        commonUtils.clickElement(createApplPage.eleQuoteSummaryContinueBtn);

        ivPage = new InstaVerifyPage(driver);
        commonUtils.scrollTopOfPage(driver);
        waitUtils.waitUntilVisible(driver,ivPage.instaVerifyScreenTitle,50);

        if(INSTA_VERIFY_FLAG == false) {
            waitUtils.waitForElementToBeVisible(driver, ivPage.instaVerifyScreenTitle);
            commonUtils.chooseActionButton(ivPage.photoVerificationTab);
            waitUtils.waitForElementToBeVisible(driver, ivPage.photoVerificationText);
            if(new BaseTest().isWeb()) {
                //commonUtils.scrollToElementAndClick(driver,ivPage.eleInstVerifyDoItLaterBtn);
                commonUtils.scrollToElement(driver,ivPage.eleInstVerifyDoItLaterBtn);
                waitUtils.waitUntilVisible(driver,ivPage.eleInstVerifyDoItLaterBtn,30);
                ivPage.eleInstVerifyDoItLaterBtn.click();
            } else {
                commonUtils.chooseActionButton(ivPage.eleInstVerifyDoItLaterBtn);

            }
        } else {
            try {
                ivPage.instaVerifyPage();
            } catch (Exception e){
                //
            }
        }

        waitUtils.waitForElementToBeVisible(driver, createApplPage.eleBankNavText);
        createApplPage.fillBankDetails( ifsccode, bankaccno, accounttype, clickverify, pennyalert);
        Assert.assertTrue(createApplPage.eleRenewNavText.isDisplayed(),"Renewal screen is not displayed");
    }

    public CreateApplPage gotoNominee(WebDriver driver, String username, String password, String policy, String leadid, String proposersame,
                                      String relationwithinsured, String isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                      String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                      String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                      String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                      String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                      String clickverify, String renewpremiumscreentitle, String paymentmethod, String drawdate, String fundsource,
                                      String nomineescreentitle) throws IOException, InterruptedException {


        createApplPage = new CreateApplPage(driver);
        createApplPage.chooseSignAndGoToLeadIdScreen(username, password, policy);
        createApplPage.fillLeadIdAndProceedTo(leadid, proposersame, relationwithinsured,isrelationanswer,isnri);
        if(new BaseTest().isWeb()) {
            waitUtils.waitUntilPageLoad(driver);
        }
        createApplPage.captureMobilePanAndProceed(pmobile, ppan);
        if(new BaseTest().isWeb()) {
            waitUtils.waitUntilPageLoad(driver);
        }
        createApplPage.prefillDetails(firstname, lastname, middlename, day, month, year, gender);
        System.out.println(planjourney);
        waitUtils.wait2Seconds();
        createApplPage.choosePlan(planjourney);
        waitUtils.waitForElementToBeVisible(driver,createApplPage.elePlanSelectionNavText);

        createApplPage.fillPlanDetails(planjourney,proposerstate,advisorstatesame,plan);
        if(new BaseTest().isWeb()) {
            waitUtils.waitUntilPageLoad(driver);
        }

        createApplPage.createQuote(sumassured,smokertype,planoptions,increasinglevel,ecs,term,ppt,premiumterm,premiumamount);
        waitUtils.waitUntilVisible(driver,createApplPage.eleQuoteSummaryContinueBtn,50);
        commonUtils.clickElement(createApplPage.eleQuoteSummaryContinueBtn);

        ivPage = new InstaVerifyPage(driver);
        commonUtils.scrollTopOfPage(driver);
        waitUtils.waitUntilVisible(driver,ivPage.instaVerifyScreenTitle,50);

        if(INSTA_VERIFY_FLAG == false) {
            waitUtils.waitForElementToBeVisible(driver, ivPage.instaVerifyScreenTitle);
            commonUtils.chooseActionButton(ivPage.photoVerificationTab);
            waitUtils.waitForElementToBeVisible(driver, ivPage.photoVerificationText);
            if(new BaseTest().isWeb()) {
                //commonUtils.scrollToElementAndClick(driver,ivPage.eleInstVerifyDoItLaterBtn);
                commonUtils.scrollToElement(driver,ivPage.eleInstVerifyDoItLaterBtn);
                waitUtils.waitUntilVisible(driver,ivPage.eleInstVerifyDoItLaterBtn,30);
                ivPage.eleInstVerifyDoItLaterBtn.click();
            } else {
                commonUtils.chooseActionButton(ivPage.eleInstVerifyDoItLaterBtn);
            }
        } else {
            try {
                ivPage.instaVerifyPage();
            } catch (Exception e){
                //
            }
        }
        waitUtils.waitForElementToBeVisible(driver, createApplPage.eleBankNavText);
        createApplPage.fillBankDetails( ifsccode, bankaccno, accounttype, clickverify, pennyalert);
        createApplPage.fillRenewalDetails( paymentmethod, drawdate, fundsource, premiumamount, premiumterm,  nomineescreentitle);
        return createApplPage;
    }

    public void gotoEnachRegistration(WebDriver driver, String username, String password, String policy, String leadid, String proposersame, String propinsurednotsame, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                      String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                      String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                      String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                      String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                      String clickverify, String renewpremiumscreentitle, String bankname, String mobileno, String pannumber,
                                      String emailaddress) throws Exception {

        createApplPage = new CreateApplPage(driver);

        createApplPage.chooseSignAndGoToLeadIdScreen(username, password, policy);
        createApplPage.fillLeadIdAndProceed(leadid, proposersame, isnri);
        waitUtils.wait2Seconds();
        createApplPage.captureMobilePanAndProceed(pmobile, ppan);
        createApplPage.prefillDetails(firstname, lastname, middlename, day, month, year, gender);
        System.out.println(planjourney);
        waitUtils.implicitWait(driver, 20000);
        createApplPage.choosePlan(planjourney);
        waitUtils.waitForElementToBeVisible(driver, createApplPage.elePlanSelectionNavText);
        createApplPage.fillPlanDetails(planjourney, proposerstate, advisorstatesame, plan);
        createApplPage.createQuote(sumassured, smokertype, planoptions, increasinglevel, ecs, term, ppt, premiumterm, premiumamount);
        commonUtils.selectButtonByName(clickcontinue, driver);

        ivPage = new InstaVerifyPage(driver);
        commonUtils.scrollTopOfPage(driver);
        waitUtils.waitUntilVisible(driver,ivPage.instaVerifyScreenTitle,50);

        if(INSTA_VERIFY_FLAG == false) {
            waitUtils.waitForElementToBeVisible(driver, ivPage.instaVerifyScreenTitle);
            commonUtils.chooseActionButton(ivPage.photoVerificationTab);
            waitUtils.waitForElementToBeVisible(driver, ivPage.photoVerificationText);
            if(new BaseTest().isWeb()) {
                //commonUtils.scrollToElementAndClick(driver,ivPage.eleInstVerifyDoItLaterBtn);
                commonUtils.scrollToElement(driver,ivPage.eleInstVerifyDoItLaterBtn);
                waitUtils.waitUntilVisible(driver,ivPage.eleInstVerifyDoItLaterBtn,30);
                ivPage.eleInstVerifyDoItLaterBtn.click();
            } else {
                commonUtils.chooseActionButton(ivPage.eleInstVerifyDoItLaterBtn);

            }
        } else {
            try {
                ivPage.instaVerifyPage();
            } catch (Exception e){
                //
            }
        }
        waitUtils.waitForElementToBeVisible(driver, createApplPage.eleBankNavText, 50, "Didnt navigate to bank details screen");
        createApplPage.fillBankDetails(ifsccode, bankaccno, accounttype, clickverify, pennyalert);
    }

    public void gotoCapturedEmailID(WebDriver driver, String username, String password, String policy, String leadid, String proposersame, String propinsurednotsame, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                    String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                    String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                    String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                    String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                    String clickverify, String renewpremiumscreentitle, String paymentmethod, String drawdate, String fundsource, String nomineescreentitle, String nomineefirstname, String nomineelastname, String nomineeday,
                                    String nomineemonth, String nomineeyear, String nomineegender, String relationshipwithproposer, String nomineeshare,
                                    String ismwppolicy,
                                    String addressscreentitle, String typeofaddress, String addresspincode, String address1, String address2, String address3, String personalDetailsscreentitle, String cityName, String preferredLanguage, String alernateNumber, String resTelephoneNumber
    ) throws Exception {

        createApplPage = new CreateApplPage(driver);
        createApplPage.chooseSignAndGoToLeadIdScreen(username, password, policy);
        createApplPage.fillLeadIdAndProceed(leadid, proposersame, isnri);
        waitUtils.wait5Seconds();
        createApplPage.captureMobilePanAndProceed(pmobile, ppan);
        waitUtils.wait5Seconds();
        createApplPage.prefillDetails(firstname, lastname, middlename, day, month, year, gender);
        System.out.println(planjourney);
        waitUtils.implicitWait(driver, 20000);
        createApplPage.choosePlan(planjourney);

        waitUtils.waitForElementToBeVisible(driver, createApplPage.elePlanSelectionNavText);
        createApplPage.fillPlanDetails(planjourney, proposerstate, advisorstatesame, plan);
        createApplPage.createQuote(sumassured, smokertype, planoptions, increasinglevel, ecs, term, ppt, premiumterm, premiumamount);
        commonUtils.selectButtonByName(clickcontinue, driver);
        waitUtils.waitForElementToBeVisible(driver, createApplPage.eleBankNavText, 50, "Didnt navigate to bank details screen");
        createApplPage.fillBankDetails(ifsccode, bankaccno, accounttype, clickverify, pennyalert);
        createApplPage.fillRenewalDetails(paymentmethod, drawdate, fundsource, premiumamount, premiumterm, nomineescreentitle);
        createApplPage.add_Nominee(nomineescreentitle, nomineefirstname, nomineelastname, nomineeday, nomineemonth, nomineeyear, nomineegender, relationshipwithproposer, nomineeshare, ismwppolicy, addressscreentitle);
        createApplPage.add_Address(addressscreentitle, typeofaddress, addresspincode, address1, address2, address3, personalDetailsscreentitle);


    }

    public void gotoExistingPolicies(WebDriver driver, String username, String password, String policy, String leadid, String proposersame, String propinsurednotsame, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                     String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                     String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                     String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                     String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                     String clickverify, String renewpremiumscreentitle, String paymentmethod, String drawdate, String fundsource,
                                     String nomineescreentitle, String nomineefirstname, String nomineelastname, String nomineeday,
                                     String nomineemonth, String nomineeyear, String nomineegender, String relationshipwithproposer, String nomineeshare,
                                     String ismwppolicy,
                                     String addressscreentitle, String typeofaddress, String addresspincode, String address1, String address2, String address3, String personalDetailsscreentitle, String cityName, String preferredLanguage, String alernateNumber, String resTelephoneNumber,
                                     String emailaddressValidations, String maritalStatus, String fathersNameOrSpouseName,
                                     String mothersName,String  question1,String answer1,String valueToBeEnter,String question2,String answer2,String valueToBeEnter2,String question3,String answer3,String valueToBeEnter3,String question4,String answer4,String valueToBeEnter4,String qualification, String occupation, String employeerName, String nameOfBusinessOrduties,
                                     String typeOfOrganization, String designation, String annualIncome, String existingPolicyscreentitle, String insurerName, String sumAssured, String policyNumber, String yearOfApplication, String basePlan, String annualPrimium, String medicalPolicy,
                                     String policyStatus, String purposeOption1, String purposeOption2, String purposeOption3) throws Exception {

        createApplPage = new CreateApplPage(driver);
        captureEmailIdPage = new CaptureEmailIdPage(driver);
        existingPolicyPage = new ExistingPolicyPage(driver);
        createApplPage.chooseSignAndGoToLeadIdScreen(username, password, policy);
        createApplPage.fillLeadIdAndProceed(leadid, proposersame, isnri);
        waitUtils.wait2Seconds();
        createApplPage.captureMobilePanAndProceed(pmobile, ppan);
        createApplPage.prefillDetails(firstname, lastname, middlename, day, month, year, gender);
        System.out.println(planjourney);
        waitUtils.implicitWait(driver, 20000);
        createApplPage.choosePlan(planjourney);
        //createApplPage.choosePlanSelectProceedButton();
        waitUtils.waitForElementToBeVisible(driver, createApplPage.elePlanSelectionNavText);
        createApplPage.fillPlanDetails(planjourney, proposerstate, advisorstatesame, plan);
        createApplPage.createQuote(sumassured, smokertype, planoptions, increasinglevel, ecs, term, ppt, premiumterm, premiumamount);
        commonUtils.selectButtonByName(clickcontinue, driver);
        waitUtils.waitForElementToBeVisible(driver, createApplPage.eleBankNavText, 50, "Didnt navigate to bank details screen");
        createApplPage.fillBankDetails(ifsccode, bankaccno, accounttype, clickverify, pennyalert);
        createApplPage.fillRenewalDetails(paymentmethod, drawdate, fundsource, premiumamount, premiumterm, nomineescreentitle);
        createApplPage.add_Nominee(nomineescreentitle, nomineefirstname, nomineelastname, nomineeday, nomineemonth, nomineeyear, nomineegender, relationshipwithproposer, nomineeshare, ismwppolicy, addressscreentitle);
        createApplPage.add_Address(addressscreentitle, typeofaddress, addresspincode, address1, address2, address3, personalDetailsscreentitle);
        captureEmailIdPage.capturedEmailID(emailaddressValidations, maritalStatus, fathersNameOrSpouseName, mothersName, question1,answer1,valueToBeEnter,question2,answer2,valueToBeEnter2,question3,answer3,valueToBeEnter3,question4,answer4,valueToBeEnter4,qualification, occupation, employeerName, nameOfBusinessOrduties, typeOfOrganization, designation, annualIncome,existingPolicyscreentitle);
        existingPolicyPage.addExistingPolicy(insurerName, sumAssured, policyNumber, yearOfApplication, basePlan, annualPrimium, policyStatus);


    }

    public void gotoRefusedPolicies(WebDriver driver, String username, String password, String policy, String leadid, String proposersame, String propinsurednotsame, String isnri, String pmobile, String ppan,
                                    String imobile, String ipan, String firstname, String lastname,
                                    String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame,
                                    String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                    String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                    String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                    String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                    String clickverify, String renewpremiumscreentitle, String paymentmethod, String drawdate, String fundsource,
                                    String nomineescreentitle, String nomineefirstname, String nomineelastname, String nomineeday,
                                    String nomineemonth, String nomineeyear, String nomineegender, String relationshipwithproposer, String nomineeshare,
                                    String ismwppolicy,
                                    String addressscreentitle, String typeofaddress, String addresspincode, String address1, String address2, String address3,
                                    String personalDetailsscreentitle, String cityName, String preferredLanguage, String alernateNumber, String resTelephoneNumber,
                                    String emailaddressValidations, String maritalStatus, String fathersNameOrSpouseName,
                                    String mothersName,String question1,String answer1,String valueToBeEnter,
                                    String question2,String answer2,String valueToBeEnter2,
                                    String question3,String answer3,String valueToBeEnter3,
                                    String question4,String answer4,String valueToBeEnter4,  String qualification, String occupation, String employeerName, String nameOfBusinessOrduties,
                                    String typeOfOrganization, String designation, String annualIncome, String policyStatus,String existingPolicyscreentitle,
                                    String insurerName, String sumAssured, String policyNumber, String yearOfApplication, String basePlan, String annualPrimium, String expolicystatus,String medicalPolicy,
                                    String refPolicyScreentitle,String refInsurerName,String refsumAssured,String refreason,String policyPurposeScreen, String purposeOption1,
                                    String purposeOption2, String purposeOption3) throws Exception {

        createApplPage = new CreateApplPage(driver);
        captureEmailIdPage = new CaptureEmailIdPage(driver);
        existingPolicyPage = new ExistingPolicyPage(driver);
        refusedPolicyPage=new RefusedPolicyPage(driver);

        createApplPage.chooseSignAndGoToLeadIdScreen(username, password, policy);
        createApplPage.fillLeadIdAndProceed(leadid, proposersame, isnri);
        waitUtils.wait2Seconds();
        createApplPage.captureMobilePanAndProceed(pmobile, ppan);
        createApplPage.prefillDetails(firstname, lastname, middlename, day, month, year, gender);
        System.out.println(planjourney);
        waitUtils.implicitWait(driver, 20000);
        createApplPage.choosePlan(planjourney);
       // createApplPage.choosePlanSelectProceedButton();
        waitUtils.waitForElementToBeVisible(driver, createApplPage.elePlanSelectionNavText);
        createApplPage.fillPlanDetails(planjourney, proposerstate, advisorstatesame, plan);
        createApplPage.createQuote(sumassured, smokertype, planoptions, increasinglevel, ecs, term, ppt, premiumterm, premiumamount);
        commonUtils.selectButtonByName(clickcontinue, driver);
        waitUtils.waitForElementToBeVisible(driver, createApplPage.eleBankNavText, 50, "Didnt navigate to bank details screen");
        createApplPage.fillBankDetails(ifsccode, bankaccno, accounttype, clickverify, pennyalert);
        createApplPage.fillRenewalDetails(paymentmethod, drawdate, fundsource, premiumamount, premiumterm, nomineescreentitle);
        createApplPage.add_Nominee(nomineescreentitle, nomineefirstname, nomineelastname, nomineeday, nomineemonth, nomineeyear, nomineegender, relationshipwithproposer, nomineeshare, ismwppolicy, addressscreentitle);
        createApplPage.add_Address(addressscreentitle, typeofaddress, addresspincode, address1, address2, address3, personalDetailsscreentitle);
        captureEmailIdPage.capturedEmailID(emailaddressValidations, maritalStatus, fathersNameOrSpouseName, mothersName, question1,answer1,valueToBeEnter,question2,answer2,valueToBeEnter2,question3,answer3,valueToBeEnter3,question4,answer4,valueToBeEnter4,qualification, occupation, employeerName, nameOfBusinessOrduties, typeOfOrganization, designation, annualIncome,existingPolicyscreentitle);
        existingPolicyPage.addExistingPolicy(insurerName, sumAssured, policyNumber, yearOfApplication, basePlan, annualPrimium, policyStatus);
        refusedPolicyPage.addRefusedPolicy(refInsurerName,refsumAssured,refreason);
        existingPolicyPage.selectPurposeInsurence(purposeOption1);
        existingPolicyPage.selectPurposeInsurence(purposeOption2);
        existingPolicyPage.selectPurposeInsurence(purposeOption3);
        Assert.assertEquals(existingPolicyPage.healthDetailsTitle.getText(),"8.0 Health Details");

    }

    public void gotoHealthDetails(WebDriver driver, String username, String password, String policy, String leadid, String proposersame, String propinsurednotsame, String isnri, String pmobile, String ppan,
                                    String imobile, String ipan, String firstname, String lastname,
                                    String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame,
                                    String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                    String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                    String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                    String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                    String clickverify, String renewpremiumscreentitle, String paymentmethod, String drawdate, String fundsource,
                                    String nomineescreentitle, String nomineefirstname, String nomineelastname, String nomineeday,
                                    String nomineemonth, String nomineeyear, String nomineegender, String relationshipwithproposer, String nomineeshare,
                                    String ismwppolicy,
                                    String addressscreentitle, String typeofaddress, String addresspincode, String address1, String address2, String address3,
                                    String personalDetailsscreentitle, String cityName, String preferredLanguage, String alernateNumber, String resTelephoneNumber,
                                    String emailaddressValidations, String maritalStatus, String fathersNameOrSpouseName,
                                    String mothersName,String question1,String answer1,String valueToBeEnter,
                                    String question2,String answer2,String valueToBeEnter2,
                                    String question3,String answer3,String valueToBeEnter3,
                                    String question4,String answer4,String valueToBeEnter4,  String qualification, String occupation, String employeerName, String nameOfBusinessOrduties,
                                    String typeOfOrganization, String designation, String annualIncome,String existingPolicyscreentitle,
                                    String insurerName, String sumAssured, String policyNumber, String yearOfApplication, String basePlan, String annualPrimium, String medicalPolicy,
                                    String refPolicyScreentitle,String refInsurerName,String refsumAssured,String refreason,String policyPurposeScreen, String purposeOption1,
                                    String purposeOption2, String purposeOption3,String healthScreenTitle) throws Exception {

        createApplPage = new CreateApplPage(driver);
        captureEmailIdPage = new CaptureEmailIdPage(driver);
        existingPolicyPage = new ExistingPolicyPage(driver);
        refusedPolicyPage=new RefusedPolicyPage(driver);
        createApplPage.chooseSignAndGoToLeadIdScreen(username, password, policy);
        createApplPage.fillLeadIdAndProceed(leadid, proposersame, isnri);
        waitUtils.wait2Seconds();
        createApplPage.captureMobilePanAndProceed(pmobile, ppan);
        createApplPage.prefillDetails(firstname, lastname, middlename, day, month, year, gender);
        waitUtils.implicitWait(driver, 20000);
        createApplPage.choosePlan(planjourney);
        // createApplPage.choosePlanSelectProceedButton();
        waitUtils.waitForElementToBeVisible(driver, createApplPage.elePlanSelectionNavText);
        createApplPage.fillPlanDetails(planjourney, proposerstate, advisorstatesame, plan);
        createApplPage.createQuote(sumassured, smokertype, planoptions, increasinglevel, ecs, term, ppt, premiumterm, premiumamount);
        commonUtils.selectButtonByName(clickcontinue, driver);
        waitUtils.waitForElementToBeVisible(driver,createApplPage.instaVerifyScreenTitle,50,"didn't navigate to the insta verify page");
        createApplPage.instaVerifyPage();
        waitUtils.waitForElementToBeVisible(driver, createApplPage.eleBankNavText, 50, "Didnt navigate to bank details screen");
        createApplPage.fillBankDetails(ifsccode, bankaccno, accounttype, clickverify, pennyalert);
        createApplPage.fillRenewalDetails(paymentmethod, drawdate, fundsource, premiumamount, premiumterm, nomineescreentitle);
        createApplPage.add_Nominee(nomineescreentitle, nomineefirstname, nomineelastname, nomineeday, nomineemonth, nomineeyear, nomineegender, relationshipwithproposer, nomineeshare, ismwppolicy, addressscreentitle);
        createApplPage.add_Address(addressscreentitle, typeofaddress, addresspincode, address1, address2, address3, personalDetailsscreentitle);
        captureEmailIdPage.capturedEmailID(emailaddressValidations, maritalStatus, fathersNameOrSpouseName, mothersName, question1,answer1,valueToBeEnter,question2,answer2,valueToBeEnter2,question3,answer3,valueToBeEnter3,question4,answer4,valueToBeEnter4,qualification, occupation, employeerName, nameOfBusinessOrduties, typeOfOrganization, designation, annualIncome,existingPolicyscreentitle);
        existingPolicyPage.addExistingPolicy(insurerName, sumAssured, policyNumber, yearOfApplication, basePlan, annualPrimium,"");
       //refusedPolicyPage.addRefusedPolicy(refInsurerName,refsumAssured,refreason);
        existingPolicyPage.selectPurposeInsurence(purposeOption1);
        existingPolicyPage.selectPurposeInsurence(purposeOption2);
        existingPolicyPage.selectPurposeInsurence(purposeOption3);
        waitUtils.wait2Seconds();
        commonUtils.selectButtonByName("NEXT",driver);
        waitUtils.wait2Seconds();
        Assert.assertEquals(existingPolicyPage.healthDetailsTitle.getText(),healthScreenTitle);

    }
    public void gotoInstaVerify(WebDriver driver, String username, String password, String policy, String leadid, String proposersame, String propinsurednotsame, String isnri, String pmobile, String ppan,
                                  String imobile, String ipan, String firstname, String lastname,
                                  String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame,
                                  String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                  String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                  String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                  String clickcontinue) throws Exception {
        createApplPage = new CreateApplPage(driver);
        captureEmailIdPage = new CaptureEmailIdPage(driver);
        existingPolicyPage = new ExistingPolicyPage(driver);
        refusedPolicyPage = new RefusedPolicyPage(driver);
        createApplPage.chooseSignAndGoToLeadIdScreen(username, password, policy);
        createApplPage.fillLeadIdAndProceed(leadid, proposersame, isnri);
        waitUtils.wait2Seconds();
        createApplPage.captureMobilePanAndProceed(pmobile, ppan);
        createApplPage.prefillDetails(firstname, lastname, middlename, day, month, year, gender);
        waitUtils.implicitWait(driver, 20000);
        createApplPage.choosePlan(planjourney);
        // createApplPage.choosePlanSelectProceedButton();
        waitUtils.waitForElementToBeVisible(driver, createApplPage.elePlanSelectionNavText);
        createApplPage.fillPlanDetails(planjourney, proposerstate, advisorstatesame, plan);
        createApplPage.createQuote(sumassured, smokertype, planoptions, increasinglevel, ecs, term, ppt, premiumterm, premiumamount);
        commonUtils.selectButtonByName(clickcontinue, driver);
        waitUtils.waitForElementToBeVisible(driver, createApplPage.instaVerifyScreenTitle, 50, "didn't navigate to the insta verify page");
        ivPage.instaVerifyPage();
    }

    public void gotoAddress(WebDriver driver,String username, String password, String policy, String leadid, String proposersame,
                            String relationwithinsured,String isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                            String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                            String ecs, String term, String ppt, String premiumterm, String premiumamount,
                            String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                            String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                            String clickverify, String renewpremiumscreentitle,String paymentmethod,String drawdate,String fundsource,
                            String nomineescreentitle,String nomineefirstname,String nomineelastname,String nomineeday,String nomineemonth,String nomineeyear,String nomineegender,String relationshipwithproposer,String typeofaddress, String addresspincode, String address1, String address2, String address3, String personalDetailsscreentitle, String cityName) throws Exception {

        createApplPage = new CreateApplPage(driver);
        captureEmailIdPage = new CaptureEmailIdPage(driver);
        existingPolicyPage = new ExistingPolicyPage(driver);
        qualificationPage = new QualificationPage(driver);
        occupationPage = new OccupationPage(driver);
        lifestylePage = new LifestylePage(driver);
        createApplPage.chooseSignAndGoToLeadIdScreen(username, password, policy);
        createApplPage.fillLeadIdAndProceed(leadid, proposersame, isnri);
        waitUtils.wait2Seconds();
        createApplPage.captureMobilePanAndProceed(pmobile, ppan);
        createApplPage.prefillDetails(firstname, lastname, middlename, day, month, year, gender);
        System.out.println(planjourney);
        waitUtils.implicitWait(driver, 20000);
        createApplPage.choosePlan(planjourney);
        //createApplPage.choosePlanSelectProceedButton();
        waitUtils.waitForElementToBeVisible(driver, createApplPage.elePlanSelectionNavText);
        createApplPage.fillPlanDetails(planjourney, proposerstate, advisorstatesame, plan);
        createApplPage.createQuote(sumassured, smokertype, planoptions, increasinglevel, ecs, term, ppt, premiumterm, premiumamount);
        commonUtils.selectButtonByName(clickcontinue, driver);
        waitUtils.waitForElementToBeVisible(driver, createApplPage.instaVerifyScreenTitle, 50, "didn't navigate to the insta verify page");
        waitUtils.wait2Seconds();
        createApplPage.skipInstaVerifyPage();

        waitUtils.waitForElementToBeVisible(driver, createApplPage.eleBankNavText, 50, "Didnt navigate to bank details screen");
        createApplPage.fillBankDetails(ifsccode, bankaccno, accounttype, clickverify, pennyalert);
        createApplPage.fillRenewalDetails(paymentmethod, drawdate, fundsource, premiumamount, premiumterm, nomineescreentitle);
        createApplPage.fillNomineeDetails( nomineefirstname, nomineelastname, nomineeday, nomineemonth, nomineeyear, nomineegender,relationshipwithproposer);
    }

    public void gotoQualification(WebDriver driver,String username, String password, String policy, String leadid, String proposersame,
                                  String relationwithinsured,String isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                  String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                  String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                  String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                  String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                  String clickverify, String renewpremiumscreentitle,String paymentmethod,String drawdate,String fundsource,
                                  String nomineescreentitle,String nomineefirstname,String nomineelastname,String nomineeday,String nomineemonth,String nomineeyear,String nomineegender,String relationshipwithproposer,String typeofaddress, String addresspincode, String address1, String address2, String address3, String personalDetailsscreentitle, String cityName) throws Exception {

        createApplPage = new CreateApplPage(driver);
        captureEmailIdPage = new CaptureEmailIdPage(driver);
        existingPolicyPage = new ExistingPolicyPage(driver);
        qualificationPage = new QualificationPage(driver);
        occupationPage = new OccupationPage(driver);
        lifestylePage = new LifestylePage(driver);

        createApplPage.chooseSignAndGoToLeadIdScreen(username, password, policy);
        createApplPage.fillLeadIdAndProceed(leadid, proposersame, isnri);
        waitUtils.wait2Seconds();
        createApplPage.captureMobilePanAndProceed(pmobile, ppan);
        createApplPage.prefillDetails(firstname, lastname, middlename, day, month, year, gender);
        System.out.println(planjourney);
        waitUtils.implicitWait(driver, 20000);
        createApplPage.choosePlan(planjourney);
        //createApplPage.choosePlanSelectProceedButton();
        waitUtils.waitForElementToBeVisible(driver, createApplPage.elePlanSelectionNavText);
        createApplPage.fillPlanDetails(planjourney, proposerstate, advisorstatesame, plan);
        createApplPage.createQuote(sumassured, smokertype, planoptions, increasinglevel, ecs, term, ppt, premiumterm, premiumamount);
        commonUtils.selectButtonByName(clickcontinue, driver);
        waitUtils.waitForElementToBeVisible(driver, createApplPage.instaVerifyScreenTitle, 50, "didn't navigate to the insta verify page");
        waitUtils.wait2Seconds();
        createApplPage.skipInstaVerifyPage();

        waitUtils.waitForElementToBeVisible(driver, createApplPage.eleBankNavText, 50, "Didnt navigate to bank details screen");
        createApplPage.fillBankDetails(ifsccode, bankaccno, accounttype, clickverify, pennyalert);
        createApplPage.fillRenewalDetails(paymentmethod, drawdate, fundsource, premiumamount, premiumterm, nomineescreentitle);
        createApplPage.fillNomineeDetails( nomineefirstname, nomineelastname, nomineeday, nomineemonth, nomineeyear, nomineegender,relationshipwithproposer);
        if(commonUtils.isDisplayed(driver,createApplPage.eleAddressNavText)) {
            Assert.assertTrue(createApplPage.eleAddressNavText.isDisplayed());
            createApplPage.fillAddressDetails( typeofaddress, addresspincode, address1, address2, address3, personalDetailsscreentitle);
        }


    }

    public void gotoLifestyle(WebDriver driver,String username, String password, String policy, String leadid, String proposersame,
                              String isnri, String pmobile, String ppan, String firstname, String lastname,
                              String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                              String ecs, String term, String ppt, String premiumterm, String premiumamount,
                              String clickcontinue, String ifsccode, String bankaccno, String accounttype, String pennyalert,
                              String clickverify,String paymentmethod,String drawdate,String fundsource,
                              String nomineescreentitle,String nomineefirstname,String nomineelastname,String nomineeday,String nomineemonth,String nomineeyear,String nomineegender,String relationshipwithproposer,String typeofaddress, String addresspincode, String address1, String address2, String address3, String personalDetailsscreentitle,
                              String PersonalEmailId, String PersonalMaritalStatus, String FatherSpouseName,
                              String MotherName, String MaidenName, String Qualification, String Occupation
            , String SpouseAnnualIncome, String AnnualIncome,String addressscreentitle, String nomineeshare,String ismwppolicy) throws Exception {

        createApplPage = new CreateApplPage(driver);
        captureEmailIdPage = new CaptureEmailIdPage(driver);
        existingPolicyPage = new ExistingPolicyPage(driver);
        qualificationPage = new QualificationPage(driver);
        occupationPage = new OccupationPage(driver);
        lifestylePage = new LifestylePage(driver);
        createApplPage.chooseSignAndGoToLeadIdScreen(username, password, policy);
        createApplPage.fillLeadIdAndProceed(leadid, proposersame, isnri);
        waitUtils.wait2Seconds();
        createApplPage.captureMobilePanAndProceed(pmobile, ppan);
        createApplPage.prefillDetails(firstname, lastname, middlename, day, month, year, gender);
        System.out.println(planjourney);
        waitUtils.implicitWait(driver, 20000);
        createApplPage.choosePlan(planjourney);
        //createApplPage.choosePlanSelectProceedButton();
        waitUtils.waitForElementToBeVisible(driver, createApplPage.elePlanSelectionNavText);
        createApplPage.fillPlanDetails(planjourney, proposerstate, advisorstatesame, plan);
        createApplPage.createQuote(sumassured, smokertype, planoptions, increasinglevel, ecs, term, ppt, premiumterm, premiumamount);
        commonUtils.selectButtonByName(clickcontinue, driver);
        waitUtils.waitForElementToBeVisible(driver, createApplPage.instaVerifyScreenTitle, 50, "didn't navigate to the insta verify page");
        waitUtils.wait2Seconds();
        createApplPage.skipInstaVerifyPage();

        waitUtils.waitForElementToBeVisible(driver, createApplPage.eleBankNavText, 50, "Didnt navigate to bank details screen");
        createApplPage.fillBankDetails(ifsccode, bankaccno, accounttype, clickverify, pennyalert);
        createApplPage.fillRenewalDetails(paymentmethod, drawdate, fundsource, premiumamount, premiumterm, nomineescreentitle);
        createApplPage.fillNomineeDetails( nomineefirstname, nomineelastname, nomineeday, nomineemonth, nomineeyear, nomineegender,relationshipwithproposer);
        if(commonUtils.isDisplayed(driver,createApplPage.eleAddressNavText)) {
            Assert.assertTrue(createApplPage.eleAddressNavText.isDisplayed());
            createApplPage.fillAddressDetails( typeofaddress, addresspincode, address1, address2, address3, personalDetailsscreentitle);
        }
        waitUtils.implicitWait(driver,10000);

        //Personal Details
        lifestylePage.fillPersonalDetails(PersonalEmailId, PersonalMaritalStatus, FatherSpouseName, MotherName, MaidenName, Qualification, Occupation, AnnualIncome, SpouseAnnualIncome);
        //captureEmailIdPage.capturedEmailID(emailaddressValidations, maritalStatus, fathersNameOrSpouseName, mothersName, qualification, occupation, employeerName, nameOfBusinessOrduties, typeOfOrganization, designation, annualIncome);

        if(! new BaseTest().isWeb()) {
            waitUtils.fluentWaitUntilElementVisible(driver,perInfo.eleEmailNextBtn,80);
            commonUtils.chooseActionButton(perInfo.eleEmailNextBtn);
            if (commonUtils.isDisplayed(driver,perInfo.eleEmailNextBtn)) {
                commonUtils.chooseActionButton(perInfo.eleEmailNextBtn);
            }
        }

        if(new BaseTest().isWeb()) {
            waitUtils.waitUntilVisible(driver,existingPolicyPage.eleDoItLaterBtn,30);
            commonUtils.chooseActionButton(existingPolicyPage.eleDoItLaterBtn);
        }
        else if(new BaseTest().isIOS()) {
            System.out.println("mobile existig policy ---------->>>>");
            try {
                waitUtils.fluentWaitUntilElementVisible(driver,existingPolicyPage.eleExistingPolicySection,50);
                WebElement ele = ((AppiumDriver)driver).findElementByAccessibilityId("policyDoItLaterBtn policyNextButton");
                waitUtils.wait2Seconds();
                ((IOSElement)ele).findElementByIosClassChain("**/XCUIElementTypeOther[`label == \"policyNextButton\"`][2]").click();
            } catch (TimeoutException e) {
                commonUtils.chooseActionButton(existingPolicyPage.eleExistingPolNextBtn);
            }

        }
        else if(new BaseTest().isAndroid()) {
            System.out.println("mobile existig policy ---------->>>>");
            Thread.sleep(2000);
            try {
                WebElement ele = driver.findElement(By.xpath("(//android.view.ViewGroup[@content-desc=\"mainContainer\"])[5]/android.view.ViewGroup[2]/android.view.ViewGroup[2]"));
                commonUtils.isDisplayed(driver,ele);
                ((AndroidElement)ele).findElementByXPath("//android.widget.Button[@content-desc=\"policyNextButton\"]/android.view.ViewGroup").click();
            } catch (TimeoutException e){
                commonUtils.chooseActionButton(existingPolicyPage.eleExistingPolNextBtn);
            } catch (NoSuchElementException e){
                commonUtils.chooseActionButton(existingPolicyPage.eleExistingPolNextBtn);

            }
        }
        if(new BaseTest().isWeb()) {
            commonUtils.clickIfEnabled(driver,lifestylePage.elePURPOSEOFINSURANCE);
            lifestylePage.elePURPOSEOFINSURANCE.click();
            commonUtils.scrollTillEndOfPage(driver);
        }
        lifestylePage.elePURPOSEOFINSURANCENextBtn.click();

/*        commonUtils.selectButtonByName("DO IT LATER ", driver);
        //commonUtils.clickIfEnabled(driver,lifestylePage.elePURPOSEOFINSURANCE);
        lifestylePage.elePURPOSEOFINSURANCE.click();
        lifestylePage.elePURPOSEOFINSURANCENextBtn.click();*/

        waitUtils.waitForElementToBeClickable(driver,lifestylePage.elePersonalDetailsWeight);
        lifestylePage.elePersonalDetailsWeight.click();
        lifestylePage.elePersonalDetailsWeight.sendKeys("65");
        commonUtils.scrollTillEndOfPage(driver);
        lifestylePage.elePersonalDetailsSaveBtn.click();

    }

    public void goToRna(WebDriver driver,String username, String password, String policy, String leadid, String proposersame,
                        String relationwithinsured,String isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                        String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                        String ecs, String term, String ppt, String premiumterm, String premiumamount,
                        String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                        String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                        String clickverify, String renewpremiumscreentitle,String paymentmethod,String drawdate,String fundsource,
                        String nomineescreentitle , String nomineefirstname,String nomineelastname,String nomineeday,String nomineemonth,String nomineeyear,String nomineegender,String relationshipwithproposer,String nomineeshare,
                        String mwpPloicy,String addressscreentitle,String typeofaddress ,String addresspincode ,String address1 ,String address2 ,String address3 ,String personalDetailsscreentitle ,String cityName ,
                        String preferredLanguage ,String alernateNumber ,String resTelephoneNumber ,String emailaddressValidations ,String maritalStatus ,String
                                fathersNameOrSpouseName ,String mothersName ,String MaidenName,String qualification ,String occupation ,String employeerName ,String
                                nameOfBusinessOrduties ,String typeOfOrganization ,String designation ,String annualIncome ,String policyStatus ,String exPolicyscreenTitle ,String exNameofInsurer ,String
                                exSumAssured ,String expolicyNumber ,String exyearOfApplication ,String exbasePlan ,String exannualpremium ,String medicalPolicy ,String expolicystatus ,String
                                refPolicyscreenTitle ,String refinsurerName ,String refsumAssured ,String refreason ,String refinsurerName1 ,String refsumAssured1 ,String refreason1 ,String
                                refinsurerName2 ,String refsumAssured2 ,String refreason2 ,String refinsurerName3 ,String refsumAssured3 ,String refreason3 ,String
                                refinsurerName4 ,String refsumAssured4 ,String refreason4 ,String policyPurposeScreen ,String purposeOption1 ,String purposeOption2 ,String purposeOption3 ,String
                                healthDetailsScreen ,String height,String 	weight,String 	weightchange,String symptomsDetails ,String testsDetails ,String covidContactDetails ,String quarantineDetails ,String healthDetails ,String
                                pastTravelContry ,String pastTravelCity ,String pastTravelArrivalDay ,String pastTravelArraivalMonth ,String pastTravelArraivalYear ,String
                                pastTravelDepartureDay ,String pastTravelDepartureMonth ,String pastTravelDepartureYear ,String futureTravelCountry ,String futureTravelCity ,String
                                futureTravelDepartureDay ,String futureTravelDepartureMonth ,String futureTravelDepartureYear ,String futureInternedDuration ,String
                                covidVaccinationFirstDoseDay ,String covidVaccinationFirstDoseMonth ,String covidVaccinationFirstDoseYear ,String covidVaccinationSecondDoseDay ,String
                                covidVaccinationSecondDoseMonth ,String covidVaccinationSecondDoseYear ,String covidVaccineName ,String postVaccineDetails ,String
                                covidOccupation ,String medicalSpeciality ,String exactNatureOfDuties ,String nameOfHealthCareFacility ,String
                                addressOfHealthCareFacility ,String healthAuthorityRegistered ,String covidWardDetails ,String diagnoseDay ,String
                                diagnoseMonth ,String diagnoseYear ,String daignoseTestName ,String receivedCovid19Test1 ,String receivedCovid19Test2 ,String receivedCovid19Test3 ,String
                                admissionDay ,String admissionMonth ,String admissionYear ,String dischargeDay ,String dischargeMonth ,String dischargeYear ,String
                                covidInfectionDetails ,String covidSymptoms1 ,String covidSymptoms2 ,String covidSymptoms3 ,String recoveryDay ,String recoveryMonth ,String recoveryYear ,String
                                testsName ,String testTakenDay ,String testTakenMonth ,String testTakenYear ,String certifiedDetails) throws InterruptedException,IOException {


        //nominee
        createApplPage = gotoNominee( driver,  username,   password,   policy,   leadid,   proposersame,
                  relationwithinsured,  isrelationanswer,   isnri,   pmobile,   ppan,   imobile,   ipan,   firstname,   lastname,
                  middlename,   day,   month,   year,   gender,   planjourney,   proposerstate,   advisorstatesame,   plan,   sumassured,   smokertype,   planoptions,   increasinglevel,
                  ecs,   term,   ppt,   premiumterm,   premiumamount,
                  rider,   rideramount,   minrider,   maxrider,   ridererror,   click,   generateillustrations,
                  clickcontinue,   ifsccode,   bankaccno,   accholdername,   accounttype,   pennyalert,
                  clickverify,   renewpremiumscreentitle,  paymentmethod,  drawdate,  fundsource,
                  nomineescreentitle);
        Assert.assertTrue(createApplPage.eleNomineeNavText.isDisplayed(),"Not in nominee screen");
        createApplPage.addNominee(nomineefirstname,nomineelastname,nomineeday,nomineemonth,nomineeyear,nomineegender,relationshipwithproposer,nomineeshare,mwpPloicy);
        Thread.sleep(500);
        waitUtils.fluentWaitUntilElementVisible(driver,createApplPage.eleFormNext,60);
        createApplPage.nextForm();
        createApplPage.nextForm();

        //address
        if(commonUtils.isDisplayed(driver,createApplPage.eleAddressNavText)) {
            Assert.assertTrue(createApplPage.eleAddressNavText.isDisplayed());
            createApplPage.addAddress(addressscreentitle,typeofaddress,addresspincode,address1,address2,address3,personalDetailsscreentitle);
        }

        //personal
        perInfo = new PersonalInfoPage(driver);
        if(commonUtils.isDisplayed(driver,createApplPage.elePersonalInfoNavText)) {
            Assert.assertTrue(createApplPage.elePersonalInfoNavText.isDisplayed());
            System.out.println("In health screen");
            perInfo.fillPersonal(emailaddressValidations,maritalStatus,fathersNameOrSpouseName,mothersName,MaidenName);
            if(! new BaseTest().isWeb()) {
                waitUtils.fluentWaitUntilElementVisible(driver,perInfo.eleEmailNextBtn,80);
                commonUtils.chooseActionButton(perInfo.eleEmailNextBtn);
                if (commonUtils.isDisplayed(driver,perInfo.eleEmailNextBtn)) {
                    commonUtils.chooseActionButton(perInfo.eleEmailNextBtn);
                }
            }

            if(new BaseTest().isWeb()) {
                waitUtils.waitUntilVisible(driver,new ExistingPolicyPage(driver).eleDoItLaterBtn,30);
                commonUtils.chooseActionButton(new ExistingPolicyPage(driver).eleDoItLaterBtn);
            }
            else if(new BaseTest().isIOS()) {
                System.out.println("mobile existig policy ---------->>>>");
                try {
                    waitUtils.fluentWaitUntilElementVisible(driver,new ExistingPolicyPage(driver).eleExistingPolicySection,50);
                    WebElement ele = ((AppiumDriver)driver).findElementByAccessibilityId("policyDoItLaterBtn policyNextButton");
                    waitUtils.wait2Seconds();
                    ((IOSElement)ele).findElementByIosClassChain("**/XCUIElementTypeOther[`label == \"policyNextButton\"`][2]").click();
                } catch (TimeoutException e) {
                    commonUtils.chooseActionButton(new ExistingPolicyPage(driver).eleExistingPolNextBtn);
                }
                catch (NoSuchElementException e) {
                    commonUtils.chooseActionButton(new ExistingPolicyPage(driver).eleExistingPolNextBtn);
                }

            }
            else if(new BaseTest().isAndroid()) {
                System.out.println("mobile existig policy ---------->>>>");
                existingPolicyPage = new ExistingPolicyPage(driver);
                Thread.sleep(3000);
                try {
                    //WebElement ele = driver.findElement(By.xpath("(//android.view.ViewGroup[@content-desc=\"mainContainer\"])[5]/android.view.ViewGroup[2]/android.view.ViewGroup[2]"));
                    //WebElement ele = driver.findElement(By.xpath("//android.widget.ScrollView//..//android.view.ViewGroup[2]"));
                    //commonUtils.isDisplayed(driver,ele);
                    //((AndroidElement)ele).findElementByXPath("//android.widget.Button[@content-desc=\"policyNextButton\"]/android.view.ViewGroup").click();
                    //WebElement ele = driver.findElement(By.xpath("(//android.view.ViewGroup[@content-desc=\"mainContainer\"])[5]/child::android.view.ViewGroup[2]"));
                    commonUtils.isDisplayed(driver,new ExistingPolicyPage(driver).eleExistingPolNextBtn);
                    //((AndroidElement)ele).findElementByAccessibilityId("policyNextButton").click();
                    ((AndroidDriver)driver).findElementByAccessibilityId("policyNextButton").click();

                }
                catch (TimeoutException e){
                    System.out.println("In existing policy try catch block -------->>>>>");
                    commonUtils.chooseActionButton(new ExistingPolicyPage(driver).eleExistingPolNextBtn);

                } catch (NoSuchElementException e){
                    System.out.println("In existing policy try catch block -------->>>>>");
                    waitUtils.wait1Seconds();
                    commonUtils.chooseActionButton(new ExistingPolicyPage(driver).eleExistingPolNextBtn);
                }
                }

        }
        if(new BaseTest().isWeb()) {
            commonUtils.scrollTillEndOfPage(driver);
        }
        waitUtils.waitUntilVisible(driver,perInfo.elePersonalInfoNextBtn,30);
        commonUtils.chooseActionButton(perInfo.elePersonalInfoNextBtn);

        //health
        healthPage = new HealthPoliciesPage(driver);
        waitUtils.waitUntilVisible(driver, healthPage.eleHealthInfoNavText,40);
        if(new BaseTest().isWeb()) {
            healthPage.inputWeight(weight);
        }

        if(new BaseTest().isWeb()) {
            commonUtils.scrollTopOfPage(driver);
            waitUtils.waitForElementToBeClickable(driver,healthPage.eleCovidTab,30);
            commonUtils.chooseActionButton(healthPage.eleCovidTab);
        } else {
            waitUtils.waitUntilVisible(driver,healthPage.eleMedHistoryTab,30);
            commonUtils.chooseActionButton(healthPage.eleMedHistoryTab);
        }
        if(new BaseTest().isWeb()) {
            commonUtils.scrollTillEndOfPage(driver);
            commonUtils.scrollTillEndOfPage(driver);
        }
        waitUtils.waitUntilVisible(driver,healthPage.eleHealthPersNextBtn,30);
        commonUtils.chooseActionButton(healthPage.eleHealthPersNextBtn);
        if (new BaseTest().isWeb()) {
            waitUtils.waitUntilPageLoad(driver);
        }

        //rna
        rna = new ReviewAcceptPage(driver);
        waitUtils.wait10Seconds();
        waitUtils.waitUntilVisible(driver,rna.eleRnaNavText,80);
        Thread.sleep(5000);
    }

    public void goToCash(WebDriver driver,String username, String password, String policy, String leadid, String proposersame,
                        String relationwithinsured,String isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                        String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                        String ecs, String term, String ppt, String premiumterm, String premiumamount,
                        String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                        String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                        String clickverify, String renewpremiumscreentitle,String paymentmethod,String drawdate,String fundsource,
                        String nomineescreentitle , String nomineefirstname,String nomineelastname,String nomineeday,String nomineemonth,String nomineeyear,String nomineegender,String relationshipwithproposer,String nomineeshare,
                        String mwpPloicy,String addressscreentitle,String typeofaddress ,String addresspincode ,String address1 ,String address2 ,String address3 ,String personalDetailsscreentitle ,String cityName ,
                        String preferredLanguage ,String alernateNumber ,String resTelephoneNumber ,String emailaddressValidations ,String maritalStatus ,String
                                fathersNameOrSpouseName ,String mothersName ,String MaidenName,String qualification ,String occupation ,String employeerName ,String
                                nameOfBusinessOrduties ,String typeOfOrganization ,String designation ,String annualIncome ,String policyStatus ,String exPolicyscreenTitle ,String exNameofInsurer ,String
                                exSumAssured ,String expolicyNumber ,String exyearOfApplication ,String exbasePlan ,String exannualpremium ,String medicalPolicy ,String expolicystatus ,String
                                refPolicyscreenTitle ,String refinsurerName ,String refsumAssured ,String refreason ,String refinsurerName1 ,String refsumAssured1 ,String refreason1 ,String
                                refinsurerName2 ,String refsumAssured2 ,String refreason2 ,String refinsurerName3 ,String refsumAssured3 ,String refreason3 ,String
                                refinsurerName4 ,String refsumAssured4 ,String refreason4 ,String policyPurposeScreen ,String purposeOption1 ,String purposeOption2 ,String purposeOption3 ,String
                                healthDetailsScreen ,String height,String 	weight,String 	weightchange,String symptomsDetails ,String testsDetails ,String covidContactDetails ,String quarantineDetails ,String healthDetails ,String
                                pastTravelContry ,String pastTravelCity ,String pastTravelArrivalDay ,String pastTravelArraivalMonth ,String pastTravelArraivalYear ,String
                                pastTravelDepartureDay ,String pastTravelDepartureMonth ,String pastTravelDepartureYear ,String futureTravelCountry ,String futureTravelCity ,String
                                futureTravelDepartureDay ,String futureTravelDepartureMonth ,String futureTravelDepartureYear ,String futureInternedDuration ,String
                                covidVaccinationFirstDoseDay ,String covidVaccinationFirstDoseMonth ,String covidVaccinationFirstDoseYear ,String covidVaccinationSecondDoseDay ,String
                                covidVaccinationSecondDoseMonth ,String covidVaccinationSecondDoseYear ,String covidVaccineName ,String postVaccineDetails ,String
                                covidOccupation ,String medicalSpeciality ,String exactNatureOfDuties ,String nameOfHealthCareFacility ,String
                                addressOfHealthCareFacility ,String healthAuthorityRegistered ,String covidWardDetails ,String diagnoseDay ,String
                                diagnoseMonth ,String diagnoseYear ,String daignoseTestName ,String receivedCovid19Test1 ,String receivedCovid19Test2 ,String receivedCovid19Test3 ,String
                                admissionDay ,String admissionMonth ,String admissionYear ,String dischargeDay ,String dischargeMonth ,String dischargeYear ,String
                                covidInfectionDetails ,String covidSymptoms1 ,String covidSymptoms2 ,String covidSymptoms3 ,String recoveryDay ,String recoveryMonth ,String recoveryYear ,String
                                testsName ,String testTakenDay ,String testTakenMonth ,String testTakenYear ,String certifiedDetails) throws InterruptedException,IOException {

        //createApplPage = new CreateApplPage(driver);
        /*perInfo = new PersonalInfoPage(driver);
        existingPolicyPage = new ExistingPolicyPage(driver);
        healthPage = new HealthPoliciesPage(driver);
        rna = new ReviewAcceptPage(driver);
        ivPage = new InstaVerifyPage(driver);*/

        //nominee
        createApplPage = gotoNominee( driver,  username,   password,   policy,   leadid,   proposersame,
                relationwithinsured,  isrelationanswer,   isnri,   pmobile,   ppan,   imobile,   ipan,   firstname,   lastname,
                middlename,   day,   month,   year,   gender,   planjourney,   proposerstate,   advisorstatesame,   plan,   sumassured,   smokertype,   planoptions,   increasinglevel,
                ecs,   term,   ppt,   premiumterm,   premiumamount,
                rider,   rideramount,   minrider,   maxrider,   ridererror,   click,   generateillustrations,
                clickcontinue,   ifsccode,   bankaccno,   accholdername,   accounttype,   pennyalert,
                clickverify,   renewpremiumscreentitle,  paymentmethod,  drawdate,  fundsource,
                nomineescreentitle);
        Assert.assertTrue(createApplPage.eleNomineeNavText.isDisplayed(),"Not in nominee screen");
        createApplPage.addNominee(nomineefirstname,nomineelastname,nomineeday,nomineemonth,nomineeyear,nomineegender,relationshipwithproposer,nomineeshare,mwpPloicy);
        Thread.sleep(500);
        waitUtils.fluentWaitUntilElementVisible(driver,createApplPage.eleFormNext,60);
        createApplPage.nextForm();
        createApplPage.nextForm();

        //address
        if(commonUtils.isDisplayed(driver,createApplPage.eleAddressNavText)) {
            Assert.assertTrue(createApplPage.eleAddressNavText.isDisplayed());
            createApplPage.addAddress(addressscreentitle,typeofaddress,addresspincode,address1,address2,address3,personalDetailsscreentitle);
        }

        //personal
        perInfo = new PersonalInfoPage(driver);
        existingPolicyPage = new ExistingPolicyPage(driver);
        if(commonUtils.isDisplayed(driver,createApplPage.elePersonalInfoNavText)) {
            Assert.assertTrue(createApplPage.elePersonalInfoNavText.isDisplayed());
            System.out.println("In health screen");
            perInfo.fillPersonal(emailaddressValidations,maritalStatus,fathersNameOrSpouseName,mothersName,MaidenName);
            if(! new BaseTest().isWeb()) {
                waitUtils.fluentWaitUntilElementVisible(driver,perInfo.eleEmailNextBtn,80);
                commonUtils.chooseActionButton(perInfo.eleEmailNextBtn);
                if (commonUtils.isDisplayed(driver,perInfo.eleEmailNextBtn)) {
                    commonUtils.chooseActionButton(perInfo.eleEmailNextBtn);
                }
            }

            if(new BaseTest().isWeb()) {
                waitUtils.waitUntilVisible(driver,existingPolicyPage.eleDoItLaterBtn,30);
                commonUtils.chooseActionButton(existingPolicyPage.eleDoItLaterBtn);
            }
            else if(new BaseTest().isIOS()) {
                System.out.println("mobile existig policy ---------->>>>");
                try {
                    waitUtils.fluentWaitUntilElementVisible(driver,existingPolicyPage.eleExistingPolicySection,50);
                    WebElement ele = ((AppiumDriver)driver).findElementByAccessibilityId("policyDoItLaterBtn policyNextButton");
                    waitUtils.wait2Seconds();
                    ((IOSElement)ele).findElementByIosClassChain("**/XCUIElementTypeOther[`label == \"policyNextButton\"`][2]").click();
                } catch (TimeoutException e) {
                    commonUtils.chooseActionButton(existingPolicyPage.eleExistingPolNextBtn);
                }

            }
            else if(new BaseTest().isAndroid()) {
                System.out.println("mobile existig policy ---------->>>>");
                Thread.sleep(2000);
                try {
                    WebElement ele = driver.findElement(By.xpath("(//android.view.ViewGroup[@content-desc=\"mainContainer\"])[5]/android.view.ViewGroup[2]/android.view.ViewGroup[2]"));
                    commonUtils.isDisplayed(driver,ele);
                    ((AndroidElement)ele).findElementByXPath("//android.widget.Button[@content-desc=\"policyNextButton\"]/android.view.ViewGroup").click();
                } catch (TimeoutException e){
                    commonUtils.scrollToElementAndClick(driver,existingPolicyPage.eleExistingPolNextBtn);
                    //commonUtils.chooseActionButton(existingPolicyPage.eleExistingPolNextBtn);
                } catch (NoSuchElementException e){
                    commonUtils.scrollToElementAndClick(driver,existingPolicyPage.eleExistingPolNextBtn);
                    //commonUtils.chooseActionButton(existingPolicyPage.eleExistingPolNextBtn);
                }
            }

        }
        if(new BaseTest().isWeb()) {
            commonUtils.scrollTillEndOfPage(driver);
        }
        waitUtils.waitUntilVisible(driver,perInfo.elePersonalInfoNextBtn,30);
        commonUtils.chooseActionButton(perInfo.elePersonalInfoNextBtn);

        //health
        healthPage = new HealthPoliciesPage(driver);
        waitUtils.waitUntilVisible(driver, healthPage.eleHealthInfoNavText,40);
        if(new BaseTest().isWeb()) {
            healthPage.inputWeight(weight);
        }

        /*if(new BaseTest().isWeb()) {
            commonUtils.scrollTillEndOfPage(driver);
        }*/
        /*waitUtils.waitUntilVisible(driver,healthPage.eleHealthPersNextBtn,30);
        commonUtils.chooseActionButton(healthPage.eleHealthPersNextBtn);
        if(new BaseTest().isWeb()) {
            waitUtils.waitUntilPageLoad(driver);
        }*/

        if(new BaseTest().isWeb()) {
            commonUtils.scrollTopOfPage(driver);
            waitUtils.waitForElementToBeClickable(driver,healthPage.eleCovidTab,30);
            commonUtils.chooseActionButton(healthPage.eleCovidTab);
        } else {
            waitUtils.waitUntilVisible(driver,healthPage.eleMedHistoryTab,30);
            commonUtils.chooseActionButton(healthPage.eleMedHistoryTab);
        }
        if(new BaseTest().isWeb()) {
            commonUtils.scrollTillEndOfPage(driver);
            commonUtils.scrollTillEndOfPage(driver);
        }
        waitUtils.waitUntilVisible(driver,healthPage.eleHealthPersNextBtn,30);
        commonUtils.chooseActionButton(healthPage.eleHealthPersNextBtn);
        if (new BaseTest().isWeb()) {
            waitUtils.waitUntilPageLoad(driver);
        }

        //rna
        rna = new ReviewAcceptPage(driver);
        waitUtils.wait10Seconds();
        waitUtils.waitUntilVisible(driver,rna.eleRnaNavText,80);
        Thread.sleep(5000);
        commonUtils.scrollTillEndOfPage(driver);
        while(!commonUtils.isDisplayed(driver,rna.eleAgreeCheckbox)) {
            commonUtils.scrollTillEndOfPage(driver);
        }
        commonUtils.scrollTillEndOfPage(driver);
        waitUtils.wait2Seconds();
        waitUtils.waitUntilVisible(driver,rna.eleAgreeCheckbox,50);
        commonUtils.chooseActionButton(rna.eleAgreeCheckbox);
        commonUtils.chooseActionButton(rna.eleSendForReviewBtn);
        waitUtils.waitUntilVisible(driver, rna.eleStatusReview, 40);

        if (new BaseTest().isWeb()) {
            waitUtils.waitUntilPageLoad(driver);
        }

        waitUtils.waitUntilVisible(driver,rna.eleStatusReview,40);
        if (new BaseTest().isWeb()) {
            commonUtils.chooseActionButton(rna.eleEnterOtpBtn);
        }
        rna.inputOtp("111111");
        waitUtils.waitUntilVisible(driver,rna.eleStatusAccept,40);

        waitUtils.waitUntilVisible(driver,rna.eleProceedBtn,30);
        Thread.sleep(3000);
        commonUtils.chooseActionButton(rna.eleProceedBtn);
        waitUtils.waitUntilVisible(driver,rna.elePaymentNavText,40);
        Thread.sleep(3000);
        System.out.println("Payment screen-wait");
        //Assert.assertTrue(rna.elePaymentNavText.isDisplayed(),"Payment screen is not displayed");
        System.out.println("Payment screen-title");
    }

    public void gotoCheque(WebDriver driver, String username, String password, String policy, String leadid, String proposersame,
                           String isnri, String pmobile, String ppan, String firstname, String lastname,
                           String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                           String ecs, String term, String ppt, String premiumterm, String premiumamount,
                           String clickcontinue, String ifsccode, String bankaccno, String accounttype, String pennyalert,
                           String clickverify, String paymentmethod, String drawdate, String fundsource,
                           String nomineescreentitle, String nomineefirstname, String nomineelastname, String nomineeday, String nomineemonth, String nomineeyear, String nomineegender, String relationshipwithproposer, String typeofaddress, String addresspincode, String address1, String address2, String address3, String personalDetailsscreentitle,
                           String PersonalEmailId, String PersonalMaritalStatus, String FatherSpouseName,
                           String MotherName, String MaidenName, String Qualification, String Occupation
            , String SpouseAnnualIncome, String AnnualIncome, String addressscreentitle, String nomineeshare, String ismwppolicy) throws Exception {

        createApplPage = new CreateApplPage(driver);
        captureEmailIdPage = new CaptureEmailIdPage(driver);
        existingPolicyPage = new ExistingPolicyPage(driver);
        qualificationPage = new QualificationPage(driver);
        occupationPage = new OccupationPage(driver);
        lifestylePage = new LifestylePage(driver);
        chequePage = new ChequePage(driver);

        createApplPage.chooseSignAndGoToLeadIdScreen(username, password, policy);
        createApplPage.fillLeadIdAndProceed(leadid, proposersame, isnri);
        waitUtils.wait2Seconds();
        createApplPage.captureMobilePanAndProceed(pmobile, ppan);
        createApplPage.prefillDetails(firstname, lastname, middlename, day, month, year, gender);
        System.out.println(planjourney);
        waitUtils.implicitWait(driver, 20000);
        createApplPage.choosePlan(planjourney);
        //createApplPage.choosePlanSelectProceedButton();
        waitUtils.waitForElementToBeVisible(driver, createApplPage.elePlanSelectionNavText);
        createApplPage.fillPlanDetails(planjourney, proposerstate, advisorstatesame, plan);
        createApplPage.createQuote(sumassured, smokertype, planoptions, increasinglevel, ecs, term, ppt, premiumterm, premiumamount);
        commonUtils.selectButtonByName(clickcontinue, driver);
        ivPage = new InstaVerifyPage(driver);

        commonUtils.scrollTopOfPage(driver);
        waitUtils.waitUntilVisible(driver,ivPage.instaVerifyScreenTitle,50);

        if(INSTA_VERIFY_FLAG == false) {
            waitUtils.waitForElementToBeVisible(driver, ivPage.instaVerifyScreenTitle);
            commonUtils.chooseActionButton(ivPage.photoVerificationTab);
            waitUtils.waitForElementToBeVisible(driver, ivPage.photoVerificationText);
            if(new BaseTest().isWeb()) {
                commonUtils.scrollToElementAndClick(driver,ivPage.eleInstVerifyDoItLaterBtn);
            } else {
                commonUtils.chooseActionButton(ivPage.eleInstVerifyDoItLaterBtn);

            }
        } else {
            try {
                ivPage.instaVerifyPage();
            } catch (Exception e){
                //
            }
        }

        waitUtils.waitForElementToBeVisible(driver, createApplPage.eleBankNavText, 50, "Didnt navigate to bank details screen");
        createApplPage.fillBankDetails(ifsccode, bankaccno, accounttype, clickverify, pennyalert);
        createApplPage.fillRenewalDetails(paymentmethod, drawdate, fundsource, premiumamount, premiumterm, nomineescreentitle);
        createApplPage.fillNomineeDetails( nomineefirstname, nomineelastname, nomineeday, nomineemonth, nomineeyear, nomineegender,relationshipwithproposer);
        createApplPage.fillAddressDetails( typeofaddress, addresspincode, address1, address2, address3, personalDetailsscreentitle);
        waitUtils.implicitWait(driver,10000);
        lifestylePage.fillPersonalDetails(PersonalEmailId, PersonalMaritalStatus, FatherSpouseName, MotherName, MaidenName, Qualification, Occupation, AnnualIncome, SpouseAnnualIncome);
        //captureEmailIdPage.capturedEmailID(emailaddressValidations, maritalStatus, fathersNameOrSpouseName, mothersName, qualification, occupation, employeerName, nameOfBusinessOrduties, typeOfOrganization, designation, annualIncome);
        //commonUtils.selectButtonByName("DO IT LATER ", driver);
        chequePage.selectPersonalInfoButton();
        //commonUtils.clickIfEnabled(driver,lifestylePage.elePURPOSEOFINSURANCE);
        lifestylePage.elePURPOSEOFINSURANCE.click();
        lifestylePage.elePURPOSEOFINSURANCENextBtn.click();
        waitUtils.waitForElementToBeClickable(driver,lifestylePage.elePersonalDetailsWeight,20);
        lifestylePage.elePersonalDetailsWeight.click();
        lifestylePage.elePersonalDetailsWeight.sendKeys("65");
        commonUtils.scrollTillEndOfPage(driver);
        lifestylePage.elePersonalDetailsSaveBtn.click();
        waitUtils.waitForElementToBeVisible(driver,lifestylePage.eleNarcoticsYesBtn,20,"Element is not visible at lifestyle screen");
        commonUtils.scrollTillEndOfPage(driver);
        lifestylePage.eleLifestyleContinueBtn.click();
        waitUtils.waitForElementToBeVisible(driver,chequePage.eleFamilyMedicalDiseaseOpt,20,"Element not visible at Family Medical");
        commonUtils.scrollTillEndOfPage(driver);
        lifestylePage.eleLifestyleContinueBtn.click();
        commonUtils.scrollTillEndOfPage(driver);
        waitUtils.waitForElementToBeVisible(driver,chequePage.eleCovid19DetailsOpt,20,"Element not visible");
        lifestylePage.eleLifestyleContinueBtn.click();
        Assert.assertTrue(rna.eleRnaNavText.isDisplayed());
        System.out.println(("APPLNS NO ------" + rna.eleApplNumberValue.getText()));
        Assert.assertNotNull(rna.eleApplNumberValue.getText());
        System.out.println(("APPLNS sum ------" + rna.eleSumAssuredValue.getText()));
        Assert.assertNotNull(rna.eleSumAssuredValue.getText());
        System.out.println(("APPLNS premium ------" + rna.elePremiumAmountValue.getText()));
        Assert.assertNotNull(rna.elePremiumAmountValue.getText());

        commonUtils.scrollTillEndOfPage(driver);
        commonUtils.chooseActionButton(rna.eleAgreeCheckbox);
        commonUtils.chooseActionButton(rna.eleSendForReviewBtn);
        waitUtils.waitUntilVisible(driver, rna.eleStatusReview, 40);

        if (new BaseTest().isWeb()) {
            waitUtils.waitUntilPageLoad(driver);
        }

        waitUtils.waitUntilVisible(driver,rna.eleStatusReview,40);
        if (new BaseTest().isWeb()) {
            commonUtils.chooseActionButton(rna.eleEnterOtpBtn);
        }
        rna.inputOtp("111111");
        waitUtils.waitUntilVisible(driver,rna.eleStatusAccept,40);
        commonUtils.chooseActionButton(rna.eleProceedBtn);
        waitUtils.waitUntilVisible(driver,rna.elePaymentNavText,40);
        Assert.assertTrue(rna.elePaymentNavText.isDisplayed(),"Payment screen is not displayed");
    }

    public void gotoPaymentSummary(WebDriver driver,String username, String password, String policy, String leadid, String proposersame,
                                   String relationwithinsured,String isrelationanswer, String isnri, String pmobile, String ppan, String imobile, String ipan, String firstname, String lastname,
                                   String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                   String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                   String rider, String rideramount, String minrider, String maxrider, String ridererror, String click, String generateillustrations,
                                   String clickcontinue, String ifsccode, String bankaccno, String accholdername, String accounttype, String pennyalert,
                                   String clickverify, String renewpremiumscreentitle,String paymentmethod,String drawdate,String fundsource,
                                   String nomineescreentitle , String nomineefirstname,String nomineelastname,String nomineeday,String nomineemonth,String nomineeyear,String nomineegender,String relationshipwithproposer,String nomineeshare,
                                   String mwpPloicy,String addressscreentitle,String typeofaddress ,String addresspincode ,String address1 ,String address2 ,String address3 ,String personalDetailsscreentitle ,String cityName ,
                                   String preferredLanguage ,String alernateNumber ,String resTelephoneNumber ,String emailaddressValidations ,String maritalStatus ,String
                                           fathersNameOrSpouseName ,String mothersName ,String MaidenName,String qualification ,String occupation ,String employeerName ,String
                                           nameOfBusinessOrduties ,String typeOfOrganization ,String designation ,String annualIncome ,String policyStatus ,String exPolicyscreenTitle ,String exNameofInsurer ,String
                                           exSumAssured ,String expolicyNumber ,String exyearOfApplication ,String exbasePlan ,String exannualpremium ,String medicalPolicy ,String expolicystatus ,String
                                           refPolicyscreenTitle ,String refinsurerName ,String refsumAssured ,String refreason ,String refinsurerName1 ,String refsumAssured1 ,String refreason1 ,String
                                           refinsurerName2 ,String refsumAssured2 ,String refreason2 ,String refinsurerName3 ,String refsumAssured3 ,String refreason3 ,String
                                           refinsurerName4 ,String refsumAssured4 ,String refreason4 ,String policyPurposeScreen ,String purposeOption1 ,String purposeOption2 ,String purposeOption3 ,String
                                           healthDetailsScreen ,String height,String 	weight,String 	weightchange,String symptomsDetails ,String testsDetails ,String covidContactDetails ,String quarantineDetails ,String healthDetails ,String
                                           pastTravelContry ,String pastTravelCity ,String pastTravelArrivalDay ,String pastTravelArraivalMonth ,String pastTravelArraivalYear ,String
                                           pastTravelDepartureDay ,String pastTravelDepartureMonth ,String pastTravelDepartureYear ,String futureTravelCountry ,String futureTravelCity ,String
                                           futureTravelDepartureDay ,String futureTravelDepartureMonth ,String futureTravelDepartureYear ,String futureInternedDuration ,String
                                           covidVaccinationFirstDoseDay ,String covidVaccinationFirstDoseMonth ,String covidVaccinationFirstDoseYear ,String covidVaccinationSecondDoseDay ,String
                                           covidVaccinationSecondDoseMonth ,String covidVaccinationSecondDoseYear ,String covidVaccineName ,String postVaccineDetails ,String
                                           covidOccupation ,String medicalSpeciality ,String exactNatureOfDuties ,String nameOfHealthCareFacility ,String
                                           addressOfHealthCareFacility ,String healthAuthorityRegistered ,String covidWardDetails ,String diagnoseDay ,String
                                           diagnoseMonth ,String diagnoseYear ,String daignoseTestName ,String receivedCovid19Test1 ,String receivedCovid19Test2 ,String receivedCovid19Test3 ,String
                                           admissionDay ,String admissionMonth ,String admissionYear ,String dischargeDay ,String dischargeMonth ,String dischargeYear ,String
                                           covidInfectionDetails ,String covidSymptoms1 ,String covidSymptoms2 ,String covidSymptoms3 ,String recoveryDay ,String recoveryMonth ,String recoveryYear ,String
                                           testsName ,String testTakenDay ,String testTakenMonth ,String testTakenYear ,String certifiedDetails,String PolicyNumber, String PolicyAmount) throws InterruptedException,IOException {

        //nominee
        createApplPage = gotoNominee( driver,  username,   password,   policy,   leadid,   proposersame,
                relationwithinsured,  isrelationanswer,   isnri,   pmobile,   ppan,   imobile,   ipan,   firstname,   lastname,
                middlename,   day,   month,   year,   gender,   planjourney,   proposerstate,   advisorstatesame,   plan,   sumassured,   smokertype,   planoptions,   increasinglevel,
                ecs,   term,   ppt,   premiumterm,   premiumamount,
                rider,   rideramount,   minrider,   maxrider,   ridererror,   click,   generateillustrations,
                clickcontinue,   ifsccode,   bankaccno,   accholdername,   accounttype,   pennyalert,
                clickverify,   renewpremiumscreentitle,  paymentmethod,  drawdate,  fundsource,
                nomineescreentitle);
        Assert.assertTrue(createApplPage.eleNomineeNavText.isDisplayed(),"Not in nominee screen");
        createApplPage.addNominee(nomineefirstname,nomineelastname,nomineeday,nomineemonth,nomineeyear,nomineegender,relationshipwithproposer,nomineeshare,mwpPloicy);
        Thread.sleep(500);
        waitUtils.fluentWaitUntilElementVisible(driver,createApplPage.eleFormNext,60);
        createApplPage.nextForm();
        createApplPage.nextForm();

        //address
        if(commonUtils.isDisplayed(driver,createApplPage.eleAddressNavText)) {
            Assert.assertTrue(createApplPage.eleAddressNavText.isDisplayed());
            createApplPage.addAddress(addressscreentitle,typeofaddress,addresspincode,address1,address2,address3,personalDetailsscreentitle);
        }

        //personal
        perInfo = new PersonalInfoPage(driver);
        existingPolicyPage = new ExistingPolicyPage(driver);
        if(commonUtils.isDisplayed(driver,createApplPage.elePersonalInfoNavText)) {
            Assert.assertTrue(createApplPage.elePersonalInfoNavText.isDisplayed());
            System.out.println("In health screen");
            perInfo.fillPersonal(emailaddressValidations,maritalStatus,fathersNameOrSpouseName,mothersName,MaidenName);
            if(! new BaseTest().isWeb()) {
                waitUtils.fluentWaitUntilElementVisible(driver,perInfo.eleEmailNextBtn,80);
                commonUtils.chooseActionButton(perInfo.eleEmailNextBtn);
                if (commonUtils.isDisplayed(driver,perInfo.eleEmailNextBtn)) {
                    commonUtils.chooseActionButton(perInfo.eleEmailNextBtn);
                }
            }

            if(new BaseTest().isWeb()) {
                waitUtils.waitUntilVisible(driver,existingPolicyPage.eleDoItLaterBtn,30);
                commonUtils.chooseActionButton(existingPolicyPage.eleDoItLaterBtn);
            }
            else if(new BaseTest().isIOS()) {
                System.out.println("mobile existig policy ---------->>>>");
                try {
                    waitUtils.fluentWaitUntilElementVisible(driver,existingPolicyPage.eleExistingPolicySection,50);
                    WebElement ele = ((AppiumDriver)driver).findElementByAccessibilityId("policyDoItLaterBtn policyNextButton");
                    waitUtils.wait2Seconds();
                    ((IOSElement)ele).findElementByIosClassChain("**/XCUIElementTypeOther[`label == \"policyNextButton\"`][2]").click();
                } catch (TimeoutException e) {
                    commonUtils.chooseActionButton(existingPolicyPage.eleExistingPolNextBtn);
                }

            }
            else if(new BaseTest().isAndroid()) {
                System.out.println("mobile existig policy ---------->>>>");
                Thread.sleep(2000);
                try {
                    WebElement ele = driver.findElement(By.xpath("(//android.view.ViewGroup[@content-desc=\"mainContainer\"])[5]/android.view.ViewGroup[2]/android.view.ViewGroup[2]"));
                    commonUtils.isDisplayed(driver,ele);
                    ((AndroidElement)ele).findElementByXPath("//android.widget.Button[@content-desc=\"policyNextButton\"]/android.view.ViewGroup").click();
                } catch (TimeoutException e){
                    commonUtils.scrollToElementAndClick(driver,existingPolicyPage.eleExistingPolNextBtn);
                    //commonUtils.chooseActionButton(existingPolicyPage.eleExistingPolNextBtn);
                } catch (NoSuchElementException e){
                    commonUtils.scrollToElementAndClick(driver,existingPolicyPage.eleExistingPolNextBtn);
                    //commonUtils.chooseActionButton(existingPolicyPage.eleExistingPolNextBtn);
                }
            }

        }
        if(new BaseTest().isWeb()) {
            commonUtils.scrollTillEndOfPage(driver);
        }
        waitUtils.waitUntilVisible(driver,perInfo.elePersonalInfoNextBtn,30);
        commonUtils.chooseActionButton(perInfo.elePersonalInfoNextBtn);

        //health
        healthPage = new HealthPoliciesPage(driver);
        waitUtils.waitUntilVisible(driver, healthPage.eleHealthInfoNavText,40);
        if(new BaseTest().isWeb()) {
            healthPage.inputWeight(weight);
        }

        /*if(new BaseTest().isWeb()) {
            commonUtils.scrollTillEndOfPage(driver);
        }*/
        /*waitUtils.waitUntilVisible(driver,healthPage.eleHealthPersNextBtn,30);
        commonUtils.chooseActionButton(healthPage.eleHealthPersNextBtn);
        if(new BaseTest().isWeb()) {
            waitUtils.waitUntilPageLoad(driver);
        }*/

        if(new BaseTest().isWeb()) {
            commonUtils.scrollTopOfPage(driver);
            waitUtils.waitForElementToBeClickable(driver,healthPage.eleCovidTab,30);
            commonUtils.chooseActionButton(healthPage.eleCovidTab);
        } else {
            waitUtils.waitUntilVisible(driver,healthPage.eleMedHistoryTab,30);
            commonUtils.chooseActionButton(healthPage.eleMedHistoryTab);
        }
        if(new BaseTest().isWeb()) {
            commonUtils.scrollTillEndOfPage(driver);
            commonUtils.scrollTillEndOfPage(driver);
        }
        waitUtils.waitUntilVisible(driver,healthPage.eleHealthPersNextBtn,30);
        commonUtils.chooseActionButton(healthPage.eleHealthPersNextBtn);
        if (new BaseTest().isWeb()) {
            waitUtils.waitUntilPageLoad(driver);
        }

        //rna
        rna = new ReviewAcceptPage(driver);
        waitUtils.wait10Seconds();
        waitUtils.waitUntilVisible(driver,rna.eleRnaNavText,80);
        Thread.sleep(5000);
        commonUtils.scrollTillEndOfPage(driver);
        while(!commonUtils.isDisplayed(driver,rna.eleAgreeCheckbox)) {
            commonUtils.scrollTillEndOfPage(driver);
        }
        commonUtils.scrollTillEndOfPage(driver);
        waitUtils.wait2Seconds();
        waitUtils.waitUntilVisible(driver,rna.eleAgreeCheckbox,50);
        commonUtils.chooseActionButton(rna.eleAgreeCheckbox);
        commonUtils.chooseActionButton(rna.eleSendForReviewBtn);
        waitUtils.waitUntilVisible(driver, rna.eleStatusReview, 40);

        if (new BaseTest().isWeb()) {
            waitUtils.waitUntilPageLoad(driver);
        }

        waitUtils.waitUntilVisible(driver,rna.eleStatusReview,40);
        if (new BaseTest().isWeb()) {
            commonUtils.chooseActionButton(rna.eleEnterOtpBtn);
        }
        rna.inputOtp("111111");
        waitUtils.waitUntilVisible(driver,rna.eleStatusAccept,40);
        waitUtils.waitUntilVisible(driver,rna.eleProceedBtn,30);
        commonUtils.chooseActionButton(rna.eleProceedBtn);
        waitUtils.waitUntilVisible(driver,rna.elePaymentNavText,40);
        Thread.sleep(3000);
        System.out.println("Payment screen-wait");
        Assert.assertTrue(rna.elePaymentNavText.isDisplayed(),"Payment screen is not displayed");
        System.out.println("Payment screen-title");

        waitUtils.wait2Seconds();
        commonUtils.scrollTillEndOfPage(driver);
        System.out.println("Payment screen-scroll to bottom");
        commonUtils.scrollToElementAndClick(driver,winBackPage.eleWinBackDrpBtn);
        System.out.println("Payment screen-WinBack menu option selected");
        waitUtils.wait2Seconds();
        winBackPage.inputPaymentPolicyNumber(PolicyNumber);
        waitUtils.wait2Seconds();
        winBackPage.inputPaymentPolicyAmount(PolicyAmount);
        waitUtils.wait2Seconds();

        commonUtils.scrollToElementAndClick(driver,winBackPage.elePolicySaveBtn);
        commonUtils.scrollTillEndOfPage(driver);
        commonUtils.scrollToElementAndClick(driver,winBackPage.elePolicyRedeemBtn);
        //Assert.assertEquals(paymentSummaryPage.elePaymentModeTitle.getText(),"10.0 Payment Mode");

    }



    public void gotoHealthDetails(WebDriver driver,String username, String password, String policy, String leadid, String proposersame,
                                  String isnri, String pmobile, String ppan, String firstname, String lastname,
                                  String middlename, String day, String month, String year, String gender, String planjourney, String proposerstate, String advisorstatesame, String plan, String sumassured, String smokertype, String planoptions, String increasinglevel,
                                  String ecs, String term, String ppt, String premiumterm, String premiumamount,
                                  String clickcontinue, String ifsccode, String bankaccno, String accounttype, String pennyalert,
                                  String clickverify,String paymentmethod,String drawdate,String fundsource,
                                  String nomineescreentitle,String nomineefirstname,String nomineelastname,String nomineeday,String nomineemonth,String nomineeyear,String nomineegender,String relationshipwithproposer,String typeofaddress, String addresspincode, String address1, String address2, String address3, String personalDetailsscreentitle,
                                  String PersonalEmailId, String PersonalMaritalStatus, String FatherSpouseName,
                                  String MotherName, String MaidenName, String Qualification, String Occupation
            , String SpouseAnnualIncome, String AnnualIncome,String addressscreentitle, String nomineeshare,String ismwppolicy) throws Exception {

        createApplPage = new CreateApplPage(driver);
        captureEmailIdPage = new CaptureEmailIdPage(driver);
        existingPolicyPage = new ExistingPolicyPage(driver);
        qualificationPage = new QualificationPage(driver);
        occupationPage = new OccupationPage(driver);
        lifestylePage = new LifestylePage(driver);
        createApplPage.chooseSignAndGoToLeadIdScreen(username, password, policy);
        createApplPage.fillLeadIdAndProceed(leadid, proposersame, isnri);
        waitUtils.wait2Seconds();
        createApplPage.captureMobilePanAndProceed(pmobile, ppan);
        createApplPage.prefillDetails(firstname, lastname, middlename, day, month, year, gender);
        System.out.println(planjourney);
        waitUtils.implicitWait(driver, 20000);
        createApplPage.choosePlan(planjourney);
        waitUtils.waitForElementToBeVisible(driver, createApplPage.elePlanSelectionNavText);
        createApplPage.fillPlanDetails(planjourney, proposerstate, advisorstatesame, plan);
        createApplPage.createQuote(sumassured, smokertype, planoptions, increasinglevel, ecs, term, ppt, premiumterm, premiumamount);
        commonUtils.selectButtonByName(clickcontinue, driver);
        waitUtils.waitForElementToBeVisible(driver, createApplPage.instaVerifyScreenTitle, 50, "didn't navigate to the insta verify page");
        waitUtils.wait2Seconds();
        createApplPage.skipInstaVerifyPage();

        waitUtils.waitForElementToBeVisible(driver, createApplPage.eleBankNavText, 50, "Didnt navigate to bank details screen");
        createApplPage.fillBankDetails(ifsccode, bankaccno, accounttype, clickverify, pennyalert);
        createApplPage.fillRenewalDetails(paymentmethod, drawdate, fundsource, premiumamount, premiumterm, nomineescreentitle);
        createApplPage.fillNomineeDetails( nomineefirstname, nomineelastname, nomineeday, nomineemonth, nomineeyear, nomineegender,relationshipwithproposer);
        if(commonUtils.isDisplayed(driver,createApplPage.eleAddressNavText)) {
            Assert.assertTrue(createApplPage.eleAddressNavText.isDisplayed());
            createApplPage.fillAddressDetails( typeofaddress, addresspincode, address1, address2, address3, personalDetailsscreentitle);
        }
        waitUtils.implicitWait(driver,10000);

        //Personal Details
        lifestylePage.fillPersonalDetails(PersonalEmailId, PersonalMaritalStatus, FatherSpouseName, MotherName, MaidenName, Qualification, Occupation, AnnualIncome, SpouseAnnualIncome);
        //captureEmailIdPage.capturedEmailID(emailaddressValidations, maritalStatus, fathersNameOrSpouseName, mothersName, qualification, occupation, employeerName, nameOfBusinessOrduties, typeOfOrganization, designation, annualIncome);

        if(! new BaseTest().isWeb()) {
            waitUtils.fluentWaitUntilElementVisible(driver,perInfo.eleEmailNextBtn,80);
            commonUtils.chooseActionButton(perInfo.eleEmailNextBtn);
            if (commonUtils.isDisplayed(driver,perInfo.eleEmailNextBtn)) {
                commonUtils.chooseActionButton(perInfo.eleEmailNextBtn);
            }
        }

        if(new BaseTest().isWeb()) {
            waitUtils.waitUntilVisible(driver,existingPolicyPage.eleDoItLaterBtn,30);
            commonUtils.chooseActionButton(existingPolicyPage.eleDoItLaterBtn);
        }
        else if(new BaseTest().isIOS()) {
            System.out.println("mobile existig policy ---------->>>>");
            try {
                waitUtils.fluentWaitUntilElementVisible(driver,existingPolicyPage.eleExistingPolicySection,50);
                WebElement ele = ((AppiumDriver)driver).findElementByAccessibilityId("policyDoItLaterBtn policyNextButton");
                waitUtils.wait2Seconds();
                ((IOSElement)ele).findElementByIosClassChain("**/XCUIElementTypeOther[`label == \"policyNextButton\"`][2]").click();
            } catch (TimeoutException e) {
                commonUtils.chooseActionButton(existingPolicyPage.eleExistingPolNextBtn);
            }

        }
        else if(new BaseTest().isAndroid()) {
            System.out.println("mobile existig policy ---------->>>>");
            Thread.sleep(2000);
            try {
                WebElement ele = driver.findElement(By.xpath("(//android.view.ViewGroup[@content-desc=\"mainContainer\"])[5]/android.view.ViewGroup[2]/android.view.ViewGroup[2]"));
                commonUtils.isDisplayed(driver,ele);
                ((AndroidElement)ele).findElementByXPath("//android.widget.Button[@content-desc=\"policyNextButton\"]/android.view.ViewGroup").click();
            } catch (TimeoutException e){
                commonUtils.chooseActionButton(existingPolicyPage.eleExistingPolNextBtn);
            } catch (NoSuchElementException e){
                commonUtils.chooseActionButton(existingPolicyPage.eleExistingPolNextBtn);
            }
        }
        if(new BaseTest().isWeb()) {
            commonUtils.clickIfEnabled(driver,lifestylePage.elePURPOSEOFINSURANCE);
            lifestylePage.elePURPOSEOFINSURANCE.click();
            commonUtils.scrollTillEndOfPage(driver);
        }
        lifestylePage.elePURPOSEOFINSURANCENextBtn.click();
        waitUtils.waitForElementToBeClickable(driver,lifestylePage.elePersonalDetailsWeight);
        lifestylePage.elePersonalDetailsWeight.click();
    }

}
