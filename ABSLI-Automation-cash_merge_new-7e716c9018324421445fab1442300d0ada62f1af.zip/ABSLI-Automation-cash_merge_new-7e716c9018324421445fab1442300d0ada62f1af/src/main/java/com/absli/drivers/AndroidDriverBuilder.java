package com.absli.drivers;

import com.absli.enums.PlatformName;
import com.absli.runner.TestRunner;
import com.absli.utils.PropertiesUtils;
import com.ssts.pcloudy.Connector;
import com.ssts.pcloudy.Version;
import com.ssts.pcloudy.appium.PCloudyAppiumSession;
import com.ssts.pcloudy.dto.appium.booking.BookingDtoDevice;
import com.ssts.pcloudy.dto.device.MobileDevice;
import com.ssts.pcloudy.exception.ConnectError;
import com.ssts.util.reporting.ExecutionResult;
import com.ssts.util.reporting.printers.HtmlFilePrinter;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.AndroidMobileCapabilityType;
import io.appium.java_client.remote.MobileCapabilityType;
import com.absli.config.AndroidDeviceModel;
import com.absli.config.DeviceConfig;
import com.absli.utils.FileUtility;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import com.absli.helpers.models.DeviceContext;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import static com.absli.logger.LoggingManager.logMessage;


public class AndroidDriverBuilder extends DeviceConfig {

    AndroidDriver driver;
    PropertiesUtils prop = new PropertiesUtils();
    public static PCloudyAppiumSession pCloudySession;
    //AppiumDriver<WebElement> driver;
    int deviceBookDuration = 10;
    String pCloudyEmailId = "sridevi.parvatikar@digital.datamatics.com";
    String pCloudyApiKey = "sndm59j4b2swkw9c2shppm4n";
    Boolean autoSelectDevices = true;
    public static File ReportsFolder = new File("Reports");
    public static Map<String, DeviceContext> allDeviceContexts = new HashMap<String, DeviceContext>();


    public AndroidDriver setupDriver(String model, String app) throws IOException {
        DesiredCapabilities androidCapabilities = new DesiredCapabilities();
        AndroidDeviceModel device = readAndroidDeviceConfig().getAndroidDeviceByName(model);
        logMessage("Received the " + model + " device configuration for execution");
        setExecutionPlatform(model);

        androidCapabilities.setCapability(MobileCapabilityType.DEVICE_NAME, device.getDeviceName());
        androidCapabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, device.getPlatformName());
        androidCapabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, device.getPlatformVersion());
        androidCapabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, device.getAutomationName());
        //androidCapabilities.setCapability(MobileCapabilityType.NO_RESET, true);
        //androidCapabilities.setCapability(MobileCapabilityType.FULL_RESET, false);
        //androidCapabilities.setCapability("dontStopAppOnReset", true);
        androidCapabilities.setCapability("unicodeKeyboard", false);
        androidCapabilities.setCapability("resetKeyboard", false);



        switch (app) {
            case "APP":
                androidCapabilities.setCapability(MobileCapabilityType.APP, FileUtility.getFile(device.getApp()).getAbsolutePath());
                androidCapabilities.setCapability(AndroidMobileCapabilityType.APP_PACKAGE, device.getPackageName());
                androidCapabilities.setCapability(AndroidMobileCapabilityType.APP_ACTIVITY, device.getActivity());
                androidCapabilities.setCapability(AndroidMobileCapabilityType.APP_WAIT_ACTIVITY, device.getActivity());
                androidCapabilities.setCapability(AndroidMobileCapabilityType.APP_WAIT_DURATION, 30000);
                break;
            case "MOBILEBROWSER":
                androidCapabilities.setCapability(MobileCapabilityType.BROWSER_NAME, PlatformName.CHROME);
                break;
            default:
                logMessage("Invalid application type");
        }

        driver = new AndroidDriver(new URL(prop.getProperties("appiumServerUrl")), androidCapabilities);
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        logMessage("Android driver has been created for the " + model + " device");
        return driver;
    }

    public AppiumDriver<WebElement> setupPcloudyAndroidAppDriver(String model, String app,String myDeviceContext) throws IOException, ConnectError, InterruptedException {

        DeviceContext myContext = TestRunner.allDeviceContexts.get(myDeviceContext);
        System.out.println("mydevice context:  =========="+myContext);
        try {

            myContext.report.beginTestcase("@Before Class");
            myContext.report.addComment("@Before Class : " + getClass().getName());
            myContext.driver = new AndroidDriver<WebElement>(myContext.endpoint, myContext.capabilities);
            myContext.report.addStep("Launch App", myContext.capabilities.toString(), myContext.endpoint.toString(), ExecutionResult.Pass);
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        myContext = TestRunner.allDeviceContexts.get(myDeviceContext);
        myContext.report.beginTestcase("@Before Test: " + this.getClass().getName());
        myContext.report.addStep("@BeforeTest", null, null, ExecutionResult.Pass);

        BookingDtoDevice aDevice = myContext.device;
        myContext.deviceFolder = new File(TestRunner.ReportsFolder, aDevice.manufacturer + " " + aDevice.model + " " + aDevice.version);
        myContext.snapshotsFolder = new File(myContext.deviceFolder, "Snapshots");
        myContext.snapshotsFolder.mkdirs();
        myContext.report.addStep("Create Report Folders", null, null, ExecutionResult.Pass);

        return myContext.driver;

    }

    public AppiumDriver<WebElement> setupPcloudyAndroidBrowserDriver(String model, String app,String myDeviceContext) throws IOException, ConnectError, InterruptedException {

        DeviceContext myContext = TestRunner.allDeviceContexts.get(myDeviceContext);
        System.out.println("mydevice context:  =========="+myContext);
        try {
            myContext.report.beginTestcase("@Before Class");
            myContext.report.addComment("@Before Class : " + getClass().getName());
            myContext.driver = new AndroidDriver<WebElement>(myContext.endpoint, myContext.capabilities);
            myContext.report.addStep("Launch App", myContext.capabilities.toString(), myContext.endpoint.toString(), ExecutionResult.Pass);
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        myContext = TestRunner.allDeviceContexts.get(myDeviceContext);
        myContext.report.beginTestcase("@Before Test: " + this.getClass().getName());
        myContext.report.addStep("@BeforeTest", null, null, ExecutionResult.Pass);

        BookingDtoDevice aDevice = myContext.device;
        myContext.deviceFolder = new File(TestRunner.ReportsFolder, aDevice.manufacturer + " " + aDevice.model + " " + aDevice.version);
        myContext.snapshotsFolder = new File(myContext.deviceFolder, "Snapshots");
        myContext.snapshotsFolder.mkdirs();
        myContext.report.addStep("Create Report Folders", null, null, ExecutionResult.Pass);

        return myContext.driver;
        /*AndroidDeviceModel device = readAndroidDeviceConfig().getAndroidDeviceByName(model);
        setExecutionPlatform(model);

        Connector pCloudyCONNECTOR = new Connector();


        // User Authentication over pCloudy
        String authToken = pCloudyCONNECTOR.authenticateUser(pCloudyEmailId, pCloudyApiKey);

        ArrayList<MobileDevice> selectedDevices = new ArrayList<>();
        if (autoSelectDevices)
            selectedDevices.addAll(pCloudyCONNECTOR.chooseDevices(authToken, "android", new Version("9.*.*"), new Version("10.*.*"), 1));
        else
            selectedDevices.add(pCloudyCONNECTOR.chooseSingleDevice(authToken, "android"));

        // Book the selected devices in pCloudy
        String sessionName = "Appium Session Android Browser" + new Date();
        BookingDtoDevice bookedDevice = pCloudyCONNECTOR.AppiumApis().bookDevicesForAppium(authToken, selectedDevices, deviceBookDuration, sessionName)[0];
        System.out.println("########## Devices booked successfully ##########");

        pCloudyCONNECTOR.AppiumApis().initAppiumHubForBrowser(authToken, bookedDevice.capabilities.browserName);

        // Get the endpoint from pCloudy
        URL endpoint = pCloudyCONNECTOR.AppiumApis().getAppiumEndpoint(authToken);
        System.out.println("Appium Endpoint:" + endpoint);

        DesiredCapabilities capabilities = new DesiredCapabilities();
        //capabilities.setCapability(MobileCapabilityType.BROWSER_NAME,bookedDevice.capabilities.browserName);
        capabilities.setCapability("newCommandTimeout", 600);
        capabilities.setCapability("deviceName", bookedDevice.capabilities.deviceName);
        capabilities.setCapability("platformName", bookedDevice.capabilities.platformName);
        capabilities.setCapability("appPackage", "com.android.chrome");
        capabilities.setCapability("appActivity", "org.chromium.chrome.browser.ChromeTabbedActivity");
        capabilities.setCapability("acceptAlerts", true);
        driver = new AndroidDriver(endpoint, capabilities);
        System.out.println("########## Initializing AndroidDriver at " + endpoint);
        if (driver == null) {
            logMessage("########## Error creating Android driver ##########");
        }
        return driver;*/

    }

    public void releasepCloudyDevices(String myDeviceContext) throws Exception {

        DeviceContext myContext = TestRunner.allDeviceContexts.get(myDeviceContext);

        /*myContext.report.beginTestcase("@AfterClass");
        myContext.report.addStep("@AfterClass : " + getClass().getName(), null, null, ExecutionResult.Pass);
        myContext.driver.quit();
        myContext.report.addStep("Quit Driver Object", null, null, ExecutionResult.Pass);*/
        if(myContext.pCloudySession != null) {
            try {
                myContext.report.beginTestcase("@After Test: " + this.getClass().getName());
                myContext.pCloudySession.releaseSessionNow();
                myContext.report.addStep("Release Appium Session", null, null, ExecutionResult.Pass);

            } catch (ConnectError | IOException e) {
                myContext.report.addStep("Error Running TestCase", null, e.getMessage(), ExecutionResult.Fail);
                e.printStackTrace();

            } finally {
                HtmlFilePrinter printer = new HtmlFilePrinter(new File(myContext.deviceFolder, myContext.deviceFolder.getName() + ".html"));
                printer.printSingleRunReport(myContext.report);
            }
        }

    }

    public void quitDrivers(String myDeviceContext) throws Exception {

        DeviceContext myContext = TestRunner.allDeviceContexts.get(myDeviceContext);

        myContext.report.beginTestcase("@AfterClass");
        myContext.report.addStep("@AfterClass : " + getClass().getName(), null, null, ExecutionResult.Pass);
        myContext.driver.quit();
        myContext.report.addStep("Quit Driver Object", null, null, ExecutionResult.Pass);
    }



    /*public AndroidDriver setupPCloudyDriver(String model, String app) throws IOException {
        DesiredCapabilities androidCapabilities = new DesiredCapabilities();
        AndroidDeviceModel device = readAndroidDeviceConfig().getAndroidDeviceByName(model);
        logMessage("Received the " + model + " device configuration for execution");
        setExecutionPlatform(model);

        DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setCapability("pCloudy_Username", "sridevi@techjini.com");
        capabilities.setCapability("pCloudy_ApiKey", "sndm59j4b2swkw9c2shppm4n");
        capabilities.setCapability("pCloudy_DurationInMinutes", 10);
        capabilities.setCapability("newCommandTimeout", 600);
        capabilities.setCapability("launchTimeout", 90000);
        capabilities.setCapability("pCloudy_DeviceFullName", device.getDeviceName());
        capabilities.setCapability("platformVersion", device.getPlatformVersion());
        capabilities.setCapability("platformName", device.getPlatformName());
        capabilities.setCapability("automationName", "appium");
        capabilities.setCapability("pCloudy_WildNet", "false");
        capabilities.setCapability("pCloudy_EnableVideo", "true");
        capabilities.setCapability("pCloudy_EnablePerformanceData", "false");
        capabilities.setCapability("pCloudy_EnableDeviceLogs", "true");

        switch (app) {
            case "APP":
                capabilities.setCapability("pCloudy_ApplicationName", FileUtility.getFile(device.getApp()).getAbsolutePath());
                capabilities.setCapability("appPackage", device.getPackageName());
                capabilities.setCapability("appActivity", device.getActivity());

                break;
            case "MOBILEBROWSER":
                capabilities.setCapability(MobileCapabilityType.BROWSER_NAME, PlatformName.CHROME);
                break;
            default:
                logMessage("Invalid application type");
        }
        AndroidDriver<WebElement> androidDriver = new AndroidDriver<WebElement>(new URL(prop.getProperties("pCloudyAppiumUrl")), capabilities);
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        logMessage("Android driver has been created for the " + model + " device");

        return androidDriver;
    }*/

    /*public AndroidDriver<WebElement> getPCloudySessionTest1(String model, String name, String deviceName) throws InterruptedException, IOException, ConnectError {

        DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setCapability("pCloudy_Username", "sridevi.parvatikar@digital.datamatics.com");
        capabilities.setCapability("pCloudy_ApiKey", "sndm59j4b2swkw9c2shppm4n");
        capabilities.setCapability("newCommandTimeout", 600);
        capabilities.setCapability("launchTimeout", 90000);

        capabilities.setCapability("pCloudy_ApplicationName", "Leap.apk");
        capabilities.setCapability("pCloudy_DurationInMinutes", 10);
        capabilities.setCapability("pCloudy_DeviceManufacturer", deviceName);
        capabilities.setCapability("pCloudy_DeviceVersion", "9.0.0");
        //capabilities.setCapability("pCloudy_DeviceFullName", "Apple_iPhone6S_Ios_11.2.0");
        capabilities.setCapability("platformVersion", "9.0");
        capabilities.setCapability("acceptAlerts", true);
        capabilities.setCapability("automationName", "appium");
        capabilities.setCapability("platformName", "Android");
        capabilities.setCapability("appPackage", "com.absli.leap");
        capabilities.setCapability("appActivity", "com.absli.leap.MainActivity");

        try {
            driver = new AndroidDriver<WebElement>(new URL(prop.getProperties("pCloudyAppiumUrl")), capabilities);
            driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
            if (driver == null) {
                logMessage("android driver is null  *********   driver not created");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        logMessage("Android driver has been created for the " + deviceName + " device");
        return driver;
    }
*/
        public void relauchApp (AndroidDriver driver){
            //DesiredCapabilities androidCapabilities = new DesiredCapabilities();
            //androidCapabilities.setCapability(AndroidMobileCapabilityType.APP_ACTIVITY,"com.absli.leap.MainActivity");
            driver.closeApp();
            ((AndroidDriver)driver).launchApp();
            //driver.navigate().refresh();
        }
    }

