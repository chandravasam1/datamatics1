package com.absli.drivers;

import io.github.bonigarcia.wdm.WebDriverManager;
import com.absli.config.DeviceConfig;
import com.absli.enums.PlatformName;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.safari.SafariOptions;
import tests.BaseTest;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class WebDriverBuilder extends DeviceConfig {

    WebDriver driver;

    public WebDriver setupDriver(String platformName) {
        if (platformName.equalsIgnoreCase(PlatformName.CHROME.name())) {
            WebDriverManager.chromedriver().setup();
            if(BaseTest.HEADLESS == null)
                BaseTest.HEADLESS = "false";
            if (BaseTest.HEADLESS.equalsIgnoreCase("true")) {
                ChromeOptions options = new ChromeOptions();
                options.addArguments("--headless");
                Map<String, Object> prefs = new HashMap<>();
                prefs.put("profile.default_content_setting_values.media_stream_mic", 1);
                prefs.put("profile.default_content_setting_values.media_stream_camera", 1);
                prefs.put("profile.default_content_setting_values.geolocation", 1);
                prefs.put("profile.default_content_setting_values.notifications", 1);
                options.setExperimentalOption("prefs", prefs);

                driver = new ChromeDriver(options);
            }
            else {
                ChromeOptions options = new ChromeOptions();
                Map<String, Object> prefs = new HashMap<>();
                prefs.put("profile.default_content_setting_values.media_stream_mic", 1);
                prefs.put("profile.default_content_setting_values.media_stream_camera", 1);
                prefs.put("profile.default_content_setting_values.geolocation", 1);
                prefs.put("profile.default_content_setting_values.notifications", 1);
                options.setExperimentalOption("prefs", prefs);
                driver = new ChromeDriver(options);
            }
        } else if (platformName.equalsIgnoreCase(PlatformName.FIREFOX.name())) {
            WebDriverManager.firefoxdriver().setup();
            if (BaseTest.HEADLESS.equalsIgnoreCase("true")) {
                FirefoxOptions options = new FirefoxOptions();
                options.addArguments("--headless");
                driver = new FirefoxDriver(options);
            }
            else
                driver = new FirefoxDriver();
        } else if (platformName.equalsIgnoreCase(PlatformName.SAFARI.name())) {
            driver = new SafariDriver();
        } else if (platformName.equalsIgnoreCase(PlatformName.IE.name())) {
            WebDriverManager.iedriver().setup();
            driver = new InternetExplorerDriver();
        }
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        setExecutionPlatform(platformName);
        driver.manage().window().maximize();
        return driver;
    }

    public void urlRedirect(String url,WebDriver driver) {
        driver.get(url);
    }

}
