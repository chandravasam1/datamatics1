package com.absli.drivers;

import com.absli.enums.PlatformName;
import com.absli.runner.TestRunner;
import com.absli.utils.PropertiesUtils;
import com.ssts.pcloudy.Connector;
import com.ssts.pcloudy.Version;
import com.ssts.pcloudy.appium.PCloudyAppiumSession;
import com.ssts.pcloudy.dto.appium.booking.BookingDtoDevice;
import com.ssts.pcloudy.dto.device.MobileDevice;
import com.ssts.pcloudy.dto.file.PDriveFileDTO;
import com.ssts.pcloudy.exception.ConnectError;
import com.ssts.util.reporting.ExecutionResult;
import com.ssts.util.reporting.printers.HtmlFilePrinter;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.remote.MobileCapabilityType;
import com.absli.config.DeviceConfig;
import com.absli.config.IOSDeviceModel;
import com.absli.utils.FileUtility;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import com.absli.helpers.models.DeviceContext;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import static com.absli.logger.LoggingManager.logMessage;

public class IOSDriverBuilder extends DeviceConfig {

    IOSDriver driver;
    PropertiesUtils prop = new PropertiesUtils();
    PCloudyAppiumSession pCloudySession;
    //AppiumDriver<WebElement> driver;
    int deviceBookDuration = 10;
    String pCloudyEmailId = "sridevi.parvatikar@digital.datamatics.com";
    String pCloudyApiKey = "sndm59j4b2swkw9c2shppm4n";
    Boolean autoSelectDevices = true;


    public IOSDriver setupDriver(String model,String app) throws IOException {
        DesiredCapabilities iosCapabilities = new DesiredCapabilities();
        IOSDeviceModel device = readIOSDeviceConfig().getIOSDeviceByName(model);
        logMessage("Received the " + model + " device configuration for execution");
        setExecutionPlatform(model);

        iosCapabilities.setCapability(MobileCapabilityType.DEVICE_NAME, device.getDeviceName());
        iosCapabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, device.getPlatformName());
        iosCapabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, device.getPlatformVersion());
        iosCapabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, device.getAutomationName());
        iosCapabilities.setCapability(MobileCapabilityType.UDID, device.getUdid());
        iosCapabilities.setCapability(MobileCapabilityType.NO_RESET, device.isReset());
        iosCapabilities.setCapability(MobileCapabilityType.FULL_RESET, device.isFullreset());


        iosCapabilities.setCapability(MobileCapabilityType.AUTO_WEBVIEW,false);

        switch (app) {
            case "APP":
                iosCapabilities.setCapability(MobileCapabilityType.APP, FileUtility.getFile(device.getApp()).getAbsolutePath());
                break;
            case "MOBILEBROWSER":
                iosCapabilities.setCapability(MobileCapabilityType.BROWSER_NAME, PlatformName.SAFARI);
                break;
            default:
                logMessage("Invalid application type");
        }
        driver = new IOSDriver(new URL(prop.getProperties("appiumServerUrl")), iosCapabilities);
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        logMessage("IOS driver has been created for the " + model + " device");
        return driver;
    }

    /*public PCloudyAppiumSession getPCloudySession(String model, String app) throws IOException, ConnectError, InterruptedException {
        IOSDeviceModel device = readIOSDeviceConfig().getIOSDeviceByName(model);
        setExecutionPlatform(model);

        Connector con = new Connector("https://device.pcloudy.com/api/");

        // User Authentication over pCloudy
        String authToken = con.authenticateUser(pCloudyEmailId, pCloudyApiKey);

        System.out.println("Auth token ------" + authToken);

        // Select IPA in pCloudy Cloud Drive
        File fileToBeUploaded = new File("./Leap_Resigned1619418029.ipa");
        PDriveFileDTO alreadyUploadedApp = con.getAvailableAppIfUploaded(authToken, fileToBeUploaded.getName());
        if (alreadyUploadedApp == null) {
            System.out.println("Uploading App: " + fileToBeUploaded.getAbsolutePath());
            PDriveFileDTO uploadedApp = con.uploadApp(authToken, fileToBeUploaded, false);
            System.out.println("App uploaded");
            alreadyUploadedApp = new PDriveFileDTO();
            alreadyUploadedApp.file = uploadedApp.file;
        } else {
            System.out.println("App already present. Not uploading... ");
        }

        ArrayList<MobileDevice> selectedDevices = new ArrayList<>();
        if (autoSelectDevices)
            selectedDevices.addAll(con.chooseDevices(authToken, "ios", new Version("12.*.*"), new Version("14.*.*"), 1));
        else
            selectedDevices.add(con.chooseSingleDevice(authToken, "ios"));

        // Book the selected devices in pCloudy
        String sessionName = "Appium Session IOS APP" + new Date();
        BookingDtoDevice bookedDevice = con.AppiumApis().bookDevicesForAppium(authToken, selectedDevices, deviceBookDuration, sessionName)[0];
        System.out.println("Devices booked successfully");


        con.AppiumApis().initAppiumHubForApp(authToken, alreadyUploadedApp);

        pCloudySession = new PCloudyAppiumSession(con, authToken, bookedDevice);
        return pCloudySession;
    }
*/
    /*public AppiumDriver<WebElement> getIOSAppDriver(PCloudyAppiumSession pCloudySession,String model) throws InterruptedException, IOException, ConnectError {
        IOSDeviceModel device = readIOSDeviceConfig().getIOSDeviceByName(model);
        setExecutionPlatform(model);
        DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setCapability("newCommandTimeout", 600);
        capabilities.setCapability("launchTimeout", 90000);
        capabilities.setCapability("deviceName", pCloudySession.getDto().capabilities.deviceName);
        capabilities.setCapability("platformName", "IOS");
        //capabilities.setCapability("pCloudy_ApplicationName", FileUtility.getFile(device.getApp()).getAbsolutePath());
        capabilities.setCapability("bundleId", "com.absli.leap");

        URL appiumEndpoint = pCloudySession.getConnector().AppiumApis().getAppiumEndpoint(pCloudySession.getAuthToken());
        driver = new IOSDriver(appiumEndpoint, capabilities);
        System.out.println("########## Initing IOSDriver at" + appiumEndpoint);
        return driver;
    }*/
    public AppiumDriver<WebElement> setupPcloudyIOSAppDriver(String model, String app,String myDeviceContext) throws IOException, ConnectError, InterruptedException {

        DeviceContext myContext = TestRunner.allDeviceContexts.get(myDeviceContext);
        System.out.println("mydevice context:  =========="+myContext);
        try {

            myContext.report.beginTestcase("@Before Class");
            myContext.report.addComment("@Before Class : " + getClass().getName());
                myContext.driver = new IOSDriver<WebElement>(myContext.endpoint, myContext.capabilities);
            myContext.report.addStep("Launch App", myContext.capabilities.toString(), myContext.endpoint.toString(), ExecutionResult.Pass);
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        myContext = TestRunner.allDeviceContexts.get(myDeviceContext);
        myContext.report.beginTestcase("@BeforeTest: " + this.getClass().getName());
        myContext.report.addStep("@BeforeTest", null, null, ExecutionResult.Pass);

        BookingDtoDevice aDevice = myContext.device;
        myContext.deviceFolder = new File(TestRunner.ReportsFolder, aDevice.manufacturer + " " + aDevice.model + " " + aDevice.version);
        myContext.snapshotsFolder = new File(myContext.deviceFolder, "Snapshots");
        myContext.snapshotsFolder.mkdirs();
        myContext.report.addStep("Create Report Folders", null, null, ExecutionResult.Pass);

        return myContext.driver;

    }

    public AppiumDriver<WebElement> setupPcloudyIOSBrowserDriver(String model, String app,String myDeviceContext) throws IOException, ConnectError, InterruptedException {

        DeviceContext myContext = TestRunner.allDeviceContexts.get(myDeviceContext);
        System.out.println("mydevice context:  =========="+myContext);
        try {

            myContext.report.beginTestcase("@Before Class");
            myContext.report.addComment("@Before Class : " + getClass().getName());
            myContext.driver = new IOSDriver<WebElement>(myContext.endpoint, myContext.capabilities);
            myContext.report.addStep("Launch App", myContext.capabilities.toString(), myContext.endpoint.toString(), ExecutionResult.Pass);
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        myContext = TestRunner.allDeviceContexts.get(myDeviceContext);
        myContext.report.beginTestcase("@Before Test: " + this.getClass().getName());
        myContext.report.addStep("@BeforeTest", null, null, ExecutionResult.Pass);

        BookingDtoDevice aDevice = myContext.device;
        myContext.deviceFolder = new File(TestRunner.ReportsFolder, aDevice.manufacturer + " " + aDevice.model + " " + aDevice.version);
        myContext.snapshotsFolder = new File(myContext.deviceFolder, "Snapshots");
        myContext.snapshotsFolder.mkdirs();
        myContext.report.addStep("Create Report Folders", null, null, ExecutionResult.Pass);

        return myContext.driver;
        /*IOSDeviceModel device = readIOSDeviceConfig().getIOSDeviceByName(model);
        setExecutionPlatform(model);

        Connector pCloudyCONNECTOR = new Connector();

        // User Authentication over pCloudy
        String authToken = pCloudyCONNECTOR.authenticateUser(pCloudyEmailId, pCloudyApiKey);

        ArrayList<MobileDevice> selectedDevices = new ArrayList<>();
        if (autoSelectDevices)
            selectedDevices.addAll(pCloudyCONNECTOR.chooseDevices(authToken, "ios", new Version("12.*.*"), new Version("14.*.*"), 1));
        else
            selectedDevices.add(pCloudyCONNECTOR.chooseSingleDevice(authToken, "ios"));

        // Book the selected devices in pCloudy
        String sessionName = "Appium Session IOS Browser" + new Date();
        BookingDtoDevice bookedDevice = pCloudyCONNECTOR.AppiumApis().bookDevicesForAppium(authToken, selectedDevices, deviceBookDuration, sessionName)[0];
        System.out.println("########## Devices booked successfully ##########");

        pCloudyCONNECTOR.AppiumApis().initAppiumHubForBrowser(authToken, bookedDevice.capabilities.browserName);

        // Get the endpoint from pCloudy
        URL endpoint = pCloudyCONNECTOR.AppiumApis().getAppiumEndpoint(authToken);
        System.out.println("Appium Endpoint:" + endpoint);

        DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setCapability("browserName","mobilesafari");
        capabilities.setCapability("newCommandTimeout", 600);
        capabilities.setCapability("deviceName", bookedDevice.capabilities.deviceName);
        capabilities.setCapability("platformName", bookedDevice.capabilities.platformName);
        //capabilities.setCapability("app","Safari.ipa");
        //capabilities.setCapability("bundleId","com.apple.mobilesafari");
        capabilities.setCapability("acceptAlerts", true);
        driver = new IOSDriver(endpoint, capabilities);
        System.out.println("########## Initializing AndroidDriver at " + endpoint);
        if (driver == null) {
            logMessage("########## Error creating IOS driver ##########");
        }
        return driver;*/

    }


    /*public IOSDriver setupPCloudyDriver(String model, String app) throws IOException {
        DesiredCapabilities androidCapabilities = new DesiredCapabilities();
        IOSDeviceModel device = readIOSDeviceConfig().getIOSDeviceByName(model);
        logMessage("Received the " + model + " device configuration for execution");
        setExecutionPlatform(model);

        DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setCapability("pCloudy_Username", "sridevi.parvatikar@digital.datamatics.com");
        capabilities.setCapability("pCloudy_ApiKey", "sndm59j4b2swkw9c2shppm4n");
        capabilities.setCapability("pCloudy_DurationInMinutes", 10);
        capabilities.setCapability("newCommandTimeout", 600);
        capabilities.setCapability("launchTimeout", 90000);
        capabilities.setCapability("pCloudy_DeviceManufacturer", "APPLE");
        capabilities.setCapability("pCloudy_DeviceVersion", "14.0.1");
        capabilities.setCapability("platformVersion", "14.0.1");
        capabilities.setCapability("platformName", "ios");
        capabilities.setCapability("acceptAlerts", true);
        capabilities.setCapability("automationName", "XCUITest");
        capabilities.setCapability("pCloudy_WildNet", "false");
        capabilities.setCapability("pCloudy_EnableVideo", "true");
        capabilities.setCapability("pCloudy_EnablePerformanceData", "false");
        capabilities.setCapability("pCloudy_EnableDeviceLogs", "true");

        switch (app) {
            case "APP":
                capabilities.setCapability("pCloudy_ApplicationName", FileUtility.getFile(device.getApp()).getAbsolutePath());
                break;
            case "MOBILEBROWSER":
                capabilities.setBrowserName("Safari");

                //capabilities.setCapability(MobileCapabilityType.BROWSER_NAME, PlatformName.SAFARI);
                break;
            default:
                logMessage("Invalid application type");
        }
        driver = new IOSDriver(new URL(prop.getProperties("pCloudyAppiumUrl")), capabilities);
        driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
        logMessage("IOS driver has been created for the " + model + " device");
        return driver;
    }*/

    public void releasepCloudyDevices(String myDeviceContext) throws Exception {
        DeviceContext myContext = TestRunner.allDeviceContexts.get(myDeviceContext);

        if(myContext.pCloudySession != null) {
            try {
                myContext.report.beginTestcase("@After Test: " + this.getClass().getName());
                myContext.pCloudySession.releaseSessionNow();
                myContext.report.addStep("Release Appium Session", null, null, ExecutionResult.Pass);

            } catch (ConnectError | IOException e) {
                myContext.report.addStep("Error Running TestCase", null, e.getMessage(), ExecutionResult.Fail);
                e.printStackTrace();

            } finally {
                HtmlFilePrinter printer = new HtmlFilePrinter(new File(myContext.deviceFolder, myContext.deviceFolder.getName() + ".html"));
                printer.printSingleRunReport(myContext.report);
            }
        }
    }

    public void quitDrivers(String myDeviceContext) throws Exception {
        DeviceContext myContext = TestRunner.allDeviceContexts.get(myDeviceContext);

        myContext.report.beginTestcase("@AfterClass");
        myContext.report.addStep("@AfterClass : " + getClass().getName(), null, null, ExecutionResult.Pass);
        myContext.driver.quit();
        myContext.report.addStep("Quit Driver Object", null, null, ExecutionResult.Pass);

    }



    public void relauchApp(IOSDriver driver) {
        driver.closeApp();
        driver.launchApp();

    }
}
