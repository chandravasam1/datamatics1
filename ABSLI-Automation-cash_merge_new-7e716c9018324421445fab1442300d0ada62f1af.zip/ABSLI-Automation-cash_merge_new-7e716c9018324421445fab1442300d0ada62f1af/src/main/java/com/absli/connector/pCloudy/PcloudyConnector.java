package com.absli.connector.pCloudy;

import com.absli.helpers.models.AuthResultModel;
import com.absli.helpers.models.ResignDownloadResultModel;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class PcloudyConnector {

    public static String getAuthToken() throws IOException {
//        String[] command = {"curl", "-u", "sridevi.parvatikar@digital.datamatics.com:sndm59j4b2swkw9c2shppm4n", "https://device.pcloudy.com/api/access"};

        //String command = "curl -u \"sridevi.parvatikar@digital.datamatics.com:sndm59j4b2swkw9c2shppm4n\" https://device.pcloudy.com/api/access";

        String command =
                "curl -u sridevi.parvatikar@digital.datamatics.com:sndm59j4b2swkw9c2shppm4n https://device.pcloudy.com/api/access";
        String result = processBuilder1(command);
        System.out.println(result);

        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,false);
        AuthResultModel rm =  mapper.readValue(result, AuthResultModel.class);
        System.out.println("Auth token file from json extracted:"+rm.getResult().getToken());

        return rm.getResult().getToken();

    }

    public static void getAvailableApps() throws IOException {
        String token = getAuthToken();

        String[] command = {"curl", "-H", "Content-Type:application/json","-d", "\'{\"token\": \"" + token + "\", \"limit\": \"5\", \"filter\": \"all\"}\'", "https://device.pcloudy.com/api/drive"};


        //String command = "curl -H \"Content-Type:application/json\" -d '{\"token\":\"" + token + "\",\"limit\": 5, \"filter\": \"all\"}' https://device.pcloudy.com/api/drive";

        System.out.println(command.toString());
        String result = processBuilder(command);
        System.out.println(result);
    }


    public static String processBuilder(String[] curlCommand) {
        String result = null;
        String authToken = "gzk97n8vw964hxrr4ntpbmym";

        //String[] command = {"curl", "-H", "Content-Tyepe:application/json", "-d", "{\"token\":\"gzk97n8vw964hxrr4ntpbmym\",\"filename\": \"./Leap.ipa\"}", "https://device.pcloudy.com/api/resign/initiate"};

        java.lang.ProcessBuilder process = new java.lang.ProcessBuilder(curlCommand);
        Process p;
        try
        {
            p = process.start();
            BufferedReader reader =  new BufferedReader(new InputStreamReader(p.getInputStream()));
            StringBuilder builder = new StringBuilder();
            String line = null;
            while ( (line = reader.readLine()) != null) {
                builder.append(line);
                builder.append(System.getProperty("line.separator"));
            }
            result = builder.toString();
            System.out.print(result);

        }
        catch (IOException e)
        {   System.out.print("error");
            e.printStackTrace();
        }


        return result;
    }

    public static String processBuilder1(String command) throws IOException {
        /*String command =
                "curl -u sridevi.parvatikar@digital.datamatics.com:sndm59j4b2swkw9c2shppm4n https://device.pcloudy.com/api/access";*/
        /*Process process = Runtime.getRuntime().exec(command);
        process.getInputStream();
        process.getOutputStream();
        process.
        process.destroy();*/

        String result = null;

        ProcessBuilder process = new ProcessBuilder(command.split(" "));
        Process p;
        try
        {
            p = process.start();
            BufferedReader reader =  new BufferedReader(new InputStreamReader(p.getInputStream()));
            StringBuilder builder = new StringBuilder();
            String line = null;
            while ( (line = reader.readLine()) != null) {
                builder.append(line);
                builder.append(System.getProperty("line.separator"));
            }
            result = builder.toString();
            System.out.print(result);

        }
        catch (IOException e)
        {   System.out.print("error");
            e.printStackTrace();
        }


        return result;

    }


}
