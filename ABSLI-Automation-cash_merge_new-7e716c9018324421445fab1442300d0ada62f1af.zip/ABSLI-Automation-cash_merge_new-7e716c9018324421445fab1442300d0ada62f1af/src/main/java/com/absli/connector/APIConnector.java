package com.absli.connector;
//import io.restassured.RestAssured;

public class APIConnector {

    public void getResponse() {
        //RestAssured.get("");
    }
}
