package com.absli.helpers.models;

public class ResignResultModel {

    private  ResignModel result;


    public ResignModel getResult() {
        return result;
    }

    public void setResult(ResignModel result) {
        this.result = result;
    }

}
