package com.absli.helpers.models;

public class ResignModel {

        private String token;
        private String resign_token;
        private String resign_filename;
        private String code;

        public String getToken() {
            return token;
        }

        public void setToken(String token) {
            this.token = token;
        }

        public String getResign_token() {
            return resign_token;
        }

        public void setResign_token(String resign_token) {
            this.resign_token = resign_token;
        }

        public String getResign_filename() {
            return resign_filename;
        }

        public void setResign_filename(String resign_filename) {
            this.resign_filename = resign_filename;
        }

        public String getCode() {
            return code;
        }

        public void setCode(String code) {
            this.code = code;
        }


    }

