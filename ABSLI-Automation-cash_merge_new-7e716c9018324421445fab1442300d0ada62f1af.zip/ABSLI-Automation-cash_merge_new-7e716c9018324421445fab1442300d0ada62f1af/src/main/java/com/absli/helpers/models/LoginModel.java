package com.absli.helpers.models;

import java.util.Arrays;

public class LoginModel {
    private String testCase;
    private String username;
    private String password;
    private LoginModel[] loginModels;

    public LoginModel(LoginModel[] loginModels) {
        this.loginModels = loginModels;
    }

    public LoginModel[] getLoginModels() {
        return loginModels;
    }

    public LoginModel() {}

    public void setLoginModels(LoginModel[] loginModels) {
        this.loginModels = loginModels;
    }

    public LoginModel getDataByTestCase(String testCase) {
        return Arrays.stream(loginModels).filter(loginModel -> loginModel.getTestCase().equalsIgnoreCase(testCase)).findFirst().get();

    }

    public String getTestCase() {
        return testCase;
    }

    public void setTestCase(String testCase) {
        this.testCase = testCase;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }


}
