package com.absli.helpers.models;

public class ResignIPADownloadModel {

    private String token;
    private String file;
    private String resign_file;
    private String code;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getFile() {
        return file;
    }

    public void setFile(String file) {
        this.file = file;
    }

    public String getResign_file() {
        return resign_file;
    }

    public void setResign_file(String resign_file) {
        this.resign_file = resign_file;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

}


/*
{"result":{"token":"gzk97n8vw964hxrr4ntpbmym","file":".\/Leap.ipa","resign_file":".\/Leap.Resigned1621690413.ipa","code":200}}

*/


