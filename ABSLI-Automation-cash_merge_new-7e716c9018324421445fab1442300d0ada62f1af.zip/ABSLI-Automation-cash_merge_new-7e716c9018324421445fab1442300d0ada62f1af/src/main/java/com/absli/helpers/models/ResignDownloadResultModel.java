package com.absli.helpers.models;

public class ResignDownloadResultModel {


    private ResignIPADownloadModel result;


    public ResignIPADownloadModel getResult() {
        return result;
    }

    public void setResult(ResignIPADownloadModel result) {
        this.result = result;
    }

}
