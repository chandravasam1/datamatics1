package com.absli.helpers.models;

public class LeadIDControllerPojo {
    private String header;
    private String footer;
    private headerPojo headPojo;
    private footerPojo footPojo;

    public headerPojo getHeadPojo() {
        return headPojo;
    }

    public void setHeadPojo(headerPojo headPojo) {
        this.headPojo = headPojo;
    }

    public footerPojo getFootPojo() {
        return footPojo;
    }

    public void setFootPojo(footerPojo footPojo) {
        this.footPojo = footPojo;
    }

    public String getFooter() {
        return footer;
    }

    public void setFooter(String footer) {
        this.footer = footer;
    }
    public String getHeader() {
        return header;
    }
    public void setHeader(String header) {
        this.header = header;
    }

    public static class headerPojo {
        private String label;
        private Boolean visible;

        public String getLabel() {
            return label;
        }

        public void setLabel(String label) {
            this.label = label;
        }

        public Boolean getVisible() {
            return visible;
        }

        public void setVisible(Boolean visible) {
            this.visible = visible;
        }
    }

    public static class footerPojo {
        private String label;
        private Boolean visible;

        public String getLabel() {
            return label;
        }

        public void setLabel(String label) {
            this.label = label;
        }

        public Boolean getVisible() {
            return visible;
        }

        public void setVisible(Boolean visible) {
            this.visible = visible;
        }
    }

}
