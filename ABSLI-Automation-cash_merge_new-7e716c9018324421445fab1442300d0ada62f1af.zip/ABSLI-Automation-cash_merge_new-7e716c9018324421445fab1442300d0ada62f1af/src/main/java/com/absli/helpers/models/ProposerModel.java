package com.absli.helpers.models;

import java.util.Arrays;
public class ProposerModel {

    private String testCase;
    private String mobileNo;
    private String pan;
    private String leadId;
    private String firstName;
    private String lastName;
    private String middleName;
    private String gender;
    private String day;
    private String month;
    private String year;

    private String state;
    private String planName;
    private String smokerType;
    private String sumAssured;
    private String minSumAssured;
    private String ecs;
    private String policyTerm;
    private String productOptions;
    private String increasingLevel;
    private String ppt;


    public String getMinSumAssured() {
        return minSumAssured;
    }

    public void setMinSumAssured(String minSumAssured) {
        this.minSumAssured = minSumAssured;
    }



    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getPlanName() {
        return planName;
    }

    public void setPlanName(String planName) {
        this.planName = planName;
    }

    public String getSmokerType() {
        return smokerType;
    }

    public void setSmokerType(String smokerType) {
        this.smokerType = smokerType;
    }

    public String getSumAssured() {
        return sumAssured;
    }

    public void setSumAssured(String sumAssured) {
        this.sumAssured = sumAssured;
    }

    public String getEcs() {
        return ecs;
    }

    public void setEcs(String ecs) {
        this.ecs = ecs;
    }

    public String getPolicyTerm() {
        return policyTerm;
    }

    public void setPolicyTerm(String policyTerm) {
        this.policyTerm = policyTerm;
    }

    public String getProductOptions() {
        return productOptions;
    }

    public void setProductOptions(String productOptions) {
        this.productOptions = productOptions;
    }

    public String getIncreasingLevel() {
        return increasingLevel;
    }

    public void setIncreasingLevel(String increasingLevel) {
        this.increasingLevel = increasingLevel;
    }

    public String getPpt() {
        return ppt;
    }

    public void setPpt(String ppt) {
        this.ppt = ppt;
    }


    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }


    private ProposerModel[] proposerModels;


    public String getLeadId() {
        return leadId;
    }

    public void setLeadId(String leadId) {
        this.leadId = leadId;
    }
    public String getTestCase() {
        return testCase;
    }

    public void setTestCase(String testCase) {
        this.testCase = testCase;
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }

        public ProposerModel(ProposerModel[] proposerModels) {
            this.proposerModels = proposerModels;
        }

        public ProposerModel[] getProposerModels() {

        return proposerModels;
        }

        public ProposerModel() {}

        public void setProposerModels(com.absli.helpers.models.ProposerModel[] proposerModels) {
            this.proposerModels = proposerModels;
        }

        public ProposerModel getDataByTestCase(String testCase) {
            return Arrays.stream(proposerModels).filter(proposerModel -> proposerModel.getTestCase().equalsIgnoreCase(testCase)).findFirst().get();
        }

    public String getPan() {
        return pan;
    }

    public void setPan(String pan) {
        this.pan = pan;
    }



}



