package com.absli.helpers.dataProviders;

import com.absli.utils.ExcelUtils;
import com.absli.utils.PropertiesUtils;
import org.testng.annotations.DataProvider;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;

public class DataProviders {
    PropertiesUtils prop = new PropertiesUtils();

    @DataProvider(name = "dataNomineeProvider")
    public Iterator<Object[]> getNomineeTestData(Method method) throws IOException {
        ArrayList<Object[]> testData = new ExcelUtils().getNomineeDataFromExcel(prop.getProperties("testExcelSheet"), method.getName(), prop.getProperties("nomineeSheetName"));
        return testData.iterator();
    }

    @DataProvider(name = "dataNomineeValidationProvider")
    public Iterator<Object[]> getNomineeValTestData(Method method) throws IOException {
        ArrayList<Object[]> testData = new ExcelUtils().getNomineeDataFromExcel(prop.getProperties("testExcelSheet"), method.getName(), prop.getProperties("nomineeValSheetName"));
        return testData.iterator();
    }

    @DataProvider(name="dataAddressProvider")
    public Iterator<Object[]> getAddressTestData(Method method) throws IOException{
        ArrayList<Object[]> testData = new ExcelUtils().getAddressDataFromExcel(prop.getProperties("testExcelSheet"), method.getName(), prop.getProperties("AddAddressSheetName"));
        return testData.iterator();
    }

    @DataProvider(name = "dataPlanProvider")
    public Iterator<Object[]> getPlanTestData(Method method) throws IOException {
        ExcelUtils utils = new ExcelUtils();
        ArrayList<Object[]> testData = utils.getPlanDataFromExcel(prop.getProperties("testExcelSheet"),method.getName(),prop.getProperties("planSheetName"));
        return testData.iterator();
    }

    @DataProvider(name = "dataSignInProvider")
    public Iterator<Object[]> getSignInTestData(Method method) throws IOException {
        ArrayList<Object[]> testData = new ExcelUtils().getLoginDataFromExcel(prop.getProperties("testExcelSheet"),method.getName(),prop.getProperties("loginSheetName"));
        return testData.iterator();
    }

    @DataProvider(name = "dataProfileInProvider")
    public Iterator<Object[]> getProfileTestData(Method method) throws IOException {
        ArrayList<Object[]> testData = new ExcelUtils().getLoginDataFromExcel(prop.getProperties("testExcelSheet"),method.getName(),prop.getProperties("profileSheetName"));
        return testData.iterator();
    }

    @DataProvider(name = "dataMobilePanProvider")
    public Iterator<Object[]> getMobilePanTestData(Method method) throws IOException {
        ArrayList<Object[]> testData = new ExcelUtils().getMobilePanDataFromExcel(prop.getProperties("testExcelSheet"),method.getName(),prop.getProperties("captureMobilePanSheetName"));
        return testData.iterator();
    }

    @DataProvider(name = "dataInsuredMobilePanProvider")
    public Iterator<Object[]> getInsuredMobilePanTestData(Method method) throws IOException {
        ArrayList<Object[]> testData = new ExcelUtils().getMobilePanDataFromExcel(prop.getProperties("testExcelSheet"),method.getName(),prop.getProperties("insuredCaptureMobilePanSheetName"));
        return testData.iterator();
    }

    @DataProvider(name = "riderDataProvider")
    public Iterator<Object[]> getRiderTestData(Method method) throws IOException {
        prop = new PropertiesUtils();
        ArrayList<Object[]> testData = new ExcelUtils().getQuoteWithRiderDataFromExcel(prop.getProperties("testExcelSheet"),method.getName(),prop.getProperties("lifeshieldSheetName"));
        return testData.iterator();
    }

    @DataProvider(name = "quoteDataProvider")
    public Iterator<Object[]> getQuoteTestData(Method method) throws IOException {
        prop = new PropertiesUtils();
        ArrayList<Object[]> testData = ExcelUtils.getQuoteDataFromExcel(prop.getProperties("testExcelSheet"),method.getName(),prop.getProperties("lifeshieldSheetName"));
        return testData.iterator();
    }

    @DataProvider(name = "majorSamePrefillDataProvider")
    public Iterator<Object[]> getMajorSamePrefillTestData(Method method) throws IOException {
        prop = new PropertiesUtils();
        ArrayList<Object[]> testData = new ExcelUtils().getPrefillMajorSameDataFromExcel(prop.getProperties("testExcelSheet"),method.getName(),prop.getProperties("majorSameSheetName"));
        return testData.iterator();
    }

    @DataProvider(name = "majorDiffPrefillDataProvider")
    public Iterator<Object[]> getMajorDiffPrefillTestData(Method method) throws IOException {
        prop = new PropertiesUtils();
        ArrayList<Object[]> testData = new ExcelUtils().getPrefillMajorDiffDataFromExcel(prop.getProperties("testExcelSheet"),method.getName(),prop.getProperties("majorDiffSheetName"));
        return testData.iterator();
    }

    @DataProvider(name = "dataRenewProvider")
    public Iterator<Object[]> getRenewalTestData(Method method) throws IOException {
        prop = new PropertiesUtils();
        ArrayList<Object[]> testData = new ExcelUtils().getRenewalDataFromExcel(prop.getProperties("testExcelSheet"), method.getName(), prop.getProperties("renewalSheetName"));
        return testData.iterator();
    }


    @DataProvider(name = "dataBankProvider")
    public Iterator<Object[]> getBankTestData(Method method) throws IOException {
        prop = new PropertiesUtils();
        ArrayList<Object[]> testData = new ExcelUtils().getBankDataFromExcel(prop.getProperties("testExcelSheet"), method.getName(), prop.getProperties("bankSheetName"));
        return testData.iterator();
    }

    @DataProvider(name = "planDataProvider")
    public Iterator<Object[]> getTestData(Method method) throws IOException {
        prop = new PropertiesUtils();
        ExcelUtils utils = new ExcelUtils();
        ArrayList<Object[]> testData = utils.getPlanDataFromExcel(prop.getProperties("testExcelSheet"),method.getName(),prop.getProperties("planSheetName"));
        return testData.iterator();
    }
    @DataProvider(name = "dataEnachProvider")
    public  Iterator<Object[]> getEnachTestData(Method method) throws IOException {
        PropertiesUtils    prop = new PropertiesUtils();
        ArrayList<Object[]> testData = ExcelUtils.getEnachDataFromExcel(prop.getProperties("testExcelSheet"), method.getName(), prop.getProperties("enachRegistration"));
        return testData.iterator();
    }
    @DataProvider(name = "dataEmailProvider")
    public Iterator<Object[]> getCapturedEmailTestData(Method method) throws IOException {
        PropertiesUtils prop = new PropertiesUtils();
        ArrayList<Object[]> testData = ExcelUtils.getCapturedEmailTestData(prop.getProperties("testExcelSheet"), method.getName(), prop.getProperties("captureEmail"));
        return testData.iterator();
    }
    @DataProvider(name = "dataExistingPolicyProvider")
    public Iterator<Object[]> getExistingPolicyTestData(Method method) throws IOException {
        PropertiesUtils prop = new PropertiesUtils();
        ArrayList<Object[]> testData = ExcelUtils.getExistingPolicyTestData(prop.getProperties("testExcelSheet"), method.getName(), prop.getProperties("exPolicy"));
        return testData.iterator();
    }
    @DataProvider(name = "dataRefusedPolicyProvider")
    public Iterator<Object[]> getRefusedPolicyTestData(Method method) throws IOException {
        PropertiesUtils prop = new PropertiesUtils();
        ArrayList<Object[]> testData = ExcelUtils.getRefeusedPolicyTestData(prop.getProperties("testExcelSheet"), method.getName(), prop.getProperties("refusedPolicy"));
        return testData.iterator();
    }
    @DataProvider(name = "dataCovid19Provider")
    public Iterator<Object[]> getCovid19TestData(Method method) throws IOException {
        PropertiesUtils prop = new PropertiesUtils();
        ArrayList<Object[]> testData = ExcelUtils.getCovid19TestData(prop.getProperties("testExcelSheet"), method.getName(), prop.getProperties("covid_19_details"));
        return testData.iterator();
    }

    @DataProvider(name = "dataMedicalHistoryProvider")
    public Iterator<Object[]> getMedicalHistoryTestData(Method method) throws IOException {
        PropertiesUtils prop = new PropertiesUtils();
        ArrayList<Object[]> testData = ExcelUtils.getMedicalHistoryTestData(prop.getProperties("testExcelSheet"), method.getName(), prop.getProperties("medicalHistory"));
        return testData.iterator();
    }
    @DataProvider(name = "dataDocumentsUploadProvider")
    public Iterator<Object[]> getDocumentsUploadTestData(Method method) throws IOException {
        PropertiesUtils prop = new PropertiesUtils();
        ArrayList<Object[]> testData = ExcelUtils.getDocumnetsUploadTestData(prop.getProperties("testExcelSheet"), method.getName(), prop.getProperties("documentsSheet"));
        return testData.iterator();
    }
    @DataProvider(name = "dataInstaVerifyProvider")
    public Iterator<Object[]> getInstaVerifyTestData(Method method) throws IOException {
        PropertiesUtils prop = new PropertiesUtils();
        ArrayList<Object[]> testData = ExcelUtils.getInstaVerifyTestData(prop.getProperties("testExcelSheet"), method.getName(), prop.getProperties("instaVerifySheet"));
        return testData.iterator();
    }
    @DataProvider(name = "dataQualificationProvider")
    public Iterator<Object[]> getQualificationTestData(Method method) throws IOException {
        prop = new PropertiesUtils();
        ArrayList<Object[]> testData = new ExcelUtils().getQualificationDataFromExcel(prop.getProperties("testExcelSheet"), method.getName(), prop.getProperties("QualificationSheetName"));
        return testData.iterator();
    }
    @DataProvider(name = "dataOccupationProvider")
    public Iterator<Object[]> getOccupationTestData(Method method) throws IOException {
        prop = new PropertiesUtils();
        ArrayList<Object[]> testData = new ExcelUtils().getOccupationDataFromExcel(prop.getProperties("testExcelSheet"), method.getName(), prop.getProperties("OccupationSheetName"));
        return testData.iterator();
    }

    @DataProvider(name = "dataLifestyleProvider")
    public Iterator<Object[]> getLifestyleTestData(Method method) throws IOException {
        prop = new PropertiesUtils();
        ArrayList<Object[]> testData = new ExcelUtils().getLifestyleDataFromExcel(prop.getProperties("testExcelSheet"), method.getName(), prop.getProperties("LifestyleSheetName"));
        return testData.iterator();
    }

    @DataProvider(name = "rnaDataProvider")
    public Iterator<Object[]> getRnaTestData(Method method) throws IOException {
        prop = new PropertiesUtils();
        ArrayList<Object[]> testData = new ExcelUtils().getRnaDataFromExcel(prop.getProperties("testExcelSheet"), method.getName(), prop.getProperties("rnaSheetName"));
        return testData.iterator();
    }

    @DataProvider(name = "dataChequeProvider")
    public Iterator<Object[]> getChequeTestData(Method method) throws IOException {
        prop = new PropertiesUtils();
        ArrayList<Object[]> testData = new ExcelUtils().getChequeDataFromExcel(prop.getProperties("testExcelSheet"), method.getName(), prop.getProperties("ChequeSheetName"));
        return testData.iterator();
    }

    @DataProvider(name = "dataCashProvider")
    public Iterator<Object[]> getCashTestData(Method method) throws IOException {
        prop = new PropertiesUtils();
        ArrayList<Object[]> testData = new ExcelUtils().getCashDataFromExcel(prop.getProperties("testExcelSheet"), method.getName(), prop.getProperties("CashSheetName"));
        return testData.iterator();
    }

    @DataProvider(name = "dataWinBackProvider")
    public Iterator<Object[]> getWinBackTestData(Method method) throws IOException {
        prop = new PropertiesUtils();
        ArrayList<Object[]> testData = new ExcelUtils().getWinBackDataFromExcel(prop.getProperties("testExcelSheet"), method.getName(), prop.getProperties("WinBackSheetName"));
        return testData.iterator();
    }

    @DataProvider(name = "dataHealthDetailsProvider")
    public Iterator<Object[]> geHealthDetailsTestData(Method method) throws IOException {
        prop = new PropertiesUtils();
        ArrayList<Object[]> testData = new ExcelUtils().getHealthDetailsDataFromExcel(prop.getProperties("testExcelSheet"), method.getName(), prop.getProperties("HealthDetailsSheetName"));
        return testData.iterator();
    }

    @DataProvider(name = "dataAppSummaryProvider")
    public Iterator<Object[]> getAppSummaryTestData(Method method) throws IOException {
        prop = new PropertiesUtils();
        ArrayList<Object[]> testData = new ExcelUtils().getAppSummaryDataFromExcel(prop.getProperties("testExcelSheet"), method.getName(), prop.getProperties("AppSummarySheetName"));
        return testData.iterator();
    }

    @DataProvider(name = "dataPaymentSummaryProvider")
    public Iterator<Object[]> getPaymentSummaryTestData(Method method) throws IOException {
        prop = new PropertiesUtils();
        ArrayList<Object[]> testData = new ExcelUtils().getPaymentSummaryDataFromExcel(prop.getProperties("testExcelSheet"), method.getName(), prop.getProperties("PaymentSummarySheetName"));
        return testData.iterator();
    }

}
