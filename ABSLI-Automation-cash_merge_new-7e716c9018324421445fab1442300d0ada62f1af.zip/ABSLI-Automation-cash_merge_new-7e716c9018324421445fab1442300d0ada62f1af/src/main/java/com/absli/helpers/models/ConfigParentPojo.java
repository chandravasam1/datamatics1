package com.absli.helpers.models;

public class ConfigParentPojo {

    private ConfigPojo ifscCode;
    private ConfigPojo bankAccNo;
    private ConfigPojo nomineeFirstName;
    private ConfigPojo nomineeLastName;
    private ConfigPojo insurerName;
    private ConfigPojo sumAssured;

    public ConfigPojo getNomineeFirstName() {
        return nomineeFirstName;
    }

    public void setNomineeFirstName(ConfigPojo nomineeFirstName) {
        this.nomineeFirstName = nomineeFirstName;
    }

    public ConfigPojo getNomineeLastName() {
        return nomineeLastName;
    }

    public void setNomineeLastName(ConfigPojo nomineeLastName) {
        this.nomineeLastName = nomineeLastName;
    }



    public ConfigPojo getIfscCode() {
        return ifscCode;
    }

    public void setIfscCode(ConfigPojo ifscCode) {
        this.ifscCode = ifscCode;
    }

    public ConfigPojo getBankAccNo() {
        return bankAccNo;
    }

    public void setBankAccNo(ConfigPojo bankAccNo) {
        this.bankAccNo = bankAccNo;
    }
    public ConfigPojo getInsurerName(){return insurerName;}
    public void setInsurerName(ConfigPojo insurerName){
        this.insurerName=insurerName;
    }
    public ConfigPojo getSumAssured(){
        return sumAssured;
    }
    public void setSumAssured(ConfigPojo sumAssured){
        this.sumAssured=sumAssured;
    }
}
