package com.absli.helpers.jsonReaders;

import com.absli.helpers.models.LoginModel;
import com.absli.utils.FileUtility;
import com.absli.utils.PropertiesUtils;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.io.FileUtils;

import java.io.IOException;
import java.nio.file.Files;

public class readLoginJson {

    String projectPath = System.getProperty("user.dir");
    PropertiesUtils prop = new PropertiesUtils();

    public LoginModel readJson() throws IOException {
        byte[] jsonData = null;
        ObjectMapper objectMapper = new ObjectMapper();
        jsonData = Files.readAllBytes(FileUtils.getFile(FileUtility.getFile(projectPath+prop.getProperties("loginTestJsonFilePath"))).toPath());
        LoginModel[] loginModels = objectMapper.readValue(jsonData, LoginModel[].class);
        return new LoginModel(loginModels);

    }
}
