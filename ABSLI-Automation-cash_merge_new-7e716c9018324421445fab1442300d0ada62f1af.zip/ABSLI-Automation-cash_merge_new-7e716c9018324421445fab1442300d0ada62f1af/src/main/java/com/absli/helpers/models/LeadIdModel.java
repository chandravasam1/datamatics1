package com.absli.helpers.models;

import java.util.Arrays;

public class LeadIdModel {

    private String leadId;
    private String testCase;
    private LeadIdModel[] leadIdModels;


    public LeadIdModel() {}

    public LeadIdModel(LeadIdModel[] leadIdModels) {
        this.leadIdModels = leadIdModels;
    }

    public String getLeadId() {
        return leadId;
    }

    public void setLeadId(String leadId) {
        this.leadId = leadId;
    }

    public String getTestCase() {
        return testCase;
    }

    public void setTestCase(String testCase) {
        this.testCase = testCase;
    }

    public LeadIdModel[] getLeadIdModels() {
        return leadIdModels;
    }

    public void setLeadIdModels(LeadIdModel[] leadIdModels) {
        this.leadIdModels = leadIdModels;
    }
    public LeadIdModel getDataByTestCase(String testCase) {
        return Arrays.stream(leadIdModels).filter(leadIdModel -> leadIdModel.getTestCase().equalsIgnoreCase(testCase)).findFirst().get();
    }


}
