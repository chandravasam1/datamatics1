package com.absli.helpers.jsonReaders;

import com.absli.helpers.models.*;
import com.absli.utils.FileUtility;
import com.absli.utils.PropertiesUtils;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.io.FileUtils;

import java.io.IOException;
import java.nio.file.Files;

public class ReadJson {

    String projectPath = System.getProperty("user.dir");
    PropertiesUtils prop = new PropertiesUtils();

    public LoginModel readLoginJson() throws IOException {
        byte[] jsonData = null;
        ObjectMapper objectMapper = new ObjectMapper();
        jsonData = Files.readAllBytes(FileUtils.getFile(FileUtility.getFile(projectPath+prop.getProperties("loginTestJsonFilePath"))).toPath());
        LoginModel[] loginModels = objectMapper.readValue(jsonData, LoginModel[].class);
        return new LoginModel(loginModels);

    }

    public ProposerModel readProposerJson() throws IOException {
        byte[] jsonData = null;
        ObjectMapper objectMapper = new ObjectMapper();
        jsonData = Files.readAllBytes(FileUtils.getFile(FileUtility.getFile(projectPath+prop.getProperties("proposerTestJsonFilePath"))).toPath());
        ProposerModel[] proposerModels = objectMapper.readValue(jsonData, ProposerModel[].class);
        return new ProposerModel(proposerModels);

    }

    public LeadIdModel readLeadIdJson() throws IOException {
        byte[] jsonData = null;
        ObjectMapper objectMapper = new ObjectMapper();
        jsonData = Files.readAllBytes(FileUtils.getFile(FileUtility.getFile(projectPath+prop.getProperties("leadIdTestJsonFilePath"))).toPath());
        LeadIdModel[] leadIdModels = objectMapper.readValue(jsonData, LeadIdModel[].class);
        return new LeadIdModel(leadIdModels);

    }

    public LeadIDControllerPojo.headerPojo readTestJson() throws IOException {
        byte[] jsonData = null;
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,false);
        jsonData = Files.readAllBytes(FileUtils.getFile(FileUtility.getFile(projectPath+"/src/main/java/com/absli/testdata/json/test.json")).toPath());
        JsonNode node  = objectMapper.readTree(jsonData);
        LeadIDControllerPojo.headerPojo node1 = objectMapper.treeToValue(node, LeadIDControllerPojo.headerPojo.class);
        return node1;
    }

    public ConfigParentPojo getConfigValues() throws IOException {
        byte[] jsonData = null;

        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,false);
        jsonData = Files.readAllBytes(FileUtils.getFile(FileUtility.getFile(projectPath+"/src/main/java/com/absli/testdata/json/Config.json")).toPath());

        ConfigParentPojo rm =  mapper.readValue(jsonData, ConfigParentPojo.class);
        return rm;
    }
}
