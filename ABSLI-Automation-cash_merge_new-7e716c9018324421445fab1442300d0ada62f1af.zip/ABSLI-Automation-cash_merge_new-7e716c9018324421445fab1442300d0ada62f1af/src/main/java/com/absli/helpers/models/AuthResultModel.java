package com.absli.helpers.models;

public class AuthResultModel {
    private AuthModel result;


    public AuthModel getResult() {
        return result;
    }

    public void setResult(AuthModel result) {
        this.result = result;
    }


}
