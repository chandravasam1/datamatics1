package com.absli.helpers.process;

import com.absli.helpers.models.ResignDownloadResultModel;
import com.absli.helpers.models.ResignResultModel;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.testng.annotations.Test;

import java.io.*;

public class ProcessBuilder {

    //@Test
    public String resignIPABuilder() throws IOException {

        String result = null;
        String authToken = "gzk97n8vw964hxrr4ntpbmym";

        String[] command = {"curl", "-H", "Content-Tyepe:application/json", "-d", "{\"token\":\"gzk97n8vw964hxrr4ntpbmym\",\"filename\": \"./Leap.ipa\"}", "https://device.pcloudy.com/api/resign/initiate"};

        java.lang.ProcessBuilder process = new java.lang.ProcessBuilder(command);
        Process p;
        try
        {
        p = process.start();
        BufferedReader reader =  new BufferedReader(new InputStreamReader(p.getInputStream()));
        StringBuilder builder = new StringBuilder();
        String line = null;
        while ( (line = reader.readLine()) != null) {
        builder.append(line);
        builder.append(System.getProperty("line.separator"));
        }
        result = builder.toString();
        System.out.print(result);

        }
        catch (IOException e)
        {   System.out.print("error");
        e.printStackTrace();
        }

        //result = "{\"result\":{\"token\":\"gzk97n8vw964hxrr4ntpbmym\",\"resign_token\":\"c802775b-e259-4952-a7b6-fd416c018213\",\"resign_filename\":\".\\/Leap.ipa\",\"code\":200}}";
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,false);
        ResignResultModel rm =  mapper.readValue(result, ResignResultModel.class);
        System.out.println("Resign token from json extracted:"+rm.getResult().getResign_token());

        String resignFileName = runDownloadCommand("gzk97n8vw964hxrr4ntpbmym",rm.getResult().getResign_token());
        return resignFileName;

    }




    private String runDownloadCommand(String authToken, String resignToken) throws JsonProcessingException {
        String[] command = {"curl", "-H", "Content-Tyepe:application/json", "-d", "{\"token\":\""+authToken+"\",\"resign_token\": \""+resignToken+"\" ,\"filename\": \"Leap.ipa\"}", "https://device.pcloudy.com/api/resign/download"};
        java.lang.ProcessBuilder process = new java.lang.ProcessBuilder(command);
        Process p;
        String result=null;
        try
        {
            p = process.start();
            BufferedReader reader =  new BufferedReader(new InputStreamReader(p.getInputStream()));
            StringBuilder builder = new StringBuilder();
            String line = null;
            while ( (line = reader.readLine()) != null) {
                builder.append(line);
                builder.append(System.getProperty("line.separator"));
            }
            result = builder.toString();
            System.out.println("Printing 2d api call response ----------------");
            System.out.print(result);

        }
        catch (IOException e)
        {   System.out.print("error");
            e.printStackTrace();
        }

        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,false);
        ResignDownloadResultModel rm =  mapper.readValue(result, ResignDownloadResultModel.class);
        System.out.println("Resign file from json extracted:"+rm.getResult().getResign_file());

        return rm.getResult().getResign_file();

    }

    /*
    * {"result":{"token":"gzk97n8vw964hxrr4ntpbmym","file":".\/Leap.ipa","resign_file":".\/Leap.Resigned1621690413.ipa","code":200}}
     */


}