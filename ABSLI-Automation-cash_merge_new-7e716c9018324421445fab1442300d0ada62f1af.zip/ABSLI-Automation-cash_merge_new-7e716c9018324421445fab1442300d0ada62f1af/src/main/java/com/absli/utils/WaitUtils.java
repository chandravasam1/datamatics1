package com.absli.utils;

import org.openqa.selenium.*;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import tests.BaseTest;
import com.google.common.base.Function;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import static com.absli.logger.LoggingManager.logMessage;

public class WaitUtils {
    public final int TimeOut = 30;
    public static final int DEFAULT_TIMEOUT_SEC = 30;
    public static final int MIN_TIMEOUT_MILLISEC = 5;



    public void waitForElementToBeVisible(WebDriver driver, WebElement element) {
        WebDriverWait wait = new WebDriverWait(driver,TimeOut);
        wait.until(ExpectedConditions.visibilityOf(element));
    }

    public void waitForElementToBeVisible(WebDriver driver, WebElement element,int timeOut,String message) {
        WebDriverWait wait = new WebDriverWait(driver,timeOut);
        try {
            wait.until(ExpectedConditions.visibilityOf(element));
        } catch (NoSuchElementException e) {
            System.out.println(message);
        } catch (TimeoutException e) {
            System.out.println(message);
        }
    }

    public void waitUntilVisible(WebDriver driver, WebElement element,int timeOut) {
        WebDriverWait wait = new WebDriverWait(driver,timeOut);
        wait.until(ExpectedConditions.visibilityOf(element));
    }


    public void implicitWait(WebDriver driver,int waitMilliseconds) {
        driver.manage().timeouts().implicitlyWait(waitMilliseconds, TimeUnit.MILLISECONDS);
    }

    public void waitForElementToBeClickable(WebDriver driver, WebElement element) {
        WebDriverWait wait = new WebDriverWait(driver,TimeOut);
        wait.until(ExpectedConditions.elementToBeClickable(element));
    }

    public void waitForElementToBeClickable(WebDriver driver, WebElement element,int timeout) {
        WebDriverWait wait = new WebDriverWait(driver,timeout);
        wait.until(ExpectedConditions.elementToBeClickable(element));
    }

    public void waitForElementToBeClickableByName(WebDriver driver, String elementName,String message) {
        WebDriverWait wait = new WebDriverWait(driver, TimeOut);
        WebElement element = null;
        try {
            switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
                case "android":
                    element = driver.findElement(By.xpath("//android.widget.TextView[@text=\"" + elementName + "\"]"));
                    break;
                case "ios":
                    break;
                default:
                    element = driver.findElement(By.xpath("//*[contains(text()='" + elementName + "')]"));
            }
            wait.until(ExpectedConditions.elementToBeClickable(element));
        } catch (Exception e) {
            logMessage("Warning:::"+message);
        }
    }

    public void waitUntilElementIsVisibleByText(WebDriver driver, int timeout, String elementName,String message) {
        WebDriverWait wait = new WebDriverWait(driver, timeout);
        try {
            WebElement element = null;
            switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
                case "android":
                    element = driver.findElement(By.xpath("//*android.widget.TextView[contains(@text,'" + elementName + "')]"));
                    break;
                case "ios":
                    break;
                default:
                    element = driver.findElement(By.xpath("//*[contains(text(),'" + elementName + "')]"));
            }
            wait.until(ExpectedConditions.visibilityOf(element));
        } catch (NoSuchElementException e) {
            logMessage(message);
        }
    }

    public void fluentWaitUntilElementVisible(WebDriver driver,WebElement element,int timeoutInSec) {
        WebElement waitElement = null;

//Sets FluentWait Setup
        FluentWait<WebDriver> fwait = new FluentWait<WebDriver>(driver)
                .withTimeout(timeoutInSec, TimeUnit.SECONDS)
                .pollingEvery(500, TimeUnit.MILLISECONDS)
                .ignoring(NoSuchElementException.class)
                .ignoring(TimeoutException.class);

//First checking to see if the loading indicator is found
// we catch and throw no exception here in case they aren't ignored
        try {
            waitElement = fwait.until(new Function<WebDriver, WebElement>() {
                public WebElement apply(WebDriver driver) {
                    return element;
                }
            });
        } catch (Exception e) {
        }

//checking if loading indicator was found and if so we wait for it to
//disappear
        if (waitElement != null) {
            return;
        }
    }


    public  void wait5Minutes(){
        long start = new Date().getTime();
        while(new Date().getTime() - start < 300000){

        }
    }

    public  void wait3Minutes(){
        long start = new Date().getTime();
        while(new Date().getTime() - start < 180000){

        }
    }
    public  void wait2Minutes(){
        long start = new Date().getTime();
        while(new Date().getTime() - start < 120000){

        }
    }
    public  void wait20Seconds(){
        long start = new Date().getTime();
        while(new Date().getTime() - start < 20000){

        }
    }
    public  void wait10Seconds(){
        long start = new Date().getTime();
        while(new Date().getTime() - start < 10000){

        }
    }
    public  void wait5Seconds(){
        long start = new Date().getTime();
        while(new Date().getTime() - start < 5000){

        }
    }
    public  void wait2Seconds(){
        long start = new Date().getTime();
        while(new Date().getTime() - start < 2000);
    }
    public  void wait1Seconds(){
        long start = new Date().getTime();
        while(new Date().getTime() - start < 1000);
    }
    public  void Asserting(String type, Object actual, Object expected) {
        switch (type) {
            case "equals":
                Assert.assertEquals(actual, expected);
                break;
            case "notEqual":
                Assert.assertNotEquals(actual, expected);
                break;
            case "contains":
                Assert.assertTrue(actual.toString().contains(expected.toString()));
                break;
        }
    }
    public  void WaitForElementPresent(WebDriver driver,WebElement element, int time) throws Exception {
        try {

            WebDriverWait newWait = new WebDriverWait(driver, time);
            newWait.until(ExpectedConditions.visibilityOf(element));

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public boolean checkIfElementPresent(WebDriver driver,WebElement element){
        try{
            WaitForElementPresent(driver,element,30);
            return element.isDisplayed();
        }catch(Exception e){
            e.printStackTrace();
            return false;
        }
    }
    public  void waitForLoad(WebDriver driver) {
        ExpectedCondition<Boolean> pageLoadCondition = new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver driver) {
                return ((JavascriptExecutor) driver).executeScript("return document.readyState").equals("complete");
            }
        };
        WebDriverWait wait = new WebDriverWait(driver,30);
        wait.until(pageLoadCondition);

    }
    public  void WaitForListOfElementPresent(WebDriver driver, List<WebElement> element, int time) throws Exception {
        try {
            WebDriverWait newWait = new WebDriverWait(driver, time);
            for (WebElement e : element) {
                newWait.until(ExpectedConditions.visibilityOf(e));
            }

        } catch (Exception e) {

        }

    }
    public static void WaitForObjectToBeClick(WebDriver driver,WebElement element, int time) throws Exception {
        WebDriverWait wait = new WebDriverWait(driver, time);
        wait.until(ExpectedConditions.elementToBeClickable(element));

    }
    public static void JavaScriptClick(WebDriver driver,WebElement element) {
        JavascriptExecutor executor = (JavascriptExecutor) driver;
        executor.executeScript("arguments[0].click();", element);
    }

    public void waitUntilPageLoad(WebDriver driver) {
        new WebDriverWait(driver, 10).until(
                webDriver -> ((JavascriptExecutor) webDriver).executeScript("return document.readyState").equals("complete"));
    }

    public void waitForInvisibility(WebDriver driver,WebElement element,int timeOut) {
        WebDriverWait wait = new WebDriverWait(driver, timeOut);
        wait.until(ExpectedConditions.invisibilityOf(element));
    }
}
