package com.absli.utils;

import com.absli.enums.ScrollDirection;
import com.beust.jcommander.JCommander;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import io.appium.java_client.*;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.ElementOption;
import io.appium.java_client.touch.offset.PointOption;
import org.openqa.selenium.*;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.Point;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.Pause;
import org.openqa.selenium.interactions.PointerInput;
import org.openqa.selenium.interactions.Sequence;
import org.openqa.selenium.interactions.touch.TouchActions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import tests.BaseTest;

import java.awt.*;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.time.Duration;
import java.time.Year;
import java.util.*;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.absli.logger.LoggingManager.logMessage;


import static io.appium.java_client.touch.TapOptions.tapOptions;
import static io.appium.java_client.touch.WaitOptions.waitOptions;
import static io.appium.java_client.touch.offset.ElementOption.element;
import static io.appium.java_client.touch.offset.PointOption.point;
import static java.time.Duration.ofMillis;
import static java.time.Duration.ofSeconds;
import io.appium.java_client.MobileElement;
import io.appium.java_client.MultiTouchAction;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import org.openqa.selenium.Dimension;

public class CommonUtils {

    private static Duration SCROLL_DUR = Duration.ofMillis(1000);
    private static double SCROLL_RATIO = 0.8;
    private static int ANDROID_SCROLL_DIVISOR = 3;
    private Dimension windowSize;
    WaitUtils waitUtils = new WaitUtils();
    //CommonUtils commonUtils = new CommonUtils();

    //BaseTest baseTest = new BaseTest();


    public void scrollTillEndOfPage(WebDriver driver) {
        JavascriptExecutor js = (JavascriptExecutor) driver;

        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                scrollDown(driver);
                //scrollToBottom(driver);
                break;
            case "ios":
                ((JavascriptExecutor) driver).executeScript("mobile: scroll", ImmutableMap.of("direction", "down"));
                break;
            default:
                ((JavascriptExecutor) driver).executeScript("window.scrollTo(0, document.body.scrollHeight)");
        }
    }

    public void scrollTopOfPage(WebDriver driver) {
        JavascriptExecutor js = (JavascriptExecutor) driver;

        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                //mobileScroll(ScrollDirection.UP,0.5,driver);
                break;
            case "ios":
                ((JavascriptExecutor) driver).executeScript("mobile: scroll", ImmutableMap.of("direction", "up"));
                break;
            default:
                ((JavascriptExecutor) driver).executeScript("window.scrollTo(0, -document.body.scrollHeight)");
        }
    }

    private void scrollDown(WebDriver driver) {
        //if pressX was zero it didn't work for me
        int pressX = driver.manage().window().getSize().width / 2;
        // 4/5 of the screen as the bottom finger-press point
        int bottomY = driver.manage().window().getSize().height * 4/5;
        // just non zero point, as it didn't scroll to zero normally
        int topY = driver.manage().window().getSize().height / 8;
        //scroll with TouchAction by itself
        scroll(pressX, bottomY, pressX, topY,driver);
    }


    private void scroll(int fromX, int fromY, int toX, int toY,WebDriver driver) {
        try {
            TouchAction touchAction = new TouchAction((PerformsTouchActions) driver);
            touchAction.longPress(PointOption.point(fromX, fromY)).moveTo(PointOption.point(toX, toY)).release().perform();
        } catch (Exception e) {
            System.out.println("We got an error scrolling!");
        }

    }
    public void scrollToBottom(WebDriver driver) {

        try
        {
            int  x = driver.manage().window().getSize().width / 2;
            int start_y = (int) (driver.manage().window().getSize().height * 0.5);
            int end_y = (int) (driver.manage().window().getSize().height);
            TouchAction dragNDrop = new TouchAction((PerformsTouchActions) driver)
                    .press(PointOption.point(x,start_y)).waitAction(waitOptions(Duration.ofMillis(500)))
                    .moveTo(PointOption.point(x, end_y))
                    .release();
            dragNDrop.perform();
        } catch (Exception e) {
            System.out.println("We got an error scrolling!");
        }

    }

    /*only for android*/
    public void scrollByText(String menuText,WebDriver driver) {

        try {

            driver.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(new UiSelector().textMatches(\"" + menuText + "\").instance(0));"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public boolean verifyElementIsVisible(WebElement element) {
        return element.isDisplayed();
    }

    public void navigateBack(WebDriver driver) {
        driver.navigate().back();

    }

    public void enterKey(WebElement element,WebDriver driver) {
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                //((AndroidDriver)driver).hideKeyboard();
                //element.sendKeys(Keys.ENTER);
                ((AndroidDriver) driver).pressKey(new KeyEvent(AndroidKey.ENTER));
                //element.sendKeys(Keys.ENTER);
                //((AndroidDriver) driver).pressKey(new KeyEvent(AndroidKey.NUMPAD_ENTER));
                break;
            case "ios":
                element.sendKeys(Keys.ENTER);
                break;
            default: element.sendKeys(Keys.TAB);

        }
    }

    public void hideKeyboard(WebDriver driver) {
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                ((AndroidDriver)driver).hideKeyboard();
                //element.sendKeys(Keys.ENTER);
                //((AndroidDriver) driver).pressKey(new KeyEvent(AndroidKey.ENTER));
                //element.sendKeys(Keys.ENTER);
                //((AndroidDriver) driver).pressKey(new KeyEvent(AndroidKey.NUMPAD_ENTER));
                break;
            case "ios":
                ((IOSDriver)driver).hideKeyboard();
                //element.sendKeys(Keys.ENTER);
                break;
            default:
                //element.sendKeys(Keys.TAB);

        }
    }

    public void clickElementByJS(WebElement element,WebDriver driver) {
        JavascriptExecutor executor = (JavascriptExecutor)driver;
        executor.executeScript("arguments[0].click();", element);
    }

    private static void clickElement(WebElement element, RemoteWebDriver driver) {
        JavascriptExecutor js = driver;
        int screenWebViewWidth = ((Long) js.executeScript("return window.innerWidth || document.body.clientWidth")).intValue();
        int elementwebViewX = element.getLocation().getX();
        //switchContext(driver, "NATIVE");
        double screenWidth = driver.manage().window().getSize().getWidth();
        double elementNativeViewX = (elementwebViewX * screenWidth) / screenWebViewWidth;
        WebElement control_container = driver.findElement(By.xpath("//*[@resource-id = 'com.android.chrome:id/control_container']"));
        int finalX = (int)elementNativeViewX + element.getRect().getWidth() / 2;
        int finalY = element.getLocation().getY() + control_container.getLocation().getY() + control_container.getSize().height + element.getRect().height/ 2;
        Map<String, Object> params1 = new HashMap<>();
        params1.put("location", finalX + "," + finalY);
        driver.executeScript("mobile:touch:tap", params1);
        //switchContext(driver, "WEBVIEW");
    }

    public void clearTextFieldValue(WebElement element ,WebDriver driver) {
        ((JavascriptExecutor) driver).executeScript("arguments[0].value ='';", element);
        ((JavascriptExecutor) driver).executeScript("arguments[0].value ='';", element);

    }

    public String decimalFormatter(String number)  {
        number = number.replace(",","");
        String pattern = "#,##,###.##";
        String format = null;
        DecimalFormat decimalFormat = new DecimalFormat(pattern);
        try {
            Double num = Double.parseDouble(number);
            format = decimalFormat.format(num);

        } catch (NumberFormatException e) {
            //
        }
        System.out.println("formatted number:"+format);
        return format ;

        /*Number parsedNumber = null;
        NumberFormat numberFormat = NumberFormat.getInstance(Locale.FRANCE);
        try {
             parsedNumber = numberFormat.parse(number);
        } catch (ParseException e) {
            //
        }

        return String.valueOf(parsedNumber.doubleValue());*/
    }

    public  boolean isClickable(WebElement el, WebDriver driver)
    {
        try{
            WebDriverWait wait = new WebDriverWait(driver, 6);
            wait.until(ExpectedConditions.elementToBeClickable(el));
            return true;
        }
        catch (Exception e){
            return false;
        }
    }

    public void selectButtonByName(String buttonName,WebDriver driver) {
        waitUtils.implicitWait(driver,40);
        buttonName = buttonName.trim();
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android" :
                WebElement buttonAndroid=null;
                try {
                    buttonAndroid = driver.findElement(By.xpath("//android.widget.TextView[@text='"+buttonName+"']/../.. | //android.widget.Button[@text='"+buttonName+"'] "));
                    if(buttonAndroid.isDisplayed()) {
                        buttonAndroid.click();
                    }

                } catch (NoSuchElementException e) {

                    logMessage("element not found:" + By.xpath("//android.widget.TextView[@text='"+buttonName+"']/../.."));
                }
                //driver.findElement(By.xpath("//android.widget.TextView[@text=\""+ buttonName +"\"]")).click();
                break;
            case "ios":

                if(buttonName.contains("CONTINUE")) {
                    driver.findElement(By.xpath("//XCUIElementTypeButton[@name='continueBtn']")).click();
                }
                else {
                    WebElement buttonIos=null;
                    try {
                        buttonIos = driver.findElement(By.xpath("//XCUIElementTypeButton[@name='"+buttonName+"']"));
                        if(buttonIos.isDisplayed()) {
                            buttonIos.click();
                        }

                    } catch (NoSuchElementException e) {

                        logMessage("element not found:" + By.xpath("//XCUIElementTypeButton[@name='"+buttonName+"']"));
                    }
                }
                break;
            default:
                WebElement button =  null;
                try {
                    button = driver.findElement(By.xpath("//*[contains(text(),'" + buttonName + "')]"));
                    if(button.isDisplayed()) {
                        button.click();
                    }
                } catch (NoSuchElementException e) {
                    logMessage("element not found:" + By.xpath("//*[contains(text(),'" + buttonName + "')]"));
                }
        }
    }

    /*
    This is applicable only for android
    * */
    public void clickElementOnScroll(WebDriver driver,String text) {
        WebElement element = driver.findElement(MobileBy.AndroidUIAutomator("new UiScrollable("
                +"new UiSelector().scrollable(true)).scrollIntoView("
                + "new UiSelector().textContains(\"" + text + "\"));"));
        element.click();
    }

    /*
   This is applicable only for android
   * */
    public void elementOnScroll(WebDriver driver,String text) {
        WebElement element = driver.findElement(MobileBy.AndroidUIAutomator("new UiScrollable("
                +"new UiSelector().scrollable(true)).scrollIntoView("
                + "new UiSelector().textContains(\"" + text + "\"));"));
    }

    /*
        This is applicable only for android
        * */
    public void scrollToTheText(WebDriver driver, String text) {
            WebElement ele=  (MobileElement) driver.findElement(MobileBy.AndroidUIAutomator
                    ("new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(" +
                            "new UiSelector().textContains(\""+text+"\").instance(0))"));

        ele.click();
    }

    public void clickOnScrollForIos(WebDriver driver,String name) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        MobileElement list = (MobileElement) driver.findElement(By.className("XCUIElementTypeScrollView"));
        MobileElement listElement = (MobileElement) driver.findElement(MobileBy.iOSNsPredicateString("type == 'XCUIElementTypeOther' AND name BEGINSWITH[cd] '"+ name+"'"));
        Map<String, Object> params = new HashMap<>();
        params.put("direction", "down");
        params.put("velocity", 2500);
        params.put("element", listElement.getId());
        js.executeScript("mobile: swipe", params);
    }

    public void clickOnScrollForAndroid(WebDriver driver,String text,WebElement element ) {
        /*HashMap<String, String> scrollObject = new HashMap<String, String>();
        //RemoteWebElement element = (RemoteWebElement)((AndroidDriver) driver).findElementByAndroidUIAutomator("new UiSelector().className(\"android.widget.ScrollView\")");
        JavascriptExecutor js = (JavascriptExecutor) driver;
        String webElementId = ((RemoteWebElement) element).getId();
        System.out.println(webElementId)
        ;System.out.println(element);
        scrollObject.put("text", text);
        scrollObject.put("element", webElementId);
        js.executeScript("mobile: scroll", scrollObject);
        element.click();*/

        TouchActions action = new TouchActions(driver);
        action.scroll(element, 10, 100);
        action.perform();
        element.click();
    }

    public void actionOnScrollForIos(WebDriver driver) {

        int x = driver.manage().window().getSize().width / 2;
        int y = (int) (driver.manage().window().getSize().height * 0.8);

        int x1 = driver.manage().window().getSize().width / 2;
        int y1 = (int)(driver.manage().window().getSize().height * 0.2);

        TouchAction action = new TouchAction((PerformsTouchActions) driver);
        action.press(PointOption.point(x,y)).moveTo(PointOption.point(x1,y1)).release();
        action.perform();
    }

    public void iosScroll(WebDriver driver,String  predicate,String dir) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        //MobileElement listElement = (MobileElement) element;
        Map<String, Object> params = new HashMap<>();
        params.put("direction", dir);
        //params.put("predicateString","type == '" + type +"' AND value == '"+ text +"'");
        params.put("predicateString",predicate);
        params.put("velocity", 2500);
        params.put("toVisible", true);
        //params.put("element", listElement.getId());
        js.executeScript("mobile: scroll", params);
    }

    public void clickOnScrollForIos(WebDriver driver,WebElement element) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        MobileElement listElement = (MobileElement) element;
        Map<String, Object> params = new HashMap<>();
        params.put("direction", "down");
        //params.put("predicateString","type == '" + type +"' AND value == '"+ text +"'");
        //XCUIElementTypeStaticText      ACTIONS
        params.put("velocity", 2500);
        params.put("toVisible", true);
        params.put("element", listElement.getId());
        js.executeScript("mobile: scroll", params);
    }

    public void clickOnScrollForIos(WebDriver driver,WebElement element,String dir) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        MobileElement listElement = (MobileElement) element;
        Map<String, Object> params = new HashMap<>();
        params.put("direction", dir);
        //params.put("predicateString","type == '" + type +"' AND value == '"+ text +"'");
        //XCUIElementTypeStaticText      ACTIONS
        params.put("velocity", 2500);
        params.put("toVisible", true);
        params.put("element", listElement.getId());
        js.executeScript("mobile: scroll", params);
    }


    public Dimension getWindowSize(WebDriver driver) {
        if (windowSize == null) {
            windowSize = driver.manage().window().getSize();
        }
        return windowSize;
    }


    public void scrollIntoView(String text,WebDriver driver) {
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                driver.findElement(MobileBy.AndroidUIAutomator("new UiScrollable("
                        +"new UiSelector().scrollable(true)).scrollIntoView("
                        + "new UiSelector().textContains(\"" + text + "\"));"));
                break;
            case "ios":
                clickOnScrollForIos(driver,text);
                break;
            default:
                WebElement ele = driver.findElement(By.xpath("//*[contains(text(),'" + text + "')]"));
                // Javascript executor
                ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", ele);
        }
    }

    public void scrollIntoView(WebElement element,WebDriver driver) {
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
               /* *//*driver.findElement(MobileBy.AndroidUIAutomator("new UiScrollable("
                        +"new UiSelector().scrollable(true)).scrollIntoView("
                        + "new UiSelector().textContains(\"" + text + "\"));"));*//*
                TouchActions action = new TouchActions(driver);
                action.scroll(element, 10, 100);
                action.perform();*/
                JavascriptExecutor js = (JavascriptExecutor) driver;
                HashMap<String, String> scrollObject = new HashMap<String, String>();
                scrollObject.put("direction", "down");
                //scrollObject.put("element", ((RemoteWebElement) element).getId());
                js.executeScript("mobile: scroll", scrollObject);
                break;
            case "ios":
                //clickOnScrollForIos(driver,element);
                break;
            default:
                // Javascript executor
                ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
        }
    }

    public void scrollIntoViewForWeb(WebElement element,WebDriver driver) {
                // Javascript executor
                ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
    }

    public void clickElement(WebElement element) {
        element.click();
    }

    public  boolean onlyDigits(String str)
    {
        // Regex to check string
        // contains only digits
        String regex = "[0-9]+";

        // Compile the ReGex
        Pattern p = Pattern.compile(regex);

        // If the string is empty
        // return false
        if (str == null) {
            return false;
        }

        // Find match between given string
        // and regular expression
        // using Pattern.matcher()
        Matcher m = p.matcher(str);

        // Return if the string
        // matched the ReGex
        return m.matches();
    }

    public boolean isDOBDayValidationFailed(String day) {
        if (onlyDigits(day)) {
            if (day.length() > 2) {
                return true;
            } else if (Integer.valueOf(day) > 31) {
                return true;
            } else if (Integer.valueOf(day) == 00) {
                return true;
            }
        }
        return false;
    }

    public boolean isDOBMonthValidationFailed(String month) {
        if (onlyDigits(month)) {
            if (month.length() > 2) {
                return true;
            }
            else if(Integer.valueOf(month) > 12) {
                return true;
            }
            else if(Integer.valueOf(month) == 00) {
                return true;
            }
        }
        return false;
    }

    public boolean isDOBYearValidationFailed(String year) {
        int currentYear = Year.now().getValue();

        System.out.println("Current year: *****"+currentYear);

        if (onlyDigits(year)) {
            if (year.length() > 4) {
            }
            else if(Integer.valueOf(year) >= currentYear) {
                return true;
            }
            else if(Integer.valueOf(year) == 00) {
                return true;
            }
            else if(Integer.valueOf(year) < 1940) {
                return true;
            }
        }
        return false;
    }

    public int getCurrentYear() {
        return Year.now().getValue();

    }

    public  int   calculateAge(Date birthDate)
    {
            int years = 0;
            int months = 0;
            int days = 0;

            //create calendar object for birth day
            Calendar birthDay = Calendar.getInstance();
            birthDay.setTimeInMillis(birthDate.getTime());

            //create calendar object for current day
            long currentTime = System.currentTimeMillis();
            Calendar now = Calendar.getInstance();
            now.setTimeInMillis(currentTime);

            //Get difference between years
            years = now.get(Calendar.YEAR) - birthDay.get(Calendar.YEAR);
            int currMonth = now.get(Calendar.MONTH) + 1;
            int birthMonth = birthDay.get(Calendar.MONTH) + 1;

            //Get difference between months
            months = currMonth - birthMonth;

            //if month difference is in negative then reduce years by one
            //and calculate the number of months.
            if (months < 0)
            {
                years--;
                months = 12 - birthMonth + currMonth;
                if (now.get(Calendar.DATE) < birthDay.get(Calendar.DATE))
                    months--;
            } else if (months == 0 && now.get(Calendar.DATE) < birthDay.get(Calendar.DATE))
            {
                years--;
                months = 11;
            }

            //Calculate the days
            if (now.get(Calendar.DATE) > birthDay.get(Calendar.DATE))
                days = now.get(Calendar.DATE) - birthDay.get(Calendar.DATE);
            else if (now.get(Calendar.DATE) < birthDay.get(Calendar.DATE))
            {
                int today = now.get(Calendar.DAY_OF_MONTH);
                now.add(Calendar.MONTH, -1);
                days = now.getActualMaximum(Calendar.DAY_OF_MONTH) - birthDay.get(Calendar.DAY_OF_MONTH) + today;
            }
            else
            {
                days = 0;
                if (months == 12)
                {
                    years++;
                    months = 0;
                }
            }
            //Create new Age object
            //return new Age(days, months, years);

        return years;
        }


        public void mobileTap(WebDriver driver,WebElement element,int x,int y, int width, int height) {
            //int x = ele.getLocation().getX() + (ele.getSize().getWidth() / 2);
            //int y = ele.getLocation().getY() + (ele.getSize().getHeight() - 5 );

            /*int x = ele.getLocation().getX() + 5;
            int y = ele.getLocation().getY()  - 5;


            System.out.println("X =======>"+ ele.getLocation().getX());
            System.out.println("Y =======>"+ ele.getLocation().getY());

            System.out.println("X =======>"+ x);
            System.out.println("Y =======>"+ y);*/



            JavascriptExecutor js = (JavascriptExecutor) driver;
            Map<String, Object> params = new HashMap();
            params.put("x", x);
            params.put("y", y);
            params.put("element", ((RemoteWebElement)element).getId());
            js.executeScript("mobile: tap", params);

        }

    public Boolean isEnabled(WebDriver driver,WebElement element) {
        waitUtils.implicitWait(driver, 100);
        try {
            return element.isEnabled();
        } catch (Exception e) {
            return false;
        }
    }

    public Boolean clickIfEnabled(WebDriver driver,WebElement element) {
        waitUtils.implicitWait(driver, 100);
        try {
            if(element.isEnabled()) {
                element.click();
            }
        } catch (Exception e) {
            return false;
        }
        return false;
    }

    public Boolean isDisplayed(WebDriver driver,WebElement element) {
        try {
            waitUtils.waitUntilVisible(driver,element,40);
            waitUtils.implicitWait(driver,100);
            return element.isDisplayed();
        } catch (Exception e) {
            logMessage("Element not displayed:-----"+element);
            return false;
        }
    }



    public void mobileTap(WebDriver driver , WebElement element) {
        // tap an element very near its top left corner
        JavascriptExecutor js = (JavascriptExecutor) driver;

        Map<String, Object> args = new HashMap<>();
        args.put("element", ((MobileElement) element).getId());
        args.put("x", 2);
        args.put("y", 2);
        js.executeScript("mobile: tap", args);
    }

    public void mobileDoubleTapIOs(WebDriver driver,WebElement element,int x,int y) {
        JavascriptExecutor js = (JavascriptExecutor) driver;

        // double-tap the screen at a specific point
        Map<String, Object> args = new HashMap<>();
        args.put("x", x);
        args.put("y", y);
        js.executeScript("mobile: tap", args);
    }

    public void mobileTapAndroid(WebDriver driver,AndroidElement androidElement) {
        driver = ((AndroidDriver<MobileElement>)driver);
        new TouchAction((PerformsTouchActions) driver)
                .tap(tapOptions().withElement(element(androidElement)))
                .waitAction(waitOptions(ofMillis(250))).perform();
    }

    public String getCurrentTimeStamp() {
        Date date= new Date();
        //getTime() returns current time in milliseconds
        long time = date.getTime();
        //Passed the milliseconds to constructor of Timestamp class
        Timestamp ts = new Timestamp(time);
        System.out.println("Current Time Stamp: "+ts);
        return String.valueOf(ts);
    }

    public void selectDropdownOption(WebDriver driver,By optionLocator,String expectedText) {
        List<WebElement> myElements = driver.findElements(optionLocator);
        for(WebElement e : myElements) {
            if (e.getText().equalsIgnoreCase(expectedText)) {
                e.click();
            }
        }
    }
    public void switchToWindow(WebDriver driver) {

        //Get handles of the windows
        String mainWindowHandle = driver.getWindowHandle();
        Set<String> allWindowHandles = driver.getWindowHandles();
        Iterator<String> iterator = allWindowHandles.iterator();

        // Here we will check if child window has other child windows and will fetch the heading of the child window
        while (iterator.hasNext()) {
            String ChildWindow = iterator.next();
            if (!mainWindowHandle.equalsIgnoreCase(ChildWindow)) {
                driver.switchTo().window(ChildWindow);

            }
        }
    }

    public  String alertGetData(WebDriver driver) {
        Alert alert = driver.switchTo().alert();
        return alert.getText();
    }

    public  void alertPicker(WebDriver driver,String action, String value) {
        Alert alert = driver.switchTo().alert();
        if (value == null) {
            switch (action) {
                case "accept":
                    alert.accept();
                    break;
                case "dismiss":
                    alert.dismiss();
                    break;
            }

        } else{

            alert.sendKeys(value);
        }

    }
    public String getElementmessage(WebDriver driver, int timeout, String elementName,String message) {
        WebDriverWait wait = new WebDriverWait(driver, timeout);
        WebElement element = null;
        String Actmessage=null;
        try {
            switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
                case "android":
                    element = driver.findElement(By.xpath("//android.widget.TextView[@text='" + elementName + "']"));
                    break;
                case "ios":
                    break;
                default:
                    element = driver.findElement(By.xpath("//*[contains(text(),'" + elementName + "')]"));
            }
            wait.until(ExpectedConditions.visibilityOf(element));
            Actmessage=element.getText();
        } catch (Exception e) {
            logMessage("Warning:::"+message);
        }
        return Actmessage.trim();
    }
    public  void waitConstantTime(int timeInMillis) {
        try {
            Thread.sleep(timeInMillis);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
    public  void scrolldown(WebDriver driver) {
        Actions actions = new Actions(driver);
        actions.keyDown(Keys.CONTROL).sendKeys(Keys.PAGE_DOWN).perform();
        waitConstantTime(5000);
    }
    // method will scroll page end
    public void scrolltopageend(WebDriver driver) throws Exception {
        try {
            Actions actions = new Actions(driver);
            actions.keyDown(Keys.CONTROL).sendKeys(Keys.END).perform();

            waitConstantTime(5000);

        } catch (Exception e) {

            e.printStackTrace();
        }

    }

    public void scrollToPageUp(WebDriver driver) throws Exception {
        try {
            Actions actions = new Actions(driver);
            actions.keyDown(Keys.CONTROL).sendKeys(Keys.HOME).perform();
            waitConstantTime(5000);

        } catch (Exception e) {

            e.printStackTrace();
        }

    }
    public  String WaitForElementPresentandGetText(WebDriver driver,WebElement element, long time) throws Exception {
        String Text = "Invalid";
        try {
            WebDriverWait newWait = new WebDriverWait(driver, time);
            newWait.until(ExpectedConditions.visibilityOf(element));
            Text = element.getText();

        } catch (Exception e) {

        }
        return Text;
    }
    public  void scrollToElementAndClick(WebDriver driver,WebElement element) {
        Actions a = new Actions(driver);
        a.moveToElement(element).click().build().perform();
    }
    public  void scrollToElement(WebDriver driver,WebElement element) {
        Actions a = new Actions(driver);
        a.moveToElement(element).build().perform();
    }
    public  void getValuesFromList(WebDriver driver,List<WebElement> elements, String value) throws Exception {

        List<WebElement> we = elements;
        for (WebElement a : we) {
            //Thread.sleep(1000);
            System.out.println(a.getText());
           // System.out.println(a.getText());
            if (a.getText().equalsIgnoreCase(value)) {
                WaitForElementPresentandGetText(driver,a,10);
                scrollToElementAndClick(driver,a);
                Thread.sleep(5000);
                break;
            }
        }

    }
public void scrollDownwindow(WebDriver driver){
    JavascriptExecutor js = (JavascriptExecutor) driver;
    HashMap<String, String> scrollObject = new HashMap<String, String>();
    scrollObject.put("direction", "down");
    js.executeScript("mobile: scroll", scrollObject);
}
public void scrollToElementAndroid(WebDriver driver,WebElement element){

    JavascriptExecutor js = (JavascriptExecutor) driver;
    HashMap<String, String> scrollObject = new HashMap<String, String>();
    scrollObject.put("direction", "down");
    scrollObject.put("element", ((RemoteWebElement) element).getId());
    js.executeScript("mobile: scroll", scrollObject);
}
public void scrollToElementTOView(WebDriver driver){
    Dimension dimension = driver.manage().window().getSize();
    int scrollStart = (int) (dimension.getHeight() * 0.5);
    int scrollEnd = (int) (dimension.getHeight() * 0.2);

    new TouchAction((PerformsTouchActions) driver)
            .press(PointOption.point(0, scrollStart))
            .waitAction(WaitOptions.waitOptions(Duration.ofSeconds(1)))
            .moveTo(PointOption.point(0, scrollEnd))
            .release().perform();
}
    public static void scrollToText(AndroidDriver<MobileElement> driver, String text) {
        MobileElement el = (MobileElement) driver.findElementByAndroidUIAutomator("new UiScrollable("
                + "new UiSelector().scrollable(true)).scrollIntoView(" + "new UiSelector().text(\"" + text + "\"));");
    }

    public static void scrollToId(AndroidDriver<MobileElement> driver, String id) {
        MobileElement el = (MobileElement) driver.findElementByAndroidUIAutomator(
                "new UiScrollable(" + "new UiSelector().scrollable(true)).scrollIntoView("
                        + "new UiSelector().resourceIdMatches(\"" + id + "\"));");
    }

    public void chooseActionButton(WebElement element) {
        clickElement(element);
    }

    public ExpectedCondition<Boolean> elementFoundAndClicked(By locator) {
        return new ExpectedCondition<Boolean>() {
            @Override
            public Boolean apply(WebDriver driver) {
                WebElement el = driver.findElement(locator);
                el.click();
                return true;
            }
        };
    }

}
