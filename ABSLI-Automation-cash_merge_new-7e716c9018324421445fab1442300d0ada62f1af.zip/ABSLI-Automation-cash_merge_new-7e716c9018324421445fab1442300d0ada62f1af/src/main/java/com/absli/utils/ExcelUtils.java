package com.absli.utils;

import com.absli.listeners.TestLevelDriverCreator;
import com.absli.listeners.TestListener;
import org.testng.ITestContext;
import org.testng.annotations.Listeners;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class ExcelUtils {

    static Xls_Reader reader;
    static ITestContext iTestContext;
    TestListener listener;

    public static Object[] appendValue(Object[] obj, String value) {

        ArrayList<Object> temp = new ArrayList<Object>(Arrays.asList(obj));
        temp.add(value);
        return temp.toArray();

    }

    public static ArrayList<Object[]> getDataFromExcel(String testExcelSheet, String testName, String loginSheetName) {
        ArrayList<Object[]> myData = new ArrayList<Object[]>();
        ArrayList<String> myColumnData = new ArrayList<String>();
        ArrayList<String> str = new ArrayList<String>();
        try {
            reader = new Xls_Reader(System.getProperty("user.dir") + testExcelSheet);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("row count ---------" + reader.getRowCount(loginSheetName));
        System.out.println(" ******* current test running method  *********" + testName);
        System.out.println("**** column count  ********" + reader.getColumnCount(loginSheetName));
        for (int columnCount = 9; columnCount < reader.getColumnCount(loginSheetName); columnCount++) {
            String data = reader.getCellData(loginSheetName, columnCount, 1);
            System.out.println(data);
            myColumnData.add(data);
        }
        System.out.println("My coulmn data --------------" + myColumnData);
        for (int rowCount = 3; rowCount <= reader.getRowCount(loginSheetName); rowCount++) {
            String currentTestMethod = reader.getCellData(loginSheetName, "testCaseName", rowCount);
            String enableFlag = reader.getCellData(loginSheetName, "flag", rowCount);
            if (currentTestMethod.equalsIgnoreCase(testName) && enableFlag.equalsIgnoreCase("YES")) {
                for (String s : myColumnData) {
                    String value = reader.getCellData(loginSheetName, s, rowCount);
                    System.out.println("Value" + value);
                    str.add(value);

                }
                Object ob[] = new Object[]{str};
                //Object ob1[] = appendValue(ob,value);
                myData.add(ob);
            }
        }
        System.out.println("mydata rows value **********" + myData);
        return myData;
    }

    public ArrayList<Object[]> getLoginDataFromExcel(String testExcelSheet, String testName, String loginSheetName) {
        ArrayList<Object[]> myData = new ArrayList<Object[]>();
        ArrayList<String> myColumnData = new ArrayList<String>();
        Xls_Reader reader = null;

        try {
            reader = new Xls_Reader(System.getProperty("user.dir") + testExcelSheet);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("Sign in Sheet row count ---------" + reader.getRowCount(loginSheetName));
        System.out.println(" ******* current test running method  *********" + testName);
        System.out.println("**** column count  ********" + reader.getColumnCount(loginSheetName));

        for (int rowCount = 3; rowCount <= reader.getRowCount(loginSheetName); rowCount++) {
            String currentTestMethod = reader.getCellData(loginSheetName, "testCaseName", rowCount);
            String enableFlag = reader.getCellData(loginSheetName, "flag", rowCount);
            if (currentTestMethod.equalsIgnoreCase(testName)) {
                String username = reader.getCellData(loginSheetName, "username", rowCount);
                String password = reader.getCellData(loginSheetName, "password", rowCount);
                Object ob[] = {username, password};
                myData.add(ob);
            }
        }
        System.out.println("mydata rows value **********" + myData);
        return myData;
    }

    public static ArrayList<String> getExecutionSuitesFromController(String testExcelSheet, String controlSheetName) {
        ArrayList<String> suiteData = new ArrayList<String>();

        try {
            reader = new Xls_Reader(System.getProperty("user.dir") + testExcelSheet);
        } catch (Exception e) {
            e.printStackTrace();
        }
        for (int rowCount = 2; rowCount <= reader.getRowCount(controlSheetName); rowCount++) {

            String currentSuiteName = reader.getCellData(controlSheetName, "suitename", rowCount);
            String enableFlag = reader.getCellData(controlSheetName, "execute", rowCount);
            if (enableFlag.equalsIgnoreCase("YES")) {
                suiteData.add(currentSuiteName);
            }
        }
        System.out.println("Selected suites for execution *********" + suiteData);
        System.out.println("Selected suites for execution *********" + suiteData);
        return suiteData;
    }

    public static ArrayList<String> getExecutionClassNames(String testExcelSheet, ArrayList<String> suiteData) {
        ArrayList<String> classData = new ArrayList<String>();

        //suiteData = getExecutionSuitesFromController(testExcelSheet, "controller");

        for (String name : suiteData) {
            int rowCount = 3;
            //for (int rowCount = 3; rowCount <= reader.getRowCount(name); rowCount++) {
            String currentClassName = reader.getCellData(name, "classname", rowCount);
            String enableFlag = reader.getCellData(name, "flag", rowCount);
            if (enableFlag.equalsIgnoreCase("YES")) {
                classData.add(currentClassName);
            }
            //}
        }
        return classData;
    }

    public static List<Map<String, String>> getExecutionClassMethodNames(String testExcelSheet, ArrayList<String> suiteData) {
        ArrayList<String> classData = new ArrayList<String>();
        List<Map<String, String>> classMethods = new ArrayList<Map<String, String>>();
        //suiteData = getExecutionSuitesFromController(testExcelSheet, "controller");

        for (String name : suiteData) {
            //int rowCount = 3;
            for (int rowCount = 3; rowCount <= reader.getRowCount(name); rowCount++) {
                String currentClassName = reader.getCellData(name, "classname", rowCount);
                String currentMethodName = reader.getCellData(name, "testCaseName", rowCount);

                String enableFlag = reader.getCellData(name, "flag", rowCount);
                if (enableFlag.equalsIgnoreCase("YES")) {
                    Map<String, String> method = new HashMap<String, String>();
                    method.put(currentClassName, currentMethodName);
                    classMethods.add(method);
                }
            }
        }
        System.out.println("class methods:========>" + classMethods);
        return classMethods;
    }

    public static List<Map<String, String>> getExecutionClassMethodNames(String testExcelSheet, String suiteName) {
        ArrayList<String> classData = new ArrayList<String>();
        List<Map<String, String>> classMethods = new ArrayList<Map<String, String>>();
        //suiteData = getExecutionSuitesFromController(testExcelSheet, "controller");

        //for (String name : suiteData) {
        //int rowCount = 3;
        for (int rowCount = 3; rowCount <= reader.getRowCount(suiteName); rowCount++) {
            String currentClassName = reader.getCellData(suiteName, "classname", rowCount);
            String currentMethodName = reader.getCellData(suiteName, "testCaseName", rowCount);

            String enableFlag = reader.getCellData(suiteName, "flag", rowCount);
            if (enableFlag.equalsIgnoreCase("YES")) {
                Map<String, String> method = new HashMap<String, String>();
                method.put(currentClassName, currentMethodName);
                classMethods.add(method);
            }
        }
        //}
        System.out.println("class methods:========>" + classMethods);
        return classMethods;
    }

    public static String getPlatformNameFromExcel(String testExcelSheet, String sheetName) {
        String platform = null;
        try {
            reader = new Xls_Reader(System.getProperty("user.dir") + testExcelSheet);
        } catch (Exception e) {
            e.printStackTrace();
        }
        for (int rowCount = 2; rowCount <= reader.getRowCount(sheetName); rowCount++) {
            String enableFlag = reader.getCellData(sheetName, "execute", rowCount);
            if (enableFlag.equalsIgnoreCase("YES")) {
                platform = reader.getCellData(sheetName, "platform", rowCount);
                break;
            }
        }
        return platform;
    }

    public static String getBrowserNameFromExcel(String testExcelSheet, String sheetName) {
        String browser = null;
        for (int rowCount = 2; rowCount <= reader.getRowCount(sheetName); rowCount++) {
            String enableFlag = reader.getCellData(sheetName, "execute", rowCount);
            if (enableFlag.equalsIgnoreCase("YES")) {
                browser = reader.getCellData(sheetName, "browser", rowCount);
                break;
            }
        }
        return browser;
    }

    public static String getInstanceCountFromExcel(String testExcelSheet, String sheetName) {
        String instance = null;
        for (int rowCount = 2; rowCount <= reader.getRowCount(sheetName); rowCount++) {
            String enableFlag = reader.getCellData(sheetName, "execute", rowCount);
            if (enableFlag.equalsIgnoreCase("YES")) {
                instance = reader.getCellData(sheetName, "instance", rowCount);
                break;
            }
        }
        return instance;
    }

    public static ArrayList<Object[]> getQuoteDataFromExcel(String testExcelSheet, String testName, String sheetName) {
        ArrayList<Object[]> myData = new ArrayList<Object[]>();
        ArrayList<String> myColumnData = new ArrayList<String>();
        Xls_Reader reader = null;

        try {
            reader = new Xls_Reader(System.getProperty("user.dir") + testExcelSheet);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("Quote sheet row count ---------" + reader.getRowCount(sheetName));

        for (int rowCount = 3; rowCount <= reader.getRowCount(sheetName); rowCount++) {
            String currentTestMethod = reader.getCellData(sheetName, "testCaseName", rowCount);
            String enableFlag = reader.getCellData(sheetName, "flag", rowCount);
            if (currentTestMethod.equalsIgnoreCase(testName) && enableFlag.equalsIgnoreCase("YES")) {

                String username = reader.getCellData(sheetName, "username", rowCount);
                String password = reader.getCellData(sheetName, "password", rowCount);

                String policy = reader.getCellData(sheetName, "policy", rowCount);
                String leadid = reader.getCellData(sheetName, "leadid", rowCount);
                String proposersame = reader.getCellData(sheetName, "proposersame", rowCount);
                String relationwithinsured = reader.getCellData(sheetName, "relationwithinsured", rowCount);
                String isrelationanswer = reader.getCellData(sheetName, "isrelationanswer", rowCount);
                String isnri = reader.getCellData(sheetName, "isnri", rowCount);
                String pmobile = reader.getCellData(sheetName, "pmobile", rowCount);
                String ppan = reader.getCellData(sheetName, "ppan", rowCount);
                String imobile = reader.getCellData(sheetName, "imobile", rowCount);
                String ipan = reader.getCellData(sheetName, "ipan", rowCount);
                String firstname = reader.getCellData(sheetName, "firstname", rowCount);
                String lastname = reader.getCellData(sheetName, "lastname", rowCount);
                String middlename = reader.getCellData(sheetName, "middlename", rowCount);
                String day = reader.getCellData(sheetName, "day", rowCount);
                String month = reader.getCellData(sheetName, "month", rowCount);
                String year = reader.getCellData(sheetName, "year", rowCount);
                String gender = reader.getCellData(sheetName, "gender", rowCount);


                String planjourney = reader.getCellData(sheetName, "planjourney", rowCount);
                String proposerstate = reader.getCellData(sheetName, "proposerstate", rowCount);
                String advisorstatesame = reader.getCellData(sheetName, "advisorstatesame", rowCount);
                String plan = reader.getCellData(sheetName, "plan", rowCount);

                String sumassured = reader.getCellData(sheetName, "sumassured", rowCount);
                String smokertype = reader.getCellData(sheetName, "smokertype", rowCount);
                String planoptions = reader.getCellData(sheetName, "planoptions", rowCount);
                String increasinglevel = reader.getCellData(sheetName, "increasinglevel", rowCount);
                String ecs = reader.getCellData(sheetName, "ecs", rowCount);
                String term = reader.getCellData(sheetName, "term", rowCount);
                String ppt = reader.getCellData(sheetName, "ppt", rowCount);
                String premiumterm = reader.getCellData(sheetName, "premiumterm", rowCount);
                String premiumamount = reader.getCellData(sheetName, "premiumamount", rowCount);

                Object ob[] = {username, password, policy, leadid, proposersame, relationwithinsured, isrelationanswer, isnri,
                        pmobile, ppan, imobile, ipan, firstname, lastname, middlename, day, month, year, gender, planjourney,
                        proposerstate, advisorstatesame, plan, sumassured, smokertype,
                        planoptions, increasinglevel, ecs, term, ppt, premiumterm, premiumamount};
                myData.add(ob);
            }
        }
        System.out.println("mydata rows value **********" + myData.toString());
        return myData;
    }

    public static ArrayList<Object[]> getQuoteWithRiderDataFromExcel(String testExcelSheet, String testName, String sheetName) {
        ArrayList<Object[]> myData = new ArrayList<Object[]>();
        ArrayList<String> myColumnData = new ArrayList<String>();
        Xls_Reader reader = null;

        try {
            reader = new Xls_Reader(System.getProperty("user.dir") + testExcelSheet);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("Lifeshield SCREEN row count ---------" + reader.getRowCount(sheetName));

        for (int rowCount = 3; rowCount <= reader.getRowCount(sheetName); rowCount++) {
            String currentTestMethod = reader.getCellData(sheetName, "testCaseName", rowCount);
            String enableFlag = reader.getCellData(sheetName, "flag", rowCount);
            if (currentTestMethod.trim().equalsIgnoreCase(testName) && enableFlag.equalsIgnoreCase("YES")) {

                String username = reader.getCellData(sheetName, "username", rowCount);
                String password = reader.getCellData(sheetName, "password", rowCount);

                String policy = reader.getCellData(sheetName, "policy", rowCount);
                String leadid = reader.getCellData(sheetName, "leadid", rowCount);
                String proposersame = reader.getCellData(sheetName, "proposersame", rowCount);
                String relationwithinsured = reader.getCellData(sheetName, "relationwithinsured", rowCount);
                String isrelationanswer = reader.getCellData(sheetName, "isrelationanswer", rowCount);
                String isnri = reader.getCellData(sheetName, "isnri", rowCount);
                String pmobile = reader.getCellData(sheetName, "pmobile", rowCount);
                String ppan = reader.getCellData(sheetName, "ppan", rowCount);
                String imobile = reader.getCellData(sheetName, "imobile", rowCount);
                String ipan = reader.getCellData(sheetName, "ipan", rowCount);
                String firstname = reader.getCellData(sheetName, "firstname", rowCount);
                String lastname = reader.getCellData(sheetName, "lastname", rowCount);
                String middlename = reader.getCellData(sheetName, "middlename", rowCount);
                String day = reader.getCellData(sheetName, "day", rowCount);
                String month = reader.getCellData(sheetName, "month", rowCount);
                String year = reader.getCellData(sheetName, "year", rowCount);
                String gender = reader.getCellData(sheetName, "gender", rowCount);


                String planjourney = reader.getCellData(sheetName, "planjourney", rowCount);
                String proposerstate = reader.getCellData(sheetName, "proposerstate", rowCount);
                String advisorstatesame = reader.getCellData(sheetName, "advisorstatesame", rowCount);
                String plan = reader.getCellData(sheetName, "plan", rowCount);

                String sumassured = reader.getCellData(sheetName, "sumassured", rowCount);
                String smokertype = reader.getCellData(sheetName, "smokertype", rowCount);
                String planoptions = reader.getCellData(sheetName, "planoptions", rowCount);
                String increasinglevel = reader.getCellData(sheetName, "increasinglevel", rowCount);
                String ecs = reader.getCellData(sheetName, "ecs", rowCount);
                String term = reader.getCellData(sheetName, "term", rowCount);
                String ppt = reader.getCellData(sheetName, "ppt", rowCount);
                String premiumterm = reader.getCellData(sheetName, "premiumterm", rowCount);
                String premiumamount = reader.getCellData(sheetName, "premiumamount", rowCount);

                String rider = reader.getCellData(sheetName, "rider", rowCount);
                String rideramount = reader.getCellData(sheetName, "rideramount", rowCount);
                String minrider = reader.getCellData(sheetName, "minrider", rowCount);
                String maxrider = reader.getCellData(sheetName, "maxrider", rowCount);
                String ridererror = reader.getCellData(sheetName, "ridererror", rowCount);
                String click = reader.getCellData(sheetName, "click", rowCount);

                String generateillustrations = reader.getCellData(sheetName, "generateillustrations", rowCount);
                String clickcontinue = reader.getCellData(sheetName, "clickcontinue", rowCount);


                Object ob[] = {username, password, policy, leadid, proposersame, relationwithinsured, isrelationanswer, isnri, pmobile, ppan, imobile, ipan, firstname, lastname, middlename, day, month, year, gender, planjourney, proposerstate, advisorstatesame, plan, sumassured, smokertype, planoptions, increasinglevel, ecs, term, ppt, premiumterm, premiumamount,
                        rider, rideramount, minrider, maxrider, ridererror, click, generateillustrations, clickcontinue};
                myData.add(ob);
            }
        }
        System.out.println("mydata rows value **********" + myData.toString());
        return myData;
    }

    public static ArrayList<Object[]> getBankDataFromExcel(String testExcelSheet, String testName, String sheetName) {
        ArrayList<Object[]> myData = new ArrayList<Object[]>();
        Xls_Reader reader = null;

        try {
            reader = new Xls_Reader(System.getProperty("user.dir") + testExcelSheet);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("BANK sheet row count ---------" + reader.getRowCount(sheetName));

        for (int rowCount = 3; rowCount <= reader.getRowCount(sheetName); rowCount++) {
            String currentTestMethod = reader.getCellData(sheetName, "testCaseName", rowCount);
            String enableFlag = reader.getCellData(sheetName, "flag", rowCount);
            //if (currentTestMethod.trim().equalsIgnoreCase(testName) && enableFlag.equalsIgnoreCase("YES")) {
            if (currentTestMethod.trim().equalsIgnoreCase(testName)) {


                String username = reader.getCellData(sheetName, "username", rowCount);
                String password = reader.getCellData(sheetName, "password", rowCount);


                String policy = reader.getCellData(sheetName, "policy", rowCount);
                String leadid = reader.getCellData(sheetName, "leadid", rowCount);
                String proposersame = reader.getCellData(sheetName, "proposersame", rowCount);
                String relationwithinsured = reader.getCellData(sheetName, "relationwithinsured", rowCount);
                String isrelationanswer = reader.getCellData(sheetName, "isrelationanswer", rowCount);
                String isnri = reader.getCellData(sheetName, "isnri", rowCount);
                String pmobile = reader.getCellData(sheetName, "pmobile", rowCount);
                String ppan = reader.getCellData(sheetName, "ppan", rowCount);
                String imobile = reader.getCellData(sheetName, "imobile", rowCount);
                String ipan = reader.getCellData(sheetName, "ipan", rowCount);
                String firstname = reader.getCellData(sheetName, "firstname", rowCount);
                String lastname = reader.getCellData(sheetName, "lastname", rowCount);
                String middlename = reader.getCellData(sheetName, "middlename", rowCount);
                String day = reader.getCellData(sheetName, "day", rowCount);
                String month = reader.getCellData(sheetName, "month", rowCount);
                String year = reader.getCellData(sheetName, "year", rowCount);
                String gender = reader.getCellData(sheetName, "gender", rowCount);


                String planjourney = reader.getCellData(sheetName, "planjourney", rowCount);
                String proposerstate = reader.getCellData(sheetName, "proposerstate", rowCount);
                String advisorstatesame = reader.getCellData(sheetName, "advisorstatesame", rowCount);
                String plan = reader.getCellData(sheetName, "plan", rowCount);

                String sumassured = reader.getCellData(sheetName, "sumassured", rowCount);
                String smokertype = reader.getCellData(sheetName, "smokertype", rowCount);
                String planoptions = reader.getCellData(sheetName, "planoptions", rowCount);
                String increasinglevel = reader.getCellData(sheetName, "increasinglevel", rowCount);
                String ecs = reader.getCellData(sheetName, "ecs", rowCount);
                String term = reader.getCellData(sheetName, "term", rowCount);
                String ppt = reader.getCellData(sheetName, "ppt", rowCount);
                String premiumterm = reader.getCellData(sheetName, "premiumterm", rowCount);
                String premiumamount = reader.getCellData(sheetName, "premiumamount", rowCount);

                String rider = reader.getCellData(sheetName, "rider", rowCount);
                String rideramount = reader.getCellData(sheetName, "rideramount", rowCount);
                String minrider = reader.getCellData(sheetName, "minrider", rowCount);
                String maxrider = reader.getCellData(sheetName, "maxrider", rowCount);
                String ridererror = reader.getCellData(sheetName, "ridererror", rowCount);
                String click = reader.getCellData(sheetName, "click", rowCount);

                String generateillustrations = reader.getCellData(sheetName, "generateillustrations", rowCount);
                String clickcontinue = reader.getCellData(sheetName, "clickcontinue", rowCount);


                String ifsccode = reader.getCellData(sheetName, "ifsccode", rowCount);
                String bankaccno = reader.getCellData(sheetName, "bankaccno", rowCount);
                String accholdername = reader.getCellData(sheetName, "accholdername", rowCount);
                String accounttype = reader.getCellData(sheetName, "accounttype", rowCount);

                String pennyalert = reader.getCellData(sheetName, "pennyalert", rowCount);
                String clickverify = reader.getCellData(sheetName, "clickverify", rowCount);
                String renewpremiumscreentitle = reader.getCellData(sheetName, "renewpremiumscreentitle", rowCount);

                Object ob[] = {username, password, policy, leadid, proposersame, relationwithinsured, isrelationanswer, isnri, pmobile, ppan, imobile, ipan, firstname, lastname, middlename, day, month, year, gender, planjourney, proposerstate, advisorstatesame, plan, sumassured, smokertype, planoptions, increasinglevel, ecs, term, ppt, premiumterm, premiumamount,
                        rider, rideramount, minrider, maxrider, ridererror, click, generateillustrations, clickcontinue, ifsccode, bankaccno, accholdername,
                        accounttype, pennyalert, clickverify, renewpremiumscreentitle};
                myData.add(ob);
            }
        }
        System.out.println("mydata rows value **********" + myData.toString());
        return myData;
    }

    public static ArrayList<Object[]> getRenewalDataFromExcel(String testExcelSheet, String testName, String sheetName) {
        ArrayList<Object[]> myData = new ArrayList<Object[]>();
        Xls_Reader reader = null;

        try {
            reader = new Xls_Reader(System.getProperty("user.dir") + testExcelSheet);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("Renewal sheet row count ---------" + reader.getRowCount(sheetName));

        for (int rowCount = 3; rowCount <= reader.getRowCount(sheetName); rowCount++) {
            String currentTestMethod = reader.getCellData(sheetName, "testCaseName", rowCount);
            String enableFlag = reader.getCellData(sheetName, "flag", rowCount);
            if (currentTestMethod.trim().equalsIgnoreCase(testName) && enableFlag.equalsIgnoreCase("YES")) {

                String username = reader.getCellData(sheetName, "username", rowCount);
                String password = reader.getCellData(sheetName, "password", rowCount);


                String policy = reader.getCellData(sheetName, "policy", rowCount);
                String leadid = reader.getCellData(sheetName, "leadid", rowCount);
                String proposersame = reader.getCellData(sheetName, "proposersame", rowCount);
                String relationwithinsured = reader.getCellData(sheetName, "relationwithinsured", rowCount);
                String isrelationanswer = reader.getCellData(sheetName, "isrelationanswer", rowCount);
                String isnri = reader.getCellData(sheetName, "isnri", rowCount);
                String pmobile = reader.getCellData(sheetName, "pmobile", rowCount);
                String ppan = reader.getCellData(sheetName, "ppan", rowCount);
                String imobile = reader.getCellData(sheetName, "imobile", rowCount);
                String ipan = reader.getCellData(sheetName, "ipan", rowCount);
                String firstname = reader.getCellData(sheetName, "firstname", rowCount);
                String lastname = reader.getCellData(sheetName, "lastname", rowCount);
                String middlename = reader.getCellData(sheetName, "middlename", rowCount);
                String day = reader.getCellData(sheetName, "day", rowCount);
                String month = reader.getCellData(sheetName, "month", rowCount);
                String year = reader.getCellData(sheetName, "year", rowCount);
                String gender = reader.getCellData(sheetName, "gender", rowCount);


                String planjourney = reader.getCellData(sheetName, "planjourney", rowCount);
                String proposerstate = reader.getCellData(sheetName, "proposerstate", rowCount);
                String advisorstatesame = reader.getCellData(sheetName, "advisorstatesame", rowCount);

                String plan = reader.getCellData(sheetName, "plan", rowCount);
                String sumassured = reader.getCellData(sheetName, "sumassured", rowCount);
                String smokertype = reader.getCellData(sheetName, "smokertype", rowCount);
                String planoptions = reader.getCellData(sheetName, "planoptions", rowCount);
                String increasinglevel = reader.getCellData(sheetName, "increasinglevel", rowCount);
                String ecs = reader.getCellData(sheetName, "ecs", rowCount);
                String term = reader.getCellData(sheetName, "term", rowCount);
                String ppt = reader.getCellData(sheetName, "ppt", rowCount);
                String premiumterm = reader.getCellData(sheetName, "premiumterm", rowCount);
                String premiumamount = reader.getCellData(sheetName, "premiumamount", rowCount);

                String rider = reader.getCellData(sheetName, "rider", rowCount);
                String rideramount = reader.getCellData(sheetName, "rideramount", rowCount);
                String minrider = reader.getCellData(sheetName, "minrider", rowCount);
                String maxrider = reader.getCellData(sheetName, "maxrider", rowCount);
                String ridererror = reader.getCellData(sheetName, "ridererror", rowCount);
                String click = reader.getCellData(sheetName, "click", rowCount);

                String generateillustrations = reader.getCellData(sheetName, "generateillustrations", rowCount);
                String clickcontinue = reader.getCellData(sheetName, "clickcontinue", rowCount);


                String ifsccode = reader.getCellData(sheetName, "ifsccode", rowCount);
                String bankaccno = reader.getCellData(sheetName, "bankaccno", rowCount);
                String accholdername = reader.getCellData(sheetName, "accholdername", rowCount);
                String accounttype = reader.getCellData(sheetName, "accounttype", rowCount);

                String pennyalert = reader.getCellData(sheetName, "pennyalert", rowCount);
                String clickverify = reader.getCellData(sheetName, "clickverify", rowCount);
                String renewpremiumscreentitle = reader.getCellData(sheetName, "renewpremiumscreentitle", rowCount);

                String paymentmethod = reader.getCellData(sheetName, "paymentmethod", rowCount);
                String drawdate = reader.getCellData(sheetName, "drawdate", rowCount);
                String fundsource = reader.getCellData(sheetName, "fundsource", rowCount);
                String nomineescreentitle = reader.getCellData(sheetName, "nomineescreentitle", rowCount);


                Object ob[] = {username.trim(), password.trim(), policy.trim(), leadid.trim(), proposersame.trim(), relationwithinsured, isrelationanswer,
                        isnri.trim(), pmobile.trim(), ppan.trim(), imobile.trim(), ipan.trim(), firstname.trim(), lastname.trim(),
                        middlename.trim(), day.trim(), month.trim(), year.trim(),
                        gender.trim(), planjourney.trim(), proposerstate.trim(), advisorstatesame.trim(), plan.trim(), sumassured.trim(), smokertype.trim(), planoptions.trim(), increasinglevel.trim(),
                        ecs.trim(), term.trim(), ppt.trim(), premiumterm.trim(), premiumamount.trim(), rider.trim(), rideramount.trim(), minrider.trim(), maxrider.trim(), ridererror.trim(), click.trim(),
                        generateillustrations.trim(), clickcontinue.trim(), ifsccode.trim(), bankaccno.trim(), accholdername.trim(),
                        accounttype.trim(), pennyalert.trim(), clickverify.trim(), renewpremiumscreentitle.trim(), paymentmethod.trim(),
                        drawdate.trim(), fundsource.trim(), nomineescreentitle.trim()};
                myData.add(ob);
            }
        }
        System.out.println("mydata rows value **********" + myData.toString());
        return myData;
    }

    public ArrayList<Object[]> getNomineeDataFromExcel(String testExcelSheet, String testName, String sheetName) {
        ArrayList<Object[]> myData = new ArrayList<Object[]>();
        Xls_Reader reader = null;


        try {
            reader = new Xls_Reader(System.getProperty("user.dir") + testExcelSheet);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("Nominee Sheet row count ---------" + reader.getRowCount(sheetName));

        for (int rowCount = 3; rowCount <= reader.getRowCount(sheetName); rowCount++) {
            String currentTestMethod = reader.getCellData(sheetName, "testCaseName", rowCount);
            String enableFlag = reader.getCellData(sheetName, "flag", rowCount);
            //if (currentTestMethod.trim().equalsIgnoreCase(testName) && enableFlag.equalsIgnoreCase("YES")) {
            if (currentTestMethod.trim().equalsIgnoreCase(testName)) {
                String username = reader.getCellData(sheetName, "username", rowCount);
                String password = reader.getCellData(sheetName, "password", rowCount);


                String policy = reader.getCellData(sheetName, "policy", rowCount);
                String leadid = reader.getCellData(sheetName, "leadid", rowCount);
                String proposersame = reader.getCellData(sheetName, "proposersame", rowCount);
                String relationwithinsured = reader.getCellData(sheetName, "relationwithinsured", rowCount);
                String isrelationanswer = reader.getCellData(sheetName, "isrelationanswer", rowCount);
                String isnri = reader.getCellData(sheetName, "isnri", rowCount);
                String pmobile = reader.getCellData(sheetName, "pmobile", rowCount);
                String ppan = reader.getCellData(sheetName, "ppan", rowCount);
                String imobile = reader.getCellData(sheetName, "imobile", rowCount);
                String ipan = reader.getCellData(sheetName, "ipan", rowCount);
                String firstname = reader.getCellData(sheetName, "firstname", rowCount);
                String lastname = reader.getCellData(sheetName, "lastname", rowCount);
                String middlename = reader.getCellData(sheetName, "middlename", rowCount);
                String day = reader.getCellData(sheetName, "day", rowCount);
                String month = reader.getCellData(sheetName, "month", rowCount);
                String year = reader.getCellData(sheetName, "year", rowCount);
                String gender = reader.getCellData(sheetName, "gender", rowCount);


                String planjourney = reader.getCellData(sheetName, "planjourney", rowCount);
                String proposerstate = reader.getCellData(sheetName, "proposerstate", rowCount);
                String advisorstatesame = reader.getCellData(sheetName, "advisorstatesame", rowCount);

                String plan = reader.getCellData(sheetName, "plan", rowCount);
                String sumassured = reader.getCellData(sheetName, "sumassured", rowCount);
                String smokertype = reader.getCellData(sheetName, "smokertype", rowCount);
                String planoptions = reader.getCellData(sheetName, "planoptions", rowCount);
                String increasinglevel = reader.getCellData(sheetName, "increasinglevel", rowCount);
                String ecs = reader.getCellData(sheetName, "ecs", rowCount);
                String term = reader.getCellData(sheetName, "term", rowCount);
                String ppt = reader.getCellData(sheetName, "ppt", rowCount);
                String premiumterm = reader.getCellData(sheetName, "premiumterm", rowCount);
                String premiumamount = reader.getCellData(sheetName, "premiumamount", rowCount);

                String rider = reader.getCellData(sheetName, "rider", rowCount);
                String rideramount = reader.getCellData(sheetName, "rideramount", rowCount);
                String minrider = reader.getCellData(sheetName, "minrider", rowCount);
                String maxrider = reader.getCellData(sheetName, "maxrider", rowCount);
                String ridererror = reader.getCellData(sheetName, "ridererror", rowCount);
                String click = reader.getCellData(sheetName, "click", rowCount);

                String generateillustrations = reader.getCellData(sheetName, "generateillustrations", rowCount);
                String clickcontinue = reader.getCellData(sheetName, "clickcontinue", rowCount);


                String ifsccode = reader.getCellData(sheetName, "ifsccode", rowCount);
                String bankaccno = reader.getCellData(sheetName, "bankaccno", rowCount);
                String accholdername = reader.getCellData(sheetName, "accholdername", rowCount);
                String accounttype = reader.getCellData(sheetName, "accounttype", rowCount);

                String pennyalert = reader.getCellData(sheetName, "pennyalert", rowCount);
                String clickverify = reader.getCellData(sheetName, "clickverify", rowCount);
                String renewpremiumscreentitle = reader.getCellData(sheetName, "renewpremiumscreentitle", rowCount);

                String paymentmethod = reader.getCellData(sheetName, "paymentmethod", rowCount);
                String drawdate = reader.getCellData(sheetName, "drawdate", rowCount);
                String fundsource = reader.getCellData(sheetName, "fundsource", rowCount);
                String nomineescreentitle = reader.getCellData(sheetName, "nomineescreentitle", rowCount);

                String nomineefirstname = reader.getCellData(sheetName, "nomineefirstname", rowCount);
                String nomineelastname = reader.getCellData(sheetName, "nomineelastname", rowCount);
                String nomineeday = reader.getCellData(sheetName, "nomineeday", rowCount);
                String nomineemonth = reader.getCellData(sheetName, "nomineemonth", rowCount);
                String nomineeyear = reader.getCellData(sheetName, "nomineeyear", rowCount);
                String nomineegender = reader.getCellData(sheetName, "nomineegender", rowCount);
                String relationshipwithproposer = reader.getCellData(sheetName, "relationshipwithproposer", rowCount);
                String nomineeshare = reader.getCellData(sheetName, "nomineeshare", rowCount);
                String ismwppolicy = reader.getCellData(sheetName, "ismwppolicy", rowCount);
                String addressscreentitle = reader.getCellData(sheetName, "addressscreentitle", rowCount);


                Object ob[] = {username.trim(), password.trim(), policy.trim(), leadid.trim(), proposersame.trim(), relationwithinsured, isrelationanswer,
                        isnri.trim(), pmobile.trim(), ppan.trim(), imobile.trim(), ipan.trim(), firstname.trim(), lastname.trim(),
                        middlename.trim(), day.trim(), month.trim(), year.trim(),
                        gender.trim(), planjourney.trim(), proposerstate.trim(), advisorstatesame.trim(), plan.trim(), sumassured.trim(), smokertype.trim(), planoptions.trim(), increasinglevel.trim(),
                        ecs.trim(), term.trim(), ppt.trim(), premiumterm.trim(), premiumamount.trim(), rider.trim(), rideramount.trim(), minrider.trim(), maxrider.trim(), ridererror.trim(), click.trim(),
                        generateillustrations.trim(), clickcontinue.trim(), ifsccode.trim(), bankaccno.trim(), accholdername.trim(),
                        accounttype.trim(), pennyalert.trim(), clickverify.trim(), renewpremiumscreentitle.trim(), paymentmethod.trim(),
                        drawdate.trim(), fundsource.trim(), nomineescreentitle.trim(), nomineefirstname.trim(), nomineelastname.trim(), nomineeday.trim(),
                        nomineemonth.trim(), nomineeyear.trim(), nomineegender.trim(), relationshipwithproposer.trim(), nomineeshare.trim(), ismwppolicy.trim(), addressscreentitle.trim(),};
                myData.add(ob);
            }
        }
        System.out.println("mydata rows value **********" + myData.toString());
        return myData;
    }

    public static ArrayList<Object[]> getAddressDataFromExcel(String testExcelSheet, String testName, String sheetName) {
        ArrayList<Object[]> myData = new ArrayList<Object[]>();

        try {
            reader = new Xls_Reader(System.getProperty("user.dir") + testExcelSheet);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("Address sheet row count ---------" + reader.getRowCount(sheetName));

        for (int rowCount = 3; rowCount <= reader.getRowCount(sheetName); rowCount++) {
            String currentTestMethod = reader.getCellData(sheetName, "testCaseName", rowCount);
            String enableFlag = reader.getCellData(sheetName, "flag", rowCount);
            if (currentTestMethod.trim().equalsIgnoreCase(testName) && enableFlag.equalsIgnoreCase("YES")) {

                String username = reader.getCellData(sheetName, "username", rowCount);
                String password = reader.getCellData(sheetName, "password", rowCount);


                String policy = reader.getCellData(sheetName, "policy", rowCount);
                String leadid = reader.getCellData(sheetName, "leadid", rowCount);
                String proposersame = reader.getCellData(sheetName, "proposersame", rowCount);
                String relationwithinsured = reader.getCellData(sheetName, "relationwithinsured", rowCount);
                String isrelationanswer = reader.getCellData(sheetName, "isrelationanswer", rowCount);


                String isnri = reader.getCellData(sheetName, "isnri", rowCount);
                String pmobile = reader.getCellData(sheetName, "pmobile", rowCount);
                String ppan = reader.getCellData(sheetName, "ppan", rowCount);
                String imobile = reader.getCellData(sheetName, "imobile", rowCount);
                String ipan = reader.getCellData(sheetName, "ipan", rowCount);
                String firstname = reader.getCellData(sheetName, "firstname", rowCount);
                String lastname = reader.getCellData(sheetName, "lastname", rowCount);
                String middlename = reader.getCellData(sheetName, "middlename", rowCount);
                String day = reader.getCellData(sheetName, "day", rowCount);
                String month = reader.getCellData(sheetName, "month", rowCount);
                String year = reader.getCellData(sheetName, "year", rowCount);
                String gender = reader.getCellData(sheetName, "gender", rowCount);


                String planjourney = reader.getCellData(sheetName, "planjourney", rowCount);
                String proposerstate = reader.getCellData(sheetName, "proposerstate", rowCount);
                String advisorstatesame = reader.getCellData(sheetName, "advisorstatesame", rowCount);

                String plan = reader.getCellData(sheetName, "plan", rowCount);
                String sumassured = reader.getCellData(sheetName, "sumassured", rowCount);
                String smokertype = reader.getCellData(sheetName, "smokertype", rowCount);
                String planoptions = reader.getCellData(sheetName, "planoptions", rowCount);
                String increasinglevel = reader.getCellData(sheetName, "increasinglevel", rowCount);
                String ecs = reader.getCellData(sheetName, "ecs", rowCount);
                String term = reader.getCellData(sheetName, "term", rowCount);
                String ppt = reader.getCellData(sheetName, "ppt", rowCount);
                String premiumterm = reader.getCellData(sheetName, "premiumterm", rowCount);
                String premiumamount = reader.getCellData(sheetName, "premiumamount", rowCount);

                String rider = reader.getCellData(sheetName, "rider", rowCount);
                String rideramount = reader.getCellData(sheetName, "rideramount", rowCount);
                String minrider = reader.getCellData(sheetName, "minrider", rowCount);
                String maxrider = reader.getCellData(sheetName, "maxrider", rowCount);
                String ridererror = reader.getCellData(sheetName, "ridererror", rowCount);
                String click = reader.getCellData(sheetName, "click", rowCount);

                String generateillustrations = reader.getCellData(sheetName, "generateillustrations", rowCount);
                String clickcontinue = reader.getCellData(sheetName, "clickcontinue", rowCount);


                String ifsccode = reader.getCellData(sheetName, "ifsccode", rowCount);
                String bankaccno = reader.getCellData(sheetName, "bankaccno", rowCount);
                String accholdername = reader.getCellData(sheetName, "accholdername", rowCount);
                String accounttype = reader.getCellData(sheetName, "accounttype", rowCount);

                String pennyalert = reader.getCellData(sheetName, "pennyalert", rowCount);
                String clickverify = reader.getCellData(sheetName, "clickverify", rowCount);
                String renewpremiumscreentitle = reader.getCellData(sheetName, "renewpremiumscreentitle", rowCount);

                String paymentmethod = reader.getCellData(sheetName, "paymentmethod", rowCount);
                String drawdate = reader.getCellData(sheetName, "drawdate", rowCount);
                String fundsource = reader.getCellData(sheetName, "fundsource", rowCount);
                String nomineescreentitle = reader.getCellData(sheetName, "nomineescreentitle", rowCount);

                String nomineefirstname = reader.getCellData(sheetName, "nomineefirstname", rowCount);
                String nomineelastname = reader.getCellData(sheetName, "nomineelastname", rowCount);
                String nomineeday = reader.getCellData(sheetName, "nomineeday", rowCount);
                String nomineemonth = reader.getCellData(sheetName, "nomineemonth", rowCount);
                String nomineeyear = reader.getCellData(sheetName, "nomineeyear", rowCount);
                String nomineegender = reader.getCellData(sheetName, "nomineegender", rowCount);
                String relationshipwithproposer = reader.getCellData(sheetName, "relationshipwithproposer", rowCount);
                String nomineeshare = reader.getCellData(sheetName, "nomineeshare", rowCount);
                String ismwppolicy = reader.getCellData(sheetName, "ismwppolicy", rowCount);
                String addressscreentitle = reader.getCellData(sheetName, "addressscreentitle", rowCount);
                String typeofaddress = reader.getCellData(sheetName, "typeofaddress", rowCount);
                String addresspincode = reader.getCellData(sheetName, "addresspincode", rowCount);
                String address1 = reader.getCellData(sheetName, "address1", rowCount);
                String address2 = reader.getCellData(sheetName, "address2", rowCount);
                String address3 = reader.getCellData(sheetName, "address3", rowCount);
                String personalDetailsscreentitle = reader.getCellData(sheetName, "personalDetailsscreentitle", rowCount);
                String cityName = reader.getCellData(sheetName, "cityName", rowCount);
                String preferredLanguage = reader.getCellData(sheetName, "preferredLanguage", rowCount);
                String alernateNumber = reader.getCellData(sheetName, "alernateNumber", rowCount);
                String resTelephoneNumber = reader.getCellData(sheetName, "resTelephoneNumber", rowCount);


                Object ob[] = {username.trim(), password.trim(), policy.trim(), leadid.trim(), proposersame.trim(), relationwithinsured.trim(), isrelationanswer.trim(),
                        isnri.trim(), pmobile.trim(), ppan.trim(), imobile.trim(), ipan.trim(), firstname.trim(), lastname.trim(),
                        middlename.trim(), day.trim(), month.trim(), year.trim(),
                        gender.trim(), planjourney.trim(), proposerstate.trim(), advisorstatesame.trim(), plan.trim(), sumassured.trim(), smokertype.trim(), planoptions.trim(), increasinglevel.trim(),
                        ecs.trim(), term.trim(), ppt.trim(), premiumterm.trim(), premiumamount.trim(), rider.trim(), rideramount.trim(), minrider.trim(), maxrider.trim(), ridererror.trim(), click.trim(),
                        generateillustrations.trim(), clickcontinue.trim(), ifsccode.trim(), bankaccno.trim(), accholdername.trim(),
                        accounttype.trim(), pennyalert.trim(), clickverify.trim(), renewpremiumscreentitle.trim(), paymentmethod.trim(),
                        drawdate.trim(), fundsource.trim(), nomineescreentitle.trim(), nomineefirstname.trim(), nomineelastname.trim(), nomineeday.trim(),
                        nomineemonth.trim(), nomineeyear.trim(), nomineegender.trim(), relationshipwithproposer.trim(), nomineeshare.trim(), ismwppolicy.trim(), addressscreentitle.trim(),
                        typeofaddress.trim(), addresspincode.trim(), address1.trim(), address2.trim(), address3.trim(), personalDetailsscreentitle.trim(), cityName.trim(), preferredLanguage.trim(), alernateNumber.trim(), resTelephoneNumber.trim()};
                myData.add(ob);
            }
        }
        System.out.println("mydata rows value **********" + myData.toString());
        return myData;
    }

    public ArrayList<Object[]> getPlanDataFromExcel(String testExcelSheet, String testName, String sheetName) {
        ArrayList<Object[]> myData = new ArrayList<Object[]>();
        Xls_Reader reader = null;

        try {
            reader = new Xls_Reader(System.getProperty("user.dir") + testExcelSheet);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("Plan sheet row count ---------" + reader.getRowCount(sheetName));

        for (int rowCount = 3; rowCount <= reader.getRowCount(sheetName); rowCount++) {
            String currentTestMethod = reader.getCellData(sheetName, "testCaseName", rowCount);
//            System.out.println(" ******* current test running method  *********" + currentTestMethod);

            String enableFlag = reader.getCellData(sheetName, "flag", rowCount);
            // if (currentTestMethod.equalsIgnoreCase(testName) && enableFlag.equalsIgnoreCase("YES")) {
            if (currentTestMethod.equalsIgnoreCase(testName)) {

                String username = reader.getCellData(sheetName, "username", rowCount);
                String password = reader.getCellData(sheetName, "password", rowCount);


                String policy = reader.getCellData(sheetName, "policy", rowCount);
                String leadid = reader.getCellData(sheetName, "leadid", rowCount);
                String proposersame = reader.getCellData(sheetName, "proposersame", rowCount);
                String relationwithinsured = reader.getCellData(sheetName, "relationwithinsured", rowCount);
                String isrelationanswer = reader.getCellData(sheetName, "isrelationanswer", rowCount);
                String isnri = reader.getCellData(sheetName, "isnri", rowCount);
                String pmobile = reader.getCellData(sheetName, "pmobile", rowCount);
                String ppan = reader.getCellData(sheetName, "ppan", rowCount);
                String imobile = reader.getCellData(sheetName, "imobile", rowCount);
                String ipan = reader.getCellData(sheetName, "ipan", rowCount);
                String firstname = reader.getCellData(sheetName, "firstname", rowCount);
                String lastname = reader.getCellData(sheetName, "lastname", rowCount);
                String middlename = reader.getCellData(sheetName, "middlename", rowCount);
                String day = reader.getCellData(sheetName, "day", rowCount);
                String month = reader.getCellData(sheetName, "month", rowCount);
                String year = reader.getCellData(sheetName, "year", rowCount);
                String gender = reader.getCellData(sheetName, "gender", rowCount);


                String planjourney = reader.getCellData(sheetName, "planjourney", rowCount);
                String proposerstate = reader.getCellData(sheetName, "proposerstate", rowCount);
                String advisorstatesame = reader.getCellData(sheetName, "advisorstatesame", rowCount);
                String plan = reader.getCellData(sheetName, "plan", rowCount);

                Object ob[] = {username.trim(), password.trim(), policy.trim(), leadid.trim(), proposersame.trim(), relationwithinsured, isrelationanswer,
                        isnri.trim(), pmobile.trim(), ppan.trim(), imobile.trim(), ipan.trim(), firstname.trim(), lastname.trim(),
                        middlename.trim(), day.trim(), month.trim(), year.trim(),
                        gender.trim(), planjourney.trim(), proposerstate.trim(), advisorstatesame.trim(), plan.trim()};
                myData.add(ob);
            }
        }
        // System.out.println("mydata rows value **********" + myData);
        return myData;
    }

    public String isStep(String testExcelSheet, String productName, String sheetName, String stepName) {
        ArrayList<Object[]> myData = new ArrayList<Object[]>();
        Xls_Reader reader = null;
        String step = null;

        try {
            reader = new Xls_Reader(System.getProperty("user.dir") + testExcelSheet);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("row count ---------" + reader.getRowCount(sheetName));

        for (int rowCount = 2; rowCount <= reader.getRowCount(sheetName); rowCount++) {
            String product = reader.getCellData(sheetName, "product", rowCount);
            if (product.equalsIgnoreCase(product)) {

                step = reader.getCellData(sheetName, stepName, rowCount);
            }
        }
        return step;
    }

    public ArrayList<Object[]> getMobilePanDataFromExcel(String testExcelSheet, String testName, String sheetName) {
        ArrayList<Object[]> myData = new ArrayList<Object[]>();
        ArrayList<String> myColumnData = new ArrayList<String>();
        Xls_Reader reader = null;

        try {
            reader = new Xls_Reader(System.getProperty("user.dir") + testExcelSheet);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("Capture pan row count ---------" + reader.getRowCount(sheetName));

        for (int rowCount = 3; rowCount <= reader.getRowCount(sheetName); rowCount++) {
            String currentTestMethod = reader.getCellData(sheetName, "testCaseName", rowCount);
            String enableFlag = reader.getCellData(sheetName, "flag", rowCount);
            if (currentTestMethod.equalsIgnoreCase(testName) && enableFlag.equalsIgnoreCase("YES")) {

                String username = reader.getCellData(sheetName, "username", rowCount);
                String password = reader.getCellData(sheetName, "password", rowCount);


                String policy = reader.getCellData(sheetName, "policy", rowCount);
                String leadid = reader.getCellData(sheetName, "leadid", rowCount);
                String proposersame = reader.getCellData(sheetName, "proposersame", rowCount);
                String relationwithinsured = reader.getCellData(sheetName, "relationwithinsured", rowCount);
                String isrelationanswer = reader.getCellData(sheetName, "isrelationanswer", rowCount);


                String isnri = reader.getCellData(sheetName, "isnri", rowCount);
                String pmobile = reader.getCellData(sheetName, "pmobile", rowCount);
                String ppan = reader.getCellData(sheetName, "ppan", rowCount);
                String imobile = reader.getCellData(sheetName, "imobile", rowCount);
                String ipan = reader.getCellData(sheetName, "ipan", rowCount);

                Object ob[] = {username.trim(), password.trim(), policy.trim(), leadid.trim(), proposersame.trim(),
                        relationwithinsured.trim(), isrelationanswer.trim(),
                        isnri.trim(), pmobile.trim(), ppan.trim(), imobile.trim(), ipan.trim()};
                myData.add(ob);
            }
        }
        System.out.println("mydata rows value **********" + myData.toString());
        return myData;
    }

    public ArrayList<Object[]> getPrefillMajorDiffDataFromExcel(String testExcelSheet, String testName, String sheetName) {
        ArrayList<Object[]> myData = new ArrayList<Object[]>();
        Xls_Reader reader = null;

        try {
            reader = new Xls_Reader(System.getProperty("user.dir") + testExcelSheet);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("Prefill sheet row count ---------" + reader.getRowCount(sheetName));

        for (int rowCount = 3; rowCount <= reader.getRowCount(sheetName); rowCount++) {
            String currentTestMethod = reader.getCellData(sheetName, "testCaseName", rowCount);
//            System.out.println(" ******* current test running method  *********" + currentTestMethod);

            String enableFlag = reader.getCellData(sheetName, "flag", rowCount);
            if (currentTestMethod.equalsIgnoreCase(testName) && enableFlag.equalsIgnoreCase("YES")) {


                String username = reader.getCellData(sheetName, "username", rowCount);
                String password = reader.getCellData(sheetName, "password", rowCount);


                String policy = reader.getCellData(sheetName, "policy", rowCount);
                String leadid = reader.getCellData(sheetName, "leadid", rowCount);
                String proposersame = reader.getCellData(sheetName, "proposersame", rowCount);
                String relationwithinsured = reader.getCellData(sheetName, "relationwithinsured", rowCount);
                String isrelationanswer = reader.getCellData(sheetName, "isrelationanswer", rowCount);
                String isnri = reader.getCellData(sheetName, "isnri", rowCount);
                String pmobile = reader.getCellData(sheetName, "pmobile", rowCount);
                String ppan = reader.getCellData(sheetName, "ppan", rowCount);
                String imobile = reader.getCellData(sheetName, "imobile", rowCount);
                String ipan = reader.getCellData(sheetName, "ipan", rowCount);
                String firstname = reader.getCellData(sheetName, "firstname", rowCount);
                String lastname = reader.getCellData(sheetName, "lastname", rowCount);
                String middlename = reader.getCellData(sheetName, "middlename", rowCount);
                String day = reader.getCellData(sheetName, "day", rowCount);
                String month = reader.getCellData(sheetName, "month", rowCount);
                String year = reader.getCellData(sheetName, "year", rowCount);
                String gender = reader.getCellData(sheetName, "gender", rowCount);

                String ifirstname = reader.getCellData(sheetName, "ifirstname", rowCount);
                String ilastname = reader.getCellData(sheetName, "ilastname", rowCount);
                String imiddlename = reader.getCellData(sheetName, "imiddlename", rowCount);
                String iday = reader.getCellData(sheetName, "iday", rowCount);
                String imonth = reader.getCellData(sheetName, "imonth", rowCount);
                String iyear = reader.getCellData(sheetName, "iyear", rowCount);
                String igender = reader.getCellData(sheetName, "igender", rowCount);

                Object ob[] = {username.trim(), password.trim(), policy.trim(), leadid.trim(), proposersame.trim(), relationwithinsured, isrelationanswer,
                        isnri.trim(), pmobile.trim(), ppan.trim(), imobile.trim(), ipan.trim(), firstname.trim(), lastname.trim(),
                        middlename.trim(), day.trim(), month.trim(), year.trim(),
                        gender.trim(), ifirstname.trim(), ilastname.trim(), imiddlename.trim(), iday.trim(), imonth.trim(), iyear.trim(), igender.trim()};
                myData.add(ob);
            }
        }
        // System.out.println("mydata rows value **********" + myData);
        return myData;
    }

    public ArrayList<Object[]> getPrefillMajorSameDataFromExcel(String testExcelSheet, String testName, String sheetName) {
        ArrayList<Object[]> myData = new ArrayList<Object[]>();
        Xls_Reader reader = null;

        try {
            reader = new Xls_Reader(System.getProperty("user.dir") + testExcelSheet);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("Prefill sheet row count ---------" + reader.getRowCount(sheetName));

        for (int rowCount = 3; rowCount <= reader.getRowCount(sheetName); rowCount++) {
            String currentTestMethod = reader.getCellData(sheetName, "testCaseName", rowCount);
//            System.out.println(" ******* current test running method  *********" + currentTestMethod);

            String enableFlag = reader.getCellData(sheetName, "flag", rowCount);
            if (currentTestMethod.equalsIgnoreCase(testName) && enableFlag.equalsIgnoreCase("YES")) {


                String username = reader.getCellData(sheetName, "username", rowCount);
                String password = reader.getCellData(sheetName, "password", rowCount);


                String policy = reader.getCellData(sheetName, "policy", rowCount);
                String leadid = reader.getCellData(sheetName, "leadid", rowCount);
                String proposersame = reader.getCellData(sheetName, "proposersame", rowCount);
                String relationwithinsured = reader.getCellData(sheetName, "relationwithinsured", rowCount);
                String isrelationanswer = reader.getCellData(sheetName, "isrelationanswer", rowCount);
                String isnri = reader.getCellData(sheetName, "isnri", rowCount);
                String pmobile = reader.getCellData(sheetName, "pmobile", rowCount);
                String ppan = reader.getCellData(sheetName, "ppan", rowCount);
                String imobile = reader.getCellData(sheetName, "imobile", rowCount);
                String ipan = reader.getCellData(sheetName, "ipan", rowCount);
                String firstname = reader.getCellData(sheetName, "firstname", rowCount);
                String lastname = reader.getCellData(sheetName, "lastname", rowCount);
                String middlename = reader.getCellData(sheetName, "middlename", rowCount);
                String day = reader.getCellData(sheetName, "day", rowCount);
                String month = reader.getCellData(sheetName, "month", rowCount);
                String year = reader.getCellData(sheetName, "year", rowCount);
                String gender = reader.getCellData(sheetName, "gender", rowCount);

                Object ob[] = {username.trim(), password.trim(), policy.trim(), leadid.trim(), proposersame.trim(), relationwithinsured, isrelationanswer,
                        isnri.trim(), pmobile.trim(), ppan.trim(), imobile.trim(), ipan.trim(), firstname.trim(), lastname.trim(),
                        middlename.trim(), day.trim(), month.trim(), year.trim(),
                        gender.trim()};
                myData.add(ob);
            }
        }
        // System.out.println("mydata rows value **********" + myData);
        return myData;
    }

    public String getCellData(String testExcelSheet, String testName, String sheetName, String colName) {
        String value = null;
        Xls_Reader reader = null;

        try {
            reader = new Xls_Reader(System.getProperty("user.dir") + testExcelSheet);
        } catch (Exception e) {
            e.printStackTrace();
        }

        for (int rowCount = 3; rowCount <= reader.getRowCount(sheetName); rowCount++) {
            String currentTestMethod = reader.getCellData(sheetName, "testCaseName", rowCount);
            //String enableFlag = reader.getCellData(sheetName, "flag", rowCount);
            //if (currentTestMethod.equalsIgnoreCase(testName) && enableFlag.equalsIgnoreCase("YES")) {
            if (currentTestMethod.equalsIgnoreCase(testName)) {

                value = reader.getCellData(sheetName, colName, rowCount);

            }
        }
        return value;
    }

    public List<String> getMobilePanDataForTest() throws IOException {
        PropertiesUtils prop = new PropertiesUtils();
        ArrayList<Object[]> obj = new ExcelUtils().getMobilePanDataFromExcel(prop.getProperties("testExcelSheet"), "enterMobileNo", prop.getProperties("captureMobilePanSheetName"));
        List<String> myData = new ArrayList<>();
        //ArrayList<HashMap<String,String>> = new ArrayList<HashMap<String,String>>();
        try {
            for (Object[] o : obj) {
                for (Object o1 : o) {
                    myData.add(o1.toString());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println(myData);
        return myData;
    }

    public String getAppFileName(String testExcelSheet, String sheetName, String colName) {
        String value = null;
        Xls_Reader reader = null;

        try {
            reader = new Xls_Reader(System.getProperty("user.dir") + testExcelSheet);
        } catch (Exception e) {
            e.printStackTrace();
        }
        for (int rowCount = 2; rowCount <= reader.getRowCount(sheetName); rowCount++) {
            value = reader.getCellData(sheetName, colName, rowCount);
            if (value != null) {
                return value;
            }
        }
        return value;
    }

    public static ArrayList<Object[]> getCapturedEmailTestData(String testExcelSheet, String testName, String sheetName) {
        ArrayList<Object[]> myData = new ArrayList<Object[]>();
        Xls_Reader reader = null;

        try {
            reader = new Xls_Reader(System.getProperty("user.dir") + testExcelSheet);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("row count ---------" + reader.getRowCount(sheetName));

        for (int rowCount = 3; rowCount <= reader.getRowCount(sheetName); rowCount++) {
            String currentTestMethod = reader.getCellData(sheetName, "testCaseName", rowCount);
            String enableFlag = reader.getCellData(sheetName, "flag", rowCount);
            if (currentTestMethod.trim().equalsIgnoreCase(testName) && enableFlag.equalsIgnoreCase("YES")) {

                String username = reader.getCellData(sheetName, "username", rowCount);
                String password = reader.getCellData(sheetName, "password", rowCount);
                String policy = reader.getCellData(sheetName, "policy", rowCount);
                String leadid = reader.getCellData(sheetName, "leadid", rowCount);
                String proposersame = reader.getCellData(sheetName, "proposersame", rowCount);
                String propinsurednotsame = reader.getCellData(sheetName, "propinsurednotsame", rowCount);
                String isnri = reader.getCellData(sheetName, "isnri", rowCount);
                String pmobile = reader.getCellData(sheetName, "pmobile", rowCount);
                String ppan = reader.getCellData(sheetName, "ppan", rowCount);
                String imobile = reader.getCellData(sheetName, "imobile", rowCount);
                String ipan = reader.getCellData(sheetName, "ipan", rowCount);
                String firstname = reader.getCellData(sheetName, "firstname", rowCount);
                String lastname = reader.getCellData(sheetName, "lastname", rowCount);
                String middlename = reader.getCellData(sheetName, "middlename", rowCount);
                String day = reader.getCellData(sheetName, "day", rowCount);
                String month = reader.getCellData(sheetName, "month", rowCount);
                String year = reader.getCellData(sheetName, "year", rowCount);
                String gender = reader.getCellData(sheetName, "gender", rowCount);


                String planjourney = reader.getCellData(sheetName, "planjourney", rowCount);
                String proposerstate = reader.getCellData(sheetName, "proposerstate", rowCount);
                String advisorstatesame = reader.getCellData(sheetName, "advisorstatesame", rowCount);

                String plan = reader.getCellData(sheetName, "plan", rowCount);
                String sumassured = reader.getCellData(sheetName, "sumassured", rowCount);
                String smokertype = reader.getCellData(sheetName, "smokertype", rowCount);
                String planoptions = reader.getCellData(sheetName, "planoptions", rowCount);
                String increasinglevel = reader.getCellData(sheetName, "increasinglevel", rowCount);
                String ecs = reader.getCellData(sheetName, "ecs", rowCount);
                String term = reader.getCellData(sheetName, "term", rowCount);
                String ppt = reader.getCellData(sheetName, "ppt", rowCount);
                String premiumterm = reader.getCellData(sheetName, "premiumterm", rowCount);
                String premiumamount = reader.getCellData(sheetName, "premiumamount", rowCount);

                String rider = reader.getCellData(sheetName, "rider", rowCount);
                String rideramount = reader.getCellData(sheetName, "rideramount", rowCount);
                String minrider = reader.getCellData(sheetName, "minrider", rowCount);
                String maxrider = reader.getCellData(sheetName, "maxrider", rowCount);
                String ridererror = reader.getCellData(sheetName, "ridererror", rowCount);
                String click = reader.getCellData(sheetName, "click", rowCount);

                String generateillustrations = reader.getCellData(sheetName, "generateillustrations", rowCount);
                String clickcontinue = reader.getCellData(sheetName, "clickcontinue", rowCount);


                String ifsccode = reader.getCellData(sheetName, "ifsccode", rowCount);
                String bankaccno = reader.getCellData(sheetName, "bankaccno", rowCount);
                String accholdername = reader.getCellData(sheetName, "accholdername", rowCount);
                String accounttype = reader.getCellData(sheetName, "accounttype", rowCount);

                String pennyalert = reader.getCellData(sheetName, "pennyalert", rowCount);
                String clickverify = reader.getCellData(sheetName, "clickverify", rowCount);

                String renewpremiumscreentitle = reader.getCellData(sheetName, "renewpremiumscreentitle", rowCount);

                String paymentmethod = reader.getCellData(sheetName, "paymentmethod", rowCount);
                String drawdate = reader.getCellData(sheetName, "drawdate", rowCount);
                String fundsource = reader.getCellData(sheetName, "fundsource", rowCount);
                String nomineescreentitle = reader.getCellData(sheetName, "nomineescreentitle", rowCount);

                String nomineefirstname = reader.getCellData(sheetName, "nomineefirstname", rowCount);
                String nomineelastname = reader.getCellData(sheetName, "nomineelastname", rowCount);
                String nomineeday = reader.getCellData(sheetName, "nomineeday", rowCount);
                String nomineemonth = reader.getCellData(sheetName, "nomineemonth", rowCount);
                String nomineeyear = reader.getCellData(sheetName, "nomineeyear", rowCount);
                String nomineegender = reader.getCellData(sheetName, "nomineegender", rowCount);
                String relationshipwithproposer = reader.getCellData(sheetName, "relationshipwithproposer", rowCount);
                String nomineeshare = reader.getCellData(sheetName, "nomineeshare", rowCount);
                String ismwppolicy = reader.getCellData(sheetName, "ismwppolicy", rowCount);
                String addressscreentitle = reader.getCellData(sheetName, "addressscreentitle", rowCount);

                String typeofaddress = reader.getCellData(sheetName, "typeofaddress", rowCount);
                String addresspincode = reader.getCellData(sheetName, "addresspincode", rowCount);
                String address1 = reader.getCellData(sheetName, "address1", rowCount);
                String address2 = reader.getCellData(sheetName, "address2", rowCount);
                String address3 = reader.getCellData(sheetName, "address3", rowCount);
                String personalDetailsscreentitle = reader.getCellData(sheetName, "personalDetailsscreentitle", rowCount);
                String cityName = reader.getCellData(sheetName, "cityName", rowCount);
                String preferredLanguage = reader.getCellData(sheetName, "preferredLanguage", rowCount);
                String alernateNumber = reader.getCellData(sheetName, "alernateNumber", rowCount);
                String resTelephoneNumber = reader.getCellData(sheetName, "resTelephoneNumber", rowCount);
                String emailaddressValidations = reader.getCellData(sheetName, "emailaddressValidations", rowCount);
                String maritalStatus = reader.getCellData(sheetName, "maritalStatus", rowCount);
                String fathersNameOrSpouseName = reader.getCellData(sheetName, "fathersNameOrSpouseName", rowCount);
                String mothersName = reader.getCellData(sheetName, "mothersName", rowCount);

                String question1 = reader.getCellData(sheetName, "question1", rowCount);
                String answer1 = reader.getCellData(sheetName, "answer1", rowCount);
                String valuetoBeEnter = reader.getCellData(sheetName, "valueToBeEnter", rowCount);
                String question2 = reader.getCellData(sheetName, "question2", rowCount);
                String answer2 = reader.getCellData(sheetName, "answer2", rowCount);
                String valuetoBeEnter2 = reader.getCellData(sheetName, "valueToBeEnter2", rowCount);
                String question3 = reader.getCellData(sheetName, "question3", rowCount);
                String answer3 = reader.getCellData(sheetName, "answer3", rowCount);
                String valuetoBeEnter3 = reader.getCellData(sheetName, "valueToBeEnter3", rowCount);
                String question4 = reader.getCellData(sheetName, "question4", rowCount);
                String answer4 = reader.getCellData(sheetName, "answer4", rowCount);
                String valuetoBeEnter4 = reader.getCellData(sheetName, "valueToBeEnter4", rowCount);

                String qualification = reader.getCellData(sheetName, "qualification", rowCount);
                String occupation = reader.getCellData(sheetName, "occupation", rowCount);
                String employeerName = reader.getCellData(sheetName, "employeerName", rowCount);
                String nameOfBusinessOrduties = reader.getCellData(sheetName, "nameOfBusinessOrduties", rowCount);
                String typeOfOrganization = reader.getCellData(sheetName, "typeOfOrganization", rowCount);
                String designation = reader.getCellData(sheetName, "designation", rowCount);
                String annualIncome = reader.getCellData(sheetName, "annualIncome", rowCount);
                String existingPolicyscreentitle = reader.getCellData(sheetName, "existingPolicyscreentitle", rowCount);

                Object ob[] = {username.trim(), password.trim(), policy.trim(), leadid.trim(), proposersame.trim(), propinsurednotsame.trim(),
                        isnri.trim(), pmobile.trim(), ppan.trim(), imobile.trim(), ipan.trim(), firstname.trim(), lastname.trim(),
                        middlename.trim(), day.trim(), month.trim(), year.trim(),
                        gender.trim(), planjourney.trim(), proposerstate.trim(), advisorstatesame.trim(), plan.trim(), sumassured.trim(), smokertype.trim(), planoptions.trim(), increasinglevel.trim(),
                        ecs.trim(), term.trim(), ppt.trim(), premiumterm.trim(), premiumamount.trim(), rider.trim(), rideramount.trim(), minrider.trim(), maxrider.trim(), ridererror.trim(), click.trim(),
                        generateillustrations.trim(), clickcontinue.trim(), ifsccode.trim(), bankaccno.trim(), accholdername.trim(),
                        accounttype.trim(), pennyalert.trim(), clickverify.trim(), renewpremiumscreentitle.trim(), paymentmethod.trim(),
                        drawdate.trim(), fundsource.trim(), nomineescreentitle.trim(), nomineefirstname.trim(), nomineelastname.trim(), nomineeday.trim(),
                        nomineemonth.trim(), nomineeyear.trim(), nomineegender.trim(), relationshipwithproposer.trim(), nomineeshare.trim(), ismwppolicy.trim(), addressscreentitle.trim(),
                        typeofaddress.trim(), addresspincode.trim(), address1.trim(), address2.trim(), address3.trim(), personalDetailsscreentitle.trim(), cityName.trim(),
                        preferredLanguage.trim(), alernateNumber.trim(), resTelephoneNumber.trim(), emailaddressValidations.trim(), maritalStatus.trim(),
                        fathersNameOrSpouseName.trim(), mothersName.trim(), question1.trim(), answer1.trim(), valuetoBeEnter.trim(), question2.trim(), answer2.trim(), valuetoBeEnter2.trim(),
                        question3.trim(), answer3.trim(), valuetoBeEnter3.trim(), question4.trim(), answer4.trim(), valuetoBeEnter4.trim(), qualification.trim(), occupation.trim(), employeerName.trim(),
                        nameOfBusinessOrduties.trim(), typeOfOrganization.trim(), designation.trim(), annualIncome.trim(), existingPolicyscreentitle.trim()};

                myData.add(ob);
            }
        }
        System.out.println("mydata rows value **********" + myData.toString());
        return myData;
    }

    public static ArrayList<Object[]> getEnachDataFromExcel(String testExcelSheet, String testName, String sheetName) {
        ArrayList<Object[]> myData = new ArrayList<Object[]>();
        Xls_Reader reader = null;

        try {
            reader = new Xls_Reader(System.getProperty("user.dir") + testExcelSheet);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("row count ---------" + reader.getRowCount(sheetName));

        for (int rowCount = 3; rowCount <= reader.getRowCount(sheetName); rowCount++) {
            String currentTestMethod = reader.getCellData(sheetName, "testCaseName", rowCount);
            String enableFlag = reader.getCellData(sheetName, "flag", rowCount);
            if (currentTestMethod.trim().equalsIgnoreCase(testName) && enableFlag.equalsIgnoreCase("YES")) {

                String username = reader.getCellData(sheetName, "username", rowCount);
                String password = reader.getCellData(sheetName, "password", rowCount);


                String policy = reader.getCellData(sheetName, "policy", rowCount);
                String leadid = reader.getCellData(sheetName, "leadid", rowCount);
                String proposersame = reader.getCellData(sheetName, "proposersame", rowCount);
                String propinsurednotsame = reader.getCellData(sheetName, "propinsurednotsame", rowCount);
                String isnri = reader.getCellData(sheetName, "isnri", rowCount);
                String pmobile = reader.getCellData(sheetName, "pmobile", rowCount);
                String ppan = reader.getCellData(sheetName, "ppan", rowCount);
                String imobile = reader.getCellData(sheetName, "imobile", rowCount);
                String ipan = reader.getCellData(sheetName, "ipan", rowCount);
                String firstname = reader.getCellData(sheetName, "firstname", rowCount);
                String lastname = reader.getCellData(sheetName, "lastname", rowCount);
                String middlename = reader.getCellData(sheetName, "middlename", rowCount);
                String day = reader.getCellData(sheetName, "day", rowCount);
                String month = reader.getCellData(sheetName, "month", rowCount);
                String year = reader.getCellData(sheetName, "year", rowCount);
                String gender = reader.getCellData(sheetName, "gender", rowCount);


                String planjourney = reader.getCellData(sheetName, "planjourney", rowCount);
                String proposerstate = reader.getCellData(sheetName, "proposerstate", rowCount);
                String advisorstatesame = reader.getCellData(sheetName, "advisorstatesame", rowCount);

                String plan = reader.getCellData(sheetName, "plan", rowCount);
                String sumassured = reader.getCellData(sheetName, "sumassured", rowCount);
                String smokertype = reader.getCellData(sheetName, "smokertype", rowCount);
                String planoptions = reader.getCellData(sheetName, "planoptions", rowCount);
                String increasinglevel = reader.getCellData(sheetName, "increasinglevel", rowCount);
                String ecs = reader.getCellData(sheetName, "ecs", rowCount);
                String term = reader.getCellData(sheetName, "term", rowCount);
                String ppt = reader.getCellData(sheetName, "ppt", rowCount);
                String premiumterm = reader.getCellData(sheetName, "premiumterm", rowCount);
                String premiumamount = reader.getCellData(sheetName, "premiumamount", rowCount);

                String rider = reader.getCellData(sheetName, "rider", rowCount);
                String rideramount = reader.getCellData(sheetName, "rideramount", rowCount);
                String minrider = reader.getCellData(sheetName, "minrider", rowCount);
                String maxrider = reader.getCellData(sheetName, "maxrider", rowCount);
                String ridererror = reader.getCellData(sheetName, "ridererror", rowCount);
                String click = reader.getCellData(sheetName, "click", rowCount);

                String generateillustrations = reader.getCellData(sheetName, "generateillustrations", rowCount);
                String clickcontinue = reader.getCellData(sheetName, "clickcontinue", rowCount);


                String ifsccode = reader.getCellData(sheetName, "ifsccode", rowCount);
                String bankaccno = reader.getCellData(sheetName, "bankaccno", rowCount);
                String accholdername = reader.getCellData(sheetName, "accholdername", rowCount);
                String accounttype = reader.getCellData(sheetName, "accounttype", rowCount);

                String pennyalert = reader.getCellData(sheetName, "pennyalert", rowCount);
                String clickverify = reader.getCellData(sheetName, "clickverify", rowCount);
                String renewpremiumscreentitle = reader.getCellData(sheetName, "renewpremiumscreentitle", rowCount);
                String bankname = reader.getCellData(sheetName, "bankname", rowCount);
                String mobileno = reader.getCellData(sheetName, "mobileno", rowCount);
                String pannumber = reader.getCellData(sheetName, "pannumber", rowCount);
                String emailaddress = reader.getCellData(sheetName, "emailaddress", rowCount);


                Object ob[] = {username.trim(), password.trim(), policy.trim(), leadid.trim(), proposersame.trim(), propinsurednotsame.trim(),
                        isnri.trim(), pmobile.trim(), ppan.trim(), imobile.trim(), ipan.trim(), firstname.trim(), lastname.trim(),
                        middlename.trim(), day.trim(), month.trim(), year.trim(),
                        gender.trim(), planjourney.trim(), proposerstate.trim(), advisorstatesame.trim(), plan.trim(), sumassured.trim(), smokertype.trim(), planoptions.trim(), increasinglevel.trim(),
                        ecs.trim(), term.trim(), ppt.trim(), premiumterm.trim(), premiumamount.trim(), rider.trim(), rideramount.trim(), minrider.trim(), maxrider.trim(), ridererror.trim(), click.trim(),
                        generateillustrations.trim(), clickcontinue.trim(), ifsccode.trim(), bankaccno.trim(), accholdername.trim(),
                        accounttype.trim(), pennyalert.trim(), clickverify.trim(), renewpremiumscreentitle.trim(), bankname.trim(),
                        mobileno.trim(), pannumber.trim(), emailaddress.trim()};
                myData.add(ob);
            }
        }
        System.out.println("mydata rows value **********" + myData.toString());
        return myData;
    }

    public static ArrayList<Object[]> getExistingPolicyTestData(String testExcelSheet, String testName, String sheetName) {
        ArrayList<Object[]> myData = new ArrayList<Object[]>();
        Xls_Reader reader = null;

        try {
            reader = new Xls_Reader(System.getProperty("user.dir") + testExcelSheet);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("row count ---------" + reader.getRowCount(sheetName));

        for (int rowCount = 3; rowCount <= reader.getRowCount(sheetName); rowCount++) {
            String currentTestMethod = reader.getCellData(sheetName, "testCaseName", rowCount);
            String enableFlag = reader.getCellData(sheetName, "flag", rowCount);
            if (currentTestMethod.trim().equalsIgnoreCase(testName) && enableFlag.equalsIgnoreCase("YES")) {

                String username = reader.getCellData(sheetName, "username", rowCount);
                String password = reader.getCellData(sheetName, "password", rowCount);


                String policy = reader.getCellData(sheetName, "policy", rowCount);
                String leadid = reader.getCellData(sheetName, "leadid", rowCount);
                String proposersame = reader.getCellData(sheetName, "proposersame", rowCount);
                String propinsurednotsame = reader.getCellData(sheetName, "propinsurednotsame", rowCount);
                String isnri = reader.getCellData(sheetName, "isnri", rowCount);
                String pmobile = reader.getCellData(sheetName, "pmobile", rowCount);
                String ppan = reader.getCellData(sheetName, "ppan", rowCount);
                String imobile = reader.getCellData(sheetName, "imobile", rowCount);
                String ipan = reader.getCellData(sheetName, "ipan", rowCount);
                String firstname = reader.getCellData(sheetName, "firstname", rowCount);
                String lastname = reader.getCellData(sheetName, "lastname", rowCount);
                String middlename = reader.getCellData(sheetName, "middlename", rowCount);
                String day = reader.getCellData(sheetName, "day", rowCount);
                String month = reader.getCellData(sheetName, "month", rowCount);
                String year = reader.getCellData(sheetName, "year", rowCount);
                String gender = reader.getCellData(sheetName, "gender", rowCount);


                String planjourney = reader.getCellData(sheetName, "planjourney", rowCount);
                String proposerstate = reader.getCellData(sheetName, "proposerstate", rowCount);
                String advisorstatesame = reader.getCellData(sheetName, "advisorstatesame", rowCount);

                String plan = reader.getCellData(sheetName, "plan", rowCount);
                String sumassured = reader.getCellData(sheetName, "sumassured", rowCount);
                String smokertype = reader.getCellData(sheetName, "smokertype", rowCount);
                String planoptions = reader.getCellData(sheetName, "planoptions", rowCount);
                String increasinglevel = reader.getCellData(sheetName, "increasinglevel", rowCount);
                String ecs = reader.getCellData(sheetName, "ecs", rowCount);
                String term = reader.getCellData(sheetName, "term", rowCount);
                String ppt = reader.getCellData(sheetName, "ppt", rowCount);
                String premiumterm = reader.getCellData(sheetName, "premiumterm", rowCount);
                String premiumamount = reader.getCellData(sheetName, "premiumamount", rowCount);

                String rider = reader.getCellData(sheetName, "rider", rowCount);
                String rideramount = reader.getCellData(sheetName, "rideramount", rowCount);
                String minrider = reader.getCellData(sheetName, "minrider", rowCount);
                String maxrider = reader.getCellData(sheetName, "maxrider", rowCount);
                String ridererror = reader.getCellData(sheetName, "ridererror", rowCount);
                String click = reader.getCellData(sheetName, "click", rowCount);

                String generateillustrations = reader.getCellData(sheetName, "generateillustrations", rowCount);
                String clickcontinue = reader.getCellData(sheetName, "clickcontinue", rowCount);


                String ifsccode = reader.getCellData(sheetName, "ifsccode", rowCount);
                String bankaccno = reader.getCellData(sheetName, "bankaccno", rowCount);
                String accholdername = reader.getCellData(sheetName, "accholdername", rowCount);
                String accounttype = reader.getCellData(sheetName, "accounttype", rowCount);

                String pennyalert = reader.getCellData(sheetName, "pennyalert", rowCount);
                String clickverify = reader.getCellData(sheetName, "clickverify", rowCount);

                String renewpremiumscreentitle = reader.getCellData(sheetName, "renewpremiumscreentitle", rowCount);

                String paymentmethod = reader.getCellData(sheetName, "paymentmethod", rowCount);
                String drawdate = reader.getCellData(sheetName, "drawdate", rowCount);
                String fundsource = reader.getCellData(sheetName, "fundsource", rowCount);
                String nomineescreentitle = reader.getCellData(sheetName, "nomineescreentitle", rowCount);

                String nomineefirstname = reader.getCellData(sheetName, "nomineefirstname", rowCount);
                String nomineelastname = reader.getCellData(sheetName, "nomineelastname", rowCount);
                String nomineeday = reader.getCellData(sheetName, "nomineeday", rowCount);
                String nomineemonth = reader.getCellData(sheetName, "nomineemonth", rowCount);
                String nomineeyear = reader.getCellData(sheetName, "nomineeyear", rowCount);
                String nomineegender = reader.getCellData(sheetName, "nomineegender", rowCount);
                String relationshipwithproposer = reader.getCellData(sheetName, "relationshipwithproposer", rowCount);
                String nomineeshare = reader.getCellData(sheetName, "nomineeshare", rowCount);
                String ismwppolicy = reader.getCellData(sheetName, "ismwppolicy", rowCount);
                String addressscreentitle = reader.getCellData(sheetName, "addressscreentitle", rowCount);

                String typeofaddress = reader.getCellData(sheetName, "typeofaddress", rowCount);
                String addresspincode = reader.getCellData(sheetName, "addresspincode", rowCount);
                String address1 = reader.getCellData(sheetName, "address1", rowCount);
                String address2 = reader.getCellData(sheetName, "address2", rowCount);
                String address3 = reader.getCellData(sheetName, "address3", rowCount);
                String personalDetailsscreentitle = reader.getCellData(sheetName, "personalDetailsscreentitle", rowCount);
                String cityName = reader.getCellData(sheetName, "cityName", rowCount);
                String preferredLanguage = reader.getCellData(sheetName, "preferredLanguage", rowCount);
                String alernateNumber = reader.getCellData(sheetName, "alernateNumber", rowCount);
                String resTelephoneNumber = reader.getCellData(sheetName, "resTelephoneNumber", rowCount);
                String emailaddressValidations = reader.getCellData(sheetName, "emailaddressValidations", rowCount);
                String maritalStatus = reader.getCellData(sheetName, "maritalStatus", rowCount);
                String fathersNameOrSpouseName = reader.getCellData(sheetName, "fathersNameOrSpouseName", rowCount);
                String mothersName = reader.getCellData(sheetName, "mothersName", rowCount);

                String question1 = reader.getCellData(sheetName, "question1", rowCount);
                String answer1 = reader.getCellData(sheetName, "answer1", rowCount);
                String valuetoBeEnter = reader.getCellData(sheetName, "valueToBeEnter", rowCount);
                String question2 = reader.getCellData(sheetName, "question2", rowCount);
                String answer2 = reader.getCellData(sheetName, "answer2", rowCount);
                String valuetoBeEnter2 = reader.getCellData(sheetName, "valueToBeEnter2", rowCount);
                String question3 = reader.getCellData(sheetName, "question3", rowCount);
                String answer3 = reader.getCellData(sheetName, "answer3", rowCount);
                String valuetoBeEnter3 = reader.getCellData(sheetName, "valueToBeEnter3", rowCount);
                String question4 = reader.getCellData(sheetName, "question4", rowCount);
                String answer4 = reader.getCellData(sheetName, "answer4", rowCount);
                String valuetoBeEnter4 = reader.getCellData(sheetName, "valueToBeEnter4", rowCount);

                String qualification = reader.getCellData(sheetName, "qualification", rowCount);
                String occupation = reader.getCellData(sheetName, "occupation", rowCount);
                String employeerName = reader.getCellData(sheetName, "employeerName", rowCount);
                String nameOfBusinessOrduties = reader.getCellData(sheetName, "nameOfBusinessOrduties", rowCount);
                String typeOfOrganization = reader.getCellData(sheetName, "typeOfOrganization", rowCount);
                String designation = reader.getCellData(sheetName, "designation", rowCount);
                String annualIncome = reader.getCellData(sheetName, "annualIncome", rowCount);

                String exPolicyscreenTitle = reader.getCellData(sheetName, "exPolicyscreenTitle", rowCount);
                String exNameofInsurer = reader.getCellData(sheetName, "exNameofInsurer", rowCount);
                String exSumAssured = reader.getCellData(sheetName, "exSumAssured", rowCount);
                String expolicyNumber = reader.getCellData(sheetName, "expolicyNumber", rowCount);
                String exyearOfApplication = reader.getCellData(sheetName, "exyearOfApplication", rowCount);
                String exbasePlan = reader.getCellData(sheetName, "exbasePlan", rowCount);
                String exannualpremium = reader.getCellData(sheetName, "exannualpremium", rowCount);
                String medicalPolicy = reader.getCellData(sheetName, "medicalPolicy", rowCount);

                String exNameofInsurer1 = reader.getCellData(sheetName, "exNameofInsurer1", rowCount);
                String exSumAssured1 = reader.getCellData(sheetName, "exSumAssured1", rowCount);
                String expolicyNumber1 = reader.getCellData(sheetName, "expolicyNumber1", rowCount);
                String exyearOfApplication1 = reader.getCellData(sheetName, "exyearOfApplication1", rowCount);
                String exbasePlan1 = reader.getCellData(sheetName, "exbasePlan1", rowCount);
                String exannualpremium1 = reader.getCellData(sheetName, "exannualpremium1", rowCount);
                String medicalPolicy1 = reader.getCellData(sheetName, "medicalPolicy1", rowCount);

                String exNameofInsurer2 = reader.getCellData(sheetName, "exNameofInsurer2", rowCount);
                String exSumAssured2 = reader.getCellData(sheetName, "exSumAssured2", rowCount);
                String expolicyNumber2 = reader.getCellData(sheetName, "expolicyNumber2", rowCount);
                String exyearOfApplication2 = reader.getCellData(sheetName, "exyearOfApplicatio2", rowCount);
                String exbasePlan2 = reader.getCellData(sheetName, "exbasePlan2", rowCount);
                String exannualpremium2 = reader.getCellData(sheetName, "exannualpremium2", rowCount);
                String medicalPolicy2 = reader.getCellData(sheetName, "medicalPolicy2", rowCount);

                String exNameofInsurer3 = reader.getCellData(sheetName, "exNameofInsurer3", rowCount);
                String exSumAssured3 = reader.getCellData(sheetName, "exSumAssured3", rowCount);
                String expolicyNumber3 = reader.getCellData(sheetName, "expolicyNumber3", rowCount);
                String exyearOfApplication3 = reader.getCellData(sheetName, "exyearOfApplication3", rowCount);
                String exbasePlan3 = reader.getCellData(sheetName, "exbasePlan3", rowCount);
                String exannualpremium3 = reader.getCellData(sheetName, "exannualpremium3", rowCount);
                String medicalPolicy3 = reader.getCellData(sheetName, "medicalPolicy3", rowCount);

                String exNameofInsurer4 = reader.getCellData(sheetName, "exNameofInsurer4", rowCount);
                String exSumAssured4 = reader.getCellData(sheetName, "exSumAssured4", rowCount);
                String expolicyNumber4 = reader.getCellData(sheetName, "expolicyNumber4", rowCount);
                String exyearOfApplication4 = reader.getCellData(sheetName, "exyearOfApplication4", rowCount);
                String exbasePlan4 = reader.getCellData(sheetName, "exbasePlan4", rowCount);
                String exannualpremium4 = reader.getCellData(sheetName, "exannualpremium4", rowCount);
                String medicalPolicy4 = reader.getCellData(sheetName, "medicalPolicy4", rowCount);
                String policyPurposeScreen = reader.getCellData(sheetName, "policyPurposeScreen", rowCount);
                String purposeOption1 = reader.getCellData(sheetName, "purposeOption1", rowCount);
                String purposeOption2 = reader.getCellData(sheetName, "purposeOption2", rowCount);
                String purposeOption3 = reader.getCellData(sheetName, "purposeOption3", rowCount);


                Object ob[] = {username.trim(), password.trim(), policy.trim(), leadid.trim(), proposersame.trim(), propinsurednotsame.trim(),
                        isnri.trim(), pmobile.trim(), ppan.trim(), imobile.trim(), ipan.trim(), firstname.trim(), lastname.trim(),
                        middlename.trim(), day.trim(), month.trim(), year.trim(),
                        gender.trim(), planjourney.trim(), proposerstate.trim(), advisorstatesame.trim(), plan.trim(), sumassured.trim(), smokertype.trim(), planoptions.trim(), increasinglevel.trim(),
                        ecs.trim(), term.trim(), ppt.trim(), premiumterm.trim(), premiumamount.trim(), rider.trim(), rideramount.trim(), minrider.trim(), maxrider.trim(), ridererror.trim(), click.trim(),
                        generateillustrations.trim(), clickcontinue.trim(), ifsccode.trim(), bankaccno.trim(), accholdername.trim(),
                        accounttype.trim(), pennyalert.trim(), clickverify.trim(), renewpremiumscreentitle.trim(), paymentmethod.trim(),
                        drawdate.trim(), fundsource.trim(), nomineescreentitle.trim(), nomineefirstname.trim(), nomineelastname.trim(), nomineeday.trim(),
                        nomineemonth.trim(), nomineeyear.trim(), nomineegender.trim(), relationshipwithproposer.trim(), nomineeshare.trim(), ismwppolicy.trim(), addressscreentitle.trim(),
                        typeofaddress.trim(), addresspincode.trim(), address1.trim(), address2.trim(), address3.trim(), personalDetailsscreentitle.trim(), cityName.trim(),
                        preferredLanguage.trim(), alernateNumber.trim(), resTelephoneNumber.trim(), emailaddressValidations.trim(), maritalStatus.trim(),
                        fathersNameOrSpouseName.trim(), mothersName.trim(), question1.trim(), answer1.trim(), valuetoBeEnter.trim(), question2.trim(), answer2.trim(), valuetoBeEnter2.trim(),
                        question3.trim(), answer3.trim(), valuetoBeEnter3.trim(), question4.trim(), answer4.trim(), valuetoBeEnter4.trim(), qualification.trim(), occupation.trim(), employeerName.trim(),
                        nameOfBusinessOrduties.trim(), typeOfOrganization.trim(), designation.trim(), annualIncome.trim(), exPolicyscreenTitle.trim(), exNameofInsurer.trim(),
                        exSumAssured.trim(), expolicyNumber.trim(), exyearOfApplication.trim(), exbasePlan.trim(), exannualpremium.trim(), medicalPolicy.trim(), policyPurposeScreen.trim(), purposeOption1.trim(), purposeOption2.trim(), purposeOption3.trim(),
                        exNameofInsurer1.trim(), exSumAssured1.trim(), expolicyNumber1.trim(), exyearOfApplication1.trim(), exbasePlan1.trim(), exannualpremium1.trim(), medicalPolicy1.trim(),
                        exNameofInsurer2.trim(), exSumAssured2.trim(), expolicyNumber2.trim(), exyearOfApplication2.trim(), exbasePlan2.trim(), exannualpremium2.trim(), medicalPolicy2.trim(),
                        exNameofInsurer3.trim(), exSumAssured3.trim(), expolicyNumber3.trim(), exyearOfApplication3.trim(), exbasePlan3.trim(), exannualpremium3.trim(), medicalPolicy3.trim(),
                        exNameofInsurer4.trim(), exSumAssured4.trim(), expolicyNumber4.trim(), exyearOfApplication4.trim(), exbasePlan4.trim(), exannualpremium4.trim(), medicalPolicy4.trim(), policyPurposeScreen.trim(), purposeOption1.trim(), purposeOption2.trim(), purposeOption3.trim()};

                myData.add(ob);
            }
        }
        System.out.println("mydata rows value **********" + myData.toString());
        return myData;
    }


    public static ArrayList<Object[]> getRefeusedPolicyTestData(String testExcelSheet, String testName, String sheetName) {
        ArrayList<Object[]> myData = new ArrayList<Object[]>();
        Xls_Reader reader = null;

        try {
            reader = new Xls_Reader(System.getProperty("user.dir") + testExcelSheet);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("row count ---------" + reader.getRowCount(sheetName));

        for (int rowCount = 3; rowCount <= reader.getRowCount(sheetName); rowCount++) {
            String currentTestMethod = reader.getCellData(sheetName, "testCaseName", rowCount);
            String enableFlag = reader.getCellData(sheetName, "flag", rowCount);
            if (currentTestMethod.trim().equalsIgnoreCase(testName) && enableFlag.equalsIgnoreCase("YES")) {

                String username = reader.getCellData(sheetName, "username", rowCount);
                String password = reader.getCellData(sheetName, "password", rowCount);


                String policy = reader.getCellData(sheetName, "policy", rowCount);
                String leadid = reader.getCellData(sheetName, "leadid", rowCount);
                String proposersame = reader.getCellData(sheetName, "proposersame", rowCount);
                String propinsurednotsame = reader.getCellData(sheetName, "propinsurednotsame", rowCount);
                String isnri = reader.getCellData(sheetName, "isnri", rowCount);
                String pmobile = reader.getCellData(sheetName, "pmobile", rowCount);
                String ppan = reader.getCellData(sheetName, "ppan", rowCount);
                String imobile = reader.getCellData(sheetName, "imobile", rowCount);
                String ipan = reader.getCellData(sheetName, "ipan", rowCount);
                String firstname = reader.getCellData(sheetName, "firstname", rowCount);
                String lastname = reader.getCellData(sheetName, "lastname", rowCount);
                String middlename = reader.getCellData(sheetName, "middlename", rowCount);
                String day = reader.getCellData(sheetName, "day", rowCount);
                String month = reader.getCellData(sheetName, "month", rowCount);
                String year = reader.getCellData(sheetName, "year", rowCount);
                String gender = reader.getCellData(sheetName, "gender", rowCount);


                String planjourney = reader.getCellData(sheetName, "planjourney", rowCount);
                String proposerstate = reader.getCellData(sheetName, "proposerstate", rowCount);
                String advisorstatesame = reader.getCellData(sheetName, "advisorstatesame", rowCount);

                String plan = reader.getCellData(sheetName, "plan", rowCount);
                String sumassured = reader.getCellData(sheetName, "sumassured", rowCount);
                String smokertype = reader.getCellData(sheetName, "smokertype", rowCount);
                String planoptions = reader.getCellData(sheetName, "planoptions", rowCount);
                String increasinglevel = reader.getCellData(sheetName, "increasinglevel", rowCount);
                String ecs = reader.getCellData(sheetName, "ecs", rowCount);
                String term = reader.getCellData(sheetName, "term", rowCount);
                String ppt = reader.getCellData(sheetName, "ppt", rowCount);
                String premiumterm = reader.getCellData(sheetName, "premiumterm", rowCount);
                String premiumamount = reader.getCellData(sheetName, "premiumamount", rowCount);

                String rider = reader.getCellData(sheetName, "rider", rowCount);
                String rideramount = reader.getCellData(sheetName, "rideramount", rowCount);
                String minrider = reader.getCellData(sheetName, "minrider", rowCount);
                String maxrider = reader.getCellData(sheetName, "maxrider", rowCount);
                String ridererror = reader.getCellData(sheetName, "ridererror", rowCount);
                String click = reader.getCellData(sheetName, "click", rowCount);

                String generateillustrations = reader.getCellData(sheetName, "generateillustrations", rowCount);
                String clickcontinue = reader.getCellData(sheetName, "clickcontinue", rowCount);


                String ifsccode = reader.getCellData(sheetName, "ifsccode", rowCount);
                String bankaccno = reader.getCellData(sheetName, "bankaccno", rowCount);
                String accholdername = reader.getCellData(sheetName, "accholdername", rowCount);
                String accounttype = reader.getCellData(sheetName, "accounttype", rowCount);

                String pennyalert = reader.getCellData(sheetName, "pennyalert", rowCount);
                String clickverify = reader.getCellData(sheetName, "clickverify", rowCount);

                String renewpremiumscreentitle = reader.getCellData(sheetName, "renewpremiumscreentitle", rowCount);

                String paymentmethod = reader.getCellData(sheetName, "paymentmethod", rowCount);
                String drawdate = reader.getCellData(sheetName, "drawdate", rowCount);
                String fundsource = reader.getCellData(sheetName, "fundsource", rowCount);
                String nomineescreentitle = reader.getCellData(sheetName, "nomineescreentitle", rowCount);

                String nomineefirstname = reader.getCellData(sheetName, "nomineefirstname", rowCount);
                String nomineelastname = reader.getCellData(sheetName, "nomineelastname", rowCount);
                String nomineeday = reader.getCellData(sheetName, "nomineeday", rowCount);
                String nomineemonth = reader.getCellData(sheetName, "nomineemonth", rowCount);
                String nomineeyear = reader.getCellData(sheetName, "nomineeyear", rowCount);
                String nomineegender = reader.getCellData(sheetName, "nomineegender", rowCount);
                String relationshipwithproposer = reader.getCellData(sheetName, "relationshipwithproposer", rowCount);
                String nomineeshare = reader.getCellData(sheetName, "nomineeshare", rowCount);
                String ismwppolicy = reader.getCellData(sheetName, "ismwppolicy", rowCount);
                String addressscreentitle = reader.getCellData(sheetName, "addressscreentitle", rowCount);

                String typeofaddress = reader.getCellData(sheetName, "typeofaddress", rowCount);
                String addresspincode = reader.getCellData(sheetName, "addresspincode", rowCount);
                String address1 = reader.getCellData(sheetName, "address1", rowCount);
                String address2 = reader.getCellData(sheetName, "address2", rowCount);
                String address3 = reader.getCellData(sheetName, "address3", rowCount);
                String personalDetailsscreentitle = reader.getCellData(sheetName, "personalDetailsscreentitle", rowCount);
                String cityName = reader.getCellData(sheetName, "cityName", rowCount);
                String preferredLanguage = reader.getCellData(sheetName, "preferredLanguage", rowCount);
                String alernateNumber = reader.getCellData(sheetName, "alernateNumber", rowCount);
                String resTelephoneNumber = reader.getCellData(sheetName, "resTelephoneNumber", rowCount);
                String emailaddressValidations = reader.getCellData(sheetName, "emailaddressValidations", rowCount);
                String maritalStatus = reader.getCellData(sheetName, "maritalStatus", rowCount);
                String fathersNameOrSpouseName = reader.getCellData(sheetName, "fathersNameOrSpouseName", rowCount);
                String mothersName = reader.getCellData(sheetName, "mothersName", rowCount);
                String qualification = reader.getCellData(sheetName, "qualification", rowCount);
                String occupation = reader.getCellData(sheetName, "occupation", rowCount);
                String employeerName = reader.getCellData(sheetName, "employeerName", rowCount);
                String nameOfBusinessOrduties = reader.getCellData(sheetName, "nameOfBusinessOrduties", rowCount);
                String typeOfOrganization = reader.getCellData(sheetName, "typeOfOrganization", rowCount);
                String designation = reader.getCellData(sheetName, "designation", rowCount);
                String annualIncome = reader.getCellData(sheetName, "annualIncome", rowCount);
                String policyStatus = reader.getCellData(sheetName, "expolicystatus", rowCount);
                String exPolicyscreenTitle = reader.getCellData(sheetName, "exPolicyscreenTitle", rowCount);
                String exNameofInsurer = reader.getCellData(sheetName, "exNameofInsurer", rowCount);
                String exSumAssured = reader.getCellData(sheetName, "exSumAssured", rowCount);
                String expolicyNumber = reader.getCellData(sheetName, "expolicyNumber", rowCount);
                String exyearOfApplication = reader.getCellData(sheetName, "exyearOfApplication", rowCount);
                String exbasePlan = reader.getCellData(sheetName, "exbasePlan", rowCount);
                String exannualpremium = reader.getCellData(sheetName, "exannualpremium", rowCount);
                String medicalPolicy = reader.getCellData(sheetName, "medicalPolicy", rowCount);
                String expolicystatus = reader.getCellData(sheetName, "expolicystatus", rowCount);
                String refPolicyscreenTitle = reader.getCellData(sheetName, "refPolicyscreenTitle", rowCount);

                String refinsurerName = reader.getCellData(sheetName, "refnsurerName", rowCount);
                String refsumAssured = reader.getCellData(sheetName, "refsumAssured", rowCount);
                String refreason = reader.getCellData(sheetName, "refreason", rowCount);

                String refinsurerName1 = reader.getCellData(sheetName, "refnsurerName1", rowCount);
                String refsumAssured1 = reader.getCellData(sheetName, "refsumAssured1", rowCount);
                String refreason1 = reader.getCellData(sheetName, "refreason1", rowCount);

                String refinsurerName2 = reader.getCellData(sheetName, "refnsurerName2", rowCount);
                String refsumAssured2 = reader.getCellData(sheetName, "refsumAssured2", rowCount);
                String refreason2 = reader.getCellData(sheetName, "refreason2", rowCount);

                String refinsurerName3 = reader.getCellData(sheetName, "refnsurerName3", rowCount);
                String refsumAssured3 = reader.getCellData(sheetName, "refsumAssured3", rowCount);
                String refreason3 = reader.getCellData(sheetName, "refreason3", rowCount);

                String refinsurerName4 = reader.getCellData(sheetName, "refnsurerName4", rowCount);
                String refsumAssured4 = reader.getCellData(sheetName, "refsumAssured4", rowCount);
                String refreason4 = reader.getCellData(sheetName, "refreason4", rowCount);


                String policyPurposeScreen = reader.getCellData(sheetName, "policyPurposeScreen", rowCount);
                String purposeOption1 = reader.getCellData(sheetName, "purposeOption1", rowCount);
                String purposeOption2 = reader.getCellData(sheetName, "purposeOption2", rowCount);
                String purposeOption3 = reader.getCellData(sheetName, "purposeOption3", rowCount);

                Object ob[] = {username.trim(), password.trim(), policy.trim(), leadid.trim(), proposersame.trim(), propinsurednotsame.trim(),
                        isnri.trim(), pmobile.trim(), ppan.trim(), imobile.trim(), ipan.trim(), firstname.trim(), lastname.trim(),
                        middlename.trim(), day.trim(), month.trim(), year.trim(),
                        gender.trim(), planjourney.trim(), proposerstate.trim(), advisorstatesame.trim(), plan.trim(), sumassured.trim(), smokertype.trim(), planoptions.trim(), increasinglevel.trim(),
                        ecs.trim(), term.trim(), ppt.trim(), premiumterm.trim(), premiumamount.trim(), rider.trim(), rideramount.trim(), minrider.trim(), maxrider.trim(), ridererror.trim(), click.trim(),
                        generateillustrations.trim(), clickcontinue.trim(), ifsccode.trim(), bankaccno.trim(), accholdername.trim(),
                        accounttype.trim(), pennyalert.trim(), clickverify.trim(), renewpremiumscreentitle.trim(), paymentmethod.trim(),
                        drawdate.trim(), fundsource.trim(), nomineescreentitle.trim(), nomineefirstname.trim(), nomineelastname.trim(), nomineeday.trim(),
                        nomineemonth.trim(), nomineeyear.trim(), nomineegender.trim(), relationshipwithproposer.trim(), nomineeshare.trim(), ismwppolicy.trim(), addressscreentitle.trim(),
                        typeofaddress.trim(), addresspincode.trim(), address1.trim(), address2.trim(), address3.trim(), personalDetailsscreentitle.trim(), cityName.trim(),
                        preferredLanguage.trim(), alernateNumber.trim(), resTelephoneNumber.trim(), emailaddressValidations.trim(), maritalStatus.trim(),
                        fathersNameOrSpouseName.trim(), mothersName.trim(), qualification.trim(), occupation.trim(), employeerName.trim(),
                        nameOfBusinessOrduties.trim(), typeOfOrganization.trim(), designation.trim(), annualIncome.trim(), policyStatus.trim(), exPolicyscreenTitle.trim(), exNameofInsurer.trim(),
                        exSumAssured.trim(), expolicyNumber.trim(), exyearOfApplication.trim(), exbasePlan.trim(), exannualpremium.trim(), medicalPolicy.trim(), expolicystatus.trim(),
                        refPolicyscreenTitle.trim(), refinsurerName.trim(), refsumAssured.trim(), refreason.trim(), refinsurerName1.trim(), refsumAssured1.trim(), refreason1.trim(),
                        refinsurerName2.trim(), refsumAssured2.trim(), refreason2.trim(), refinsurerName3.trim(), refsumAssured3.trim(), refreason3.trim(),
                        refinsurerName4.trim(), refsumAssured4.trim(), refreason4.trim(), policyPurposeScreen.trim(), purposeOption1.trim(), purposeOption2.trim(), purposeOption3.trim()};

                myData.add(ob);
            }
        }
        System.out.println("mydata rows value **********" + myData.toString());
        return myData;
    }

    public static ArrayList<Object[]> getCovid19TestData(String testExcelSheet, String testName, String sheetName) {
        ArrayList<Object[]> myData = new ArrayList<Object[]>();
        Xls_Reader reader = null;

        try {
            reader = new Xls_Reader(System.getProperty("user.dir") + testExcelSheet);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("row count ---------" + reader.getRowCount(sheetName));

        for (int rowCount = 3; rowCount <= reader.getRowCount(sheetName); rowCount++) {
            String currentTestMethod = reader.getCellData(sheetName, "testCaseName", rowCount);
            String enableFlag = reader.getCellData(sheetName, "flag", rowCount);
            if (currentTestMethod.trim().equalsIgnoreCase(testName) && enableFlag.equalsIgnoreCase("YES")) {

                String username = reader.getCellData(sheetName, "username", rowCount);
                String password = reader.getCellData(sheetName, "password", rowCount);


                String policy = reader.getCellData(sheetName, "policy", rowCount);
                String leadid = reader.getCellData(sheetName, "leadid", rowCount);
                String proposersame = reader.getCellData(sheetName, "proposersame", rowCount);
                String propinsurednotsame = reader.getCellData(sheetName, "propinsurednotsame", rowCount);
                String isnri = reader.getCellData(sheetName, "isnri", rowCount);
                String pmobile = reader.getCellData(sheetName, "pmobile", rowCount);
                String ppan = reader.getCellData(sheetName, "ppan", rowCount);
                String imobile = reader.getCellData(sheetName, "imobile", rowCount);
                String ipan = reader.getCellData(sheetName, "ipan", rowCount);
                String firstname = reader.getCellData(sheetName, "firstname", rowCount);
                String lastname = reader.getCellData(sheetName, "lastname", rowCount);
                String middlename = reader.getCellData(sheetName, "middlename", rowCount);
                String day = reader.getCellData(sheetName, "day", rowCount);
                String month = reader.getCellData(sheetName, "month", rowCount);
                String year = reader.getCellData(sheetName, "year", rowCount);
                String gender = reader.getCellData(sheetName, "gender", rowCount);


                String planjourney = reader.getCellData(sheetName, "planjourney", rowCount);
                String proposerstate = reader.getCellData(sheetName, "proposerstate", rowCount);
                String advisorstatesame = reader.getCellData(sheetName, "advisorstatesame", rowCount);

                String plan = reader.getCellData(sheetName, "plan", rowCount);
                String sumassured = reader.getCellData(sheetName, "sumassured", rowCount);
                String smokertype = reader.getCellData(sheetName, "smokertype", rowCount);
                String planoptions = reader.getCellData(sheetName, "planoptions", rowCount);
                String increasinglevel = reader.getCellData(sheetName, "increasinglevel", rowCount);
                String ecs = reader.getCellData(sheetName, "ecs", rowCount);
                String term = reader.getCellData(sheetName, "term", rowCount);
                String ppt = reader.getCellData(sheetName, "ppt", rowCount);
                String premiumterm = reader.getCellData(sheetName, "premiumterm", rowCount);
                String premiumamount = reader.getCellData(sheetName, "premiumamount", rowCount);

                String rider = reader.getCellData(sheetName, "rider", rowCount);
                String rideramount = reader.getCellData(sheetName, "rideramount", rowCount);
                String minrider = reader.getCellData(sheetName, "minrider", rowCount);
                String maxrider = reader.getCellData(sheetName, "maxrider", rowCount);
                String ridererror = reader.getCellData(sheetName, "ridererror", rowCount);
                String click = reader.getCellData(sheetName, "click", rowCount);

                String generateillustrations = reader.getCellData(sheetName, "generateillustrations", rowCount);
                String clickcontinue = reader.getCellData(sheetName, "clickcontinue", rowCount);


                String ifsccode = reader.getCellData(sheetName, "ifsccode", rowCount);
                String bankaccno = reader.getCellData(sheetName, "bankaccno", rowCount);
                String accholdername = reader.getCellData(sheetName, "accholdername", rowCount);
                String accounttype = reader.getCellData(sheetName, "accounttype", rowCount);

                String pennyalert = reader.getCellData(sheetName, "pennyalert", rowCount);
                String clickverify = reader.getCellData(sheetName, "clickverify", rowCount);

                String renewpremiumscreentitle = reader.getCellData(sheetName, "renewpremiumscreentitle", rowCount);

                String paymentmethod = reader.getCellData(sheetName, "paymentmethod", rowCount);
                String drawdate = reader.getCellData(sheetName, "drawdate", rowCount);
                String fundsource = reader.getCellData(sheetName, "fundsource", rowCount);
                String nomineescreentitle = reader.getCellData(sheetName, "nomineescreentitle", rowCount);

                String nomineefirstname = reader.getCellData(sheetName, "nomineefirstname", rowCount);
                String nomineelastname = reader.getCellData(sheetName, "nomineelastname", rowCount);
                String nomineeday = reader.getCellData(sheetName, "nomineeday", rowCount);
                String nomineemonth = reader.getCellData(sheetName, "nomineemonth", rowCount);
                String nomineeyear = reader.getCellData(sheetName, "nomineeyear", rowCount);
                String nomineegender = reader.getCellData(sheetName, "nomineegender", rowCount);
                String relationshipwithproposer = reader.getCellData(sheetName, "relationshipwithproposer", rowCount);
                String nomineeshare = reader.getCellData(sheetName, "nomineeshare", rowCount);
                String ismwppolicy = reader.getCellData(sheetName, "ismwppolicy", rowCount);
                String addressscreentitle = reader.getCellData(sheetName, "addressscreentitle", rowCount);

                String typeofaddress = reader.getCellData(sheetName, "typeofaddress", rowCount);
                String addresspincode = reader.getCellData(sheetName, "addresspincode", rowCount);
                String address1 = reader.getCellData(sheetName, "address1", rowCount);
                String address2 = reader.getCellData(sheetName, "address2", rowCount);
                String address3 = reader.getCellData(sheetName, "address3", rowCount);
                String personalDetailsscreentitle = reader.getCellData(sheetName, "personalDetailsscreentitle", rowCount);
                String cityName = reader.getCellData(sheetName, "cityName", rowCount);
                String preferredLanguage = reader.getCellData(sheetName, "preferredLanguage", rowCount);
                String alernateNumber = reader.getCellData(sheetName, "alernateNumber", rowCount);
                String resTelephoneNumber = reader.getCellData(sheetName, "resTelephoneNumber", rowCount);
                String emailaddressValidations = reader.getCellData(sheetName, "emailaddressValidations", rowCount);
                String maritalStatus = reader.getCellData(sheetName, "maritalStatus", rowCount);
                String fathersNameOrSpouseName = reader.getCellData(sheetName, "fathersNameOrSpouseName", rowCount);
                String mothersName = reader.getCellData(sheetName, "mothersName", rowCount);
                String qualification = reader.getCellData(sheetName, "qualification", rowCount);
                String occupation = reader.getCellData(sheetName, "occupation", rowCount);
                String employeerName = reader.getCellData(sheetName, "employeerName", rowCount);
                String nameOfBusinessOrduties = reader.getCellData(sheetName, "nameOfBusinessOrduties", rowCount);
                String typeOfOrganization = reader.getCellData(sheetName, "typeOfOrganization", rowCount);
                String designation = reader.getCellData(sheetName, "designation", rowCount);
                String annualIncome = reader.getCellData(sheetName, "annualIncome", rowCount);
                String policyStatus = reader.getCellData(sheetName, "expolicystatus", rowCount);
                String exPolicyscreenTitle = reader.getCellData(sheetName, "exPolicyscreenTitle", rowCount);
                String exNameofInsurer = reader.getCellData(sheetName, "exNameofInsurer", rowCount);
                String exSumAssured = reader.getCellData(sheetName, "exSumAssured", rowCount);
                String expolicyNumber = reader.getCellData(sheetName, "expolicyNumber", rowCount);
                String exyearOfApplication = reader.getCellData(sheetName, "exyearOfApplication", rowCount);
                String exbasePlan = reader.getCellData(sheetName, "exbasePlan", rowCount);
                String exannualpremium = reader.getCellData(sheetName, "exannualpremium", rowCount);
                String medicalPolicy = reader.getCellData(sheetName, "medicalPolicy", rowCount);
                String expolicystatus = reader.getCellData(sheetName, "expolicystatus", rowCount);
                String refPolicyscreenTitle = reader.getCellData(sheetName, "refPolicyscreenTitle", rowCount);

                String refinsurerName = reader.getCellData(sheetName, "refnsurerName", rowCount);
                String refsumAssured = reader.getCellData(sheetName, "refsumAssured", rowCount);
                String refreason = reader.getCellData(sheetName, "refreason", rowCount);

                String refinsurerName1 = reader.getCellData(sheetName, "refnsurerName1", rowCount);
                String refsumAssured1 = reader.getCellData(sheetName, "refsumAssured1", rowCount);
                String refreason1 = reader.getCellData(sheetName, "refreason1", rowCount);

                String refinsurerName2 = reader.getCellData(sheetName, "refnsurerName2", rowCount);
                String refsumAssured2 = reader.getCellData(sheetName, "refsumAssured2", rowCount);
                String refreason2 = reader.getCellData(sheetName, "refreason2", rowCount);

                String refinsurerName3 = reader.getCellData(sheetName, "refnsurerName3", rowCount);
                String refsumAssured3 = reader.getCellData(sheetName, "refsumAssured3", rowCount);
                String refreason3 = reader.getCellData(sheetName, "refreason3", rowCount);

                String refinsurerName4 = reader.getCellData(sheetName, "refnsurerName4", rowCount);
                String refsumAssured4 = reader.getCellData(sheetName, "refsumAssured4", rowCount);
                String refreason4 = reader.getCellData(sheetName, "refreason4", rowCount);


                String policyPurposeScreen = reader.getCellData(sheetName, "policyPurposeScreen", rowCount);
                String purposeOption1 = reader.getCellData(sheetName, "purposeOption1", rowCount);
                String purposeOption2 = reader.getCellData(sheetName, "purposeOption2", rowCount);
                String purposeOption3 = reader.getCellData(sheetName, "purposeOption3", rowCount);

                String healthDetailsScreen = reader.getCellData(sheetName, "healthDetailsScreen", rowCount);

                String absentCurrentSymptoms = reader.getCellData(sheetName, "absentCurrentSymptoms", rowCount);
                String absentDoctorsDetails = reader.getCellData(sheetName, "absentDoctorsDetails", rowCount);
                String abDiagnosDay = reader.getCellData(sheetName, "abDiagnosDay", rowCount);
                String abDiagnosMonth = reader.getCellData(sheetName, "abDiagnosMonth", rowCount);
                String abDiagnosYear = reader.getCellData(sheetName, "abDiagnosYear", rowCount);
                String abHospitalizationDetails = reader.getCellData(sheetName, "abHospitalizationDetails", rowCount);
                String hosCurrentSymptoms = reader.getCellData(sheetName, "hosCurrentSymptoms", rowCount);
                String hosDoctorsDetails = reader.getCellData(sheetName, "hosDoctorsDetails", rowCount);
                String hosDiagnosDay = reader.getCellData(sheetName, "hosDiagnosDay", rowCount);
                String hosDiagnosMonth = reader.getCellData(sheetName, "hosDiagnosMonth", rowCount);
                String hosDiagnosYear = reader.getCellData(sheetName, "hosDiagnosYear", rowCount);
                String hosHospitalizationDetails = reader.getCellData(sheetName, "hosHospitalizationDetails", rowCount);
                String heartIssues1 = reader.getCellData(sheetName, "heartIssues1", rowCount);
                String heartIssues2 = reader.getCellData(sheetName, "heartIssues2", rowCount);
                String heartIssues3 = reader.getCellData(sheetName, "heartIssues3", rowCount);
                String breathingIssues1 = reader.getCellData(sheetName, "breathingIssues1", rowCount);
                String breathingIssues2 = reader.getCellData(sheetName, "breathingIssues2", rowCount);
                String breathingIssues3 = reader.getCellData(sheetName, "breathingIssues3", rowCount);
                String diabetesIssues1 = reader.getCellData(sheetName, "diabetesIssues1", rowCount);
                String diabetesIssues2 = reader.getCellData(sheetName, "diabetesIssues2", rowCount);
                String diabetesIssues3 = reader.getCellData(sheetName, "diabetesIssues3", rowCount);
                String ulcerIssues1 = reader.getCellData(sheetName, "ulcerIssues1", rowCount);
                String ulcerIssues2 = reader.getCellData(sheetName, "ulcerIssues2", rowCount);
                String ulcerIssues3 = reader.getCellData(sheetName, "ulcerIssues3", rowCount);
                String tumorIssues1 = reader.getCellData(sheetName, "tumorIssues1", rowCount);
                String tumorIssues2 = reader.getCellData(sheetName, "tumorIssues2", rowCount);
                String tumorIssues3 = reader.getCellData(sheetName, "tumorIssues3", rowCount);
                String paralysisIssues1 = reader.getCellData(sheetName, "paralysisIssues1", rowCount);
                String paralysisIssues2 = reader.getCellData(sheetName, "paralysisIssues2", rowCount);
                String paralysisIssues3 = reader.getCellData(sheetName, "paralysisIssues3", rowCount);
                String kidneyIssues1 = reader.getCellData(sheetName, "kidneyIssues1", rowCount);
                String kidneyIssues2 = reader.getCellData(sheetName, "kidneyIssues2", rowCount);
                String kidneyIssues3 = reader.getCellData(sheetName, "kidneyIssues3", rowCount);
                String arthritisIssues1 = reader.getCellData(sheetName, "arthritisIssues1", rowCount);
                String arthritisIssues2 = reader.getCellData(sheetName, "arthritisIssues2", rowCount);
                String arthritisIssues3 = reader.getCellData(sheetName, "arthritisIssues3", rowCount);
                String eyeOrearIssue1 = reader.getCellData(sheetName, "eyeOrearIssue1", rowCount);
                String eyeOrearIssue2 = reader.getCellData(sheetName, "eyeOrearIssue2", rowCount);

                String othersIssues1 = reader.getCellData(sheetName, "othersIssues1", rowCount);
                String othersIssues2 = reader.getCellData(sheetName, "othersIssues2", rowCount);
                String othersIssues3 = reader.getCellData(sheetName, "othersIssues3", rowCount);

                String disOCurrentSymptoms = reader.getCellData(sheetName, "disOCurrentSymptoms", rowCount);
                String disODoctorsDetails = reader.getCellData(sheetName, "disODoctorsDetails", rowCount);
                String disOdayLastconsultation = reader.getCellData(sheetName, "disOdayLastconsultation", rowCount);
                String disOMonthLastconsultation = reader.getCellData(sheetName, "disOMonthLastconsultation", rowCount);
                String disOYearLastconsultation = reader.getCellData(sheetName, "disOYearLastconsultation", rowCount);
                String disODayDiagnosis = reader.getCellData(sheetName, "disODayDiagnosis", rowCount);
                String disOMonthDiagnosis = reader.getCellData(sheetName, "disOMonthDiagnosis", rowCount);
                String disOYearDiagnosis = reader.getCellData(sheetName, "disOYearDiagnosis", rowCount);
                String disOHospitalization = reader.getCellData(sheetName, "disOHospitalization", rowCount);
                String spouseHCurrentSymptoms = reader.getCellData(sheetName, "spouseHCurrentSymptoms", rowCount);
                String spouseHDoctorsDetails = reader.getCellData(sheetName, "spouseHDoctorsDetails", rowCount);
                String spouseHdayLastconsultation = reader.getCellData(sheetName, "spouseHdayLastconsultation", rowCount);
                String spouseHMonthLastconsultation = reader.getCellData(sheetName, "spouseHMonthLastconsultation", rowCount);
                String spouseHYearLastconsultation = reader.getCellData(sheetName, "spouseHYearLastconsultation", rowCount);
                String otherSymCurrentSymptoms = reader.getCellData(sheetName, "otherSymCurrentSymptoms", rowCount);
                String otherSymDoctorsDetail = reader.getCellData(sheetName, "otherSymDoctorsDetail", rowCount);
                String otherSymDayDiagnosis = reader.getCellData(sheetName, "otherSymDayDiagnosis", rowCount);
                String otherSymMonthDiagnosis = reader.getCellData(sheetName, "otherSymMonthDiagnosis", rowCount);
                String otherSymYearDiagnosis = reader.getCellData(sheetName, "otherSymYearDiagnosis", rowCount);
                String otherSymHospitalization = reader.getCellData(sheetName, "otherSymHospitalization", rowCount);


                String forFemaleCurrentSymptoms = reader.getCellData(sheetName, "forFemaleCurrentSymptoms", rowCount);
                String forFemaleDoctorsDetails = reader.getCellData(sheetName, "forFemaleDoctorsDetails", rowCount);
                String forFemaledayLastconsultation = reader.getCellData(sheetName, "forFemaledayLastconsultation", rowCount);
                String forFemaleMonthLastconsultation = reader.getCellData(sheetName, "forFemaleMonthLastconsultation", rowCount);
                String forFemaleYearLastconsultation = reader.getCellData(sheetName, "forFemaleYearLastconsultation", rowCount);
                String forFemaleHospitalization = reader.getCellData(sheetName, "forFemaleHospitalization", rowCount);
                String currentSymptoms = reader.getCellData(sheetName, "currentSymptoms", rowCount);
                String doctorsDetails = reader.getCellData(sheetName, "doctorsDetails", rowCount);

                String dayLastconsultation = reader.getCellData(sheetName, "dayLastconsultation", rowCount);
                String monthLastconsultation = reader.getCellData(sheetName, "monthLastconsultation", rowCount);
                String yearLastconsultation = reader.getCellData(sheetName, "yearLastconsultation", rowCount);
                String dayDiagnosis = reader.getCellData(sheetName, "dayDiagnosis", rowCount);
                String monthDiagnosis = reader.getCellData(sheetName, "monthDiagnosis", rowCount);
                String yearDiagnosis = reader.getCellData(sheetName, "yearDiagnosis", rowCount);
                String hospitalization = reader.getCellData(sheetName, "hospitalization", rowCount);


                Object ob[] = {username.trim(), password.trim(), policy.trim(), leadid.trim(), proposersame.trim(), propinsurednotsame.trim(),
                        isnri.trim(), pmobile.trim(), ppan.trim(), imobile.trim(), ipan.trim(), firstname.trim(), lastname.trim(),
                        middlename.trim(), day.trim(), month.trim(), year.trim(),
                        gender.trim(), planjourney.trim(), proposerstate.trim(), advisorstatesame.trim(), plan.trim(), sumassured.trim(), smokertype.trim(), planoptions.trim(), increasinglevel.trim(),
                        ecs.trim(), term.trim(), ppt.trim(), premiumterm.trim(), premiumamount.trim(), rider.trim(), rideramount.trim(), minrider.trim(), maxrider.trim(), ridererror.trim(), click.trim(),
                        generateillustrations.trim(), clickcontinue.trim(), ifsccode.trim(), bankaccno.trim(), accholdername.trim(),
                        accounttype.trim(), pennyalert.trim(), clickverify.trim(), renewpremiumscreentitle.trim(), paymentmethod.trim(),
                        drawdate.trim(), fundsource.trim(), nomineescreentitle.trim(), nomineefirstname.trim(), nomineelastname.trim(), nomineeday.trim(),
                        nomineemonth.trim(), nomineeyear.trim(), nomineegender.trim(), relationshipwithproposer.trim(), nomineeshare.trim(), ismwppolicy.trim(), addressscreentitle.trim(),
                        typeofaddress.trim(), addresspincode.trim(), address1.trim(), address2.trim(), address3.trim(), personalDetailsscreentitle.trim(), cityName.trim(),
                        preferredLanguage.trim(), alernateNumber.trim(), resTelephoneNumber.trim(), emailaddressValidations.trim(), maritalStatus.trim(),
                        fathersNameOrSpouseName.trim(), mothersName.trim(), qualification.trim(), occupation.trim(), employeerName.trim(),
                        nameOfBusinessOrduties.trim(), typeOfOrganization.trim(), designation.trim(), annualIncome.trim(), policyStatus.trim(), exPolicyscreenTitle.trim(), exNameofInsurer.trim(),
                        exSumAssured.trim(), expolicyNumber.trim(), exyearOfApplication.trim(), exbasePlan.trim(), exannualpremium.trim(), medicalPolicy.trim(), expolicystatus.trim(),
                        refPolicyscreenTitle.trim(), refinsurerName.trim(), refsumAssured.trim(), refreason.trim(), refinsurerName1.trim(), refsumAssured1.trim(), refreason1.trim(),
                        refinsurerName2.trim(), refsumAssured2.trim(), refreason2.trim(), refinsurerName3.trim(), refsumAssured3.trim(), refreason3.trim(),
                        refinsurerName4.trim(), refsumAssured4.trim(), refreason4.trim(), policyPurposeScreen.trim(), purposeOption1.trim(), purposeOption2.trim(), purposeOption3.trim(),
                        healthDetailsScreen.trim(), absentCurrentSymptoms.trim(), absentDoctorsDetails.trim(), abDiagnosDay.trim(), abDiagnosMonth.trim(), abDiagnosYear.trim(),
                        abHospitalizationDetails.trim(), hosCurrentSymptoms.trim(), hosDoctorsDetails.trim(), hosDiagnosDay.trim(), hosDiagnosMonth.trim(), hosDiagnosYear.trim(),
                        hosHospitalizationDetails.trim(), heartIssues1.trim(), heartIssues2.trim(), heartIssues3.trim(), breathingIssues1.trim(), breathingIssues2.trim(), breathingIssues3.trim(),
                        diabetesIssues1.trim(), diabetesIssues2.trim(), diabetesIssues3.trim(), ulcerIssues1.trim(), ulcerIssues2.trim(), ulcerIssues3.trim(),
                        tumorIssues1.trim(), tumorIssues2.trim(), tumorIssues3.trim(), paralysisIssues1.trim(), paralysisIssues2.trim(), paralysisIssues3.trim(),
                        kidneyIssues1.trim(), kidneyIssues2.trim(), kidneyIssues3.trim(), arthritisIssues1.trim(), arthritisIssues2.trim(), arthritisIssues3.trim(),
                        eyeOrearIssue1.trim(), eyeOrearIssue2.trim(), othersIssues1.trim(), othersIssues2.trim(), othersIssues3.trim(), disOCurrentSymptoms.trim(), disODoctorsDetails.trim(),
                        disOdayLastconsultation.trim(), disOMonthLastconsultation.trim(), disOYearLastconsultation.trim(), disODayDiagnosis.trim(), disOMonthDiagnosis.trim(),
                        disOYearDiagnosis.trim(), disOHospitalization.trim(), spouseHCurrentSymptoms.trim(), spouseHDoctorsDetails.trim(), spouseHdayLastconsultation.trim(), spouseHMonthLastconsultation.trim(), spouseHYearLastconsultation.trim(),
                        otherSymCurrentSymptoms.trim(), otherSymDoctorsDetail.trim(), otherSymDayDiagnosis.trim(), otherSymMonthDiagnosis.trim(), otherSymYearDiagnosis.trim(),
                        otherSymHospitalization.trim(), forFemaleCurrentSymptoms.trim(), forFemaleDoctorsDetails.trim(), forFemaledayLastconsultation.trim(), forFemaleMonthLastconsultation.trim(), forFemaleYearLastconsultation.trim(),
                        forFemaleHospitalization.trim(), currentSymptoms.trim(), doctorsDetails.trim(), dayLastconsultation.trim(), monthLastconsultation.trim(), yearLastconsultation.trim(),
                        dayDiagnosis.trim(), monthDiagnosis.trim(), yearDiagnosis.trim(), hospitalization.trim()};

                myData.add(ob);
            }
        }
        System.out.println("mydata rows value **********" + myData.toString());
        return myData;
    }


    public static ArrayList<Object[]> getMedicalHistoryTestData(String testExcelSheet, String testName, String sheetName) {
        ArrayList<Object[]> myData = new ArrayList<Object[]>();
        Xls_Reader reader = null;

        try {
            reader = new Xls_Reader(System.getProperty("user.dir") + testExcelSheet);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("row count ---------" + reader.getRowCount(sheetName));

        for (int rowCount = 3; rowCount <= reader.getRowCount(sheetName); rowCount++) {
            String currentTestMethod = reader.getCellData(sheetName, "testCaseName", rowCount);
            String enableFlag = reader.getCellData(sheetName, "flag", rowCount);
            if (currentTestMethod.trim().equalsIgnoreCase(testName) && enableFlag.equalsIgnoreCase("YES")) {

                String username = reader.getCellData(sheetName, "username", rowCount);
                String password = reader.getCellData(sheetName, "password", rowCount);


                String policy = reader.getCellData(sheetName, "policy", rowCount);
                String leadid = reader.getCellData(sheetName, "leadid", rowCount);
                String proposersame = reader.getCellData(sheetName, "proposersame", rowCount);
                String propinsurednotsame = reader.getCellData(sheetName, "propinsurednotsame", rowCount);
                String isnri = reader.getCellData(sheetName, "isnri", rowCount);
                String pmobile = reader.getCellData(sheetName, "pmobile", rowCount);
                String ppan = reader.getCellData(sheetName, "ppan", rowCount);
                String imobile = reader.getCellData(sheetName, "imobile", rowCount);
                String ipan = reader.getCellData(sheetName, "ipan", rowCount);
                String firstname = reader.getCellData(sheetName, "firstname", rowCount);
                String lastname = reader.getCellData(sheetName, "lastname", rowCount);
                String middlename = reader.getCellData(sheetName, "middlename", rowCount);
                String day = reader.getCellData(sheetName, "day", rowCount);
                String month = reader.getCellData(sheetName, "month", rowCount);
                String year = reader.getCellData(sheetName, "year", rowCount);
                String gender = reader.getCellData(sheetName, "gender", rowCount);


                String planjourney = reader.getCellData(sheetName, "planjourney", rowCount);
                String proposerstate = reader.getCellData(sheetName, "proposerstate", rowCount);
                String advisorstatesame = reader.getCellData(sheetName, "advisorstatesame", rowCount);

                String plan = reader.getCellData(sheetName, "plan", rowCount);
                String sumassured = reader.getCellData(sheetName, "sumassured", rowCount);
                String smokertype = reader.getCellData(sheetName, "smokertype", rowCount);
                String planoptions = reader.getCellData(sheetName, "planoptions", rowCount);
                String increasinglevel = reader.getCellData(sheetName, "increasinglevel", rowCount);
                String ecs = reader.getCellData(sheetName, "ecs", rowCount);
                String term = reader.getCellData(sheetName, "term", rowCount);
                String ppt = reader.getCellData(sheetName, "ppt", rowCount);
                String premiumterm = reader.getCellData(sheetName, "premiumterm", rowCount);
                String premiumamount = reader.getCellData(sheetName, "premiumamount", rowCount);

                String rider = reader.getCellData(sheetName, "rider", rowCount);
                String rideramount = reader.getCellData(sheetName, "rideramount", rowCount);
                String minrider = reader.getCellData(sheetName, "minrider", rowCount);
                String maxrider = reader.getCellData(sheetName, "maxrider", rowCount);
                String ridererror = reader.getCellData(sheetName, "ridererror", rowCount);
                String click = reader.getCellData(sheetName, "click", rowCount);

                String generateillustrations = reader.getCellData(sheetName, "generateillustrations", rowCount);
                String clickcontinue = reader.getCellData(sheetName, "clickcontinue", rowCount);


                String ifsccode = reader.getCellData(sheetName, "ifsccode", rowCount);
                String bankaccno = reader.getCellData(sheetName, "bankaccno", rowCount);
                String accholdername = reader.getCellData(sheetName, "accholdername", rowCount);
                String accounttype = reader.getCellData(sheetName, "accounttype", rowCount);

                String pennyalert = reader.getCellData(sheetName, "pennyalert", rowCount);
                String clickverify = reader.getCellData(sheetName, "clickverify", rowCount);

                String renewpremiumscreentitle = reader.getCellData(sheetName, "renewpremiumscreentitle", rowCount);

                String paymentmethod = reader.getCellData(sheetName, "paymentmethod", rowCount);
                String drawdate = reader.getCellData(sheetName, "drawdate", rowCount);
                String fundsource = reader.getCellData(sheetName, "fundsource", rowCount);
                String nomineescreentitle = reader.getCellData(sheetName, "nomineescreentitle", rowCount);

                String nomineefirstname = reader.getCellData(sheetName, "nomineefirstname", rowCount);
                String nomineelastname = reader.getCellData(sheetName, "nomineelastname", rowCount);
                String nomineeday = reader.getCellData(sheetName, "nomineeday", rowCount);
                String nomineemonth = reader.getCellData(sheetName, "nomineemonth", rowCount);
                String nomineeyear = reader.getCellData(sheetName, "nomineeyear", rowCount);
                String nomineegender = reader.getCellData(sheetName, "nomineegender", rowCount);
                String relationshipwithproposer = reader.getCellData(sheetName, "relationshipwithproposer", rowCount);
                String nomineeshare = reader.getCellData(sheetName, "nomineeshare", rowCount);
                String ismwppolicy = reader.getCellData(sheetName, "ismwppolicy", rowCount);
                String addressscreentitle = reader.getCellData(sheetName, "addressscreentitle", rowCount);

                String typeofaddress = reader.getCellData(sheetName, "typeofaddress", rowCount);
                String addresspincode = reader.getCellData(sheetName, "addresspincode", rowCount);
                String address1 = reader.getCellData(sheetName, "address1", rowCount);
                String address2 = reader.getCellData(sheetName, "address2", rowCount);
                String address3 = reader.getCellData(sheetName, "address3", rowCount);
                String personalDetailsscreentitle = reader.getCellData(sheetName, "personalDetailsscreentitle", rowCount);
                String cityName = reader.getCellData(sheetName, "cityName", rowCount);
                String preferredLanguage = reader.getCellData(sheetName, "preferredLanguage", rowCount);
                String alernateNumber = reader.getCellData(sheetName, "alernateNumber", rowCount);
                String resTelephoneNumber = reader.getCellData(sheetName, "resTelephoneNumber", rowCount);
                String emailaddressValidations = reader.getCellData(sheetName, "emailaddressValidations", rowCount);
                String maritalStatus = reader.getCellData(sheetName, "maritalStatus", rowCount);
                String fathersNameOrSpouseName = reader.getCellData(sheetName, "fathersNameOrSpouseName", rowCount);
                String mothersName = reader.getCellData(sheetName, "mothersName", rowCount);

                String question1 = reader.getCellData(sheetName, "question1", rowCount);
                String answer1 = reader.getCellData(sheetName, "answer1", rowCount);
                String valuetoBeEnter = reader.getCellData(sheetName, "valueToBeEnter", rowCount);
                String question2 = reader.getCellData(sheetName, "question2", rowCount);
                String answer2 = reader.getCellData(sheetName, "answer2", rowCount);
                String valuetoBeEnter2 = reader.getCellData(sheetName, "valueToBeEnter2", rowCount);
                String question3 = reader.getCellData(sheetName, "question3", rowCount);
                String answer3 = reader.getCellData(sheetName, "answer3", rowCount);
                String valuetoBeEnter3 = reader.getCellData(sheetName, "valueToBeEnter3", rowCount);
                String question4 = reader.getCellData(sheetName, "question4", rowCount);
                String answer4 = reader.getCellData(sheetName, "answer4", rowCount);
                String valuetoBeEnter4 = reader.getCellData(sheetName, "valueToBeEnter4", rowCount);

                String qualification = reader.getCellData(sheetName, "qualification", rowCount);
                String occupation = reader.getCellData(sheetName, "occupation", rowCount);
                String employeerName = reader.getCellData(sheetName, "employeerName", rowCount);
                String nameOfBusinessOrduties = reader.getCellData(sheetName, "nameOfBusinessOrduties", rowCount);
                String typeOfOrganization = reader.getCellData(sheetName, "typeOfOrganization", rowCount);
                String designation = reader.getCellData(sheetName, "designation", rowCount);
                String annualIncome = reader.getCellData(sheetName, "annualIncome", rowCount);
                String exPolicyscreenTitle = reader.getCellData(sheetName, "exPolicyscreenTitle", rowCount);
                String exNameofInsurer = reader.getCellData(sheetName, "exNameofInsurer", rowCount);
                String exSumAssured = reader.getCellData(sheetName, "exSumAssured", rowCount);
                String expolicyNumber = reader.getCellData(sheetName, "expolicyNumber", rowCount);
                String exyearOfApplication = reader.getCellData(sheetName, "exyearOfApplication", rowCount);
                String exbasePlan = reader.getCellData(sheetName, "exbasePlan", rowCount);
                String exannualpremium = reader.getCellData(sheetName, "exannualpremium", rowCount);
                String medicalPolicy = reader.getCellData(sheetName, "medicalPolicy", rowCount);
                String refPolicyscreenTitle = reader.getCellData(sheetName, "refPolicyscreenTitle", rowCount);

                String refinsurerName = reader.getCellData(sheetName, "refnsurerName", rowCount);
                String refsumAssured = reader.getCellData(sheetName, "refsumAssured", rowCount);
                String refreason = reader.getCellData(sheetName, "refreason", rowCount);


                String policyPurposeScreen = reader.getCellData(sheetName, "policyPurposeScreen", rowCount);
                String purposeOption1 = reader.getCellData(sheetName, "purposeOption1", rowCount);
                String purposeOption2 = reader.getCellData(sheetName, "purposeOption2", rowCount);
                String purposeOption3 = reader.getCellData(sheetName, "purposeOption3", rowCount);

                String healthDetailsScreen = reader.getCellData(sheetName, "healthDetailsScreen", rowCount);

                Object ob[] = {username.trim(), password.trim(), policy.trim(), leadid.trim(), proposersame.trim(), propinsurednotsame.trim(),
                        isnri.trim(), pmobile.trim(), ppan.trim(), imobile.trim(), ipan.trim(), firstname.trim(), lastname.trim(),
                        middlename.trim(), day.trim(), month.trim(), year.trim(),
                        gender.trim(), planjourney.trim(), proposerstate.trim(), advisorstatesame.trim(), plan.trim(), sumassured.trim(), smokertype.trim(), planoptions.trim(), increasinglevel.trim(),
                        ecs.trim(), term.trim(), ppt.trim(), premiumterm.trim(), premiumamount.trim(), rider.trim(), rideramount.trim(), minrider.trim(), maxrider.trim(), ridererror.trim(), click.trim(),
                        generateillustrations.trim(), clickcontinue.trim(), ifsccode.trim(), bankaccno.trim(), accholdername.trim(),
                        accounttype.trim(), pennyalert.trim(), clickverify.trim(), renewpremiumscreentitle.trim(), paymentmethod.trim(),
                        drawdate.trim(), fundsource.trim(), nomineescreentitle.trim(), nomineefirstname.trim(), nomineelastname.trim(), nomineeday.trim(),
                        nomineemonth.trim(), nomineeyear.trim(), nomineegender.trim(), relationshipwithproposer.trim(), nomineeshare.trim(), ismwppolicy.trim(), addressscreentitle.trim(),
                        typeofaddress.trim(), addresspincode.trim(), address1.trim(), address2.trim(), address3.trim(), personalDetailsscreentitle.trim(), cityName.trim(),
                        preferredLanguage.trim(), alernateNumber.trim(), resTelephoneNumber.trim(), emailaddressValidations.trim(), maritalStatus.trim(),
                        fathersNameOrSpouseName.trim(), mothersName.trim(), question1.trim(), answer1.trim(), valuetoBeEnter.trim(), question2.trim(), valuetoBeEnter2.trim(), question3.trim(), answer3.trim(), valuetoBeEnter3.trim(), question4.trim(), answer4.trim(), valuetoBeEnter4.trim(),
                        qualification.trim(), occupation.trim(), employeerName.trim(),
                        nameOfBusinessOrduties.trim(), typeOfOrganization.trim(), designation.trim(), annualIncome.trim(), exPolicyscreenTitle.trim(), exNameofInsurer.trim(),
                        exSumAssured.trim(), expolicyNumber.trim(), exyearOfApplication.trim(), exbasePlan.trim(), exannualpremium.trim(), medicalPolicy.trim(), refPolicyscreenTitle.trim(), refinsurerName.trim(), refsumAssured.trim(), refreason.trim(), policyPurposeScreen.trim(), purposeOption1.trim(), purposeOption2.trim(), purposeOption3.trim(),
                        healthDetailsScreen.trim()};
                myData.add(ob);
            }
        }
        System.out.println("mydata rows value **********" + myData.toString());
        return myData;
    }

    public static ArrayList<Object[]> getRnaDataFromExcel(String testExcelSheet, String testName, String sheetName) {
        ArrayList<Object[]> myData = new ArrayList<Object[]>();
        Xls_Reader reader = null;

        try {
            reader = new Xls_Reader(System.getProperty("user.dir") + testExcelSheet);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("RNA sheet row count ---------" + reader.getRowCount(sheetName));

        for (int rowCount = 3; rowCount <= reader.getRowCount(sheetName); rowCount++) {
            String currentTestMethod = reader.getCellData(sheetName, "testCaseName", rowCount);
            String enableFlag = reader.getCellData(sheetName, "flag", rowCount);
            //if (currentTestMethod.trim().equalsIgnoreCase(testName) && enableFlag.equalsIgnoreCase("YES")) {
            if (currentTestMethod.trim().equalsIgnoreCase(testName)) {


                String username = reader.getCellData(sheetName, "username", rowCount);
                String password = reader.getCellData(sheetName, "password", rowCount);


                String policy = reader.getCellData(sheetName, "policy", rowCount);
                String leadid = reader.getCellData(sheetName, "leadid", rowCount);
                String proposersame = reader.getCellData(sheetName, "proposersame", rowCount);
                String relationwithinsured = reader.getCellData(sheetName, "relationwithinsured", rowCount);
                String isrelationanswer = reader.getCellData(sheetName, "isrelationanswer", rowCount);

                String isnri = reader.getCellData(sheetName, "isnri", rowCount);
                String pmobile = reader.getCellData(sheetName, "pmobile", rowCount);
                String ppan = reader.getCellData(sheetName, "ppan", rowCount);
                String imobile = reader.getCellData(sheetName, "imobile", rowCount);
                String ipan = reader.getCellData(sheetName, "ipan", rowCount);
                String firstname = reader.getCellData(sheetName, "firstname", rowCount);
                String lastname = reader.getCellData(sheetName, "lastname", rowCount);
                String middlename = reader.getCellData(sheetName, "middlename", rowCount);
                String day = reader.getCellData(sheetName, "day", rowCount);
                String month = reader.getCellData(sheetName, "month", rowCount);
                String year = reader.getCellData(sheetName, "year", rowCount);
                String gender = reader.getCellData(sheetName, "gender", rowCount);


                String planjourney = reader.getCellData(sheetName, "planjourney", rowCount);
                String proposerstate = reader.getCellData(sheetName, "proposerstate", rowCount);
                String advisorstatesame = reader.getCellData(sheetName, "advisorstatesame", rowCount);

                String plan = reader.getCellData(sheetName, "plan", rowCount);
                String sumassured = reader.getCellData(sheetName, "sumassured", rowCount);
                String smokertype = reader.getCellData(sheetName, "smokertype", rowCount);
                String planoptions = reader.getCellData(sheetName, "planoptions", rowCount);
                String increasinglevel = reader.getCellData(sheetName, "increasinglevel", rowCount);
                String ecs = reader.getCellData(sheetName, "ecs", rowCount);
                String term = reader.getCellData(sheetName, "term", rowCount);
                String ppt = reader.getCellData(sheetName, "ppt", rowCount);
                String premiumterm = reader.getCellData(sheetName, "premiumterm", rowCount);
                String premiumamount = reader.getCellData(sheetName, "premiumamount", rowCount);

                String rider = reader.getCellData(sheetName, "rider", rowCount);
                String rideramount = reader.getCellData(sheetName, "rideramount", rowCount);
                String minrider = reader.getCellData(sheetName, "minrider", rowCount);
                String maxrider = reader.getCellData(sheetName, "maxrider", rowCount);
                String ridererror = reader.getCellData(sheetName, "ridererror", rowCount);
                String click = reader.getCellData(sheetName, "click", rowCount);

                String generateillustrations = reader.getCellData(sheetName, "generateillustrations", rowCount);
                String clickcontinue = reader.getCellData(sheetName, "clickcontinue", rowCount);


                String ifsccode = reader.getCellData(sheetName, "ifsccode", rowCount);
                String bankaccno = reader.getCellData(sheetName, "bankaccno", rowCount);
                String accholdername = reader.getCellData(sheetName, "accholdername", rowCount);
                String accounttype = reader.getCellData(sheetName, "accounttype", rowCount);

                String pennyalert = reader.getCellData(sheetName, "pennyalert", rowCount);
                String clickverify = reader.getCellData(sheetName, "clickverify", rowCount);

                String renewpremiumscreentitle = reader.getCellData(sheetName, "renewpremiumscreentitle", rowCount);

                String paymentmethod = reader.getCellData(sheetName, "paymentmethod", rowCount);
                String drawdate = reader.getCellData(sheetName, "drawdate", rowCount);
                String fundsource = reader.getCellData(sheetName, "fundsource", rowCount);
                String nomineescreentitle = reader.getCellData(sheetName, "nomineescreentitle", rowCount);

                String nomineefirstname = reader.getCellData(sheetName, "nomineefirstname", rowCount);
                String nomineelastname = reader.getCellData(sheetName, "nomineelastname", rowCount);
                String nomineeday = reader.getCellData(sheetName, "nomineeday", rowCount);
                String nomineemonth = reader.getCellData(sheetName, "nomineemonth", rowCount);
                String nomineeyear = reader.getCellData(sheetName, "nomineeyear", rowCount);
                String nomineegender = reader.getCellData(sheetName, "nomineegender", rowCount);
                String relationshipwithproposer = reader.getCellData(sheetName, "relationshipwithproposer", rowCount);
                String nomineeshare = reader.getCellData(sheetName, "nomineeshare", rowCount);
                String ismwppolicy = reader.getCellData(sheetName, "ismwppolicy", rowCount);
                String addressscreentitle = reader.getCellData(sheetName, "addressscreentitle", rowCount);

                String typeofaddress = reader.getCellData(sheetName, "typeofaddress", rowCount);
                String addresspincode = reader.getCellData(sheetName, "addresspincode", rowCount);
                String address1 = reader.getCellData(sheetName, "address1", rowCount);
                String address2 = reader.getCellData(sheetName, "address2", rowCount);
                String address3 = reader.getCellData(sheetName, "address3", rowCount);
                String personalDetailsscreentitle = reader.getCellData(sheetName, "personalDetailsscreentitle", rowCount);
                String cityName = reader.getCellData(sheetName, "cityName", rowCount);
                String preferredLanguage = reader.getCellData(sheetName, "preferredLanguage", rowCount);
                String alernateNumber = reader.getCellData(sheetName, "alernateNumber", rowCount);
                String resTelephoneNumber = reader.getCellData(sheetName, "resTelephoneNumber", rowCount);
                String emailaddressValidations = reader.getCellData(sheetName, "emailaddressValidations", rowCount);
                String maritalStatus = reader.getCellData(sheetName, "maritalStatus", rowCount);
                String fathersNameOrSpouseName = reader.getCellData(sheetName, "fathersNameOrSpouseName", rowCount);
                String mothersName = reader.getCellData(sheetName, "mothersName", rowCount);
                String MaidenName = reader.getCellData(sheetName, "MaidenName", rowCount);


                String question1 = reader.getCellData(sheetName, "question1", rowCount);
                String answer1 = reader.getCellData(sheetName, "answer1", rowCount);
                String valuetoBeEnter = reader.getCellData(sheetName, "valueToBeEnter", rowCount);
                String question2 = reader.getCellData(sheetName, "question2", rowCount);
                String answer2 = reader.getCellData(sheetName, "answer2", rowCount);
                String valuetoBeEnter2 = reader.getCellData(sheetName, "valueToBeEnter2", rowCount);
                String question3 = reader.getCellData(sheetName, "question3", rowCount);
                String answer3 = reader.getCellData(sheetName, "answer3", rowCount);
                String valuetoBeEnter3 = reader.getCellData(sheetName, "valueToBeEnter3", rowCount);
                String question4 = reader.getCellData(sheetName, "question4", rowCount);
                String answer4 = reader.getCellData(sheetName, "answer4", rowCount);
                String valuetoBeEnter4 = reader.getCellData(sheetName, "valueToBeEnter4", rowCount);
                String qualification = reader.getCellData(sheetName, "qualification", rowCount);
                String occupation = reader.getCellData(sheetName, "occupation", rowCount);
                String employeerName = reader.getCellData(sheetName, "employeerName", rowCount);
                String nameOfBusinessOrduties = reader.getCellData(sheetName, "nameOfBusinessOrduties", rowCount);
                String typeOfOrganization = reader.getCellData(sheetName, "typeOfOrganization", rowCount);
                String designation = reader.getCellData(sheetName, "designation", rowCount);
                String annualIncome = reader.getCellData(sheetName, "annualIncome", rowCount);
                String policyStatus = reader.getCellData(sheetName, "expolicystatus", rowCount);
                String exPolicyscreenTitle = reader.getCellData(sheetName, "exPolicyscreenTitle", rowCount);
                String exNameofInsurer = reader.getCellData(sheetName, "exNameofInsurer", rowCount);
                String exSumAssured = reader.getCellData(sheetName, "exSumAssured", rowCount);
                String expolicyNumber = reader.getCellData(sheetName, "expolicyNumber", rowCount);
                String exyearOfApplication = reader.getCellData(sheetName, "exyearOfApplication", rowCount);
                String exbasePlan = reader.getCellData(sheetName, "exbasePlan", rowCount);
                String exannualpremium = reader.getCellData(sheetName, "exannualpremium", rowCount);
                String medicalPolicy = reader.getCellData(sheetName, "medicalPolicy", rowCount);
                String expolicystatus = reader.getCellData(sheetName, "expolicystatus", rowCount);
                String refPolicyscreenTitle = reader.getCellData(sheetName, "refPolicyscreenTitle", rowCount);

                String refinsurerName = reader.getCellData(sheetName, "refnsurerName", rowCount);
                String refsumAssured = reader.getCellData(sheetName, "refsumAssured", rowCount);
                String refreason = reader.getCellData(sheetName, "refreason", rowCount);

                String refinsurerName1 = reader.getCellData(sheetName, "refnsurerName1", rowCount);
                String refsumAssured1 = reader.getCellData(sheetName, "refsumAssured1", rowCount);
                String refreason1 = reader.getCellData(sheetName, "refreason1", rowCount);

                String refinsurerName2 = reader.getCellData(sheetName, "refnsurerName2", rowCount);
                String refsumAssured2 = reader.getCellData(sheetName, "refsumAssured2", rowCount);
                String refreason2 = reader.getCellData(sheetName, "refreason2", rowCount);

                String refinsurerName3 = reader.getCellData(sheetName, "refnsurerName3", rowCount);
                String refsumAssured3 = reader.getCellData(sheetName, "refsumAssured3", rowCount);
                String refreason3 = reader.getCellData(sheetName, "refreason3", rowCount);

                String refinsurerName4 = reader.getCellData(sheetName, "refnsurerName4", rowCount);
                String refsumAssured4 = reader.getCellData(sheetName, "refsumAssured4", rowCount);
                String refreason4 = reader.getCellData(sheetName, "refreason4", rowCount);


                String policyPurposeScreen = reader.getCellData(sheetName, "policyPurposeScreen", rowCount);
                String purposeOption1 = reader.getCellData(sheetName, "purposeOption1", rowCount);
                String purposeOption2 = reader.getCellData(sheetName, "purposeOption2", rowCount);
                String purposeOption3 = reader.getCellData(sheetName, "purposeOption3", rowCount);

                String healthDetailsScreen = reader.getCellData(sheetName, "healthDetailsScreen", rowCount);

                String height = reader.getCellData(sheetName, "height", rowCount);
                String weight = reader.getCellData(sheetName, "weight", rowCount);
                String weightchange = reader.getCellData(sheetName, "weightchange", rowCount);

                String symptomsDetails = reader.getCellData(sheetName, "symptomsDetails", rowCount);
                String testsDetails = reader.getCellData(sheetName, "testsDetails", rowCount);
                String covidContactDetails = reader.getCellData(sheetName, "covidContactDetails", rowCount);
                String quarantineDetails = reader.getCellData(sheetName, "quarantineDetails", rowCount);
                String healthDetails = reader.getCellData(sheetName, "healthDetails", rowCount);
                String pastTravelContry = reader.getCellData(sheetName, "pastTravelContry", rowCount);
                String pastTravelCity = reader.getCellData(sheetName, "pastTravelCity", rowCount);
                String pastTravelArrivalDay = reader.getCellData(sheetName, "pastTravelArrivalDay", rowCount);
                String pastTravelArraivalMonth = reader.getCellData(sheetName, "pastTravelArraivalMonth", rowCount);
                String pastTravelArraivalYear = reader.getCellData(sheetName, "pastTravelArraivalYear", rowCount);
                String pastTravelDepartureDay = reader.getCellData(sheetName, "pastTravelDepartureDay", rowCount);
                String pastTravelDepartureMonth = reader.getCellData(sheetName, "pastTravelDepartureMonth", rowCount);
                String pastTravelDepartureYear = reader.getCellData(sheetName, "pastTravelDepartureYear", rowCount);
                String futureTravelCountry = reader.getCellData(sheetName, "futureTravelCountry", rowCount);
                String futureTravelCity = reader.getCellData(sheetName, "futureTravelCity", rowCount);
                String futureTravelDepartureDay = reader.getCellData(sheetName, "futureTravelDepartureDay", rowCount);
                String futureTravelDepartureMonth = reader.getCellData(sheetName, "futureTravelDepartureMonth", rowCount);
                String futureTravelDepartureYear = reader.getCellData(sheetName, "futureTravelDepartureYear", rowCount);
                String futureInternedDuration = reader.getCellData(sheetName, "futureInternedDuration", rowCount);
                String covidVaccinationFirstDoseDay = reader.getCellData(sheetName, "covidVaccinationFirstDoseDay", rowCount);
                String covidVaccinationFirstDoseMonth = reader.getCellData(sheetName, "covidVaccinationFirstDoseMonth", rowCount);
                String covidVaccinationFirstDoseYear = reader.getCellData(sheetName, "covidVaccinationFirstDoseYear", rowCount);
                String covidVaccinationSecondDoseDay = reader.getCellData(sheetName, "covidVaccinationSecondDoseDay", rowCount);
                String covidVaccinationSecondDoseMonth = reader.getCellData(sheetName, "covidVaccinationSecondDoseMonth", rowCount);
                String covidVaccinationSecondDoseYear = reader.getCellData(sheetName, "covidVaccinationSecondDoseYear", rowCount);
                String covidVaccineName = reader.getCellData(sheetName, "covidVaccineName", rowCount);
                String postVaccineDetails = reader.getCellData(sheetName, "postVaccineDetails", rowCount);
                String covidOccupation = reader.getCellData(sheetName, "covidOccupation", rowCount);
                String medicalSpeciality = reader.getCellData(sheetName, "medicalSpeciality", rowCount);
                String exactNatureOfDuties = reader.getCellData(sheetName, "exactNatureOfDuties", rowCount);
                String nameOfHealthCareFacility = reader.getCellData(sheetName, "nameOfHealthCareFacility", rowCount);
                String addressOfHealthCareFacility = reader.getCellData(sheetName, "addressOfHealthCareFacility", rowCount);
                String healthAuthorityRegistered = reader.getCellData(sheetName, "healthAuthorityRegistered", rowCount);
                String covidWardDetails = reader.getCellData(sheetName, "covidWardDetails", rowCount);
                String diagnoseDay = reader.getCellData(sheetName, "diagnoseDay", rowCount);
                String diagnoseMonth = reader.getCellData(sheetName, "diagnoseMonth", rowCount);
                String diagnoseYear = reader.getCellData(sheetName, "diagnoseYear", rowCount);
                String daignoseTestName = reader.getCellData(sheetName, "daignoseTestName", rowCount);
                String receivedCovid19Test1 = reader.getCellData(sheetName, "receivedCovid19Test1", rowCount);
                String receivedCovid19Test2 = reader.getCellData(sheetName, "receivedCovid19Test2", rowCount);
                String receivedCovid19Test3 = reader.getCellData(sheetName, "receivedCovid19Test3", rowCount);
                String admissionDay = reader.getCellData(sheetName, "admissionDay", rowCount);
                String admissionMonth = reader.getCellData(sheetName, "admissionMonth", rowCount);
                String admissionYear = reader.getCellData(sheetName, "admissionYear", rowCount);
                String dischargeDay = reader.getCellData(sheetName, "dischargeDay", rowCount);
                String dischargeMonth = reader.getCellData(sheetName, "dischargeMonth", rowCount);
                String dischargeYear = reader.getCellData(sheetName, "dischargeYear", rowCount);
                String covidInfectionDetails = reader.getCellData(sheetName, "covidInfectionDetails", rowCount);
                String covidSymptoms1 = reader.getCellData(sheetName, "covidSymptoms1", rowCount);
                String covidSymptoms2 = reader.getCellData(sheetName, "covidSymptoms2", rowCount);
                String covidSymptoms3 = reader.getCellData(sheetName, "covidSymptoms3", rowCount);
                String recoveryDay = reader.getCellData(sheetName, "recoveryDay", rowCount);
                String recoveryMonth = reader.getCellData(sheetName, "recoveryMonth", rowCount);
                String recoveryYear = reader.getCellData(sheetName, "recoveryYear", rowCount);
                String testsName = reader.getCellData(sheetName, "testsName", rowCount);
                String testTakenDay = reader.getCellData(sheetName, "testTakenDay", rowCount);
                String testTakenMonth = reader.getCellData(sheetName, "testTakenMonth", rowCount);
                String testTakenYear = reader.getCellData(sheetName, "testTakenYear", rowCount);
                String certifiedDetails = reader.getCellData(sheetName, "certifiedDetails", rowCount);

                Object ob[] = {username.trim(), password.trim(), policy.trim(), leadid.trim(), proposersame.trim(), relationwithinsured.trim(), isrelationanswer.trim(),
                        isnri.trim(), pmobile.trim(), ppan.trim(), imobile.trim(), ipan.trim(), firstname.trim(), lastname.trim(),
                        middlename.trim(), day.trim(), month.trim(), year.trim(),
                        gender.trim(), planjourney.trim(), proposerstate.trim(), advisorstatesame.trim(), plan.trim(), sumassured.trim(), smokertype.trim(), planoptions.trim(), increasinglevel.trim(),
                        ecs.trim(), term.trim(), ppt.trim(), premiumterm.trim(), premiumamount.trim(), rider.trim(), rideramount.trim(), minrider.trim(), maxrider.trim(), ridererror.trim(), click.trim(),
                        generateillustrations.trim(), clickcontinue.trim(), ifsccode.trim(), bankaccno.trim(), accholdername.trim(),
                        accounttype.trim(), pennyalert.trim(), clickverify.trim(), renewpremiumscreentitle.trim(), paymentmethod.trim(),
                        drawdate.trim(), fundsource.trim(), nomineescreentitle.trim(), nomineefirstname.trim(), nomineelastname.trim(), nomineeday.trim(),
                        nomineemonth.trim(), nomineeyear.trim(), nomineegender.trim(), relationshipwithproposer.trim(), nomineeshare.trim(), ismwppolicy.trim(), addressscreentitle.trim(),
                        typeofaddress.trim(), addresspincode.trim(), address1.trim(), address2.trim(), address3.trim(), personalDetailsscreentitle.trim(), cityName.trim(),
                        preferredLanguage.trim(), alernateNumber.trim(), resTelephoneNumber.trim(), emailaddressValidations.trim(), maritalStatus.trim(),
                        fathersNameOrSpouseName.trim(), mothersName.trim(), MaidenName.trim(), qualification.trim(), occupation.trim(), employeerName.trim(),
                        nameOfBusinessOrduties.trim(), typeOfOrganization.trim(), designation.trim(), annualIncome.trim(), policyStatus.trim(), exPolicyscreenTitle.trim(), exNameofInsurer.trim(),
                        exSumAssured.trim(), expolicyNumber.trim(), exyearOfApplication.trim(), exbasePlan.trim(), exannualpremium.trim(), medicalPolicy.trim(), expolicystatus.trim(),
                        refPolicyscreenTitle.trim(), refinsurerName.trim(), refsumAssured.trim(), refreason.trim(), refinsurerName1.trim(), refsumAssured1.trim(), refreason1.trim(),
                        refinsurerName2.trim(), refsumAssured2.trim(), refreason2.trim(), refinsurerName3.trim(), refsumAssured3.trim(), refreason3.trim(),
                        refinsurerName4.trim(), refsumAssured4.trim(), refreason4.trim(), policyPurposeScreen.trim(), purposeOption1.trim(), purposeOption2.trim(), purposeOption3.trim(),
                        healthDetailsScreen.trim(), height.trim(), weight.trim(), weightchange.trim(), symptomsDetails.trim(), testsDetails.trim(), covidContactDetails.trim(), quarantineDetails.trim(), healthDetails.trim(),
                        pastTravelContry.trim(), pastTravelCity.trim(), pastTravelArrivalDay.trim(), pastTravelArraivalMonth.trim(), pastTravelArraivalYear.trim(),
                        pastTravelDepartureDay.trim(), pastTravelDepartureMonth.trim(), pastTravelDepartureYear.trim(), futureTravelCountry.trim(), futureTravelCity.trim(),
                        futureTravelDepartureDay.trim(), futureTravelDepartureMonth.trim(), futureTravelDepartureYear.trim(), futureInternedDuration.trim(),
                        covidVaccinationFirstDoseDay.trim(), covidVaccinationFirstDoseMonth.trim(), covidVaccinationFirstDoseYear.trim(), covidVaccinationSecondDoseDay.trim(),
                        covidVaccinationSecondDoseMonth.trim(), covidVaccinationSecondDoseYear.trim(), covidVaccineName.trim(), postVaccineDetails.trim(),
                        covidOccupation.trim(), medicalSpeciality.trim(), exactNatureOfDuties.trim(), nameOfHealthCareFacility.trim(),
                        addressOfHealthCareFacility.trim(), healthAuthorityRegistered.trim(), covidWardDetails.trim(), diagnoseDay.trim(),
                        diagnoseMonth.trim(), diagnoseYear.trim(), daignoseTestName.trim(), receivedCovid19Test1.trim(), receivedCovid19Test2.trim(), receivedCovid19Test3.trim(),
                        admissionDay.trim(), admissionMonth.trim(), admissionYear.trim(), dischargeDay.trim(), dischargeMonth.trim(), dischargeYear.trim(),
                        covidInfectionDetails.trim(), covidSymptoms1.trim(), covidSymptoms2.trim(), covidSymptoms3.trim(), recoveryDay.trim(), recoveryMonth.trim(), recoveryYear.trim(),
                        testsName.trim(), testTakenDay.trim(), testTakenMonth.trim(), testTakenYear.trim(), certifiedDetails.trim()};

                myData.add(ob);
            }
        }
        System.out.println("mydata rows value **********" + myData.toString());
        return myData;
    }

    public static ArrayList<Object[]> getDocumnetsUploadTestData(String testExcelSheet, String testName, String sheetName) {
        ArrayList<Object[]> myData = new ArrayList<Object[]>();
        Xls_Reader reader = null;

        try {
            reader = new Xls_Reader(System.getProperty("user.dir") + testExcelSheet);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("row count ---------" + reader.getRowCount(sheetName));

        for (int rowCount = 3; rowCount <= reader.getRowCount(sheetName); rowCount++) {
            String currentTestMethod = reader.getCellData(sheetName, "testCaseName", rowCount);
            String enableFlag = reader.getCellData(sheetName, "flag", rowCount);
            if (currentTestMethod.trim().equalsIgnoreCase(testName) && enableFlag.equalsIgnoreCase("YES")) {

                String username = reader.getCellData(sheetName, "username", rowCount);
                String password = reader.getCellData(sheetName, "password", rowCount);
                String policy = reader.getCellData(sheetName, "policy", rowCount);
                String leadid = reader.getCellData(sheetName, "leadid", rowCount);
                String proposersame = reader.getCellData(sheetName, "proposersame", rowCount);
                String propinsurednotsame = reader.getCellData(sheetName, "propinsurednotsame", rowCount);
                String isnri = reader.getCellData(sheetName, "isnri", rowCount);
                String pmobile = reader.getCellData(sheetName, "pmobile", rowCount);
                String ppan = reader.getCellData(sheetName, "ppan", rowCount);
                String imobile = reader.getCellData(sheetName, "imobile", rowCount);
                String ipan = reader.getCellData(sheetName, "ipan", rowCount);
                String firstname = reader.getCellData(sheetName, "firstname", rowCount);
                String lastname = reader.getCellData(sheetName, "lastname", rowCount);
                String middlename = reader.getCellData(sheetName, "middlename", rowCount);
                String day = reader.getCellData(sheetName, "day", rowCount);
                String month = reader.getCellData(sheetName, "month", rowCount);
                String year = reader.getCellData(sheetName, "year", rowCount);
                String gender = reader.getCellData(sheetName, "gender", rowCount);
                String planjourney = reader.getCellData(sheetName, "planjourney", rowCount);
                String proposerstate = reader.getCellData(sheetName, "proposerstate", rowCount);
                String advisorstatesame = reader.getCellData(sheetName, "advisorstatesame", rowCount);
                String plan = reader.getCellData(sheetName, "plan", rowCount);
                String sumassured = reader.getCellData(sheetName, "sumassured", rowCount);
                String smokertype = reader.getCellData(sheetName, "smokertype", rowCount);
                String planoptions = reader.getCellData(sheetName, "planoptions", rowCount);
                String increasinglevel = reader.getCellData(sheetName, "increasinglevel", rowCount);
                String ecs = reader.getCellData(sheetName, "ecs", rowCount);
                String term = reader.getCellData(sheetName, "term", rowCount);
                String ppt = reader.getCellData(sheetName, "ppt", rowCount);
                String premiumterm = reader.getCellData(sheetName, "premiumterm", rowCount);
                String premiumamount = reader.getCellData(sheetName, "premiumamount", rowCount);
                String rider = reader.getCellData(sheetName, "rider", rowCount);
                String rideramount = reader.getCellData(sheetName, "rideramount", rowCount);
                String minrider = reader.getCellData(sheetName, "minrider", rowCount);
                String maxrider = reader.getCellData(sheetName, "maxrider", rowCount);
                String ridererror = reader.getCellData(sheetName, "ridererror", rowCount);
                String click = reader.getCellData(sheetName, "click", rowCount);
                String generateillustrations = reader.getCellData(sheetName, "generateillustrations", rowCount);
                String clickcontinue = reader.getCellData(sheetName, "clickcontinue", rowCount);
                String ifsccode = reader.getCellData(sheetName, "ifsccode", rowCount);
                String bankaccno = reader.getCellData(sheetName, "bankaccno", rowCount);
                String accholdername = reader.getCellData(sheetName, "accholdername", rowCount);
                String accounttype = reader.getCellData(sheetName, "accounttype", rowCount);
                String pennyalert = reader.getCellData(sheetName, "pennyalert", rowCount);
                String clickverify = reader.getCellData(sheetName, "clickverify", rowCount);
                String renewpremiumscreentitle = reader.getCellData(sheetName, "renewpremiumscreentitle", rowCount);
                String paymentmethod = reader.getCellData(sheetName, "paymentmethod", rowCount);
                String drawdate = reader.getCellData(sheetName, "drawdate", rowCount);
                String fundsource = reader.getCellData(sheetName, "fundsource", rowCount);
                String nomineescreentitle = reader.getCellData(sheetName, "nomineescreentitle", rowCount);
                String nomineefirstname = reader.getCellData(sheetName, "nomineefirstname", rowCount);
                String nomineelastname = reader.getCellData(sheetName, "nomineelastname", rowCount);
                String nomineeday = reader.getCellData(sheetName, "nomineeday", rowCount);
                String nomineemonth = reader.getCellData(sheetName, "nomineemonth", rowCount);
                String nomineeyear = reader.getCellData(sheetName, "nomineeyear", rowCount);
                String nomineegender = reader.getCellData(sheetName, "nomineegender", rowCount);
                String relationshipwithproposer = reader.getCellData(sheetName, "relationshipwithproposer", rowCount);
                String nomineeshare = reader.getCellData(sheetName, "nomineeshare", rowCount);
                String ismwppolicy = reader.getCellData(sheetName, "ismwppolicy", rowCount);
                String addressscreentitle = reader.getCellData(sheetName, "addressscreentitle", rowCount);
                String typeofaddress = reader.getCellData(sheetName, "typeofaddress", rowCount);
                String addresspincode = reader.getCellData(sheetName, "addresspincode", rowCount);
                String address1 = reader.getCellData(sheetName, "address1", rowCount);
                String address2 = reader.getCellData(sheetName, "address2", rowCount);
                String address3 = reader.getCellData(sheetName, "address3", rowCount);
                String personalDetailsscreentitle = reader.getCellData(sheetName, "personalDetailsscreentitle", rowCount);
                String cityName = reader.getCellData(sheetName, "cityName", rowCount);
                String preferredLanguage = reader.getCellData(sheetName, "preferredLanguage", rowCount);
                String alernateNumber = reader.getCellData(sheetName, "alernateNumber", rowCount);
                String resTelephoneNumber = reader.getCellData(sheetName, "resTelephoneNumber", rowCount);
                String emailaddressValidations = reader.getCellData(sheetName, "emailaddressValidations", rowCount);
                String maritalStatus = reader.getCellData(sheetName, "maritalStatus", rowCount);
                String fathersNameOrSpouseName = reader.getCellData(sheetName, "fathersNameOrSpouseName", rowCount);
                String mothersName = reader.getCellData(sheetName, "mothersName", rowCount);
                String question1 = reader.getCellData(sheetName, "question1", rowCount);
                String answer1 = reader.getCellData(sheetName, "answer1", rowCount);
                String valuetoBeEnter = reader.getCellData(sheetName, "valueToBeEnter", rowCount);
                String question2 = reader.getCellData(sheetName, "question2", rowCount);
                String answer2 = reader.getCellData(sheetName, "answer2", rowCount);
                String valuetoBeEnter2 = reader.getCellData(sheetName, "valueToBeEnter2", rowCount);
                String question3 = reader.getCellData(sheetName, "question3", rowCount);
                String answer3 = reader.getCellData(sheetName, "answer3", rowCount);
                String valuetoBeEnter3 = reader.getCellData(sheetName, "valueToBeEnter3", rowCount);
                String question4 = reader.getCellData(sheetName, "question4", rowCount);
                String answer4 = reader.getCellData(sheetName, "answer4", rowCount);
                String valuetoBeEnter4 = reader.getCellData(sheetName, "valueToBeEnter4", rowCount);
                String qualification = reader.getCellData(sheetName, "qualification", rowCount);
                String occupation = reader.getCellData(sheetName, "occupation", rowCount);
                String employeerName = reader.getCellData(sheetName, "employeerName", rowCount);
                String nameOfBusinessOrduties = reader.getCellData(sheetName, "nameOfBusinessOrduties", rowCount);
                String typeOfOrganization = reader.getCellData(sheetName, "typeOfOrganization", rowCount);
                String designation = reader.getCellData(sheetName, "designation", rowCount);
                String annualIncome = reader.getCellData(sheetName, "annualIncome", rowCount);
                String exPolicyscreenTitle = reader.getCellData(sheetName, "exPolicyscreenTitle", rowCount);
                String exNameofInsurer = reader.getCellData(sheetName, "exNameofInsurer", rowCount);
                String exSumAssured = reader.getCellData(sheetName, "exSumAssured", rowCount);
                String expolicyNumber = reader.getCellData(sheetName, "expolicyNumber", rowCount);
                String exyearOfApplication = reader.getCellData(sheetName, "exyearOfApplication", rowCount);
                String exbasePlan = reader.getCellData(sheetName, "exbasePlan", rowCount);
                String exannualpremium = reader.getCellData(sheetName, "exannualpremium", rowCount);
                String medicalPolicy = reader.getCellData(sheetName, "medicalPolicy", rowCount);
                String refPolicyscreenTitle = reader.getCellData(sheetName, "refPolicyscreenTitle", rowCount);
                String refnsurerName = reader.getCellData(sheetName, "refnsurerName", rowCount);
                String refsumAssured = reader.getCellData(sheetName, "refsumAssured", rowCount);
                String refreason = reader.getCellData(sheetName, "refreason", rowCount);
                String policyPurposeScreen = reader.getCellData(sheetName, "policyPurposeScreen", rowCount);
                String purposeOption1 = reader.getCellData(sheetName, "purposeOption1", rowCount);
                String purposeOption2 = reader.getCellData(sheetName, "purposeOption2", rowCount);
                String purposeOption3 = reader.getCellData(sheetName, "purposeOption3", rowCount);
                String healthDetailsScreen = reader.getCellData(sheetName, "healthDetailsScreen", rowCount);

                Object ob[] = {username.trim(), password.trim(), policy.trim(), leadid.trim(), proposersame.trim(), propinsurednotsame.trim(),
                        isnri.trim(), pmobile.trim(), ppan.trim(), imobile.trim(), ipan.trim(), firstname.trim(), lastname.trim(),
                        middlename.trim(), day.trim(), month.trim(), year.trim(),
                        gender.trim(), planjourney.trim(), proposerstate.trim(), advisorstatesame.trim(), plan.trim(), sumassured.trim(), smokertype.trim(), planoptions.trim(), increasinglevel.trim(),
                        ecs.trim(), term.trim(), ppt.trim(), premiumterm.trim(), premiumamount.trim(), rider.trim(), rideramount.trim(), minrider.trim(), maxrider.trim(), ridererror.trim(), click.trim(),
                        generateillustrations.trim(), clickcontinue.trim(), ifsccode.trim(), bankaccno.trim(), accholdername.trim(),
                        accounttype.trim(), pennyalert.trim(), clickverify.trim(), renewpremiumscreentitle.trim(), paymentmethod.trim(),
                        drawdate.trim(), fundsource.trim(), nomineescreentitle.trim(), nomineefirstname.trim(), nomineelastname.trim(), nomineeday.trim(),
                        nomineemonth.trim(), nomineeyear.trim(), nomineegender.trim(), relationshipwithproposer.trim(), nomineeshare.trim(), ismwppolicy.trim(), addressscreentitle.trim(),
                        typeofaddress.trim(), addresspincode.trim(), address1.trim(), address2.trim(), address3.trim(), personalDetailsscreentitle.trim(), cityName.trim(),
                        preferredLanguage.trim(), alernateNumber.trim(), resTelephoneNumber.trim(), emailaddressValidations.trim(), maritalStatus.trim(),
                        fathersNameOrSpouseName.trim(), mothersName.trim(), question1.trim(), answer1.trim(), valuetoBeEnter.trim(), question2.trim(), answer2.trim(), valuetoBeEnter2.trim(), question3.trim(), answer3.trim(), valuetoBeEnter3.trim(), question4.trim(), answer4.trim(), valuetoBeEnter4.trim(),
                        qualification.trim(), occupation.trim(), employeerName.trim(),
                        nameOfBusinessOrduties.trim(), typeOfOrganization.trim(), designation.trim(), annualIncome.trim(), exPolicyscreenTitle.trim(), exNameofInsurer.trim(),
                        exSumAssured.trim(), expolicyNumber.trim(), exyearOfApplication.trim(), exbasePlan.trim(), exannualpremium.trim(), medicalPolicy.trim(),
                        refPolicyscreenTitle.trim(), refnsurerName.trim(), refsumAssured.trim(), refreason.trim(), policyPurposeScreen.trim(), purposeOption1.trim(), purposeOption2.trim(), purposeOption3.trim(),
                        healthDetailsScreen.trim()};
                myData.add(ob);
            }
        }
        System.out.println("mydata rows value **********" + myData.toString());
        return myData;
    }

    public static ArrayList<Object[]> getInstaVerifyTestData(String testExcelSheet, String testName, String sheetName) {
        ArrayList<Object[]> myData = new ArrayList<Object[]>();
        Xls_Reader reader = null;

        try {
            reader = new Xls_Reader(System.getProperty("user.dir") + testExcelSheet);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("row count ---------" + reader.getRowCount(sheetName));

        for (int rowCount = 3; rowCount <= reader.getRowCount(sheetName); rowCount++) {
            String currentTestMethod = reader.getCellData(sheetName, "testCaseName", rowCount);
            String enableFlag = reader.getCellData(sheetName, "flag", rowCount);
            if (currentTestMethod.trim().equalsIgnoreCase(testName) && enableFlag.equalsIgnoreCase("YES")) {

                String username = reader.getCellData(sheetName, "username", rowCount);
                String password = reader.getCellData(sheetName, "password", rowCount);
                String policy = reader.getCellData(sheetName, "policy", rowCount);
                String leadid = reader.getCellData(sheetName, "leadid", rowCount);
                String proposersame = reader.getCellData(sheetName, "proposersame", rowCount);
                String propinsurednotsame = reader.getCellData(sheetName, "propinsurednotsame", rowCount);
                String isnri = reader.getCellData(sheetName, "isnri", rowCount);
                String pmobile = reader.getCellData(sheetName, "pmobile", rowCount);
                String ppan = reader.getCellData(sheetName, "ppan", rowCount);
                String imobile = reader.getCellData(sheetName, "imobile", rowCount);
                String ipan = reader.getCellData(sheetName, "ipan", rowCount);
                String firstname = reader.getCellData(sheetName, "firstname", rowCount);
                String lastname = reader.getCellData(sheetName, "lastname", rowCount);
                String middlename = reader.getCellData(sheetName, "middlename", rowCount);
                String day = reader.getCellData(sheetName, "day", rowCount);
                String month = reader.getCellData(sheetName, "month", rowCount);
                String year = reader.getCellData(sheetName, "year", rowCount);
                String gender = reader.getCellData(sheetName, "gender", rowCount);
                String planjourney = reader.getCellData(sheetName, "planjourney", rowCount);
                String proposerstate = reader.getCellData(sheetName, "proposerstate", rowCount);
                String advisorstatesame = reader.getCellData(sheetName, "advisorstatesame", rowCount);
                String plan = reader.getCellData(sheetName, "plan", rowCount);
                String sumassured = reader.getCellData(sheetName, "sumassured", rowCount);
                String smokertype = reader.getCellData(sheetName, "smokertype", rowCount);
                String planoptions = reader.getCellData(sheetName, "planoptions", rowCount);
                String increasinglevel = reader.getCellData(sheetName, "increasinglevel", rowCount);
                String ecs = reader.getCellData(sheetName, "ecs", rowCount);
                String term = reader.getCellData(sheetName, "term", rowCount);
                String ppt = reader.getCellData(sheetName, "ppt", rowCount);
                String premiumterm = reader.getCellData(sheetName, "premiumterm", rowCount);
                String premiumamount = reader.getCellData(sheetName, "premiumamount", rowCount);
                String rider = reader.getCellData(sheetName, "rider", rowCount);
                String rideramount = reader.getCellData(sheetName, "rideramount", rowCount);
                String minrider = reader.getCellData(sheetName, "minrider", rowCount);
                String maxrider = reader.getCellData(sheetName, "maxrider", rowCount);
                String ridererror = reader.getCellData(sheetName, "ridererror", rowCount);
                String click = reader.getCellData(sheetName, "click", rowCount);
                String generateillustrations = reader.getCellData(sheetName, "generateillustrations", rowCount);
                String clickcontinue = reader.getCellData(sheetName, "clickcontinue", rowCount);

                Object ob[] = {username.trim(), password.trim(), policy.trim(), leadid.trim(), proposersame.trim(), propinsurednotsame.trim(),
                        isnri.trim(), pmobile.trim(), ppan.trim(), imobile.trim(), ipan.trim(), firstname.trim(), lastname.trim(),
                        middlename.trim(), day.trim(), month.trim(), year.trim(),
                        gender.trim(), planjourney.trim(), proposerstate.trim(), advisorstatesame.trim(), plan.trim(), sumassured.trim(), smokertype.trim(), planoptions.trim(), increasinglevel.trim(),
                        ecs.trim(), term.trim(), ppt.trim(), premiumterm.trim(), premiumamount.trim(), rider.trim(), rideramount.trim(), minrider.trim(), maxrider.trim(), ridererror.trim(), click.trim(),
                        generateillustrations.trim(), clickcontinue.trim(),};
                myData.add(ob);
            }
        }
        System.out.println("mydata rows value **********" + myData.toString());
        return myData;
    }

    public static ArrayList<Object[]> getQualificationDataFromExcel(String testExcelSheet, String testName, String sheetName) {
        ArrayList<Object[]> myData = new ArrayList<Object[]>();
        Xls_Reader reader = null;

        try {
            reader = new Xls_Reader(System.getProperty("user.dir") + testExcelSheet);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("Address sheet row count ---------" + reader.getRowCount(sheetName));

        for (int rowCount = 3; rowCount <= reader.getRowCount(sheetName); rowCount++) {
            String currentTestMethod = reader.getCellData(sheetName, "testCaseName", rowCount);
            String enableFlag = reader.getCellData(sheetName, "flag", rowCount);
            if (currentTestMethod.trim().equalsIgnoreCase(testName) && enableFlag.equalsIgnoreCase("YES")) {

                String username = reader.getCellData(sheetName, "username", rowCount);
                String password = reader.getCellData(sheetName, "password", rowCount);


                String policy = reader.getCellData(sheetName, "policy", rowCount);
                String leadid = reader.getCellData(sheetName, "leadid", rowCount);
                String proposersame = reader.getCellData(sheetName, "proposersame", rowCount);
                String relationwithinsured = reader.getCellData(sheetName, "relationwithinsured", rowCount);
                String isrelationanswer = reader.getCellData(sheetName, "isrelationanswer", rowCount);


                String isnri = reader.getCellData(sheetName, "isnri", rowCount);
                String pmobile = reader.getCellData(sheetName, "pmobile", rowCount);
                String ppan = reader.getCellData(sheetName, "ppan", rowCount);
                String imobile = reader.getCellData(sheetName, "imobile", rowCount);
                String ipan = reader.getCellData(sheetName, "ipan", rowCount);
                String firstname = reader.getCellData(sheetName, "firstname", rowCount);
                String lastname = reader.getCellData(sheetName, "lastname", rowCount);
                String middlename = reader.getCellData(sheetName, "middlename", rowCount);
                String day = reader.getCellData(sheetName, "day", rowCount);
                String month = reader.getCellData(sheetName, "month", rowCount);
                String year = reader.getCellData(sheetName, "year", rowCount);
                String gender = reader.getCellData(sheetName, "gender", rowCount);


                String planjourney = reader.getCellData(sheetName, "planjourney", rowCount);
                String proposerstate = reader.getCellData(sheetName, "proposerstate", rowCount);
                String advisorstatesame = reader.getCellData(sheetName, "advisorstatesame", rowCount);

                String plan = reader.getCellData(sheetName, "plan", rowCount);
                String sumassured = reader.getCellData(sheetName, "sumassured", rowCount);
                String smokertype = reader.getCellData(sheetName, "smokertype", rowCount);
                String planoptions = reader.getCellData(sheetName, "planoptions", rowCount);
                String increasinglevel = reader.getCellData(sheetName, "increasinglevel", rowCount);
                String ecs = reader.getCellData(sheetName, "ecs", rowCount);
                String term = reader.getCellData(sheetName, "term", rowCount);
                String ppt = reader.getCellData(sheetName, "ppt", rowCount);
                String premiumterm = reader.getCellData(sheetName, "premiumterm", rowCount);
                String premiumamount = reader.getCellData(sheetName, "premiumamount", rowCount);

                String rider = reader.getCellData(sheetName, "rider", rowCount);
                String rideramount = reader.getCellData(sheetName, "rideramount", rowCount);
                String minrider = reader.getCellData(sheetName, "minrider", rowCount);
                String maxrider = reader.getCellData(sheetName, "maxrider", rowCount);
                String ridererror = reader.getCellData(sheetName, "ridererror", rowCount);
                String click = reader.getCellData(sheetName, "click", rowCount);

                String generateillustrations = reader.getCellData(sheetName, "generateillustrations", rowCount);
                String clickcontinue = reader.getCellData(sheetName, "clickcontinue", rowCount);


                String ifsccode = reader.getCellData(sheetName, "ifsccode", rowCount);
                String bankaccno = reader.getCellData(sheetName, "bankaccno", rowCount);
                String accholdername = reader.getCellData(sheetName, "accholdername", rowCount);
                String accounttype = reader.getCellData(sheetName, "accounttype", rowCount);

                String pennyalert = reader.getCellData(sheetName, "pennyalert", rowCount);
                String clickverify = reader.getCellData(sheetName, "clickverify", rowCount);
                String renewpremiumscreentitle = reader.getCellData(sheetName, "renewpremiumscreentitle", rowCount);

                String paymentmethod = reader.getCellData(sheetName, "paymentmethod", rowCount);
                String drawdate = reader.getCellData(sheetName, "drawdate", rowCount);
                String fundsource = reader.getCellData(sheetName, "fundsource", rowCount);
                String nomineescreentitle = reader.getCellData(sheetName, "nomineescreentitle", rowCount);

                String nomineefirstname = reader.getCellData(sheetName, "nomineefirstname", rowCount);
                String nomineelastname = reader.getCellData(sheetName, "nomineelastname", rowCount);
                String nomineeday = reader.getCellData(sheetName, "nomineeday", rowCount);
                String nomineemonth = reader.getCellData(sheetName, "nomineemonth", rowCount);
                String nomineeyear = reader.getCellData(sheetName, "nomineeyear", rowCount);
                String nomineegender = reader.getCellData(sheetName, "nomineegender", rowCount);
                String relationshipwithproposer = reader.getCellData(sheetName, "relationshipwithproposer", rowCount);
                String nomineeshare = reader.getCellData(sheetName, "nomineeshare", rowCount);
                String ismwppolicy = reader.getCellData(sheetName, "ismwppolicy", rowCount);
                String addressscreentitle = reader.getCellData(sheetName, "addressscreentitle", rowCount);
                String typeofaddress = reader.getCellData(sheetName, "typeofaddress", rowCount);
                String addresspincode = reader.getCellData(sheetName, "addresspincode", rowCount);
                String address1 = reader.getCellData(sheetName, "address1", rowCount);
                String address2 = reader.getCellData(sheetName, "address2", rowCount);
                String address3 = reader.getCellData(sheetName, "address3", rowCount);
                String personalDetailsscreentitle = reader.getCellData(sheetName, "personalDetailsscreentitle", rowCount);
                String cityName = reader.getCellData(sheetName, "cityName", rowCount);
                String preferredLanguage = reader.getCellData(sheetName, "preferredLanguage", rowCount);
                String alernateNumber = reader.getCellData(sheetName, "alernateNumber", rowCount);
                String resTelephoneNumber = reader.getCellData(sheetName, "resTelephoneNumber", rowCount);
                String PersonalEmailId = reader.getCellData(sheetName, "PersonalEmailId", rowCount);
                String PersonalMaritalStatus = reader.getCellData(sheetName, "PersonalMaritalStatus", rowCount);
                String FatherSpouseName = reader.getCellData(sheetName, "FatherSpouseName", rowCount);
                String MotherName = reader.getCellData(sheetName, "MotherName", rowCount);
                String MaidenName = reader.getCellData(sheetName, "MaidenName", rowCount);
                String Qualification = reader.getCellData(sheetName, "Qualification", rowCount);
                String Others = reader.getCellData(sheetName, "Others", rowCount);

                Object ob[] = {username.trim(), password.trim(), policy.trim(), leadid.trim(), proposersame.trim(), relationwithinsured.trim(), isrelationanswer.trim(),
                        isnri.trim(), pmobile.trim(), ppan.trim(), imobile.trim(), ipan.trim(), firstname.trim(), lastname.trim(),
                        middlename.trim(), day.trim(), month.trim(), year.trim(),
                        gender.trim(), planjourney.trim(), proposerstate.trim(), advisorstatesame.trim(), plan.trim(), sumassured.trim(), smokertype.trim(), planoptions.trim(), increasinglevel.trim(),
                        ecs.trim(), term.trim(), ppt.trim(), premiumterm.trim(), premiumamount.trim(), rider.trim(), rideramount.trim(), minrider.trim(), maxrider.trim(), ridererror.trim(), click.trim(),
                        generateillustrations.trim(), clickcontinue.trim(), ifsccode.trim(), bankaccno.trim(), accholdername.trim(),
                        accounttype.trim(), pennyalert.trim(), clickverify.trim(), renewpremiumscreentitle.trim(), paymentmethod.trim(),
                        drawdate.trim(), fundsource.trim(), nomineescreentitle.trim(), nomineefirstname.trim(), nomineelastname.trim(), nomineeday.trim(),
                        nomineemonth.trim(), nomineeyear.trim(), nomineegender.trim(), relationshipwithproposer.trim(), nomineeshare.trim(), ismwppolicy.trim(), addressscreentitle.trim(),
                        typeofaddress.trim(), addresspincode.trim(), address1.trim(), address2.trim(), address3.trim(), personalDetailsscreentitle.trim(), cityName.trim(), preferredLanguage.trim(), alernateNumber.trim(), resTelephoneNumber.trim(),
                        PersonalEmailId.trim(), PersonalMaritalStatus.trim(), FatherSpouseName.trim(), MotherName.trim(), MaidenName.trim(), Qualification.trim(), Others.trim()};
                myData.add(ob);
            }
        }
        System.out.println("mydata rows value **********" + myData.toString());
        return myData;
    }

    public static ArrayList<Object[]> getOccupationDataFromExcel(String testExcelSheet, String testName, String sheetName) {
        ArrayList<Object[]> myData = new ArrayList<Object[]>();
        Xls_Reader reader = null;

        try {
            reader = new Xls_Reader(System.getProperty("user.dir") + testExcelSheet);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("Address sheet row count ---------" + reader.getRowCount(sheetName));

        for (int rowCount = 3; rowCount <= reader.getRowCount(sheetName); rowCount++) {
            String currentTestMethod = reader.getCellData(sheetName, "testCaseName", rowCount);
            String enableFlag = reader.getCellData(sheetName, "flag", rowCount);
            if (currentTestMethod.trim().equalsIgnoreCase(testName) && enableFlag.equalsIgnoreCase("YES")) {

                String username = reader.getCellData(sheetName, "username", rowCount);
                String password = reader.getCellData(sheetName, "password", rowCount);


                String policy = reader.getCellData(sheetName, "policy", rowCount);
                String leadid = reader.getCellData(sheetName, "leadid", rowCount);
                String proposersame = reader.getCellData(sheetName, "proposersame", rowCount);
                String relationwithinsured = reader.getCellData(sheetName, "relationwithinsured", rowCount);
                String isrelationanswer = reader.getCellData(sheetName, "isrelationanswer", rowCount);


                String isnri = reader.getCellData(sheetName, "isnri", rowCount);
                String pmobile = reader.getCellData(sheetName, "pmobile", rowCount);
                String ppan = reader.getCellData(sheetName, "ppan", rowCount);
                String imobile = reader.getCellData(sheetName, "imobile", rowCount);
                String ipan = reader.getCellData(sheetName, "ipan", rowCount);
                String firstname = reader.getCellData(sheetName, "firstname", rowCount);
                String lastname = reader.getCellData(sheetName, "lastname", rowCount);
                String middlename = reader.getCellData(sheetName, "middlename", rowCount);
                String day = reader.getCellData(sheetName, "day", rowCount);
                String month = reader.getCellData(sheetName, "month", rowCount);
                String year = reader.getCellData(sheetName, "year", rowCount);
                String gender = reader.getCellData(sheetName, "gender", rowCount);


                String planjourney = reader.getCellData(sheetName, "planjourney", rowCount);
                String proposerstate = reader.getCellData(sheetName, "proposerstate", rowCount);
                String advisorstatesame = reader.getCellData(sheetName, "advisorstatesame", rowCount);

                String plan = reader.getCellData(sheetName, "plan", rowCount);
                String sumassured = reader.getCellData(sheetName, "sumassured", rowCount);
                String smokertype = reader.getCellData(sheetName, "smokertype", rowCount);
                String planoptions = reader.getCellData(sheetName, "planoptions", rowCount);
                String increasinglevel = reader.getCellData(sheetName, "increasinglevel", rowCount);
                String ecs = reader.getCellData(sheetName, "ecs", rowCount);
                String term = reader.getCellData(sheetName, "term", rowCount);
                String ppt = reader.getCellData(sheetName, "ppt", rowCount);
                String premiumterm = reader.getCellData(sheetName, "premiumterm", rowCount);
                String premiumamount = reader.getCellData(sheetName, "premiumamount", rowCount);

                String rider = reader.getCellData(sheetName, "rider", rowCount);
                String rideramount = reader.getCellData(sheetName, "rideramount", rowCount);
                String minrider = reader.getCellData(sheetName, "minrider", rowCount);
                String maxrider = reader.getCellData(sheetName, "maxrider", rowCount);
                String ridererror = reader.getCellData(sheetName, "ridererror", rowCount);
                String click = reader.getCellData(sheetName, "click", rowCount);

                String generateillustrations = reader.getCellData(sheetName, "generateillustrations", rowCount);
                String clickcontinue = reader.getCellData(sheetName, "clickcontinue", rowCount);


                String ifsccode = reader.getCellData(sheetName, "ifsccode", rowCount);
                String bankaccno = reader.getCellData(sheetName, "bankaccno", rowCount);
                String accholdername = reader.getCellData(sheetName, "accholdername", rowCount);
                String accounttype = reader.getCellData(sheetName, "accounttype", rowCount);

                String pennyalert = reader.getCellData(sheetName, "pennyalert", rowCount);
                String clickverify = reader.getCellData(sheetName, "clickverify", rowCount);
                String renewpremiumscreentitle = reader.getCellData(sheetName, "renewpremiumscreentitle", rowCount);

                String paymentmethod = reader.getCellData(sheetName, "paymentmethod", rowCount);
                String drawdate = reader.getCellData(sheetName, "drawdate", rowCount);
                String fundsource = reader.getCellData(sheetName, "fundsource", rowCount);
                String nomineescreentitle = reader.getCellData(sheetName, "nomineescreentitle", rowCount);

                String nomineefirstname = reader.getCellData(sheetName, "nomineefirstname", rowCount);
                String nomineelastname = reader.getCellData(sheetName, "nomineelastname", rowCount);
                String nomineeday = reader.getCellData(sheetName, "nomineeday", rowCount);
                String nomineemonth = reader.getCellData(sheetName, "nomineemonth", rowCount);
                String nomineeyear = reader.getCellData(sheetName, "nomineeyear", rowCount);
                String nomineegender = reader.getCellData(sheetName, "nomineegender", rowCount);
                String relationshipwithproposer = reader.getCellData(sheetName, "relationshipwithproposer", rowCount);
                String nomineeshare = reader.getCellData(sheetName, "nomineeshare", rowCount);
                String ismwppolicy = reader.getCellData(sheetName, "ismwppolicy", rowCount);
                String addressscreentitle = reader.getCellData(sheetName, "addressscreentitle", rowCount);
                String typeofaddress = reader.getCellData(sheetName, "typeofaddress", rowCount);
                String addresspincode = reader.getCellData(sheetName, "addresspincode", rowCount);
                String address1 = reader.getCellData(sheetName, "address1", rowCount);
                String address2 = reader.getCellData(sheetName, "address2", rowCount);
                String address3 = reader.getCellData(sheetName, "address3", rowCount);
                String personalDetailsscreentitle = reader.getCellData(sheetName, "personalDetailsscreentitle", rowCount);
                String cityName = reader.getCellData(sheetName, "cityName", rowCount);
                String preferredLanguage = reader.getCellData(sheetName, "preferredLanguage", rowCount);
                String alernateNumber = reader.getCellData(sheetName, "alernateNumber", rowCount);
                String resTelephoneNumber = reader.getCellData(sheetName, "resTelephoneNumber", rowCount);
                String PersonalEmailId = reader.getCellData(sheetName, "PersonalEmailId", rowCount);
                String PersonalMaritalStatus = reader.getCellData(sheetName, "PersonalMaritalStatus", rowCount);
                String FatherSpouseName = reader.getCellData(sheetName, "FatherSpouseName", rowCount);
                String MotherName = reader.getCellData(sheetName, "MotherName", rowCount);
                String MaidenName = reader.getCellData(sheetName, "MaidenName", rowCount);
                String Qualification = reader.getCellData(sheetName, "Qualification", rowCount);
                String Others = reader.getCellData(sheetName, "Others", rowCount);

                String Occupation = reader.getCellData(sheetName, "Occupation", rowCount);
                String typeOfOccupation = reader.getCellData(sheetName, "typeOfOccupation", rowCount);
                String NameofEmployer = reader.getCellData(sheetName, "NameofEmployer", rowCount);
                String Designation = reader.getCellData(sheetName, "Designation", rowCount);
                String AnnualIncome = reader.getCellData(sheetName, "AnnualIncome", rowCount);
                String SpouseAnnualIncome = reader.getCellData(sheetName, "SpouseAnnualIncome", rowCount);
                String ParentInsuranceCover = reader.getCellData(sheetName, "ParentInsuranceCover", rowCount);

                String ParentAnnualIncome = reader.getCellData(sheetName, "ParentAnnualIncome", rowCount);
                String SpouseInsuranceCover = reader.getCellData(sheetName, "SpouseInsuranceCover", rowCount);


                Object ob[] = {username.trim(), password.trim(), policy.trim(), leadid.trim(), proposersame.trim(), relationwithinsured.trim(), isrelationanswer.trim(),
                        isnri.trim(), pmobile.trim(), ppan.trim(), imobile.trim(), ipan.trim(), firstname.trim(), lastname.trim(),
                        middlename.trim(), day.trim(), month.trim(), year.trim(),
                        gender.trim(), planjourney.trim(), proposerstate.trim(), advisorstatesame.trim(), plan.trim(), sumassured.trim(), smokertype.trim(), planoptions.trim(), increasinglevel.trim(),
                        ecs.trim(), term.trim(), ppt.trim(), premiumterm.trim(), premiumamount.trim(), rider.trim(), rideramount.trim(), minrider.trim(), maxrider.trim(), ridererror.trim(), click.trim(),
                        generateillustrations.trim(), clickcontinue.trim(), ifsccode.trim(), bankaccno.trim(), accholdername.trim(),
                        accounttype.trim(), pennyalert.trim(), clickverify.trim(), renewpremiumscreentitle.trim(), paymentmethod.trim(),
                        drawdate.trim(), fundsource.trim(), nomineescreentitle.trim(), nomineefirstname.trim(), nomineelastname.trim(), nomineeday.trim(),
                        nomineemonth.trim(), nomineeyear.trim(), nomineegender.trim(), relationshipwithproposer.trim(), nomineeshare.trim(), ismwppolicy.trim(), addressscreentitle.trim(),
                        typeofaddress.trim(), addresspincode.trim(), address1.trim(), address2.trim(), address3.trim(), personalDetailsscreentitle.trim(), cityName.trim(), preferredLanguage.trim(), alernateNumber.trim(), resTelephoneNumber.trim(),

                        PersonalEmailId.trim(), PersonalMaritalStatus.trim(), FatherSpouseName.trim(), MotherName.trim(), MaidenName.trim(), Qualification.trim(), Others.trim(), Occupation.trim(), typeOfOccupation.trim(),
                        NameofEmployer.trim(), Designation.trim(), AnnualIncome.trim(), SpouseAnnualIncome.trim(), ParentInsuranceCover.trim(), ParentAnnualIncome.trim(), SpouseInsuranceCover.trim()};

                myData.add(ob);
            }
        }
        System.out.println("mydata rows value **********" + myData.toString());
        return myData;
    }

    public static ArrayList<Object[]> getLifestyleDataFromExcel(String testExcelSheet, String testName, String sheetName) {
        ArrayList<Object[]> myData = new ArrayList<Object[]>();
        Xls_Reader reader = null;

        try {
            reader = new Xls_Reader(System.getProperty("user.dir") + testExcelSheet);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("Address sheet row count ---------" + reader.getRowCount(sheetName));

        for (int rowCount = 3; rowCount <= reader.getRowCount(sheetName); rowCount++) {
            String currentTestMethod = reader.getCellData(sheetName, "testCaseName", rowCount);
            String enableFlag = reader.getCellData(sheetName, "flag", rowCount);
            if (currentTestMethod.trim().equalsIgnoreCase(testName) && enableFlag.equalsIgnoreCase("YES")) {

                String username = reader.getCellData(sheetName, "username", rowCount);
                String password = reader.getCellData(sheetName, "password", rowCount);


                String policy = reader.getCellData(sheetName, "policy", rowCount);
                String leadid = reader.getCellData(sheetName, "leadid", rowCount);
                String proposersame = reader.getCellData(sheetName, "proposersame", rowCount);
                String relationwithinsured = reader.getCellData(sheetName, "relationwithinsured", rowCount);
                String isrelationanswer = reader.getCellData(sheetName, "isrelationanswer", rowCount);


                String isnri = reader.getCellData(sheetName, "isnri", rowCount);
                String pmobile = reader.getCellData(sheetName, "pmobile", rowCount);
                String ppan = reader.getCellData(sheetName, "ppan", rowCount);
                String imobile = reader.getCellData(sheetName, "imobile", rowCount);
                String ipan = reader.getCellData(sheetName, "ipan", rowCount);
                String firstname = reader.getCellData(sheetName, "firstname", rowCount);
                String lastname = reader.getCellData(sheetName, "lastname", rowCount);
                String middlename = reader.getCellData(sheetName, "middlename", rowCount);
                String day = reader.getCellData(sheetName, "day", rowCount);
                String month = reader.getCellData(sheetName, "month", rowCount);
                String year = reader.getCellData(sheetName, "year", rowCount);
                String gender = reader.getCellData(sheetName, "gender", rowCount);


                String planjourney = reader.getCellData(sheetName, "planjourney", rowCount);
                String proposerstate = reader.getCellData(sheetName, "proposerstate", rowCount);
                String advisorstatesame = reader.getCellData(sheetName, "advisorstatesame", rowCount);

                String plan = reader.getCellData(sheetName, "plan", rowCount);
                String sumassured = reader.getCellData(sheetName, "sumassured", rowCount);
                String smokertype = reader.getCellData(sheetName, "smokertype", rowCount);
                String planoptions = reader.getCellData(sheetName, "planoptions", rowCount);
                String increasinglevel = reader.getCellData(sheetName, "increasinglevel", rowCount);
                String ecs = reader.getCellData(sheetName, "ecs", rowCount);
                String term = reader.getCellData(sheetName, "term", rowCount);
                String ppt = reader.getCellData(sheetName, "ppt", rowCount);
                String premiumterm = reader.getCellData(sheetName, "premiumterm", rowCount);
                String premiumamount = reader.getCellData(sheetName, "premiumamount", rowCount);

                String rider = reader.getCellData(sheetName, "rider", rowCount);
                String rideramount = reader.getCellData(sheetName, "rideramount", rowCount);
                String minrider = reader.getCellData(sheetName, "minrider", rowCount);
                String maxrider = reader.getCellData(sheetName, "maxrider", rowCount);
                String ridererror = reader.getCellData(sheetName, "ridererror", rowCount);
                String click = reader.getCellData(sheetName, "click", rowCount);

                String generateillustrations = reader.getCellData(sheetName, "generateillustrations", rowCount);
                String clickcontinue = reader.getCellData(sheetName, "clickcontinue", rowCount);


                String ifsccode = reader.getCellData(sheetName, "ifsccode", rowCount);
                String bankaccno = reader.getCellData(sheetName, "bankaccno", rowCount);
                String accholdername = reader.getCellData(sheetName, "accholdername", rowCount);
                String accounttype = reader.getCellData(sheetName, "accounttype", rowCount);

                String pennyalert = reader.getCellData(sheetName, "pennyalert", rowCount);
                String clickverify = reader.getCellData(sheetName, "clickverify", rowCount);
                String renewpremiumscreentitle = reader.getCellData(sheetName, "renewpremiumscreentitle", rowCount);

                String paymentmethod = reader.getCellData(sheetName, "paymentmethod", rowCount);
                String drawdate = reader.getCellData(sheetName, "drawdate", rowCount);
                String fundsource = reader.getCellData(sheetName, "fundsource", rowCount);
                String nomineescreentitle = reader.getCellData(sheetName, "nomineescreentitle", rowCount);

                String nomineefirstname = reader.getCellData(sheetName, "nomineefirstname", rowCount);
                String nomineelastname = reader.getCellData(sheetName, "nomineelastname", rowCount);
                String nomineeday = reader.getCellData(sheetName, "nomineeday", rowCount);
                String nomineemonth = reader.getCellData(sheetName, "nomineemonth", rowCount);
                String nomineeyear = reader.getCellData(sheetName, "nomineeyear", rowCount);
                String nomineegender = reader.getCellData(sheetName, "nomineegender", rowCount);
                String relationshipwithproposer = reader.getCellData(sheetName, "relationshipwithproposer", rowCount);
                String nomineeshare = reader.getCellData(sheetName, "nomineeshare", rowCount);
                String ismwppolicy = reader.getCellData(sheetName, "ismwppolicy", rowCount);
                String addressscreentitle = reader.getCellData(sheetName, "addressscreentitle", rowCount);
                String typeofaddress = reader.getCellData(sheetName, "typeofaddress", rowCount);
                String addresspincode = reader.getCellData(sheetName, "addresspincode", rowCount);
                String address1 = reader.getCellData(sheetName, "address1", rowCount);
                String address2 = reader.getCellData(sheetName, "address2", rowCount);
                String address3 = reader.getCellData(sheetName, "address3", rowCount);
                String personalDetailsscreentitle = reader.getCellData(sheetName, "personalDetailsscreentitle", rowCount);
                String cityName = reader.getCellData(sheetName, "cityName", rowCount);
                String preferredLanguage = reader.getCellData(sheetName, "preferredLanguage", rowCount);
                String alernateNumber = reader.getCellData(sheetName, "alernateNumber", rowCount);
                String resTelephoneNumber = reader.getCellData(sheetName, "resTelephoneNumber", rowCount);
                String PersonalEmailId = reader.getCellData(sheetName, "PersonalEmailId", rowCount);
                String PersonalMaritalStatus = reader.getCellData(sheetName, "PersonalMaritalStatus", rowCount);
                String FatherSpouseName = reader.getCellData(sheetName, "FatherSpouseName", rowCount);
                String MotherName = reader.getCellData(sheetName, "MotherName", rowCount);
                String MaidenName = reader.getCellData(sheetName, "MaidenName", rowCount);
                String Qualification = reader.getCellData(sheetName, "Qualification", rowCount);
                String Others = reader.getCellData(sheetName, "Others", rowCount);

                String Occupation = reader.getCellData(sheetName, "Occupation", rowCount);
                String typeOfOccupation = reader.getCellData(sheetName, "typeOfOccupation", rowCount);
                String NameofEmployer = reader.getCellData(sheetName, "NameofEmployer", rowCount);
                String Designation = reader.getCellData(sheetName, "Designation", rowCount);
                String AnnualIncome = reader.getCellData(sheetName, "AnnualIncome", rowCount);
                String SpouseAnnualIncome = reader.getCellData(sheetName, "SpouseAnnualIncome", rowCount);
                String ParentInsuranceCover = reader.getCellData(sheetName, "ParentInsuranceCover", rowCount);

                String ParentAnnualIncome = reader.getCellData(sheetName, "ParentAnnualIncome", rowCount);
                String SpouseInsuranceCover = reader.getCellData(sheetName, "SpouseInsuranceCover", rowCount);

                String NarcoticsDetails = reader.getCellData(sheetName, "NarcoticsDetails", rowCount);
                String AlcoholQuantity = reader.getCellData(sheetName, "AlcoholQuantity", rowCount);
                String Frequency = reader.getCellData(sheetName, "Frequency", rowCount);
                String NicotineDuration = reader.getCellData(sheetName, "NicotineDuration", rowCount);
                String TobaccoQuantityConsumed = reader.getCellData(sheetName, "TobaccoQuantityConsumed", rowCount);
                String TobaccoYrsConsumed = reader.getCellData(sheetName, "TobaccoYrsConsumed", rowCount);
                String HazardousActivitiesOption = reader.getCellData(sheetName, "HazardousActivitiesOption", rowCount);
                String HazardousActivitiesYrs = reader.getCellData(sheetName, "HazardousActivitiesYrs", rowCount);
                String HazardousActivitiesType = reader.getCellData(sheetName, "HazardousActivitiesType", rowCount);

                Object ob[] = {username.trim(), password.trim(), policy.trim(), leadid.trim(), proposersame.trim(), relationwithinsured.trim(), isrelationanswer.trim(),
                        isnri.trim(), pmobile.trim(), ppan.trim(), imobile.trim(), ipan.trim(), firstname.trim(), lastname.trim(),
                        middlename.trim(), day.trim(), month.trim(), year.trim(),
                        gender.trim(), planjourney.trim(), proposerstate.trim(), advisorstatesame.trim(), plan.trim(), sumassured.trim(), smokertype.trim(), planoptions.trim(), increasinglevel.trim(),
                        ecs.trim(), term.trim(), ppt.trim(), premiumterm.trim(), premiumamount.trim(), rider.trim(), rideramount.trim(), minrider.trim(), maxrider.trim(), ridererror.trim(), click.trim(),
                        generateillustrations.trim(), clickcontinue.trim(), ifsccode.trim(), bankaccno.trim(), accholdername.trim(),
                        accounttype.trim(), pennyalert.trim(), clickverify.trim(), renewpremiumscreentitle.trim(), paymentmethod.trim(),
                        drawdate.trim(), fundsource.trim(), nomineescreentitle.trim(), nomineefirstname.trim(), nomineelastname.trim(), nomineeday.trim(),
                        nomineemonth.trim(), nomineeyear.trim(), nomineegender.trim(), relationshipwithproposer.trim(), nomineeshare.trim(), ismwppolicy.trim(), addressscreentitle.trim(),
                        typeofaddress.trim(), addresspincode.trim(), address1.trim(), address2.trim(), address3.trim(), personalDetailsscreentitle.trim(), cityName.trim(), preferredLanguage.trim(), alernateNumber.trim(), resTelephoneNumber.trim(),
                        PersonalEmailId.trim(), PersonalMaritalStatus.trim(), FatherSpouseName.trim(), MotherName.trim(), MaidenName.trim(), Qualification.trim(), Others.trim(), Occupation.trim(), typeOfOccupation.trim(),
                        NameofEmployer.trim(), Designation.trim(), AnnualIncome.trim(), SpouseAnnualIncome.trim(), ParentInsuranceCover.trim(), ParentAnnualIncome.trim(), SpouseInsuranceCover.trim(),
                        NarcoticsDetails.trim(), AlcoholQuantity.trim(), Frequency.trim(), NicotineDuration.trim(), TobaccoQuantityConsumed.trim(), TobaccoYrsConsumed.trim(), HazardousActivitiesOption.trim(), HazardousActivitiesYrs.trim(), HazardousActivitiesType.trim()};
                myData.add(ob);
            }
        }
        System.out.println("mydata rows value **********" + myData.toString());
        return myData;
    }

    public static ArrayList<Object[]> getChequeDataFromExcel(String testExcelSheet, String testName, String sheetName) {
        ArrayList<Object[]> myData = new ArrayList<Object[]>();
        Xls_Reader reader = null;

        try {
            reader = new Xls_Reader(System.getProperty("user.dir") + testExcelSheet);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("Address sheet row count ---------" + reader.getRowCount(sheetName));

        for (int rowCount = 3; rowCount <= reader.getRowCount(sheetName); rowCount++) {
            String currentTestMethod = reader.getCellData(sheetName, "testCaseName", rowCount);
            String enableFlag = reader.getCellData(sheetName, "flag", rowCount);
            if (currentTestMethod.trim().equalsIgnoreCase(testName) && enableFlag.equalsIgnoreCase("YES")) {

                String username = reader.getCellData(sheetName, "username", rowCount);
                String password = reader.getCellData(sheetName, "password", rowCount);


                String policy = reader.getCellData(sheetName, "policy", rowCount);
                String leadid = reader.getCellData(sheetName, "leadid", rowCount);
                String proposersame = reader.getCellData(sheetName, "proposersame", rowCount);
                String relationwithinsured = reader.getCellData(sheetName, "relationwithinsured", rowCount);
                String isrelationanswer = reader.getCellData(sheetName, "isrelationanswer", rowCount);

                String isnri = reader.getCellData(sheetName, "isnri", rowCount);
                String pmobile = reader.getCellData(sheetName, "pmobile", rowCount);
                String ppan = reader.getCellData(sheetName, "ppan", rowCount);
                String imobile = reader.getCellData(sheetName, "imobile", rowCount);
                String ipan = reader.getCellData(sheetName, "ipan", rowCount);
                String firstname = reader.getCellData(sheetName, "firstname", rowCount);
                String lastname = reader.getCellData(sheetName, "lastname", rowCount);
                String middlename = reader.getCellData(sheetName, "middlename", rowCount);
                String day = reader.getCellData(sheetName, "day", rowCount);
                String month = reader.getCellData(sheetName, "month", rowCount);
                String year = reader.getCellData(sheetName, "year", rowCount);
                String gender = reader.getCellData(sheetName, "gender", rowCount);


                String planjourney = reader.getCellData(sheetName, "planjourney", rowCount);
                String proposerstate = reader.getCellData(sheetName, "proposerstate", rowCount);
                String advisorstatesame = reader.getCellData(sheetName, "advisorstatesame", rowCount);

                String plan = reader.getCellData(sheetName, "plan", rowCount);
                String sumassured = reader.getCellData(sheetName, "sumassured", rowCount);
                String smokertype = reader.getCellData(sheetName, "smokertype", rowCount);
                String planoptions = reader.getCellData(sheetName, "planoptions", rowCount);
                String increasinglevel = reader.getCellData(sheetName, "increasinglevel", rowCount);
                String ecs = reader.getCellData(sheetName, "ecs", rowCount);
                String term = reader.getCellData(sheetName, "term", rowCount);
                String ppt = reader.getCellData(sheetName, "ppt", rowCount);
                String premiumterm = reader.getCellData(sheetName, "premiumterm", rowCount);
                String premiumamount = reader.getCellData(sheetName, "premiumamount", rowCount);

                String rider = reader.getCellData(sheetName, "rider", rowCount);
                String rideramount = reader.getCellData(sheetName, "rideramount", rowCount);
                String minrider = reader.getCellData(sheetName, "minrider", rowCount);
                String maxrider = reader.getCellData(sheetName, "maxrider", rowCount);
                String ridererror = reader.getCellData(sheetName, "ridererror", rowCount);
                String click = reader.getCellData(sheetName, "click", rowCount);

                String generateillustrations = reader.getCellData(sheetName, "generateillustrations", rowCount);
                String clickcontinue = reader.getCellData(sheetName, "clickcontinue", rowCount);


                String ifsccode = reader.getCellData(sheetName, "ifsccode", rowCount);
                String bankaccno = reader.getCellData(sheetName, "bankaccno", rowCount);
                String accholdername = reader.getCellData(sheetName, "accholdername", rowCount);
                String accounttype = reader.getCellData(sheetName, "accounttype", rowCount);

                String pennyalert = reader.getCellData(sheetName, "pennyalert", rowCount);
                String clickverify = reader.getCellData(sheetName, "clickverify", rowCount);

                String renewpremiumscreentitle = reader.getCellData(sheetName, "renewpremiumscreentitle", rowCount);

                String paymentmethod = reader.getCellData(sheetName, "paymentmethod", rowCount);
                String drawdate = reader.getCellData(sheetName, "drawdate", rowCount);
                String fundsource = reader.getCellData(sheetName, "fundsource", rowCount);
                String nomineescreentitle = reader.getCellData(sheetName, "nomineescreentitle", rowCount);

                String nomineefirstname = reader.getCellData(sheetName, "nomineefirstname", rowCount);
                String nomineelastname = reader.getCellData(sheetName, "nomineelastname", rowCount);
                String nomineeday = reader.getCellData(sheetName, "nomineeday", rowCount);
                String nomineemonth = reader.getCellData(sheetName, "nomineemonth", rowCount);
                String nomineeyear = reader.getCellData(sheetName, "nomineeyear", rowCount);
                String nomineegender = reader.getCellData(sheetName, "nomineegender", rowCount);
                String relationshipwithproposer = reader.getCellData(sheetName, "relationshipwithproposer", rowCount);
                String nomineeshare = reader.getCellData(sheetName, "nomineeshare", rowCount);
                String ismwppolicy = reader.getCellData(sheetName, "ismwppolicy", rowCount);
                String addressscreentitle = reader.getCellData(sheetName, "addressscreentitle", rowCount);

                String typeofaddress = reader.getCellData(sheetName, "typeofaddress", rowCount);
                String addresspincode = reader.getCellData(sheetName, "addresspincode", rowCount);
                String address1 = reader.getCellData(sheetName, "address1", rowCount);
                String address2 = reader.getCellData(sheetName, "address2", rowCount);
                String address3 = reader.getCellData(sheetName, "address3", rowCount);
                String personalDetailsscreentitle = reader.getCellData(sheetName, "personalDetailsscreentitle", rowCount);
                String cityName = reader.getCellData(sheetName, "cityName", rowCount);
                String preferredLanguage = reader.getCellData(sheetName, "preferredLanguage", rowCount);
                String alernateNumber = reader.getCellData(sheetName, "alernateNumber", rowCount);
                String resTelephoneNumber = reader.getCellData(sheetName, "resTelephoneNumber", rowCount);
                String emailaddressValidations = reader.getCellData(sheetName, "emailaddressValidations", rowCount);
                String maritalStatus = reader.getCellData(sheetName, "maritalStatus", rowCount);
                String fathersNameOrSpouseName = reader.getCellData(sheetName, "fathersNameOrSpouseName", rowCount);
                String mothersName = reader.getCellData(sheetName, "mothersName", rowCount);
                String MaidenName = reader.getCellData(sheetName, "MaidenName", rowCount);


                String question1 = reader.getCellData(sheetName, "question1", rowCount);
                String answer1 = reader.getCellData(sheetName, "answer1", rowCount);
                String valuetoBeEnter = reader.getCellData(sheetName, "valueToBeEnter", rowCount);
                String question2 = reader.getCellData(sheetName, "question2", rowCount);
                String answer2 = reader.getCellData(sheetName, "answer2", rowCount);
                String valuetoBeEnter2 = reader.getCellData(sheetName, "valueToBeEnter2", rowCount);
                String question3 = reader.getCellData(sheetName, "question3", rowCount);
                String answer3 = reader.getCellData(sheetName, "answer3", rowCount);
                String valuetoBeEnter3 = reader.getCellData(sheetName, "valueToBeEnter3", rowCount);
                String question4 = reader.getCellData(sheetName, "question4", rowCount);
                String answer4 = reader.getCellData(sheetName, "answer4", rowCount);
                String valuetoBeEnter4 = reader.getCellData(sheetName, "valueToBeEnter4", rowCount);
                String qualification = reader.getCellData(sheetName, "qualification", rowCount);
                String occupation = reader.getCellData(sheetName, "occupation", rowCount);
                String employeerName = reader.getCellData(sheetName, "employeerName", rowCount);
                String nameOfBusinessOrduties = reader.getCellData(sheetName, "nameOfBusinessOrduties", rowCount);
                String typeOfOrganization = reader.getCellData(sheetName, "typeOfOrganization", rowCount);
                String designation = reader.getCellData(sheetName, "designation", rowCount);
                String annualIncome = reader.getCellData(sheetName, "annualIncome", rowCount);
                String policyStatus = reader.getCellData(sheetName, "expolicystatus", rowCount);
                String exPolicyscreenTitle = reader.getCellData(sheetName, "exPolicyscreenTitle", rowCount);
                String exNameofInsurer = reader.getCellData(sheetName, "exNameofInsurer", rowCount);
                String exSumAssured = reader.getCellData(sheetName, "exSumAssured", rowCount);
                String expolicyNumber = reader.getCellData(sheetName, "expolicyNumber", rowCount);
                String exyearOfApplication = reader.getCellData(sheetName, "exyearOfApplication", rowCount);
                String exbasePlan = reader.getCellData(sheetName, "exbasePlan", rowCount);
                String exannualpremium = reader.getCellData(sheetName, "exannualpremium", rowCount);
                String medicalPolicy = reader.getCellData(sheetName, "medicalPolicy", rowCount);
                String expolicystatus = reader.getCellData(sheetName, "expolicystatus", rowCount);
                String refPolicyscreenTitle = reader.getCellData(sheetName, "refPolicyscreenTitle", rowCount);

                String refinsurerName = reader.getCellData(sheetName, "refnsurerName", rowCount);
                String refsumAssured = reader.getCellData(sheetName, "refsumAssured", rowCount);
                String refreason = reader.getCellData(sheetName, "refreason", rowCount);

                String refinsurerName1 = reader.getCellData(sheetName, "refnsurerName1", rowCount);
                String refsumAssured1 = reader.getCellData(sheetName, "refsumAssured1", rowCount);
                String refreason1 = reader.getCellData(sheetName, "refreason1", rowCount);

                String refinsurerName2 = reader.getCellData(sheetName, "refnsurerName2", rowCount);
                String refsumAssured2 = reader.getCellData(sheetName, "refsumAssured2", rowCount);
                String refreason2 = reader.getCellData(sheetName, "refreason2", rowCount);

                String refinsurerName3 = reader.getCellData(sheetName, "refnsurerName3", rowCount);
                String refsumAssured3 = reader.getCellData(sheetName, "refsumAssured3", rowCount);
                String refreason3 = reader.getCellData(sheetName, "refreason3", rowCount);

                String refinsurerName4 = reader.getCellData(sheetName, "refnsurerName4", rowCount);
                String refsumAssured4 = reader.getCellData(sheetName, "refsumAssured4", rowCount);
                String refreason4 = reader.getCellData(sheetName, "refreason4", rowCount);


                String policyPurposeScreen = reader.getCellData(sheetName, "policyPurposeScreen", rowCount);
                String purposeOption1 = reader.getCellData(sheetName, "purposeOption1", rowCount);
                String purposeOption2 = reader.getCellData(sheetName, "purposeOption2", rowCount);
                String purposeOption3 = reader.getCellData(sheetName, "purposeOption3", rowCount);

                String healthDetailsScreen = reader.getCellData(sheetName, "healthDetailsScreen", rowCount);

                String height = reader.getCellData(sheetName, "height", rowCount);
                String weight = reader.getCellData(sheetName, "weight", rowCount);
                String weightchange = reader.getCellData(sheetName, "weightchange", rowCount);

                String symptomsDetails = reader.getCellData(sheetName, "symptomsDetails", rowCount);
                String testsDetails = reader.getCellData(sheetName, "testsDetails", rowCount);
                String covidContactDetails = reader.getCellData(sheetName, "covidContactDetails", rowCount);
                String quarantineDetails = reader.getCellData(sheetName, "quarantineDetails", rowCount);
                String healthDetails = reader.getCellData(sheetName, "healthDetails", rowCount);
                String pastTravelContry = reader.getCellData(sheetName, "pastTravelContry", rowCount);
                String pastTravelCity = reader.getCellData(sheetName, "pastTravelCity", rowCount);
                String pastTravelArrivalDay = reader.getCellData(sheetName, "pastTravelArrivalDay", rowCount);
                String pastTravelArraivalMonth = reader.getCellData(sheetName, "pastTravelArraivalMonth", rowCount);
                String pastTravelArraivalYear = reader.getCellData(sheetName, "pastTravelArraivalYear", rowCount);
                String pastTravelDepartureDay = reader.getCellData(sheetName, "pastTravelDepartureDay", rowCount);
                String pastTravelDepartureMonth = reader.getCellData(sheetName, "pastTravelDepartureMonth", rowCount);
                String pastTravelDepartureYear = reader.getCellData(sheetName, "pastTravelDepartureYear", rowCount);
                String futureTravelCountry = reader.getCellData(sheetName, "futureTravelCountry", rowCount);
                String futureTravelCity = reader.getCellData(sheetName, "futureTravelCity", rowCount);
                String futureTravelDepartureDay = reader.getCellData(sheetName, "futureTravelDepartureDay", rowCount);
                String futureTravelDepartureMonth = reader.getCellData(sheetName, "futureTravelDepartureMonth", rowCount);
                String futureTravelDepartureYear = reader.getCellData(sheetName, "futureTravelDepartureYear", rowCount);
                String futureInternedDuration = reader.getCellData(sheetName, "futureInternedDuration", rowCount);
                String covidVaccinationFirstDoseDay = reader.getCellData(sheetName, "covidVaccinationFirstDoseDay", rowCount);
                String covidVaccinationFirstDoseMonth = reader.getCellData(sheetName, "covidVaccinationFirstDoseMonth", rowCount);
                String covidVaccinationFirstDoseYear = reader.getCellData(sheetName, "covidVaccinationFirstDoseYear", rowCount);
                String covidVaccinationSecondDoseDay = reader.getCellData(sheetName, "covidVaccinationSecondDoseDay", rowCount);
                String covidVaccinationSecondDoseMonth = reader.getCellData(sheetName, "covidVaccinationSecondDoseMonth", rowCount);
                String covidVaccinationSecondDoseYear = reader.getCellData(sheetName, "covidVaccinationSecondDoseYear", rowCount);
                String covidVaccineName = reader.getCellData(sheetName, "covidVaccineName", rowCount);
                String postVaccineDetails = reader.getCellData(sheetName, "postVaccineDetails", rowCount);
                String covidOccupation = reader.getCellData(sheetName, "covidOccupation", rowCount);
                String medicalSpeciality = reader.getCellData(sheetName, "medicalSpeciality", rowCount);
                String exactNatureOfDuties = reader.getCellData(sheetName, "exactNatureOfDuties", rowCount);
                String nameOfHealthCareFacility = reader.getCellData(sheetName, "nameOfHealthCareFacility", rowCount);
                String addressOfHealthCareFacility = reader.getCellData(sheetName, "addressOfHealthCareFacility", rowCount);
                String healthAuthorityRegistered = reader.getCellData(sheetName, "healthAuthorityRegistered", rowCount);
                String covidWardDetails = reader.getCellData(sheetName, "covidWardDetails", rowCount);
                String diagnoseDay = reader.getCellData(sheetName, "diagnoseDay", rowCount);
                String diagnoseMonth = reader.getCellData(sheetName, "diagnoseMonth", rowCount);
                String diagnoseYear = reader.getCellData(sheetName, "diagnoseYear", rowCount);
                String daignoseTestName = reader.getCellData(sheetName, "daignoseTestName", rowCount);
                String receivedCovid19Test1 = reader.getCellData(sheetName, "receivedCovid19Test1", rowCount);
                String receivedCovid19Test2 = reader.getCellData(sheetName, "receivedCovid19Test2", rowCount);
                String receivedCovid19Test3 = reader.getCellData(sheetName, "receivedCovid19Test3", rowCount);
                String admissionDay = reader.getCellData(sheetName, "admissionDay", rowCount);
                String admissionMonth = reader.getCellData(sheetName, "admissionMonth", rowCount);
                String admissionYear = reader.getCellData(sheetName, "admissionYear", rowCount);
                String dischargeDay = reader.getCellData(sheetName, "dischargeDay", rowCount);
                String dischargeMonth = reader.getCellData(sheetName, "dischargeMonth", rowCount);
                String dischargeYear = reader.getCellData(sheetName, "dischargeYear", rowCount);
                String covidInfectionDetails = reader.getCellData(sheetName, "covidInfectionDetails", rowCount);
                String covidSymptoms1 = reader.getCellData(sheetName, "covidSymptoms1", rowCount);
                String covidSymptoms2 = reader.getCellData(sheetName, "covidSymptoms2", rowCount);
                String covidSymptoms3 = reader.getCellData(sheetName, "covidSymptoms3", rowCount);
                String recoveryDay = reader.getCellData(sheetName, "recoveryDay", rowCount);
                String recoveryMonth = reader.getCellData(sheetName, "recoveryMonth", rowCount);
                String recoveryYear = reader.getCellData(sheetName, "recoveryYear", rowCount);
                String testsName = reader.getCellData(sheetName, "testsName", rowCount);
                String testTakenDay = reader.getCellData(sheetName, "testTakenDay", rowCount);
                String testTakenMonth = reader.getCellData(sheetName, "testTakenMonth", rowCount);
                String testTakenYear = reader.getCellData(sheetName, "testTakenYear", rowCount);
                String certifiedDetails = reader.getCellData(sheetName, "certifiedDetails", rowCount);
                String ChequeNumber = reader.getCellData(sheetName, "ChequeNumber", rowCount);
                String PaymentModeDate = reader.getCellData(sheetName, "PaymentModeDate", rowCount);
                String PaymentModeMonth = reader.getCellData(sheetName, "PaymentModeMonth", rowCount);
                String PaymentModeYear = reader.getCellData(sheetName, "PaymentModeYear", rowCount);
                String IFSCCode = reader.getCellData(sheetName, "IFSCCode", rowCount);
                String MICRCODE = reader.getCellData(sheetName, "MICRCODE", rowCount);
                String DDNumber = reader.getCellData(sheetName, "DDNumber", rowCount);

                Object ob[] = {username.trim(), password.trim(), policy.trim(), leadid.trim(), proposersame.trim(), relationwithinsured.trim(), isrelationanswer.trim(),
                        isnri.trim(), pmobile.trim(), ppan.trim(), imobile.trim(), ipan.trim(), firstname.trim(), lastname.trim(),
                        middlename.trim(), day.trim(), month.trim(), year.trim(),
                        gender.trim(), planjourney.trim(), proposerstate.trim(), advisorstatesame.trim(), plan.trim(), sumassured.trim(), smokertype.trim(), planoptions.trim(), increasinglevel.trim(),
                        ecs.trim(), term.trim(), ppt.trim(), premiumterm.trim(), premiumamount.trim(), rider.trim(), rideramount.trim(), minrider.trim(), maxrider.trim(), ridererror.trim(), click.trim(),
                        generateillustrations.trim(), clickcontinue.trim(), ifsccode.trim(), bankaccno.trim(), accholdername.trim(),
                        accounttype.trim(), pennyalert.trim(), clickverify.trim(), renewpremiumscreentitle.trim(), paymentmethod.trim(),
                        drawdate.trim(), fundsource.trim(), nomineescreentitle.trim(), nomineefirstname.trim(), nomineelastname.trim(), nomineeday.trim(),
                        nomineemonth.trim(), nomineeyear.trim(), nomineegender.trim(), relationshipwithproposer.trim(), nomineeshare.trim(), ismwppolicy.trim(), addressscreentitle.trim(),
                        typeofaddress.trim(), addresspincode.trim(), address1.trim(), address2.trim(), address3.trim(), personalDetailsscreentitle.trim(), cityName.trim(),
                        preferredLanguage.trim(), alernateNumber.trim(), resTelephoneNumber.trim(), emailaddressValidations.trim(), maritalStatus.trim(),
                        fathersNameOrSpouseName.trim(), mothersName.trim(), MaidenName.trim(), qualification.trim(), occupation.trim(), employeerName.trim(),
                        nameOfBusinessOrduties.trim(), typeOfOrganization.trim(), designation.trim(), annualIncome.trim(), policyStatus.trim(), exPolicyscreenTitle.trim(), exNameofInsurer.trim(),
                        exSumAssured.trim(), expolicyNumber.trim(), exyearOfApplication.trim(), exbasePlan.trim(), exannualpremium.trim(), medicalPolicy.trim(), expolicystatus.trim(),
                        refPolicyscreenTitle.trim(), refinsurerName.trim(), refsumAssured.trim(), refreason.trim(), refinsurerName1.trim(), refsumAssured1.trim(), refreason1.trim(),
                        refinsurerName2.trim(), refsumAssured2.trim(), refreason2.trim(), refinsurerName3.trim(), refsumAssured3.trim(), refreason3.trim(),
                        refinsurerName4.trim(), refsumAssured4.trim(), refreason4.trim(), policyPurposeScreen.trim(), purposeOption1.trim(), purposeOption2.trim(), purposeOption3.trim(),
                        healthDetailsScreen.trim(), height.trim(), weight.trim(), weightchange.trim(), symptomsDetails.trim(), testsDetails.trim(), covidContactDetails.trim(), quarantineDetails.trim(), healthDetails.trim(),
                        pastTravelContry.trim(), pastTravelCity.trim(), pastTravelArrivalDay.trim(), pastTravelArraivalMonth.trim(), pastTravelArraivalYear.trim(),
                        pastTravelDepartureDay.trim(), pastTravelDepartureMonth.trim(), pastTravelDepartureYear.trim(), futureTravelCountry.trim(), futureTravelCity.trim(),
                        futureTravelDepartureDay.trim(), futureTravelDepartureMonth.trim(), futureTravelDepartureYear.trim(), futureInternedDuration.trim(),
                        covidVaccinationFirstDoseDay.trim(), covidVaccinationFirstDoseMonth.trim(), covidVaccinationFirstDoseYear.trim(), covidVaccinationSecondDoseDay.trim(),
                        covidVaccinationSecondDoseMonth.trim(), covidVaccinationSecondDoseYear.trim(), covidVaccineName.trim(), postVaccineDetails.trim(),
                        covidOccupation.trim(), medicalSpeciality.trim(), exactNatureOfDuties.trim(), nameOfHealthCareFacility.trim(),
                        addressOfHealthCareFacility.trim(), healthAuthorityRegistered.trim(), covidWardDetails.trim(), diagnoseDay.trim(),
                        diagnoseMonth.trim(), diagnoseYear.trim(), daignoseTestName.trim(), receivedCovid19Test1.trim(), receivedCovid19Test2.trim(), receivedCovid19Test3.trim(),
                        admissionDay.trim(), admissionMonth.trim(), admissionYear.trim(), dischargeDay.trim(), dischargeMonth.trim(), dischargeYear.trim(),
                        covidInfectionDetails.trim(), covidSymptoms1.trim(), covidSymptoms2.trim(), covidSymptoms3.trim(), recoveryDay.trim(), recoveryMonth.trim(), recoveryYear.trim(),
                        testsName.trim(), testTakenDay.trim(), testTakenMonth.trim(), testTakenYear.trim(), certifiedDetails.trim(),ChequeNumber.trim(),PaymentModeDate.trim(),PaymentModeMonth.trim(),PaymentModeYear.trim(),IFSCCode.trim(),MICRCODE.trim(),DDNumber.trim()};

                myData.add(ob);
            }
        }
        System.out.println("mydata rows value **********" + myData.toString());
        return myData;
    }

    public static ArrayList<Object[]> getCashDataFromExcel(String testExcelSheet, String testName, String sheetName) {
        ArrayList<Object[]> myData = new ArrayList<Object[]>();
        Xls_Reader reader = null;

        try {
            reader = new Xls_Reader(System.getProperty("user.dir") + testExcelSheet);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("Cash sheet row count ---------" + reader.getRowCount(sheetName));

        for (int rowCount = 3; rowCount <= reader.getRowCount(sheetName); rowCount++) {
            String currentTestMethod = reader.getCellData(sheetName, "testCaseName", rowCount);
            String enableFlag = reader.getCellData(sheetName, "flag", rowCount);
            if (currentTestMethod.trim().equalsIgnoreCase(testName) && enableFlag.equalsIgnoreCase("YES")) {

                String username = reader.getCellData(sheetName, "username", rowCount);
                String password = reader.getCellData(sheetName, "password", rowCount);


                String policy = reader.getCellData(sheetName, "policy", rowCount);
                String leadid = reader.getCellData(sheetName, "leadid", rowCount);
                String proposersame = reader.getCellData(sheetName, "proposersame", rowCount);
                String relationwithinsured = reader.getCellData(sheetName, "relationwithinsured", rowCount);
                String isrelationanswer = reader.getCellData(sheetName, "isrelationanswer", rowCount);

                String isnri = reader.getCellData(sheetName, "isnri", rowCount);
                String pmobile = reader.getCellData(sheetName, "pmobile", rowCount);
                String ppan = reader.getCellData(sheetName, "ppan", rowCount);
                String imobile = reader.getCellData(sheetName, "imobile", rowCount);
                String ipan = reader.getCellData(sheetName, "ipan", rowCount);
                String firstname = reader.getCellData(sheetName, "firstname", rowCount);
                String lastname = reader.getCellData(sheetName, "lastname", rowCount);
                String middlename = reader.getCellData(sheetName, "middlename", rowCount);
                String day = reader.getCellData(sheetName, "day", rowCount);
                String month = reader.getCellData(sheetName, "month", rowCount);
                String year = reader.getCellData(sheetName, "year", rowCount);
                String gender = reader.getCellData(sheetName, "gender", rowCount);


                String planjourney = reader.getCellData(sheetName, "planjourney", rowCount);
                String proposerstate = reader.getCellData(sheetName, "proposerstate", rowCount);
                String advisorstatesame = reader.getCellData(sheetName, "advisorstatesame", rowCount);

                String plan = reader.getCellData(sheetName, "plan", rowCount);
                String sumassured = reader.getCellData(sheetName, "sumassured", rowCount);
                String smokertype = reader.getCellData(sheetName, "smokertype", rowCount);
                String planoptions = reader.getCellData(sheetName, "planoptions", rowCount);
                String increasinglevel = reader.getCellData(sheetName, "increasinglevel", rowCount);
                String ecs = reader.getCellData(sheetName, "ecs", rowCount);
                String term = reader.getCellData(sheetName, "term", rowCount);
                String ppt = reader.getCellData(sheetName, "ppt", rowCount);
                String premiumterm = reader.getCellData(sheetName, "premiumterm", rowCount);
                String premiumamount = reader.getCellData(sheetName, "premiumamount", rowCount);

                String rider = reader.getCellData(sheetName, "rider", rowCount);
                String rideramount = reader.getCellData(sheetName, "rideramount", rowCount);
                String minrider = reader.getCellData(sheetName, "minrider", rowCount);
                String maxrider = reader.getCellData(sheetName, "maxrider", rowCount);
                String ridererror = reader.getCellData(sheetName, "ridererror", rowCount);
                String click = reader.getCellData(sheetName, "click", rowCount);

                String generateillustrations = reader.getCellData(sheetName, "generateillustrations", rowCount);
                String clickcontinue = reader.getCellData(sheetName, "clickcontinue", rowCount);


                String ifsccode = reader.getCellData(sheetName, "ifsccode", rowCount);
                String bankaccno = reader.getCellData(sheetName, "bankaccno", rowCount);
                String accholdername = reader.getCellData(sheetName, "accholdername", rowCount);
                String accounttype = reader.getCellData(sheetName, "accounttype", rowCount);

                String pennyalert = reader.getCellData(sheetName, "pennyalert", rowCount);
                String clickverify = reader.getCellData(sheetName, "clickverify", rowCount);

                String renewpremiumscreentitle = reader.getCellData(sheetName, "renewpremiumscreentitle", rowCount);

                String paymentmethod = reader.getCellData(sheetName, "paymentmethod", rowCount);
                String drawdate = reader.getCellData(sheetName, "drawdate", rowCount);
                String fundsource = reader.getCellData(sheetName, "fundsource", rowCount);
                String nomineescreentitle = reader.getCellData(sheetName, "nomineescreentitle", rowCount);

                String nomineefirstname = reader.getCellData(sheetName, "nomineefirstname", rowCount);
                String nomineelastname = reader.getCellData(sheetName, "nomineelastname", rowCount);
                String nomineeday = reader.getCellData(sheetName, "nomineeday", rowCount);
                String nomineemonth = reader.getCellData(sheetName, "nomineemonth", rowCount);
                String nomineeyear = reader.getCellData(sheetName, "nomineeyear", rowCount);
                String nomineegender = reader.getCellData(sheetName, "nomineegender", rowCount);
                String relationshipwithproposer = reader.getCellData(sheetName, "relationshipwithproposer", rowCount);
                String nomineeshare = reader.getCellData(sheetName, "nomineeshare", rowCount);
                String ismwppolicy = reader.getCellData(sheetName, "ismwppolicy", rowCount);
                String addressscreentitle = reader.getCellData(sheetName, "addressscreentitle", rowCount);

                String typeofaddress = reader.getCellData(sheetName, "typeofaddress", rowCount);
                String addresspincode = reader.getCellData(sheetName, "addresspincode", rowCount);
                String address1 = reader.getCellData(sheetName, "address1", rowCount);
                String address2 = reader.getCellData(sheetName, "address2", rowCount);
                String address3 = reader.getCellData(sheetName, "address3", rowCount);
                String personalDetailsscreentitle = reader.getCellData(sheetName, "personalDetailsscreentitle", rowCount);
                String cityName = reader.getCellData(sheetName, "cityName", rowCount);
                String preferredLanguage = reader.getCellData(sheetName, "preferredLanguage", rowCount);
                String alernateNumber = reader.getCellData(sheetName, "alernateNumber", rowCount);
                String resTelephoneNumber = reader.getCellData(sheetName, "resTelephoneNumber", rowCount);
                String emailaddressValidations = reader.getCellData(sheetName, "emailaddressValidations", rowCount);
                String maritalStatus = reader.getCellData(sheetName, "maritalStatus", rowCount);
                String fathersNameOrSpouseName = reader.getCellData(sheetName, "fathersNameOrSpouseName", rowCount);
                String mothersName = reader.getCellData(sheetName, "mothersName", rowCount);
                String MaidenName = reader.getCellData(sheetName, "MaidenName", rowCount);


                String question1 = reader.getCellData(sheetName, "question1", rowCount);
                String answer1 = reader.getCellData(sheetName, "answer1", rowCount);
                String valuetoBeEnter = reader.getCellData(sheetName, "valueToBeEnter", rowCount);
                String question2 = reader.getCellData(sheetName, "question2", rowCount);
                String answer2 = reader.getCellData(sheetName, "answer2", rowCount);
                String valuetoBeEnter2 = reader.getCellData(sheetName, "valueToBeEnter2", rowCount);
                String question3 = reader.getCellData(sheetName, "question3", rowCount);
                String answer3 = reader.getCellData(sheetName, "answer3", rowCount);
                String valuetoBeEnter3 = reader.getCellData(sheetName, "valueToBeEnter3", rowCount);
                String question4 = reader.getCellData(sheetName, "question4", rowCount);
                String answer4 = reader.getCellData(sheetName, "answer4", rowCount);
                String valuetoBeEnter4 = reader.getCellData(sheetName, "valueToBeEnter4", rowCount);
                String qualification = reader.getCellData(sheetName, "qualification", rowCount);
                String occupation = reader.getCellData(sheetName, "occupation", rowCount);
                String employeerName = reader.getCellData(sheetName, "employeerName", rowCount);
                String nameOfBusinessOrduties = reader.getCellData(sheetName, "nameOfBusinessOrduties", rowCount);
                String typeOfOrganization = reader.getCellData(sheetName, "typeOfOrganization", rowCount);
                String designation = reader.getCellData(sheetName, "designation", rowCount);
                String annualIncome = reader.getCellData(sheetName, "annualIncome", rowCount);
                String policyStatus = reader.getCellData(sheetName, "expolicystatus", rowCount);
                String exPolicyscreenTitle = reader.getCellData(sheetName, "exPolicyscreenTitle", rowCount);
                String exNameofInsurer = reader.getCellData(sheetName, "exNameofInsurer", rowCount);
                String exSumAssured = reader.getCellData(sheetName, "exSumAssured", rowCount);
                String expolicyNumber = reader.getCellData(sheetName, "expolicyNumber", rowCount);
                String exyearOfApplication = reader.getCellData(sheetName, "exyearOfApplication", rowCount);
                String exbasePlan = reader.getCellData(sheetName, "exbasePlan", rowCount);
                String exannualpremium = reader.getCellData(sheetName, "exannualpremium", rowCount);
                String medicalPolicy = reader.getCellData(sheetName, "medicalPolicy", rowCount);
                String expolicystatus = reader.getCellData(sheetName, "expolicystatus", rowCount);
                String refPolicyscreenTitle = reader.getCellData(sheetName, "refPolicyscreenTitle", rowCount);

                String refinsurerName = reader.getCellData(sheetName, "refnsurerName", rowCount);
                String refsumAssured = reader.getCellData(sheetName, "refsumAssured", rowCount);
                String refreason = reader.getCellData(sheetName, "refreason", rowCount);

                String refinsurerName1 = reader.getCellData(sheetName, "refnsurerName1", rowCount);
                String refsumAssured1 = reader.getCellData(sheetName, "refsumAssured1", rowCount);
                String refreason1 = reader.getCellData(sheetName, "refreason1", rowCount);

                String refinsurerName2 = reader.getCellData(sheetName, "refnsurerName2", rowCount);
                String refsumAssured2 = reader.getCellData(sheetName, "refsumAssured2", rowCount);
                String refreason2 = reader.getCellData(sheetName, "refreason2", rowCount);

                String refinsurerName3 = reader.getCellData(sheetName, "refnsurerName3", rowCount);
                String refsumAssured3 = reader.getCellData(sheetName, "refsumAssured3", rowCount);
                String refreason3 = reader.getCellData(sheetName, "refreason3", rowCount);

                String refinsurerName4 = reader.getCellData(sheetName, "refnsurerName4", rowCount);
                String refsumAssured4 = reader.getCellData(sheetName, "refsumAssured4", rowCount);
                String refreason4 = reader.getCellData(sheetName, "refreason4", rowCount);


                String policyPurposeScreen = reader.getCellData(sheetName, "policyPurposeScreen", rowCount);
                String purposeOption1 = reader.getCellData(sheetName, "purposeOption1", rowCount);
                String purposeOption2 = reader.getCellData(sheetName, "purposeOption2", rowCount);
                String purposeOption3 = reader.getCellData(sheetName, "purposeOption3", rowCount);

                String healthDetailsScreen = reader.getCellData(sheetName, "healthDetailsScreen", rowCount);

                String height = reader.getCellData(sheetName, "height", rowCount);
                String weight = reader.getCellData(sheetName, "weight", rowCount);
                String weightchange = reader.getCellData(sheetName, "weightchange", rowCount);

                String symptomsDetails = reader.getCellData(sheetName, "symptomsDetails", rowCount);
                String testsDetails = reader.getCellData(sheetName, "testsDetails", rowCount);
                String covidContactDetails = reader.getCellData(sheetName, "covidContactDetails", rowCount);
                String quarantineDetails = reader.getCellData(sheetName, "quarantineDetails", rowCount);
                String healthDetails = reader.getCellData(sheetName, "healthDetails", rowCount);
                String pastTravelContry = reader.getCellData(sheetName, "pastTravelContry", rowCount);
                String pastTravelCity = reader.getCellData(sheetName, "pastTravelCity", rowCount);
                String pastTravelArrivalDay = reader.getCellData(sheetName, "pastTravelArrivalDay", rowCount);
                String pastTravelArraivalMonth = reader.getCellData(sheetName, "pastTravelArraivalMonth", rowCount);
                String pastTravelArraivalYear = reader.getCellData(sheetName, "pastTravelArraivalYear", rowCount);
                String pastTravelDepartureDay = reader.getCellData(sheetName, "pastTravelDepartureDay", rowCount);
                String pastTravelDepartureMonth = reader.getCellData(sheetName, "pastTravelDepartureMonth", rowCount);
                String pastTravelDepartureYear = reader.getCellData(sheetName, "pastTravelDepartureYear", rowCount);
                String futureTravelCountry = reader.getCellData(sheetName, "futureTravelCountry", rowCount);
                String futureTravelCity = reader.getCellData(sheetName, "futureTravelCity", rowCount);
                String futureTravelDepartureDay = reader.getCellData(sheetName, "futureTravelDepartureDay", rowCount);
                String futureTravelDepartureMonth = reader.getCellData(sheetName, "futureTravelDepartureMonth", rowCount);
                String futureTravelDepartureYear = reader.getCellData(sheetName, "futureTravelDepartureYear", rowCount);
                String futureInternedDuration = reader.getCellData(sheetName, "futureInternedDuration", rowCount);
                String covidVaccinationFirstDoseDay = reader.getCellData(sheetName, "covidVaccinationFirstDoseDay", rowCount);
                String covidVaccinationFirstDoseMonth = reader.getCellData(sheetName, "covidVaccinationFirstDoseMonth", rowCount);
                String covidVaccinationFirstDoseYear = reader.getCellData(sheetName, "covidVaccinationFirstDoseYear", rowCount);
                String covidVaccinationSecondDoseDay = reader.getCellData(sheetName, "covidVaccinationSecondDoseDay", rowCount);
                String covidVaccinationSecondDoseMonth = reader.getCellData(sheetName, "covidVaccinationSecondDoseMonth", rowCount);
                String covidVaccinationSecondDoseYear = reader.getCellData(sheetName, "covidVaccinationSecondDoseYear", rowCount);
                String covidVaccineName = reader.getCellData(sheetName, "covidVaccineName", rowCount);
                String postVaccineDetails = reader.getCellData(sheetName, "postVaccineDetails", rowCount);
                String covidOccupation = reader.getCellData(sheetName, "covidOccupation", rowCount);
                String medicalSpeciality = reader.getCellData(sheetName, "medicalSpeciality", rowCount);
                String exactNatureOfDuties = reader.getCellData(sheetName, "exactNatureOfDuties", rowCount);
                String nameOfHealthCareFacility = reader.getCellData(sheetName, "nameOfHealthCareFacility", rowCount);
                String addressOfHealthCareFacility = reader.getCellData(sheetName, "addressOfHealthCareFacility", rowCount);
                String healthAuthorityRegistered = reader.getCellData(sheetName, "healthAuthorityRegistered", rowCount);
                String covidWardDetails = reader.getCellData(sheetName, "covidWardDetails", rowCount);
                String diagnoseDay = reader.getCellData(sheetName, "diagnoseDay", rowCount);
                String diagnoseMonth = reader.getCellData(sheetName, "diagnoseMonth", rowCount);
                String diagnoseYear = reader.getCellData(sheetName, "diagnoseYear", rowCount);
                String daignoseTestName = reader.getCellData(sheetName, "daignoseTestName", rowCount);
                String receivedCovid19Test1 = reader.getCellData(sheetName, "receivedCovid19Test1", rowCount);
                String receivedCovid19Test2 = reader.getCellData(sheetName, "receivedCovid19Test2", rowCount);
                String receivedCovid19Test3 = reader.getCellData(sheetName, "receivedCovid19Test3", rowCount);
                String admissionDay = reader.getCellData(sheetName, "admissionDay", rowCount);
                String admissionMonth = reader.getCellData(sheetName, "admissionMonth", rowCount);
                String admissionYear = reader.getCellData(sheetName, "admissionYear", rowCount);
                String dischargeDay = reader.getCellData(sheetName, "dischargeDay", rowCount);
                String dischargeMonth = reader.getCellData(sheetName, "dischargeMonth", rowCount);
                String dischargeYear = reader.getCellData(sheetName, "dischargeYear", rowCount);
                String covidInfectionDetails = reader.getCellData(sheetName, "covidInfectionDetails", rowCount);
                String covidSymptoms1 = reader.getCellData(sheetName, "covidSymptoms1", rowCount);
                String covidSymptoms2 = reader.getCellData(sheetName, "covidSymptoms2", rowCount);
                String covidSymptoms3 = reader.getCellData(sheetName, "covidSymptoms3", rowCount);
                String recoveryDay = reader.getCellData(sheetName, "recoveryDay", rowCount);
                String recoveryMonth = reader.getCellData(sheetName, "recoveryMonth", rowCount);
                String recoveryYear = reader.getCellData(sheetName, "recoveryYear", rowCount);
                String testsName = reader.getCellData(sheetName, "testsName", rowCount);
                String testTakenDay = reader.getCellData(sheetName, "testTakenDay", rowCount);
                String testTakenMonth = reader.getCellData(sheetName, "testTakenMonth", rowCount);
                String testTakenYear = reader.getCellData(sheetName, "testTakenYear", rowCount);
                String certifiedDetails = reader.getCellData(sheetName, "certifiedDetails", rowCount);

                Object ob[] = {username.trim(), password.trim(), policy.trim(), leadid.trim(), proposersame.trim(), relationwithinsured.trim(), isrelationanswer.trim(),
                        isnri.trim(), pmobile.trim(), ppan.trim(), imobile.trim(), ipan.trim(), firstname.trim(), lastname.trim(),
                        middlename.trim(), day.trim(), month.trim(), year.trim(),
                        gender.trim(), planjourney.trim(), proposerstate.trim(), advisorstatesame.trim(), plan.trim(), sumassured.trim(), smokertype.trim(), planoptions.trim(), increasinglevel.trim(),
                        ecs.trim(), term.trim(), ppt.trim(), premiumterm.trim(), premiumamount.trim(), rider.trim(), rideramount.trim(), minrider.trim(), maxrider.trim(), ridererror.trim(), click.trim(),
                        generateillustrations.trim(), clickcontinue.trim(), ifsccode.trim(), bankaccno.trim(), accholdername.trim(),
                        accounttype.trim(), pennyalert.trim(), clickverify.trim(), renewpremiumscreentitle.trim(), paymentmethod.trim(),
                        drawdate.trim(), fundsource.trim(), nomineescreentitle.trim(), nomineefirstname.trim(), nomineelastname.trim(), nomineeday.trim(),
                        nomineemonth.trim(), nomineeyear.trim(), nomineegender.trim(), relationshipwithproposer.trim(), nomineeshare.trim(), ismwppolicy.trim(), addressscreentitle.trim(),
                        typeofaddress.trim(), addresspincode.trim(), address1.trim(), address2.trim(), address3.trim(), personalDetailsscreentitle.trim(), cityName.trim(),
                        preferredLanguage.trim(), alernateNumber.trim(), resTelephoneNumber.trim(), emailaddressValidations.trim(), maritalStatus.trim(),
                        fathersNameOrSpouseName.trim(), mothersName.trim(), MaidenName.trim(), qualification.trim(), occupation.trim(), employeerName.trim(),
                        nameOfBusinessOrduties.trim(), typeOfOrganization.trim(), designation.trim(), annualIncome.trim(), policyStatus.trim(), exPolicyscreenTitle.trim(), exNameofInsurer.trim(),
                        exSumAssured.trim(), expolicyNumber.trim(), exyearOfApplication.trim(), exbasePlan.trim(), exannualpremium.trim(), medicalPolicy.trim(), expolicystatus.trim(),
                        refPolicyscreenTitle.trim(), refinsurerName.trim(), refsumAssured.trim(), refreason.trim(), refinsurerName1.trim(), refsumAssured1.trim(), refreason1.trim(),
                        refinsurerName2.trim(), refsumAssured2.trim(), refreason2.trim(), refinsurerName3.trim(), refsumAssured3.trim(), refreason3.trim(),
                        refinsurerName4.trim(), refsumAssured4.trim(), refreason4.trim(), policyPurposeScreen.trim(), purposeOption1.trim(), purposeOption2.trim(), purposeOption3.trim(),
                        healthDetailsScreen.trim(), height.trim(), weight.trim(), weightchange.trim(), symptomsDetails.trim(), testsDetails.trim(), covidContactDetails.trim(), quarantineDetails.trim(), healthDetails.trim(),
                        pastTravelContry.trim(), pastTravelCity.trim(), pastTravelArrivalDay.trim(), pastTravelArraivalMonth.trim(), pastTravelArraivalYear.trim(),
                        pastTravelDepartureDay.trim(), pastTravelDepartureMonth.trim(), pastTravelDepartureYear.trim(), futureTravelCountry.trim(), futureTravelCity.trim(),
                        futureTravelDepartureDay.trim(), futureTravelDepartureMonth.trim(), futureTravelDepartureYear.trim(), futureInternedDuration.trim(),
                        covidVaccinationFirstDoseDay.trim(), covidVaccinationFirstDoseMonth.trim(), covidVaccinationFirstDoseYear.trim(), covidVaccinationSecondDoseDay.trim(),
                        covidVaccinationSecondDoseMonth.trim(), covidVaccinationSecondDoseYear.trim(), covidVaccineName.trim(), postVaccineDetails.trim(),
                        covidOccupation.trim(), medicalSpeciality.trim(), exactNatureOfDuties.trim(), nameOfHealthCareFacility.trim(),
                        addressOfHealthCareFacility.trim(), healthAuthorityRegistered.trim(), covidWardDetails.trim(), diagnoseDay.trim(),
                        diagnoseMonth.trim(), diagnoseYear.trim(), daignoseTestName.trim(), receivedCovid19Test1.trim(), receivedCovid19Test2.trim(), receivedCovid19Test3.trim(),
                        admissionDay.trim(), admissionMonth.trim(), admissionYear.trim(), dischargeDay.trim(), dischargeMonth.trim(), dischargeYear.trim(),
                        covidInfectionDetails.trim(), covidSymptoms1.trim(), covidSymptoms2.trim(), covidSymptoms3.trim(), recoveryDay.trim(), recoveryMonth.trim(), recoveryYear.trim(),
                        testsName.trim(), testTakenDay.trim(), testTakenMonth.trim(), testTakenYear.trim(), certifiedDetails.trim()};
                myData.add(ob);
            }
        }
        System.out.println("mydata rows value **********" + myData.toString());
        return myData;
    }
    public static ArrayList<Object[]> getWinBackDataFromExcel(String testExcelSheet, String testName, String sheetName) {
        ArrayList<Object[]> myData = new ArrayList<Object[]>();
        Xls_Reader reader = null;

        try {
            reader = new Xls_Reader(System.getProperty("user.dir") + testExcelSheet);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("WinBack sheet row count ---------" + reader.getRowCount(sheetName));

        for (int rowCount = 3; rowCount <= reader.getRowCount(sheetName); rowCount++) {
            String currentTestMethod = reader.getCellData(sheetName, "testCaseName", rowCount);
            String enableFlag = reader.getCellData(sheetName, "flag", rowCount);
            if (currentTestMethod.trim().equalsIgnoreCase(testName) && enableFlag.equalsIgnoreCase("YES")) {

                String username = reader.getCellData(sheetName, "username", rowCount);
                String password = reader.getCellData(sheetName, "password", rowCount);


                String policy = reader.getCellData(sheetName, "policy", rowCount);
                String leadid = reader.getCellData(sheetName, "leadid", rowCount);
                String proposersame = reader.getCellData(sheetName, "proposersame", rowCount);
                String relationwithinsured = reader.getCellData(sheetName, "relationwithinsured", rowCount);
                String isrelationanswer = reader.getCellData(sheetName, "isrelationanswer", rowCount);

                String isnri = reader.getCellData(sheetName, "isnri", rowCount);
                String pmobile = reader.getCellData(sheetName, "pmobile", rowCount);
                String ppan = reader.getCellData(sheetName, "ppan", rowCount);
                String imobile = reader.getCellData(sheetName, "imobile", rowCount);
                String ipan = reader.getCellData(sheetName, "ipan", rowCount);
                String firstname = reader.getCellData(sheetName, "firstname", rowCount);
                String lastname = reader.getCellData(sheetName, "lastname", rowCount);
                String middlename = reader.getCellData(sheetName, "middlename", rowCount);
                String day = reader.getCellData(sheetName, "day", rowCount);
                String month = reader.getCellData(sheetName, "month", rowCount);
                String year = reader.getCellData(sheetName, "year", rowCount);
                String gender = reader.getCellData(sheetName, "gender", rowCount);


                String planjourney = reader.getCellData(sheetName, "planjourney", rowCount);
                String proposerstate = reader.getCellData(sheetName, "proposerstate", rowCount);
                String advisorstatesame = reader.getCellData(sheetName, "advisorstatesame", rowCount);

                String plan = reader.getCellData(sheetName, "plan", rowCount);
                String sumassured = reader.getCellData(sheetName, "sumassured", rowCount);
                String smokertype = reader.getCellData(sheetName, "smokertype", rowCount);
                String planoptions = reader.getCellData(sheetName, "planoptions", rowCount);
                String increasinglevel = reader.getCellData(sheetName, "increasinglevel", rowCount);
                String ecs = reader.getCellData(sheetName, "ecs", rowCount);
                String term = reader.getCellData(sheetName, "term", rowCount);
                String ppt = reader.getCellData(sheetName, "ppt", rowCount);
                String premiumterm = reader.getCellData(sheetName, "premiumterm", rowCount);
                String premiumamount = reader.getCellData(sheetName, "premiumamount", rowCount);

                String rider = reader.getCellData(sheetName, "rider", rowCount);
                String rideramount = reader.getCellData(sheetName, "rideramount", rowCount);
                String minrider = reader.getCellData(sheetName, "minrider", rowCount);
                String maxrider = reader.getCellData(sheetName, "maxrider", rowCount);
                String ridererror = reader.getCellData(sheetName, "ridererror", rowCount);
                String click = reader.getCellData(sheetName, "click", rowCount);

                String generateillustrations = reader.getCellData(sheetName, "generateillustrations", rowCount);
                String clickcontinue = reader.getCellData(sheetName, "clickcontinue", rowCount);


                String ifsccode = reader.getCellData(sheetName, "ifsccode", rowCount);
                String bankaccno = reader.getCellData(sheetName, "bankaccno", rowCount);
                String accholdername = reader.getCellData(sheetName, "accholdername", rowCount);
                String accounttype = reader.getCellData(sheetName, "accounttype", rowCount);

                String pennyalert = reader.getCellData(sheetName, "pennyalert", rowCount);
                String clickverify = reader.getCellData(sheetName, "clickverify", rowCount);

                String renewpremiumscreentitle = reader.getCellData(sheetName, "renewpremiumscreentitle", rowCount);

                String paymentmethod = reader.getCellData(sheetName, "paymentmethod", rowCount);
                String drawdate = reader.getCellData(sheetName, "drawdate", rowCount);
                String fundsource = reader.getCellData(sheetName, "fundsource", rowCount);
                String nomineescreentitle = reader.getCellData(sheetName, "nomineescreentitle", rowCount);

                String nomineefirstname = reader.getCellData(sheetName, "nomineefirstname", rowCount);
                String nomineelastname = reader.getCellData(sheetName, "nomineelastname", rowCount);
                String nomineeday = reader.getCellData(sheetName, "nomineeday", rowCount);
                String nomineemonth = reader.getCellData(sheetName, "nomineemonth", rowCount);
                String nomineeyear = reader.getCellData(sheetName, "nomineeyear", rowCount);
                String nomineegender = reader.getCellData(sheetName, "nomineegender", rowCount);
                String relationshipwithproposer = reader.getCellData(sheetName, "relationshipwithproposer", rowCount);
                String nomineeshare = reader.getCellData(sheetName, "nomineeshare", rowCount);
                String ismwppolicy = reader.getCellData(sheetName, "ismwppolicy", rowCount);
                String addressscreentitle = reader.getCellData(sheetName, "addressscreentitle", rowCount);

                String typeofaddress = reader.getCellData(sheetName, "typeofaddress", rowCount);
                String addresspincode = reader.getCellData(sheetName, "addresspincode", rowCount);
                String address1 = reader.getCellData(sheetName, "address1", rowCount);
                String address2 = reader.getCellData(sheetName, "address2", rowCount);
                String address3 = reader.getCellData(sheetName, "address3", rowCount);
                String personalDetailsscreentitle = reader.getCellData(sheetName, "personalDetailsscreentitle", rowCount);
                String cityName = reader.getCellData(sheetName, "cityName", rowCount);
                String preferredLanguage = reader.getCellData(sheetName, "preferredLanguage", rowCount);
                String alernateNumber = reader.getCellData(sheetName, "alernateNumber", rowCount);
                String resTelephoneNumber = reader.getCellData(sheetName, "resTelephoneNumber", rowCount);
                String emailaddressValidations = reader.getCellData(sheetName, "emailaddressValidations", rowCount);
                String maritalStatus = reader.getCellData(sheetName, "maritalStatus", rowCount);
                String fathersNameOrSpouseName = reader.getCellData(sheetName, "fathersNameOrSpouseName", rowCount);
                String mothersName = reader.getCellData(sheetName, "mothersName", rowCount);
                String MaidenName = reader.getCellData(sheetName, "MaidenName", rowCount);


                String question1 = reader.getCellData(sheetName, "question1", rowCount);
                String answer1 = reader.getCellData(sheetName, "answer1", rowCount);
                String valuetoBeEnter = reader.getCellData(sheetName, "valueToBeEnter", rowCount);
                String question2 = reader.getCellData(sheetName, "question2", rowCount);
                String answer2 = reader.getCellData(sheetName, "answer2", rowCount);
                String valuetoBeEnter2 = reader.getCellData(sheetName, "valueToBeEnter2", rowCount);
                String question3 = reader.getCellData(sheetName, "question3", rowCount);
                String answer3 = reader.getCellData(sheetName, "answer3", rowCount);
                String valuetoBeEnter3 = reader.getCellData(sheetName, "valueToBeEnter3", rowCount);
                String question4 = reader.getCellData(sheetName, "question4", rowCount);
                String answer4 = reader.getCellData(sheetName, "answer4", rowCount);
                String valuetoBeEnter4 = reader.getCellData(sheetName, "valueToBeEnter4", rowCount);
                String qualification = reader.getCellData(sheetName, "qualification", rowCount);
                String occupation = reader.getCellData(sheetName, "occupation", rowCount);
                String employeerName = reader.getCellData(sheetName, "employeerName", rowCount);
                String nameOfBusinessOrduties = reader.getCellData(sheetName, "nameOfBusinessOrduties", rowCount);
                String typeOfOrganization = reader.getCellData(sheetName, "typeOfOrganization", rowCount);
                String designation = reader.getCellData(sheetName, "designation", rowCount);
                String annualIncome = reader.getCellData(sheetName, "annualIncome", rowCount);
                String policyStatus = reader.getCellData(sheetName, "expolicystatus", rowCount);
                String exPolicyscreenTitle = reader.getCellData(sheetName, "exPolicyscreenTitle", rowCount);
                String exNameofInsurer = reader.getCellData(sheetName, "exNameofInsurer", rowCount);
                String exSumAssured = reader.getCellData(sheetName, "exSumAssured", rowCount);
                String expolicyNumber = reader.getCellData(sheetName, "expolicyNumber", rowCount);
                String exyearOfApplication = reader.getCellData(sheetName, "exyearOfApplication", rowCount);
                String exbasePlan = reader.getCellData(sheetName, "exbasePlan", rowCount);
                String exannualpremium = reader.getCellData(sheetName, "exannualpremium", rowCount);
                String medicalPolicy = reader.getCellData(sheetName, "medicalPolicy", rowCount);
                String expolicystatus = reader.getCellData(sheetName, "expolicystatus", rowCount);
                String refPolicyscreenTitle = reader.getCellData(sheetName, "refPolicyscreenTitle", rowCount);

                String refinsurerName = reader.getCellData(sheetName, "refnsurerName", rowCount);
                String refsumAssured = reader.getCellData(sheetName, "refsumAssured", rowCount);
                String refreason = reader.getCellData(sheetName, "refreason", rowCount);

                String refinsurerName1 = reader.getCellData(sheetName, "refnsurerName1", rowCount);
                String refsumAssured1 = reader.getCellData(sheetName, "refsumAssured1", rowCount);
                String refreason1 = reader.getCellData(sheetName, "refreason1", rowCount);

                String refinsurerName2 = reader.getCellData(sheetName, "refnsurerName2", rowCount);
                String refsumAssured2 = reader.getCellData(sheetName, "refsumAssured2", rowCount);
                String refreason2 = reader.getCellData(sheetName, "refreason2", rowCount);

                String refinsurerName3 = reader.getCellData(sheetName, "refnsurerName3", rowCount);
                String refsumAssured3 = reader.getCellData(sheetName, "refsumAssured3", rowCount);
                String refreason3 = reader.getCellData(sheetName, "refreason3", rowCount);

                String refinsurerName4 = reader.getCellData(sheetName, "refnsurerName4", rowCount);
                String refsumAssured4 = reader.getCellData(sheetName, "refsumAssured4", rowCount);
                String refreason4 = reader.getCellData(sheetName, "refreason4", rowCount);


                String policyPurposeScreen = reader.getCellData(sheetName, "policyPurposeScreen", rowCount);
                String purposeOption1 = reader.getCellData(sheetName, "purposeOption1", rowCount);
                String purposeOption2 = reader.getCellData(sheetName, "purposeOption2", rowCount);
                String purposeOption3 = reader.getCellData(sheetName, "purposeOption3", rowCount);

                String healthDetailsScreen = reader.getCellData(sheetName, "healthDetailsScreen", rowCount);

                String height = reader.getCellData(sheetName, "height", rowCount);
                String weight = reader.getCellData(sheetName, "weight", rowCount);
                String weightchange = reader.getCellData(sheetName, "weightchange", rowCount);

                String symptomsDetails = reader.getCellData(sheetName, "symptomsDetails", rowCount);
                String testsDetails = reader.getCellData(sheetName, "testsDetails", rowCount);
                String covidContactDetails = reader.getCellData(sheetName, "covidContactDetails", rowCount);
                String quarantineDetails = reader.getCellData(sheetName, "quarantineDetails", rowCount);
                String healthDetails = reader.getCellData(sheetName, "healthDetails", rowCount);
                String pastTravelContry = reader.getCellData(sheetName, "pastTravelContry", rowCount);
                String pastTravelCity = reader.getCellData(sheetName, "pastTravelCity", rowCount);
                String pastTravelArrivalDay = reader.getCellData(sheetName, "pastTravelArrivalDay", rowCount);
                String pastTravelArraivalMonth = reader.getCellData(sheetName, "pastTravelArraivalMonth", rowCount);
                String pastTravelArraivalYear = reader.getCellData(sheetName, "pastTravelArraivalYear", rowCount);
                String pastTravelDepartureDay = reader.getCellData(sheetName, "pastTravelDepartureDay", rowCount);
                String pastTravelDepartureMonth = reader.getCellData(sheetName, "pastTravelDepartureMonth", rowCount);
                String pastTravelDepartureYear = reader.getCellData(sheetName, "pastTravelDepartureYear", rowCount);
                String futureTravelCountry = reader.getCellData(sheetName, "futureTravelCountry", rowCount);
                String futureTravelCity = reader.getCellData(sheetName, "futureTravelCity", rowCount);
                String futureTravelDepartureDay = reader.getCellData(sheetName, "futureTravelDepartureDay", rowCount);
                String futureTravelDepartureMonth = reader.getCellData(sheetName, "futureTravelDepartureMonth", rowCount);
                String futureTravelDepartureYear = reader.getCellData(sheetName, "futureTravelDepartureYear", rowCount);
                String futureInternedDuration = reader.getCellData(sheetName, "futureInternedDuration", rowCount);
                String covidVaccinationFirstDoseDay = reader.getCellData(sheetName, "covidVaccinationFirstDoseDay", rowCount);
                String covidVaccinationFirstDoseMonth = reader.getCellData(sheetName, "covidVaccinationFirstDoseMonth", rowCount);
                String covidVaccinationFirstDoseYear = reader.getCellData(sheetName, "covidVaccinationFirstDoseYear", rowCount);
                String covidVaccinationSecondDoseDay = reader.getCellData(sheetName, "covidVaccinationSecondDoseDay", rowCount);
                String covidVaccinationSecondDoseMonth = reader.getCellData(sheetName, "covidVaccinationSecondDoseMonth", rowCount);
                String covidVaccinationSecondDoseYear = reader.getCellData(sheetName, "covidVaccinationSecondDoseYear", rowCount);
                String covidVaccineName = reader.getCellData(sheetName, "covidVaccineName", rowCount);
                String postVaccineDetails = reader.getCellData(sheetName, "postVaccineDetails", rowCount);
                String covidOccupation = reader.getCellData(sheetName, "covidOccupation", rowCount);
                String medicalSpeciality = reader.getCellData(sheetName, "medicalSpeciality", rowCount);
                String exactNatureOfDuties = reader.getCellData(sheetName, "exactNatureOfDuties", rowCount);
                String nameOfHealthCareFacility = reader.getCellData(sheetName, "nameOfHealthCareFacility", rowCount);
                String addressOfHealthCareFacility = reader.getCellData(sheetName, "addressOfHealthCareFacility", rowCount);
                String healthAuthorityRegistered = reader.getCellData(sheetName, "healthAuthorityRegistered", rowCount);
                String covidWardDetails = reader.getCellData(sheetName, "covidWardDetails", rowCount);
                String diagnoseDay = reader.getCellData(sheetName, "diagnoseDay", rowCount);
                String diagnoseMonth = reader.getCellData(sheetName, "diagnoseMonth", rowCount);
                String diagnoseYear = reader.getCellData(sheetName, "diagnoseYear", rowCount);
                String daignoseTestName = reader.getCellData(sheetName, "daignoseTestName", rowCount);
                String receivedCovid19Test1 = reader.getCellData(sheetName, "receivedCovid19Test1", rowCount);
                String receivedCovid19Test2 = reader.getCellData(sheetName, "receivedCovid19Test2", rowCount);
                String receivedCovid19Test3 = reader.getCellData(sheetName, "receivedCovid19Test3", rowCount);
                String admissionDay = reader.getCellData(sheetName, "admissionDay", rowCount);
                String admissionMonth = reader.getCellData(sheetName, "admissionMonth", rowCount);
                String admissionYear = reader.getCellData(sheetName, "admissionYear", rowCount);
                String dischargeDay = reader.getCellData(sheetName, "dischargeDay", rowCount);
                String dischargeMonth = reader.getCellData(sheetName, "dischargeMonth", rowCount);
                String dischargeYear = reader.getCellData(sheetName, "dischargeYear", rowCount);
                String covidInfectionDetails = reader.getCellData(sheetName, "covidInfectionDetails", rowCount);
                String covidSymptoms1 = reader.getCellData(sheetName, "covidSymptoms1", rowCount);
                String covidSymptoms2 = reader.getCellData(sheetName, "covidSymptoms2", rowCount);
                String covidSymptoms3 = reader.getCellData(sheetName, "covidSymptoms3", rowCount);
                String recoveryDay = reader.getCellData(sheetName, "recoveryDay", rowCount);
                String recoveryMonth = reader.getCellData(sheetName, "recoveryMonth", rowCount);
                String recoveryYear = reader.getCellData(sheetName, "recoveryYear", rowCount);
                String testsName = reader.getCellData(sheetName, "testsName", rowCount);
                String testTakenDay = reader.getCellData(sheetName, "testTakenDay", rowCount);
                String testTakenMonth = reader.getCellData(sheetName, "testTakenMonth", rowCount);
                String testTakenYear = reader.getCellData(sheetName, "testTakenYear", rowCount);
                String certifiedDetails = reader.getCellData(sheetName, "certifiedDetails", rowCount);
                String PolicyNumber = reader.getCellData(sheetName, "PolicyNumber", rowCount);
                String PolicyAmount = reader.getCellData(sheetName, "PolicyAmount", rowCount);

                Object ob[] = {username.trim(), password.trim(), policy.trim(), leadid.trim(), proposersame.trim(), relationwithinsured.trim(), isrelationanswer.trim(),
                        isnri.trim(), pmobile.trim(), ppan.trim(), imobile.trim(), ipan.trim(), firstname.trim(), lastname.trim(),
                        middlename.trim(), day.trim(), month.trim(), year.trim(),
                        gender.trim(), planjourney.trim(), proposerstate.trim(), advisorstatesame.trim(), plan.trim(), sumassured.trim(), smokertype.trim(), planoptions.trim(), increasinglevel.trim(),
                        ecs.trim(), term.trim(), ppt.trim(), premiumterm.trim(), premiumamount.trim(), rider.trim(), rideramount.trim(), minrider.trim(), maxrider.trim(), ridererror.trim(), click.trim(),
                        generateillustrations.trim(), clickcontinue.trim(), ifsccode.trim(), bankaccno.trim(), accholdername.trim(),
                        accounttype.trim(), pennyalert.trim(), clickverify.trim(), renewpremiumscreentitle.trim(), paymentmethod.trim(),
                        drawdate.trim(), fundsource.trim(), nomineescreentitle.trim(), nomineefirstname.trim(), nomineelastname.trim(), nomineeday.trim(),
                        nomineemonth.trim(), nomineeyear.trim(), nomineegender.trim(), relationshipwithproposer.trim(), nomineeshare.trim(), ismwppolicy.trim(), addressscreentitle.trim(),
                        typeofaddress.trim(), addresspincode.trim(), address1.trim(), address2.trim(), address3.trim(), personalDetailsscreentitle.trim(), cityName.trim(),
                        preferredLanguage.trim(), alernateNumber.trim(), resTelephoneNumber.trim(), emailaddressValidations.trim(), maritalStatus.trim(),
                        fathersNameOrSpouseName.trim(), mothersName.trim(), MaidenName.trim(), qualification.trim(), occupation.trim(), employeerName.trim(),
                        nameOfBusinessOrduties.trim(), typeOfOrganization.trim(), designation.trim(), annualIncome.trim(), policyStatus.trim(), exPolicyscreenTitle.trim(), exNameofInsurer.trim(),
                        exSumAssured.trim(), expolicyNumber.trim(), exyearOfApplication.trim(), exbasePlan.trim(), exannualpremium.trim(), medicalPolicy.trim(), expolicystatus.trim(),
                        refPolicyscreenTitle.trim(), refinsurerName.trim(), refsumAssured.trim(), refreason.trim(), refinsurerName1.trim(), refsumAssured1.trim(), refreason1.trim(),
                        refinsurerName2.trim(), refsumAssured2.trim(), refreason2.trim(), refinsurerName3.trim(), refsumAssured3.trim(), refreason3.trim(),
                        refinsurerName4.trim(), refsumAssured4.trim(), refreason4.trim(), policyPurposeScreen.trim(), purposeOption1.trim(), purposeOption2.trim(), purposeOption3.trim(),
                        healthDetailsScreen.trim(), height.trim(), weight.trim(), weightchange.trim(), symptomsDetails.trim(), testsDetails.trim(), covidContactDetails.trim(), quarantineDetails.trim(), healthDetails.trim(),
                        pastTravelContry.trim(), pastTravelCity.trim(), pastTravelArrivalDay.trim(), pastTravelArraivalMonth.trim(), pastTravelArraivalYear.trim(),
                        pastTravelDepartureDay.trim(), pastTravelDepartureMonth.trim(), pastTravelDepartureYear.trim(), futureTravelCountry.trim(), futureTravelCity.trim(),
                        futureTravelDepartureDay.trim(), futureTravelDepartureMonth.trim(), futureTravelDepartureYear.trim(), futureInternedDuration.trim(),
                        covidVaccinationFirstDoseDay.trim(), covidVaccinationFirstDoseMonth.trim(), covidVaccinationFirstDoseYear.trim(), covidVaccinationSecondDoseDay.trim(),
                        covidVaccinationSecondDoseMonth.trim(), covidVaccinationSecondDoseYear.trim(), covidVaccineName.trim(), postVaccineDetails.trim(),
                        covidOccupation.trim(), medicalSpeciality.trim(), exactNatureOfDuties.trim(), nameOfHealthCareFacility.trim(),
                        addressOfHealthCareFacility.trim(), healthAuthorityRegistered.trim(), covidWardDetails.trim(), diagnoseDay.trim(),
                        diagnoseMonth.trim(), diagnoseYear.trim(), daignoseTestName.trim(), receivedCovid19Test1.trim(), receivedCovid19Test2.trim(), receivedCovid19Test3.trim(),
                        admissionDay.trim(), admissionMonth.trim(), admissionYear.trim(), dischargeDay.trim(), dischargeMonth.trim(), dischargeYear.trim(),
                        covidInfectionDetails.trim(), covidSymptoms1.trim(), covidSymptoms2.trim(), covidSymptoms3.trim(), recoveryDay.trim(), recoveryMonth.trim(), recoveryYear.trim(),
                        testsName.trim(), testTakenDay.trim(), testTakenMonth.trim(), testTakenYear.trim(), certifiedDetails.trim(),PolicyNumber.trim(),PolicyAmount.trim()};

                 myData.add(ob);
            }
        }
        System.out.println("mydata rows value **********" + myData.toString());
        return myData;
    }

    public static ArrayList<Object[]> getHealthDetailsDataFromExcel(String testExcelSheet, String testName, String sheetName) {
        ArrayList<Object[]> myData = new ArrayList<Object[]>();
        Xls_Reader reader = null;

        try {
            reader = new Xls_Reader(System.getProperty("user.dir") + testExcelSheet);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("HealthDetails sheet row count ---------" + reader.getRowCount(sheetName));

        for (int rowCount = 3; rowCount <= reader.getRowCount(sheetName); rowCount++) {
            String currentTestMethod = reader.getCellData(sheetName, "testCaseName", rowCount);
            String enableFlag = reader.getCellData(sheetName, "flag", rowCount);
            if (currentTestMethod.trim().equalsIgnoreCase(testName) && enableFlag.equalsIgnoreCase("YES")) {

                String username = reader.getCellData(sheetName, "username", rowCount);
                String password = reader.getCellData(sheetName, "password", rowCount);


                String policy = reader.getCellData(sheetName, "policy", rowCount);
                String leadid = reader.getCellData(sheetName, "leadid", rowCount);
                String proposersame = reader.getCellData(sheetName, "proposersame", rowCount);
                String relationwithinsured = reader.getCellData(sheetName, "relationwithinsured", rowCount);
                String isrelationanswer = reader.getCellData(sheetName, "isrelationanswer", rowCount);


                String isnri = reader.getCellData(sheetName, "isnri", rowCount);
                String pmobile = reader.getCellData(sheetName, "pmobile", rowCount);
                String ppan = reader.getCellData(sheetName, "ppan", rowCount);
                String imobile = reader.getCellData(sheetName, "imobile", rowCount);
                String ipan = reader.getCellData(sheetName, "ipan", rowCount);
                String firstname = reader.getCellData(sheetName, "firstname", rowCount);
                String lastname = reader.getCellData(sheetName, "lastname", rowCount);
                String middlename = reader.getCellData(sheetName, "middlename", rowCount);
                String day = reader.getCellData(sheetName, "day", rowCount);
                String month = reader.getCellData(sheetName, "month", rowCount);
                String year = reader.getCellData(sheetName, "year", rowCount);
                String gender = reader.getCellData(sheetName, "gender", rowCount);


                String planjourney = reader.getCellData(sheetName, "planjourney", rowCount);
                String proposerstate = reader.getCellData(sheetName, "proposerstate", rowCount);
                String advisorstatesame = reader.getCellData(sheetName, "advisorstatesame", rowCount);

                String plan = reader.getCellData(sheetName, "plan", rowCount);
                String sumassured = reader.getCellData(sheetName, "sumassured", rowCount);
                String smokertype = reader.getCellData(sheetName, "smokertype", rowCount);
                String planoptions = reader.getCellData(sheetName, "planoptions", rowCount);
                String increasinglevel = reader.getCellData(sheetName, "increasinglevel", rowCount);
                String ecs = reader.getCellData(sheetName, "ecs", rowCount);
                String term = reader.getCellData(sheetName, "term", rowCount);
                String ppt = reader.getCellData(sheetName, "ppt", rowCount);
                String premiumterm = reader.getCellData(sheetName, "premiumterm", rowCount);
                String premiumamount = reader.getCellData(sheetName, "premiumamount", rowCount);

                String rider = reader.getCellData(sheetName, "rider", rowCount);
                String rideramount = reader.getCellData(sheetName, "rideramount", rowCount);
                String minrider = reader.getCellData(sheetName, "minrider", rowCount);
                String maxrider = reader.getCellData(sheetName, "maxrider", rowCount);
                String ridererror = reader.getCellData(sheetName, "ridererror", rowCount);
                String click = reader.getCellData(sheetName, "click", rowCount);

                String generateillustrations = reader.getCellData(sheetName, "generateillustrations", rowCount);
                String clickcontinue = reader.getCellData(sheetName, "clickcontinue", rowCount);


                String ifsccode = reader.getCellData(sheetName, "ifsccode", rowCount);
                String bankaccno = reader.getCellData(sheetName, "bankaccno", rowCount);
                String accholdername = reader.getCellData(sheetName, "accholdername", rowCount);
                String accounttype = reader.getCellData(sheetName, "accounttype", rowCount);

                String pennyalert = reader.getCellData(sheetName, "pennyalert", rowCount);
                String clickverify = reader.getCellData(sheetName, "clickverify", rowCount);
                String renewpremiumscreentitle = reader.getCellData(sheetName, "renewpremiumscreentitle", rowCount);

                String paymentmethod = reader.getCellData(sheetName, "paymentmethod", rowCount);
                String drawdate = reader.getCellData(sheetName, "drawdate", rowCount);
                String fundsource = reader.getCellData(sheetName, "fundsource", rowCount);
                String nomineescreentitle = reader.getCellData(sheetName, "nomineescreentitle", rowCount);

                String nomineefirstname = reader.getCellData(sheetName, "nomineefirstname", rowCount);
                String nomineelastname = reader.getCellData(sheetName, "nomineelastname", rowCount);
                String nomineeday = reader.getCellData(sheetName, "nomineeday", rowCount);
                String nomineemonth = reader.getCellData(sheetName, "nomineemonth", rowCount);
                String nomineeyear = reader.getCellData(sheetName, "nomineeyear", rowCount);
                String nomineegender = reader.getCellData(sheetName, "nomineegender", rowCount);
                String relationshipwithproposer = reader.getCellData(sheetName, "relationshipwithproposer", rowCount);
                String nomineeshare = reader.getCellData(sheetName, "nomineeshare", rowCount);
                String ismwppolicy = reader.getCellData(sheetName, "ismwppolicy", rowCount);
                String addressscreentitle = reader.getCellData(sheetName, "addressscreentitle", rowCount);
                String typeofaddress = reader.getCellData(sheetName, "typeofaddress", rowCount);
                String addresspincode = reader.getCellData(sheetName, "addresspincode", rowCount);
                String address1 = reader.getCellData(sheetName, "address1", rowCount);
                String address2 = reader.getCellData(sheetName, "address2", rowCount);
                String address3 = reader.getCellData(sheetName, "address3", rowCount);
                String personalDetailsscreentitle = reader.getCellData(sheetName, "personalDetailsscreentitle", rowCount);
                String cityName = reader.getCellData(sheetName, "cityName", rowCount);
                String preferredLanguage = reader.getCellData(sheetName, "preferredLanguage", rowCount);
                String alernateNumber = reader.getCellData(sheetName, "alernateNumber", rowCount);
                String resTelephoneNumber = reader.getCellData(sheetName, "resTelephoneNumber", rowCount);
                String PersonalEmailId = reader.getCellData(sheetName, "PersonalEmailId", rowCount);
                String PersonalMaritalStatus = reader.getCellData(sheetName, "PersonalMaritalStatus", rowCount);
                String FatherSpouseName = reader.getCellData(sheetName, "FatherSpouseName", rowCount);
                String MotherName = reader.getCellData(sheetName, "MotherName", rowCount);
                String MaidenName = reader.getCellData(sheetName, "MaidenName", rowCount);
                String Qualification = reader.getCellData(sheetName, "Qualification", rowCount);
                String Others = reader.getCellData(sheetName, "Others", rowCount);

                String Occupation = reader.getCellData(sheetName, "Occupation", rowCount);
                String typeOfOccupation = reader.getCellData(sheetName, "typeOfOccupation", rowCount);
                String NameofEmployer = reader.getCellData(sheetName, "NameofEmployer", rowCount);
                String Designation = reader.getCellData(sheetName, "Designation", rowCount);
                String AnnualIncome = reader.getCellData(sheetName, "AnnualIncome", rowCount);
                String SpouseAnnualIncome = reader.getCellData(sheetName, "SpouseAnnualIncome", rowCount);
                String ParentInsuranceCover = reader.getCellData(sheetName, "ParentInsuranceCover", rowCount);

                String ParentAnnualIncome = reader.getCellData(sheetName, "ParentAnnualIncome", rowCount);
                String SpouseInsuranceCover = reader.getCellData(sheetName, "SpouseInsuranceCover", rowCount);

                String NarcoticsDetails = reader.getCellData(sheetName, "NarcoticsDetails", rowCount);
                String AlcoholQuantity = reader.getCellData(sheetName, "AlcoholQuantity", rowCount);
                String Frequency = reader.getCellData(sheetName, "Frequency", rowCount);
                String NicotineDuration = reader.getCellData(sheetName, "NicotineDuration", rowCount);
                String TobaccoQuantityConsumed = reader.getCellData(sheetName, "TobaccoQuantityConsumed", rowCount);
                String TobaccoYrsConsumed = reader.getCellData(sheetName, "TobaccoYrsConsumed", rowCount);
                String HazardousActivitiesOption = reader.getCellData(sheetName, "HazardousActivitiesOption", rowCount);
                String HazardousActivitiesYrs = reader.getCellData(sheetName, "HazardousActivitiesYrs", rowCount);
                String HazardousActivitiesType = reader.getCellData(sheetName, "HazardousActivitiesType", rowCount);

                String HealthWeight = reader.getCellData(sheetName, "HealthWeight", rowCount);
                String WeightLossReason = reader.getCellData(sheetName, "WeightLossReason", rowCount);


                Object ob[] = {username.trim(), password.trim(), policy.trim(), leadid.trim(), proposersame.trim(), relationwithinsured.trim(), isrelationanswer.trim(),
                        isnri.trim(), pmobile.trim(), ppan.trim(), imobile.trim(), ipan.trim(), firstname.trim(), lastname.trim(),
                        middlename.trim(), day.trim(), month.trim(), year.trim(),
                        gender.trim(), planjourney.trim(), proposerstate.trim(), advisorstatesame.trim(), plan.trim(), sumassured.trim(), smokertype.trim(), planoptions.trim(), increasinglevel.trim(),
                        ecs.trim(), term.trim(), ppt.trim(), premiumterm.trim(), premiumamount.trim(), rider.trim(), rideramount.trim(), minrider.trim(), maxrider.trim(), ridererror.trim(), click.trim(),
                        generateillustrations.trim(), clickcontinue.trim(), ifsccode.trim(), bankaccno.trim(), accholdername.trim(),
                        accounttype.trim(), pennyalert.trim(), clickverify.trim(), renewpremiumscreentitle.trim(), paymentmethod.trim(),
                        drawdate.trim(), fundsource.trim(), nomineescreentitle.trim(), nomineefirstname.trim(), nomineelastname.trim(), nomineeday.trim(),
                        nomineemonth.trim(), nomineeyear.trim(), nomineegender.trim(), relationshipwithproposer.trim(), nomineeshare.trim(), ismwppolicy.trim(), addressscreentitle.trim(),
                        typeofaddress.trim(), addresspincode.trim(), address1.trim(), address2.trim(), address3.trim(), personalDetailsscreentitle.trim(), cityName.trim(), preferredLanguage.trim(), alernateNumber.trim(), resTelephoneNumber.trim(),
                        PersonalEmailId.trim(), PersonalMaritalStatus.trim(), FatherSpouseName.trim(), MotherName.trim(), MaidenName.trim(), Qualification.trim(), Others.trim(), Occupation.trim(), typeOfOccupation.trim(),
                        NameofEmployer.trim(), Designation.trim(), AnnualIncome.trim(), SpouseAnnualIncome.trim(), ParentInsuranceCover.trim(), ParentAnnualIncome.trim(), SpouseInsuranceCover.trim(),
                        NarcoticsDetails.trim(), AlcoholQuantity.trim(), Frequency.trim(), NicotineDuration.trim(), TobaccoQuantityConsumed.trim(), TobaccoYrsConsumed.trim(), HazardousActivitiesOption.trim(), HazardousActivitiesYrs.trim(), HazardousActivitiesType.trim(),HealthWeight.trim(), WeightLossReason.trim()};
                myData.add(ob);
            }
        }
        System.out.println("mydata rows value **********" + myData.toString());
        return myData;
    }
    public static ArrayList<Object[]> getAppSummaryDataFromExcel(String testExcelSheet, String testName, String sheetName) {
        ArrayList<Object[]> myData = new ArrayList<Object[]>();
        Xls_Reader reader = null;

        try {
            reader = new Xls_Reader(System.getProperty("user.dir") + testExcelSheet);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("App Summary sheet row count ---------" + reader.getRowCount(sheetName));

        for (int rowCount = 3; rowCount <= reader.getRowCount(sheetName); rowCount++) {
            String currentTestMethod = reader.getCellData(sheetName, "testCaseName", rowCount);
            String enableFlag = reader.getCellData(sheetName, "flag", rowCount);
            if (currentTestMethod.trim().equalsIgnoreCase(testName) && enableFlag.equalsIgnoreCase("YES")) {

                String username = reader.getCellData(sheetName, "username", rowCount);
                String password = reader.getCellData(sheetName, "password", rowCount);


                String policy = reader.getCellData(sheetName, "policy", rowCount);
                String leadid = reader.getCellData(sheetName, "leadid", rowCount);
                String proposersame = reader.getCellData(sheetName, "proposersame", rowCount);
                String relationwithinsured = reader.getCellData(sheetName, "relationwithinsured", rowCount);
                String isrelationanswer = reader.getCellData(sheetName, "isrelationanswer", rowCount);


                String isnri = reader.getCellData(sheetName, "isnri", rowCount);
                String pmobile = reader.getCellData(sheetName, "pmobile", rowCount);
                String ppan = reader.getCellData(sheetName, "ppan", rowCount);
                String imobile = reader.getCellData(sheetName, "imobile", rowCount);
                String ipan = reader.getCellData(sheetName, "ipan", rowCount);
                String firstname = reader.getCellData(sheetName, "firstname", rowCount);
                String lastname = reader.getCellData(sheetName, "lastname", rowCount);
                String middlename = reader.getCellData(sheetName, "middlename", rowCount);
                String day = reader.getCellData(sheetName, "day", rowCount);
                String month = reader.getCellData(sheetName, "month", rowCount);
                String year = reader.getCellData(sheetName, "year", rowCount);
                String gender = reader.getCellData(sheetName, "gender", rowCount);


                String planjourney = reader.getCellData(sheetName, "planjourney", rowCount);
                String proposerstate = reader.getCellData(sheetName, "proposerstate", rowCount);
                String advisorstatesame = reader.getCellData(sheetName, "advisorstatesame", rowCount);

                String plan = reader.getCellData(sheetName, "plan", rowCount);
                String sumassured = reader.getCellData(sheetName, "sumassured", rowCount);
                String smokertype = reader.getCellData(sheetName, "smokertype", rowCount);
                String planoptions = reader.getCellData(sheetName, "planoptions", rowCount);
                String increasinglevel = reader.getCellData(sheetName, "increasinglevel", rowCount);
                String ecs = reader.getCellData(sheetName, "ecs", rowCount);
                String term = reader.getCellData(sheetName, "term", rowCount);
                String ppt = reader.getCellData(sheetName, "ppt", rowCount);
                String premiumterm = reader.getCellData(sheetName, "premiumterm", rowCount);
                String premiumamount = reader.getCellData(sheetName, "premiumamount", rowCount);

                String rider = reader.getCellData(sheetName, "rider", rowCount);
                String rideramount = reader.getCellData(sheetName, "rideramount", rowCount);
                String minrider = reader.getCellData(sheetName, "minrider", rowCount);
                String maxrider = reader.getCellData(sheetName, "maxrider", rowCount);
                String ridererror = reader.getCellData(sheetName, "ridererror", rowCount);
                String click = reader.getCellData(sheetName, "click", rowCount);

                String generateillustrations = reader.getCellData(sheetName, "generateillustrations", rowCount);
                String clickcontinue = reader.getCellData(sheetName, "clickcontinue", rowCount);


                String ifsccode = reader.getCellData(sheetName, "ifsccode", rowCount);
                String bankaccno = reader.getCellData(sheetName, "bankaccno", rowCount);
                String accholdername = reader.getCellData(sheetName, "accholdername", rowCount);
                String accounttype = reader.getCellData(sheetName, "accounttype", rowCount);

                String pennyalert = reader.getCellData(sheetName, "pennyalert", rowCount);
                String clickverify = reader.getCellData(sheetName, "clickverify", rowCount);
                String renewpremiumscreentitle = reader.getCellData(sheetName, "renewpremiumscreentitle", rowCount);

                String paymentmethod = reader.getCellData(sheetName, "paymentmethod", rowCount);
                String drawdate = reader.getCellData(sheetName, "drawdate", rowCount);
                String fundsource = reader.getCellData(sheetName, "fundsource", rowCount);
                String nomineescreentitle = reader.getCellData(sheetName, "nomineescreentitle", rowCount);

                String nomineefirstname = reader.getCellData(sheetName, "nomineefirstname", rowCount);
                String nomineelastname = reader.getCellData(sheetName, "nomineelastname", rowCount);
                String nomineeday = reader.getCellData(sheetName, "nomineeday", rowCount);
                String nomineemonth = reader.getCellData(sheetName, "nomineemonth", rowCount);
                String nomineeyear = reader.getCellData(sheetName, "nomineeyear", rowCount);
                String nomineegender = reader.getCellData(sheetName, "nomineegender", rowCount);
                String relationshipwithproposer = reader.getCellData(sheetName, "relationshipwithproposer", rowCount);
                String nomineeshare = reader.getCellData(sheetName, "nomineeshare", rowCount);
                String ismwppolicy = reader.getCellData(sheetName, "ismwppolicy", rowCount);
                String addressscreentitle = reader.getCellData(sheetName, "addressscreentitle", rowCount);
                String typeofaddress = reader.getCellData(sheetName, "typeofaddress", rowCount);
                String addresspincode = reader.getCellData(sheetName, "addresspincode", rowCount);
                String address1 = reader.getCellData(sheetName, "address1", rowCount);
                String address2 = reader.getCellData(sheetName, "address2", rowCount);
                String address3 = reader.getCellData(sheetName, "address3", rowCount);
                String personalDetailsscreentitle = reader.getCellData(sheetName, "personalDetailsscreentitle", rowCount);
                String cityName = reader.getCellData(sheetName, "cityName", rowCount);
                String preferredLanguage = reader.getCellData(sheetName, "preferredLanguage", rowCount);
                String alernateNumber = reader.getCellData(sheetName,"alernateNumber",rowCount);
                String resTelephoneNumber = reader.getCellData(sheetName,"resTelephoneNumber",rowCount);
                String PersonalEmailId = reader.getCellData(sheetName,"PersonalEmailId",rowCount);
                String PersonalMaritalStatus = reader.getCellData(sheetName, "PersonalMaritalStatus", rowCount);
                String FatherSpouseName = reader.getCellData(sheetName, "FatherSpouseName", rowCount);
                String MotherName = reader.getCellData(sheetName, "MotherName", rowCount);
                String MaidenName = reader.getCellData(sheetName, "MaidenName", rowCount);
                String Qualification = reader.getCellData(sheetName, "Qualification", rowCount);
                String Others = reader.getCellData(sheetName,"Others", rowCount);

                String Occupation = reader.getCellData(sheetName, "Occupation", rowCount);
                String typeOfOccupation = reader.getCellData(sheetName, "typeOfOccupation", rowCount);
                String NameofEmployer = reader.getCellData(sheetName, "NameofEmployer", rowCount);
                String Designation = reader.getCellData(sheetName, "Designation", rowCount);
                String AnnualIncome = reader.getCellData(sheetName, "AnnualIncome", rowCount);
                String SpouseAnnualIncome = reader.getCellData(sheetName, "SpouseAnnualIncome", rowCount);
                String ParentInsuranceCover = reader.getCellData(sheetName, "ParentInsuranceCover", rowCount);

                String ParentAnnualIncome = reader.getCellData(sheetName, "ParentAnnualIncome", rowCount);
                String SpouseInsuranceCover = reader.getCellData(sheetName, "SpouseInsuranceCover", rowCount);

                String NarcoticsDetails = reader.getCellData(sheetName,"NarcoticsDetails",rowCount);
                String AlcoholQuantity = reader.getCellData(sheetName,"AlcoholQuantity",rowCount);
                String Frequency = reader.getCellData(sheetName,"Frequency",rowCount);
                String NicotineDuration = reader.getCellData(sheetName,"NicotineDuration",rowCount);
                String TobaccoQuantityConsumed = reader.getCellData(sheetName,"TobaccoQuantityConsumed",rowCount);
                String TobaccoYrsConsumed = reader.getCellData(sheetName,"TobaccoYrsConsumed",rowCount);
                String HazardousActivitiesOption = reader.getCellData(sheetName,"HazardousActivitiesOption",rowCount);
                String HazardousActivitiesYrs = reader.getCellData(sheetName,"HazardousActivitiesYrs",rowCount);
                String HazardousActivitiesType = reader.getCellData(sheetName,"HazardousActivitiesType",rowCount);
                String ChequeNumber = reader.getCellData(sheetName, "ChequeNumber", rowCount);
                String PaymentModeDate = reader.getCellData(sheetName, "PaymentModeDate", rowCount);
                String PaymentModeMonth = reader.getCellData(sheetName, "PaymentModeMonth", rowCount);
                String PaymentModeYear= reader.getCellData(sheetName, "PaymentModeYear", rowCount);
                String IFSCCode = reader.getCellData(sheetName, "IFSCCode", rowCount);
                String MICRCODE = reader.getCellData(sheetName, "MICRCODE", rowCount);
                String DDNumber = reader.getCellData(sheetName, "DDNumber", rowCount);

                Object ob[] = {username.trim(),	password.trim(),	policy.trim(),	leadid.trim(),	proposersame.trim(),	relationwithinsured.trim(),isrelationanswer.trim(),
                        isnri.trim(),	pmobile.trim(),	ppan.trim(), imobile.trim(),	ipan.trim(),	firstname.trim(),	lastname.trim(),
                        middlename.trim(),	day.trim(),	month.trim(),	year.trim(),
                        gender.trim(),	planjourney.trim(), proposerstate.trim(),	advisorstatesame.trim(), plan.trim(),	sumassured.trim(),	smokertype.trim(),	planoptions.trim(),	increasinglevel.trim(),
                        ecs.trim(),	term.trim(),	ppt.trim(),	premiumterm.trim(),	premiumamount.trim(), rider.trim(),	rideramount.trim(),	minrider.trim(),	maxrider.trim(),	ridererror.trim(),	click.trim(),
                        generateillustrations.trim(),	clickcontinue.trim(),	ifsccode.trim(),	bankaccno.trim(),	accholdername.trim(),
                        accounttype.trim(), pennyalert.trim(),	clickverify.trim(), renewpremiumscreentitle.trim(), paymentmethod.trim(),
                        drawdate.trim(),	fundsource.trim(),nomineescreentitle.trim(),nomineefirstname.trim(),	nomineelastname.trim(),	nomineeday.trim(),
                        nomineemonth.trim(),	nomineeyear.trim(),	nomineegender.trim(),	relationshipwithproposer.trim(),	nomineeshare.trim(),	ismwppolicy.trim(),addressscreentitle.trim(),
                        typeofaddress.trim(), addresspincode.trim(), address1.trim(), address2.trim(), address3.trim(), personalDetailsscreentitle.trim(), cityName.trim(), preferredLanguage.trim(),alernateNumber.trim(),resTelephoneNumber.trim(),
                        PersonalEmailId.trim(),PersonalMaritalStatus.trim(),FatherSpouseName.trim(),MotherName.trim(),MaidenName.trim(),Qualification.trim(),Others.trim(),Occupation.trim(),typeOfOccupation.trim(),
                        NameofEmployer.trim(),Designation.trim(),AnnualIncome.trim(),SpouseAnnualIncome.trim(),ParentInsuranceCover.trim(),ParentAnnualIncome.trim(),SpouseInsuranceCover.trim(),
                        NarcoticsDetails.trim(),AlcoholQuantity.trim(),Frequency.trim(),NicotineDuration.trim(),TobaccoQuantityConsumed.trim(),TobaccoYrsConsumed.trim(),HazardousActivitiesOption.trim(),HazardousActivitiesYrs.trim(),HazardousActivitiesType.trim(),ChequeNumber.trim(),PaymentModeDate.trim(),
                        PaymentModeMonth.trim(),PaymentModeYear.trim(),IFSCCode.trim(),MICRCODE.trim(),DDNumber.trim()};
                myData.add(ob);
            }
        }
        System.out.println("mydata rows value **********" + myData.toString());
        return myData;
    }

    public static ArrayList<Object[]> getPaymentSummaryDataFromExcel(String testExcelSheet, String testName, String sheetName) {
        ArrayList<Object[]> myData = new ArrayList<Object[]>();
        Xls_Reader reader = null;

        try {
            reader = new Xls_Reader(System.getProperty("user.dir") + testExcelSheet);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("Payment Summary sheet row count ---------" + reader.getRowCount(sheetName));

        for (int rowCount = 3; rowCount <= reader.getRowCount(sheetName); rowCount++) {
            String currentTestMethod = reader.getCellData(sheetName, "testCaseName", rowCount);
            String enableFlag = reader.getCellData(sheetName, "flag", rowCount);
            if (currentTestMethod.trim().equalsIgnoreCase(testName) && enableFlag.equalsIgnoreCase("YES")) {
                String username = reader.getCellData(sheetName, "username", rowCount);
                String password = reader.getCellData(sheetName, "password", rowCount);


                String policy = reader.getCellData(sheetName, "policy", rowCount);
                String leadid = reader.getCellData(sheetName, "leadid", rowCount);
                String proposersame = reader.getCellData(sheetName, "proposersame", rowCount);
                String relationwithinsured = reader.getCellData(sheetName, "relationwithinsured", rowCount);
                String isrelationanswer = reader.getCellData(sheetName, "isrelationanswer", rowCount);

                String isnri = reader.getCellData(sheetName, "isnri", rowCount);
                String pmobile = reader.getCellData(sheetName, "pmobile", rowCount);
                String ppan = reader.getCellData(sheetName, "ppan", rowCount);
                String imobile = reader.getCellData(sheetName, "imobile", rowCount);
                String ipan = reader.getCellData(sheetName, "ipan", rowCount);
                String firstname = reader.getCellData(sheetName, "firstname", rowCount);
                String lastname = reader.getCellData(sheetName, "lastname", rowCount);
                String middlename = reader.getCellData(sheetName, "middlename", rowCount);
                String day = reader.getCellData(sheetName, "day", rowCount);
                String month = reader.getCellData(sheetName, "month", rowCount);
                String year = reader.getCellData(sheetName, "year", rowCount);
                String gender = reader.getCellData(sheetName, "gender", rowCount);


                String planjourney = reader.getCellData(sheetName, "planjourney", rowCount);
                String proposerstate = reader.getCellData(sheetName, "proposerstate", rowCount);
                String advisorstatesame = reader.getCellData(sheetName, "advisorstatesame", rowCount);

                String plan = reader.getCellData(sheetName, "plan", rowCount);
                String sumassured = reader.getCellData(sheetName, "sumassured", rowCount);
                String smokertype = reader.getCellData(sheetName, "smokertype", rowCount);
                String planoptions = reader.getCellData(sheetName, "planoptions", rowCount);
                String increasinglevel = reader.getCellData(sheetName, "increasinglevel", rowCount);
                String ecs = reader.getCellData(sheetName, "ecs", rowCount);
                String term = reader.getCellData(sheetName, "term", rowCount);
                String ppt = reader.getCellData(sheetName, "ppt", rowCount);
                String premiumterm = reader.getCellData(sheetName, "premiumterm", rowCount);
                String premiumamount = reader.getCellData(sheetName, "premiumamount", rowCount);

                String rider = reader.getCellData(sheetName, "rider", rowCount);
                String rideramount = reader.getCellData(sheetName, "rideramount", rowCount);
                String minrider = reader.getCellData(sheetName, "minrider", rowCount);
                String maxrider = reader.getCellData(sheetName, "maxrider", rowCount);
                String ridererror = reader.getCellData(sheetName, "ridererror", rowCount);
                String click = reader.getCellData(sheetName, "click", rowCount);

                String generateillustrations = reader.getCellData(sheetName, "generateillustrations", rowCount);
                String clickcontinue = reader.getCellData(sheetName, "clickcontinue", rowCount);


                String ifsccode = reader.getCellData(sheetName, "ifsccode", rowCount);
                String bankaccno = reader.getCellData(sheetName, "bankaccno", rowCount);
                String accholdername = reader.getCellData(sheetName, "accholdername", rowCount);
                String accounttype = reader.getCellData(sheetName, "accounttype", rowCount);

                String pennyalert = reader.getCellData(sheetName, "pennyalert", rowCount);
                String clickverify = reader.getCellData(sheetName, "clickverify", rowCount);

                String renewpremiumscreentitle = reader.getCellData(sheetName, "renewpremiumscreentitle", rowCount);

                String paymentmethod = reader.getCellData(sheetName, "paymentmethod", rowCount);
                String drawdate = reader.getCellData(sheetName, "drawdate", rowCount);
                String fundsource = reader.getCellData(sheetName, "fundsource", rowCount);
                String nomineescreentitle = reader.getCellData(sheetName, "nomineescreentitle", rowCount);

                String nomineefirstname = reader.getCellData(sheetName, "nomineefirstname", rowCount);
                String nomineelastname = reader.getCellData(sheetName, "nomineelastname", rowCount);
                String nomineeday = reader.getCellData(sheetName, "nomineeday", rowCount);
                String nomineemonth = reader.getCellData(sheetName, "nomineemonth", rowCount);
                String nomineeyear = reader.getCellData(sheetName, "nomineeyear", rowCount);
                String nomineegender = reader.getCellData(sheetName, "nomineegender", rowCount);
                String relationshipwithproposer = reader.getCellData(sheetName, "relationshipwithproposer", rowCount);
                String nomineeshare = reader.getCellData(sheetName, "nomineeshare", rowCount);
                String ismwppolicy = reader.getCellData(sheetName, "ismwppolicy", rowCount);
                String addressscreentitle = reader.getCellData(sheetName, "addressscreentitle", rowCount);

                String typeofaddress = reader.getCellData(sheetName, "typeofaddress", rowCount);
                String addresspincode = reader.getCellData(sheetName, "addresspincode", rowCount);
                String address1 = reader.getCellData(sheetName, "address1", rowCount);
                String address2 = reader.getCellData(sheetName, "address2", rowCount);
                String address3 = reader.getCellData(sheetName, "address3", rowCount);
                String personalDetailsscreentitle = reader.getCellData(sheetName, "personalDetailsscreentitle", rowCount);
                String cityName = reader.getCellData(sheetName, "cityName", rowCount);
                String preferredLanguage = reader.getCellData(sheetName, "preferredLanguage", rowCount);
                String alernateNumber = reader.getCellData(sheetName, "alernateNumber", rowCount);
                String resTelephoneNumber = reader.getCellData(sheetName, "resTelephoneNumber", rowCount);
                String emailaddressValidations = reader.getCellData(sheetName, "emailaddressValidations", rowCount);
                String maritalStatus = reader.getCellData(sheetName, "maritalStatus", rowCount);
                String fathersNameOrSpouseName = reader.getCellData(sheetName, "fathersNameOrSpouseName", rowCount);
                String mothersName = reader.getCellData(sheetName, "mothersName", rowCount);
                String MaidenName = reader.getCellData(sheetName, "MaidenName", rowCount);


                String question1 = reader.getCellData(sheetName, "question1", rowCount);
                String answer1 = reader.getCellData(sheetName, "answer1", rowCount);
                String valuetoBeEnter = reader.getCellData(sheetName, "valueToBeEnter", rowCount);
                String question2 = reader.getCellData(sheetName, "question2", rowCount);
                String answer2 = reader.getCellData(sheetName, "answer2", rowCount);
                String valuetoBeEnter2 = reader.getCellData(sheetName, "valueToBeEnter2", rowCount);
                String question3 = reader.getCellData(sheetName, "question3", rowCount);
                String answer3 = reader.getCellData(sheetName, "answer3", rowCount);
                String valuetoBeEnter3 = reader.getCellData(sheetName, "valueToBeEnter3", rowCount);
                String question4 = reader.getCellData(sheetName, "question4", rowCount);
                String answer4 = reader.getCellData(sheetName, "answer4", rowCount);
                String valuetoBeEnter4 = reader.getCellData(sheetName, "valueToBeEnter4", rowCount);
                String qualification = reader.getCellData(sheetName, "qualification", rowCount);
                String occupation = reader.getCellData(sheetName, "occupation", rowCount);
                String employeerName = reader.getCellData(sheetName, "employeerName", rowCount);
                String nameOfBusinessOrduties = reader.getCellData(sheetName, "nameOfBusinessOrduties", rowCount);
                String typeOfOrganization = reader.getCellData(sheetName, "typeOfOrganization", rowCount);
                String designation = reader.getCellData(sheetName, "designation", rowCount);
                String annualIncome = reader.getCellData(sheetName, "annualIncome", rowCount);
                String policyStatus = reader.getCellData(sheetName, "expolicystatus", rowCount);
                String exPolicyscreenTitle = reader.getCellData(sheetName, "exPolicyscreenTitle", rowCount);
                String exNameofInsurer = reader.getCellData(sheetName, "exNameofInsurer", rowCount);
                String exSumAssured = reader.getCellData(sheetName, "exSumAssured", rowCount);
                String expolicyNumber = reader.getCellData(sheetName, "expolicyNumber", rowCount);
                String exyearOfApplication = reader.getCellData(sheetName, "exyearOfApplication", rowCount);
                String exbasePlan = reader.getCellData(sheetName, "exbasePlan", rowCount);
                String exannualpremium = reader.getCellData(sheetName, "exannualpremium", rowCount);
                String medicalPolicy = reader.getCellData(sheetName, "medicalPolicy", rowCount);
                String expolicystatus = reader.getCellData(sheetName, "expolicystatus", rowCount);
                String refPolicyscreenTitle = reader.getCellData(sheetName, "refPolicyscreenTitle", rowCount);

                String refinsurerName = reader.getCellData(sheetName, "refnsurerName", rowCount);
                String refsumAssured = reader.getCellData(sheetName, "refsumAssured", rowCount);
                String refreason = reader.getCellData(sheetName, "refreason", rowCount);

                String refinsurerName1 = reader.getCellData(sheetName, "refnsurerName1", rowCount);
                String refsumAssured1 = reader.getCellData(sheetName, "refsumAssured1", rowCount);
                String refreason1 = reader.getCellData(sheetName, "refreason1", rowCount);

                String refinsurerName2 = reader.getCellData(sheetName, "refnsurerName2", rowCount);
                String refsumAssured2 = reader.getCellData(sheetName, "refsumAssured2", rowCount);
                String refreason2 = reader.getCellData(sheetName, "refreason2", rowCount);

                String refinsurerName3 = reader.getCellData(sheetName, "refnsurerName3", rowCount);
                String refsumAssured3 = reader.getCellData(sheetName, "refsumAssured3", rowCount);
                String refreason3 = reader.getCellData(sheetName, "refreason3", rowCount);

                String refinsurerName4 = reader.getCellData(sheetName, "refnsurerName4", rowCount);
                String refsumAssured4 = reader.getCellData(sheetName, "refsumAssured4", rowCount);
                String refreason4 = reader.getCellData(sheetName, "refreason4", rowCount);


                String policyPurposeScreen = reader.getCellData(sheetName, "policyPurposeScreen", rowCount);
                String purposeOption1 = reader.getCellData(sheetName, "purposeOption1", rowCount);
                String purposeOption2 = reader.getCellData(sheetName, "purposeOption2", rowCount);
                String purposeOption3 = reader.getCellData(sheetName, "purposeOption3", rowCount);

                String healthDetailsScreen = reader.getCellData(sheetName, "healthDetailsScreen", rowCount);

                String height = reader.getCellData(sheetName, "height", rowCount);
                String weight = reader.getCellData(sheetName, "weight", rowCount);
                String weightchange = reader.getCellData(sheetName, "weightchange", rowCount);

                String symptomsDetails = reader.getCellData(sheetName, "symptomsDetails", rowCount);
                String testsDetails = reader.getCellData(sheetName, "testsDetails", rowCount);
                String covidContactDetails = reader.getCellData(sheetName, "covidContactDetails", rowCount);
                String quarantineDetails = reader.getCellData(sheetName, "quarantineDetails", rowCount);
                String healthDetails = reader.getCellData(sheetName, "healthDetails", rowCount);
                String pastTravelContry = reader.getCellData(sheetName, "pastTravelContry", rowCount);
                String pastTravelCity = reader.getCellData(sheetName, "pastTravelCity", rowCount);
                String pastTravelArrivalDay = reader.getCellData(sheetName, "pastTravelArrivalDay", rowCount);
                String pastTravelArraivalMonth = reader.getCellData(sheetName, "pastTravelArraivalMonth", rowCount);
                String pastTravelArraivalYear = reader.getCellData(sheetName, "pastTravelArraivalYear", rowCount);
                String pastTravelDepartureDay = reader.getCellData(sheetName, "pastTravelDepartureDay", rowCount);
                String pastTravelDepartureMonth = reader.getCellData(sheetName, "pastTravelDepartureMonth", rowCount);
                String pastTravelDepartureYear = reader.getCellData(sheetName, "pastTravelDepartureYear", rowCount);
                String futureTravelCountry = reader.getCellData(sheetName, "futureTravelCountry", rowCount);
                String futureTravelCity = reader.getCellData(sheetName, "futureTravelCity", rowCount);
                String futureTravelDepartureDay = reader.getCellData(sheetName, "futureTravelDepartureDay", rowCount);
                String futureTravelDepartureMonth = reader.getCellData(sheetName, "futureTravelDepartureMonth", rowCount);
                String futureTravelDepartureYear = reader.getCellData(sheetName, "futureTravelDepartureYear", rowCount);
                String futureInternedDuration = reader.getCellData(sheetName, "futureInternedDuration", rowCount);
                String covidVaccinationFirstDoseDay = reader.getCellData(sheetName, "covidVaccinationFirstDoseDay", rowCount);
                String covidVaccinationFirstDoseMonth = reader.getCellData(sheetName, "covidVaccinationFirstDoseMonth", rowCount);
                String covidVaccinationFirstDoseYear = reader.getCellData(sheetName, "covidVaccinationFirstDoseYear", rowCount);
                String covidVaccinationSecondDoseDay = reader.getCellData(sheetName, "covidVaccinationSecondDoseDay", rowCount);
                String covidVaccinationSecondDoseMonth = reader.getCellData(sheetName, "covidVaccinationSecondDoseMonth", rowCount);
                String covidVaccinationSecondDoseYear = reader.getCellData(sheetName, "covidVaccinationSecondDoseYear", rowCount);
                String covidVaccineName = reader.getCellData(sheetName, "covidVaccineName", rowCount);
                String postVaccineDetails = reader.getCellData(sheetName, "postVaccineDetails", rowCount);
                String covidOccupation = reader.getCellData(sheetName, "covidOccupation", rowCount);
                String medicalSpeciality = reader.getCellData(sheetName, "medicalSpeciality", rowCount);
                String exactNatureOfDuties = reader.getCellData(sheetName, "exactNatureOfDuties", rowCount);
                String nameOfHealthCareFacility = reader.getCellData(sheetName, "nameOfHealthCareFacility", rowCount);
                String addressOfHealthCareFacility = reader.getCellData(sheetName, "addressOfHealthCareFacility", rowCount);
                String healthAuthorityRegistered = reader.getCellData(sheetName, "healthAuthorityRegistered", rowCount);
                String covidWardDetails = reader.getCellData(sheetName, "covidWardDetails", rowCount);
                String diagnoseDay = reader.getCellData(sheetName, "diagnoseDay", rowCount);
                String diagnoseMonth = reader.getCellData(sheetName, "diagnoseMonth", rowCount);
                String diagnoseYear = reader.getCellData(sheetName, "diagnoseYear", rowCount);
                String daignoseTestName = reader.getCellData(sheetName, "daignoseTestName", rowCount);
                String receivedCovid19Test1 = reader.getCellData(sheetName, "receivedCovid19Test1", rowCount);
                String receivedCovid19Test2 = reader.getCellData(sheetName, "receivedCovid19Test2", rowCount);
                String receivedCovid19Test3 = reader.getCellData(sheetName, "receivedCovid19Test3", rowCount);
                String admissionDay = reader.getCellData(sheetName, "admissionDay", rowCount);
                String admissionMonth = reader.getCellData(sheetName, "admissionMonth", rowCount);
                String admissionYear = reader.getCellData(sheetName, "admissionYear", rowCount);
                String dischargeDay = reader.getCellData(sheetName, "dischargeDay", rowCount);
                String dischargeMonth = reader.getCellData(sheetName, "dischargeMonth", rowCount);
                String dischargeYear = reader.getCellData(sheetName, "dischargeYear", rowCount);
                String covidInfectionDetails = reader.getCellData(sheetName, "covidInfectionDetails", rowCount);
                String covidSymptoms1 = reader.getCellData(sheetName, "covidSymptoms1", rowCount);
                String covidSymptoms2 = reader.getCellData(sheetName, "covidSymptoms2", rowCount);
                String covidSymptoms3 = reader.getCellData(sheetName, "covidSymptoms3", rowCount);
                String recoveryDay = reader.getCellData(sheetName, "recoveryDay", rowCount);
                String recoveryMonth = reader.getCellData(sheetName, "recoveryMonth", rowCount);
                String recoveryYear = reader.getCellData(sheetName, "recoveryYear", rowCount);
                String testsName = reader.getCellData(sheetName, "testsName", rowCount);
                String testTakenDay = reader.getCellData(sheetName, "testTakenDay", rowCount);
                String testTakenMonth = reader.getCellData(sheetName, "testTakenMonth", rowCount);
                String testTakenYear = reader.getCellData(sheetName, "testTakenYear", rowCount);
                String certifiedDetails = reader.getCellData(sheetName, "certifiedDetails", rowCount);

                String PolicyNumber = reader.getCellData(sheetName, "PolicyNumber", rowCount);
                String PolicyAmount = reader.getCellData(sheetName, "PolicyAmount", rowCount);

                Object ob[] = {username.trim(), password.trim(), policy.trim(), leadid.trim(), proposersame.trim(), relationwithinsured.trim(), isrelationanswer.trim(),
                        isnri.trim(), pmobile.trim(), ppan.trim(), imobile.trim(), ipan.trim(), firstname.trim(), lastname.trim(),
                        middlename.trim(), day.trim(), month.trim(), year.trim(),
                        gender.trim(), planjourney.trim(), proposerstate.trim(), advisorstatesame.trim(), plan.trim(), sumassured.trim(), smokertype.trim(), planoptions.trim(), increasinglevel.trim(),
                        ecs.trim(), term.trim(), ppt.trim(), premiumterm.trim(), premiumamount.trim(), rider.trim(), rideramount.trim(), minrider.trim(), maxrider.trim(), ridererror.trim(), click.trim(),
                        generateillustrations.trim(), clickcontinue.trim(), ifsccode.trim(), bankaccno.trim(), accholdername.trim(),
                        accounttype.trim(), pennyalert.trim(), clickverify.trim(), renewpremiumscreentitle.trim(), paymentmethod.trim(),
                        drawdate.trim(), fundsource.trim(), nomineescreentitle.trim(), nomineefirstname.trim(), nomineelastname.trim(), nomineeday.trim(),
                        nomineemonth.trim(), nomineeyear.trim(), nomineegender.trim(), relationshipwithproposer.trim(), nomineeshare.trim(), ismwppolicy.trim(), addressscreentitle.trim(),
                        typeofaddress.trim(), addresspincode.trim(), address1.trim(), address2.trim(), address3.trim(), personalDetailsscreentitle.trim(), cityName.trim(),
                        preferredLanguage.trim(), alernateNumber.trim(), resTelephoneNumber.trim(), emailaddressValidations.trim(), maritalStatus.trim(),
                        fathersNameOrSpouseName.trim(), mothersName.trim(), MaidenName.trim(), qualification.trim(), occupation.trim(), employeerName.trim(),
                        nameOfBusinessOrduties.trim(), typeOfOrganization.trim(), designation.trim(), annualIncome.trim(), policyStatus.trim(), exPolicyscreenTitle.trim(), exNameofInsurer.trim(),
                        exSumAssured.trim(), expolicyNumber.trim(), exyearOfApplication.trim(), exbasePlan.trim(), exannualpremium.trim(), medicalPolicy.trim(), expolicystatus.trim(),
                        refPolicyscreenTitle.trim(), refinsurerName.trim(), refsumAssured.trim(), refreason.trim(), refinsurerName1.trim(), refsumAssured1.trim(), refreason1.trim(),
                        refinsurerName2.trim(), refsumAssured2.trim(), refreason2.trim(), refinsurerName3.trim(), refsumAssured3.trim(), refreason3.trim(),
                        refinsurerName4.trim(), refsumAssured4.trim(), refreason4.trim(), policyPurposeScreen.trim(), purposeOption1.trim(), purposeOption2.trim(), purposeOption3.trim(),
                        healthDetailsScreen.trim(), height.trim(), weight.trim(), weightchange.trim(), symptomsDetails.trim(), testsDetails.trim(), covidContactDetails.trim(), quarantineDetails.trim(), healthDetails.trim(),
                        pastTravelContry.trim(), pastTravelCity.trim(), pastTravelArrivalDay.trim(), pastTravelArraivalMonth.trim(), pastTravelArraivalYear.trim(),
                        pastTravelDepartureDay.trim(), pastTravelDepartureMonth.trim(), pastTravelDepartureYear.trim(), futureTravelCountry.trim(), futureTravelCity.trim(),
                        futureTravelDepartureDay.trim(), futureTravelDepartureMonth.trim(), futureTravelDepartureYear.trim(), futureInternedDuration.trim(),
                        covidVaccinationFirstDoseDay.trim(), covidVaccinationFirstDoseMonth.trim(), covidVaccinationFirstDoseYear.trim(), covidVaccinationSecondDoseDay.trim(),
                        covidVaccinationSecondDoseMonth.trim(), covidVaccinationSecondDoseYear.trim(), covidVaccineName.trim(), postVaccineDetails.trim(),
                        covidOccupation.trim(), medicalSpeciality.trim(), exactNatureOfDuties.trim(), nameOfHealthCareFacility.trim(),
                        addressOfHealthCareFacility.trim(), healthAuthorityRegistered.trim(), covidWardDetails.trim(), diagnoseDay.trim(),
                        diagnoseMonth.trim(), diagnoseYear.trim(), daignoseTestName.trim(), receivedCovid19Test1.trim(), receivedCovid19Test2.trim(), receivedCovid19Test3.trim(),
                        admissionDay.trim(), admissionMonth.trim(), admissionYear.trim(), dischargeDay.trim(), dischargeMonth.trim(), dischargeYear.trim(),
                        covidInfectionDetails.trim(), covidSymptoms1.trim(), covidSymptoms2.trim(), covidSymptoms3.trim(), recoveryDay.trim(), recoveryMonth.trim(), recoveryYear.trim(),
                        testsName.trim(), testTakenDay.trim(), testTakenMonth.trim(), testTakenYear.trim(), certifiedDetails.trim(),PolicyNumber.trim(),PolicyAmount.trim()};

                myData.add(ob);
            }
        }
        System.out.println("mydata rows value **********" + myData.toString());
        return myData;
    }

    public String getData(String testName, String sheetName, String cell) throws IOException {
        return new ExcelUtils().getCellData(new PropertiesUtils().getProperties("testExcelSheet"),
                testName, new PropertiesUtils().getProperties(sheetName), cell);
    }
}
