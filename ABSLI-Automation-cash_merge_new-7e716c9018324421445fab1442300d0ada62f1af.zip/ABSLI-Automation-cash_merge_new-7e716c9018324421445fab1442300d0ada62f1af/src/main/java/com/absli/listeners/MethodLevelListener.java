package com.absli.listeners;

import com.ssts.pcloudy.exception.ConnectError;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.IInvokedMethod;
        import org.testng.IInvokedMethodListener;
        import org.testng.ITestResult;
import tests.BaseTest;

import java.io.IOException;

public class MethodLevelListener extends BaseTest implements IInvokedMethodListener {
    WebDriver driver = null;

    @Override
    public void afterInvocation(IInvokedMethod method, ITestResult result) {
        System.out.println("This method is invoked after every config method - " + method.getTestMethod().getMethodName());

        try {
            driver = (RemoteWebDriver) setupDriver("web","browser","model","local","appType",
                    "QA","false","");
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ConnectError connectError) {
            connectError.printStackTrace();
        }

    }

    @Override
    public void beforeInvocation(IInvokedMethod method, ITestResult result) {
        System.out.println("This method is invoked before every config method - " + method.getTestMethod().getMethodName());



    }

}
