package com.absli.listeners;
import com.ssts.pcloudy.exception.ConnectError;
import io.qameta.allure.Attachment;
import org.apache.xpath.operations.Bool;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.*;
import tests.BaseTest;

import java.io.IOException;

public class SuiteLevelDriverCreator extends BaseTest implements ISuiteListener {
    public static String testMethodName = "";
    private static final String DRIVER = "driver";


    @Override
    public void onStart(ISuite suite) {
        RemoteWebDriver driver = null;
        String platformName = suite.getParameter("platformName");
        String env = suite.getParameter("env");
        String platformType = suite.getParameter("platformType");
        String appType = suite.getParameter("appType");
        String runType = suite.getParameter("runType");
        String myDeviceContext = suite.getParameter("myDeviceContext");
        String headless = suite.getParameter("headless");
        String model = suite.getParameter("model");

        try {
            driver = (RemoteWebDriver) setupDriver(platformType,platformName,model,runType,appType,env,headless,myDeviceContext);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ConnectError connectError) {
            connectError.printStackTrace();
        }
        suite.setAttribute(DRIVER, driver);
    }

    @Override
    public void onFinish(ISuite suite) {
        Object driver = suite.getAttribute(DRIVER);
        if (driver == null) {
            return;
        }
        if (!(driver instanceof RemoteWebDriver)) {
            throw new IllegalStateException("Corrupted WebDriver.");
        }
        ((RemoteWebDriver) driver).quit();
        suite.setAttribute(DRIVER, null);
    }

    /**
     * @return - A valid {@link RemoteWebDriver} instance only when invoked from within a <code>@Test</code> annotated
     * test method.
     */
    public  RemoteWebDriver getDriver() {
        ITestResult result = Reporter.getCurrentTestResult();
        if (result == null) {
            throw new UnsupportedOperationException("Please invoke only from within an @Test method");
        }
        Object driver = result.getTestContext().getSuite().getAttribute(DRIVER);
        if (driver == null) {
            throw new IllegalStateException("Unable to find a valid webdriver instance");
        }
        if (!(driver instanceof RemoteWebDriver)) {
            throw new IllegalStateException("Corrupted WebDriver.");
        }
        return (RemoteWebDriver) driver;
    }



    }



