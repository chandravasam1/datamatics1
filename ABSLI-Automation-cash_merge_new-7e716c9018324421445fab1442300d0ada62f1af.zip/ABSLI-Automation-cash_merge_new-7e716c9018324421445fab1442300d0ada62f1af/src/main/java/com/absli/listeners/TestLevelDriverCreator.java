package com.absli.listeners;

import com.absli.utils.CommonUtils;
import com.ssts.pcloudy.exception.ConnectError;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.ios.IOSDriver;
import io.qameta.allure.Attachment;
import io.qameta.allure.Allure;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import org.testng.Reporter;
import tests.BaseTest;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;

public class TestLevelDriverCreator extends BaseTest implements ITestListener {

    public static String testMethodName = "";

    private static final String DRIVER = "driver";
    @Override
    public void onTestStart(ITestResult iTestResult) {
        System.out.println("*************************************");
        System.out.println("******* TEST START: "+iTestResult.getMethod().getMethodName()+" - "+iTestResult.getMethod().getDescription());
        System.out.println("*************************************");
        testMethodName = iTestResult.getMethod().getMethodName();
    }

    @Override
    public void onTestSuccess(ITestResult iTestResult) {
        System.out.println("*************************************");
        System.out.println("******* TEST PASS: "+iTestResult.getMethod().getMethodName()+" - "+iTestResult.getMethod().getDescription());
        System.out.println("*************************************");

    }

    /*@Override
    public void onTestFailure(ITestResult iTestResult) {
        System.out.println("**************************************");
        System.out.println("******* TEST FAIL: "+iTestResult.getMethod().getMethodName()+" - "+iTestResult.getMethod().getDescription());
        System.out.println("**************************************");
        Object testClass = iTestResult.getInstance();
        WebDriver driver = getDriver();
        if(driver instanceof AppiumDriver) {
            saveScreenshotPng(((AppiumDriver<MobileElement>) driver), iTestResult);
        }
        else if(driver instanceof WebDriver) {
            saveScreenshot(driver, iTestResult);
        }
        saveTextLog(iTestResult.getMethod().getMethodName()+"failed and screenshot taken");
    }*/

    @Override
    public void onTestFailure(ITestResult iTestResult) {
        System.out.println("**************************************");
        System.out.println("******* TEST FAIL: "+iTestResult.getMethod().getMethodName()+" - "+iTestResult.getMethod().getDescription());
        System.out.println("**************************************");
        Object testClass = iTestResult.getInstance();
        //RemoteWebDriver driver = getDriver();
        //if(driver instanceof RemoteWebDriver) {
        try {
            saveScreenshot(getDriver(), iTestResult);
        } catch (IOException e) {
            e.printStackTrace();
        }
        //}
        saveTextLog(iTestResult.getMethod().getMethodName()+"failed and screenshot taken");
    }

    @Attachment(value = "Actual Screenshot", type = "image/png")
    public byte[] saveScreenshot(RemoteWebDriver driver, ITestResult iTestResult) throws IOException {
        System.out.println("Screenshot captured for test case :"+iTestResult.getMethod().getMethodName());
        //File file  = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        /*String fileImage = "Screenshot" + new CommonUtils().getCurrentTimeStamp() +".jpg";
        FileUtils.copyFile(file, new File(fileImage));*/

        Allure.addAttachment(iTestResult.getMethod().getMethodName(), new ByteArrayInputStream(((TakesScreenshot)driver).getScreenshotAs(OutputType.BYTES)));
        return ((TakesScreenshot)driver).getScreenshotAs(OutputType.BYTES);
    }

    @Override
    public void onTestSkipped(ITestResult iTestResult) {
        System.out.println("*************************************");
        System.out.println("******* TEST SKIP:"+iTestResult.getMethod().getMethodName()+" - "+iTestResult.getMethod().getDescription());
        System.out.println("*************************************");
        //RemoteWebDriver driver = getDriver();
        //if(driver instanceof RemoteWebDriver) {
        try {
            saveScreenshot(getDriver(), iTestResult);
        } catch (IOException e) {
            e.printStackTrace();
        }
        //}
    }

    @Override
    public void onTestFailedButWithinSuccessPercentage(ITestResult result) { }


    @Override
    public void onStart(ITestContext context) {
        RemoteWebDriver driver = null;
        String platformName = context.getCurrentXmlTest().getParameter("platformName");
        String env = context.getCurrentXmlTest().getParameter("env");
        String platformType = context.getCurrentXmlTest().getParameter("platformType");
        String appType = context.getCurrentXmlTest().getParameter("appType");
        String runType = context.getCurrentXmlTest().getParameter("runType");
        String myDeviceContext = context.getCurrentXmlTest().getParameter("myDeviceContext");
        String headless = context.getCurrentXmlTest().getParameter("headless");
        String model = context.getCurrentXmlTest().getParameter("model");

        try {
            driver = (RemoteWebDriver) setupDriver(platformType,platformName,model,runType,appType,env,headless,myDeviceContext);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ConnectError connectError) {
            connectError.printStackTrace();
        }
        context.setAttribute(DRIVER, driver);
    }

    @Override
    public void onFinish(ITestContext context) {
        Object driver = context.getAttribute(DRIVER);
        if (driver == null) {
            return;
        }
        if (!(driver instanceof RemoteWebDriver)) {
            throw new IllegalStateException("Corrupted WebDriver.");
        }
        ((RemoteWebDriver) driver).quit();
        context.setAttribute(DRIVER, null);
    }

    /**
     * @return - A valid {@link RemoteWebDriver} instance only when invoked from within a <code>@Test</code> annotated
     * test method.
     */
    public  RemoteWebDriver getDriver() {
        ITestResult result = Reporter.getCurrentTestResult();
        if (result == null) {
            throw new UnsupportedOperationException("Please invoke only from within an @Test method");
        }
        Object driver = result.getTestContext().getAttribute(DRIVER);
        if (driver == null) {
            throw new IllegalStateException("Unable to find a valid webdriver instance");
        }
        if (!(driver instanceof RemoteWebDriver)) {
            throw new IllegalStateException("Corrupted WebDriver.");
        }
        return (RemoteWebDriver) driver;
    }

    //Text attachment for allure
    @Attachment(value = "{0}",type = "text/plain")
    public static String saveTextLog(String message) {
        return message;
    }
}

