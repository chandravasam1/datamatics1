package com.absli.pageObjects;

import com.absli.utils.CommonUtils;
import com.absli.utils.WaitUtils;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import tests.BaseTest;

import java.util.List;

import static com.absli.logger.LoggingManager.logMessage;

public class SignInPage extends Page {

    public WebDriver driver;
    WaitUtils waitUtils;
    CommonUtils utils;

    public SignInPage(WebDriver driver)  {
        this.driver = driver;
        waitUtils = new WaitUtils();
        utils = new CommonUtils();
        PageFactory.initElements(driver, this);
        logMessage("Initializing the " + this.getClass().getSimpleName() + " elements");
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
    }
    //@FindBy(xpath = "")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Login']")
    //@iOSXCUITFindBy(id = "")
    private WebElement eleSignInTitle;

    @FindBy(css = "#loginId")
    @AndroidFindBy(accessibility = "userName")
    //@iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name=\"userName\"]")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeTextField' AND name BEGINSWITH[c] 'userName'")
    public WebElement eleSignInUsername;

    @FindBy(css = "input#password")
    @AndroidFindBy(xpath = "//android.widget.EditText[@index=1]")
    //@iOSXCUITFindBy(xpath = "//XCUIElementTypeSecureTextField[@name=\"password\"]")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeSecureTextField' AND name BEGINSWITH[c] 'password'")
    public WebElement eleSignInPassword;


    @FindBy(xpath = "//button[@type=\"submit\"]")
    @AndroidFindBy(accessibility = "userLoginBtn")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeButton' AND name BEGINSWITH[c] 'userLoginBtn'")
    public WebElement eleSignInButton;

    @FindBy(xpath = "//div[text()='Dashboard']")
    @AndroidFindBy(xpath = "//android.view.View[@text='Dashboard']")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeOther[`label == \"Dashboard\"`][9]")
    public WebElement eleDashboardTitle;

    @FindBy(css = "#loginId-helper-text")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Please enter User ID']")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name=\"inputHelperText\"])[1]")
    public WebElement eleSignInUserIdErrorMessage;

    @FindBy(css = "#password-helper-text")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Please enter Password']")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name=\"inputHelperText\"])[2]")
    public WebElement eleSignInPasswordErrorMessage;

    @FindBy(css = "#rememberme")
    @AndroidFindBy(xpath = "//android.widget.CheckBox[@index=3]")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"rememberMe\"])[1]")
    public WebElement eleSignInRememberMeCheckBox;

    @FindBy(xpath = "//button[@class='MuiButtonBase-root MuiIconButton-root MuiIconButton-edgeEnd']")
    @AndroidFindBy(xpath = "//android.widget.Button[@index=2]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"rightIcon\"]")
    public WebElement eleSignPasswordEyeIcon;

    @FindBy(css = "input#password")
    @AndroidFindBy(xpath = "//android.widget.EditText[@index=1]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name=\"password\"]")
    private WebElement elePlainPasswordTextField;

    public void inputUsername(String username)  {
        System.out.println("Selected   Username ==========>" + eleSignInUsername);
        this.eleSignInUsername.click();
        this.eleSignInUsername.clear();
        this.eleSignInUsername.sendKeys(username);
        logMessage("entered username =======>");
    }

    public void inputPassword(String password) {
        this.eleSignInPassword.click();
        this.eleSignInPassword.clear();
        this.eleSignInPassword.sendKeys(password);
        logMessage("entered password =======>");

    }

    public void clickSignInButton() {
        this.eleSignInButton.click();
    }

    public boolean isLoggedIn() {
        Boolean isLoggedIn = true;
        waitUtils.implicitWait(driver,100);
        try {
            waitUtils.waitForElementToBeVisible(driver,eleSignInButton);
            eleSignInButton.isDisplayed();
            isLoggedIn = false;
        } catch (NoSuchElementException e) {
            isLoggedIn = true;
            return isLoggedIn;
        }
        catch (TimeoutException e) {
            isLoggedIn = true;
            return isLoggedIn;
        }
        return isLoggedIn;
    }

    public void signIn(String username,String pwd) {
        if(!isLoggedIn()) {
            this.inputUsername(username);
            waitUtils.waitForElementToBeClickable(driver,eleSignInPassword,30);
            this.inputPassword(pwd);
            switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
                case "android" :
                    ((AndroidDriver)driver).hideKeyboard();
                    break;
                case "ios":
                    eleSignInPassword.sendKeys("\n");
                    //((IOSDriver)driver).getKeyboard().pressKey("\n");

                    //((IOSDriver)driver).hideKeyboard();
                    //new CommonUtils().enterKey(eleSignInPassword,driver);
                    break;
                default:
                    break;
            }
            waitUtils.waitForElementToBeClickable(driver,eleSignInButton,10);
            //this.clickSignInButton();
            this.clickSignInButton();
            logMessage("clicked on sign in button");
        }
    }

    public boolean elementIsDisplayed(WebElement element) throws InterruptedException {
        logMessage(element.toString());
        return element.isDisplayed();
    }

    public boolean verifyPasswordFieldIsDisplayed() {
        return this.eleSignInPassword.isDisplayed();
    }

    public String getPlainTextPassword(){
        return this.elePlainPasswordTextField.getText();
    }

    public String getMessage(WebElement element) {
        return element.getText();
    }

    public void clearSignInFieldValues() {
        this.eleSignInUsername.click();
        this.eleSignInUsername.clear();
        this.eleSignInPassword.click();
        this.eleSignInPassword.clear();
    }

    public void clickOnRememberMe() {
        clickElement(eleSignInRememberMeCheckBox);
    }

    public void navigateBack() {
        driver.navigate().back();
    }

    public String getText(WebElement element) {
        return element.getText();
    }

    public boolean verifyDashboardIsDisplayed() {
        waitUtils.implicitWait(driver,WaitUtils.MIN_TIMEOUT_MILLISEC);
        try {
            return this.eleDashboardTitle.isDisplayed();
        } catch (NoSuchElementException e) {
            logMessage("Element not found:"+ eleDashboardTitle);
            return false;
        }
    }

    public boolean verifyUsernameErrorIsDisplayed() {
        waitUtils.implicitWait(driver,WaitUtils.MIN_TIMEOUT_MILLISEC);
        try {
            return this.eleSignInUserIdErrorMessage.isDisplayed();
        } catch (NoSuchElementException e) {
            logMessage("Element not found:"+ eleSignInUserIdErrorMessage);
            return false;
        }
    }
    public boolean verifyPasswordErrorIsDisplayed() {
        waitUtils.implicitWait(driver,WaitUtils.MIN_TIMEOUT_MILLISEC);
        try {
            return this.eleSignInPasswordErrorMessage.isDisplayed();
        } catch (NoSuchElementException e) {
            logMessage("Element not found:"+ eleSignInPasswordErrorMessage);
            return false;
        }
    }

    public void logOut() {
        driver.findElement(By.xpath("//span[text()='Logout']")).click();
    }
}
