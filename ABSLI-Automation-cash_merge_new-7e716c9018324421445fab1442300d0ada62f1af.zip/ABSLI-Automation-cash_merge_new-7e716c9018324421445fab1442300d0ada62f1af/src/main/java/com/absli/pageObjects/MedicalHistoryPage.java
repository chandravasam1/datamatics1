package com.absli.pageObjects;

import com.absli.helpers.jsonReaders.ReadJson;
import com.absli.helpers.models.LoginModel;
import com.absli.helpers.models.ProposerModel;
import com.absli.utils.CommonUtils;
import com.absli.utils.WaitUtils;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import tests.BaseTest;

import static com.absli.logger.LoggingManager.logMessage;

public class MedicalHistoryPage extends Page{
    WebDriver driver;
    CommonUtils commonUtils;
    ReadJson jsonObj;
    LoginModel loginModel;
    SignInPage signIn;
    DashboardPage dashPage;
    WaitUtils waitUtils;
    ProposerModel proposerModel;

    public MedicalHistoryPage(WebDriver driver) throws InterruptedException {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        logMessage("Initializing the " + this.getClass().getSimpleName() + " elements");
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);

        waitUtils = new WaitUtils();
        commonUtils = new CommonUtils();
    }

    @FindBy(xpath = "//div[contains(text(),'8.0 Health Details')]")
    @AndroidFindBy(xpath = "//android.view.View[@text='8.0 Health Details']")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"8.0 Health Details\"])[2]")
    public WebElement healthDetailsTitle;

    public String getPageTitle(){
        String pageTitle = "";
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                pageTitle=this.healthDetailsTitle.getText();
                break;
            case "ios":
                pageTitle=this.healthDetailsTitle.getText();
                break;
            default:
                WebElement element=driver.findElement((By.xpath("//div[contains(text(),'8.0 Health Details')]")));
                pageTitle=element.getText();
        }
        return pageTitle;
    }
    @FindBy(xpath = "//div[contains(text(),'Medical History')]")
    @AndroidFindBy(accessibility = "Medical History")
    @iOSXCUITFindBy(accessibility = "Medical History")
    public WebElement moduleTitle;

    public void getModuleName(String nameOfModule){
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                commonUtils.scrollIntoView(nameOfModule,driver);
                this.moduleTitle.click();
                break;
            case "ios":
                commonUtils.scrollIntoView(nameOfModule,driver);
                this.moduleTitle.click();
                break;
            default:
                WebElement element=driver.findElement((By.xpath("//div[contains(text(),'"+nameOfModule+"')]")));
                commonUtils.scrollToElement(driver,element);
                element.click();
        }

    }
    @FindBy(xpath = "//div[contains(text(),'Absent from Work')]/ancestor::div[@class='card-title-container']/following-sibling::div//div[text()='Yes']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Absent from Work']//following-sibling::android.view.ViewGroup//android.widget.TextView[@text='Yes']")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"Yes\"])[1]")
    public WebElement elementSection;

    public void gotoSection(String sectionName){
        WebElement element;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                element   =driver.findElement(By.xpath("//android.widget.TextView[@text='"+sectionName+"']//following-sibling::android.view.ViewGroup//android.widget.TextView[@text='Yes']"));
                element.click();
                break;
            case "ios":
                element=driver.findElement(By.xpath("(//XCUIElementTypeStaticText[@name=\"" + sectionName + "\"]/parent::XCUIElementTypeOther/..//XCUIElementTypeOther[contains(@name,'Yes')])[5]"));
                element.click();
                break;
            default:
                element=driver.findElement((By.xpath("//div[contains(text(),'"+sectionName+"')]/ancestor::div[@class='card-title-container']/following-sibling::div//div[text()='Yes']")));
                element.click();
                break;
        }

    }
    public WebElement gotoSectionElement(String sectionName){
        WebElement element = null;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                element   =driver.findElement(By.xpath("//android.widget.TextView[@text='"+sectionName+"']//following-sibling::android.view.ViewGroup//android.widget.TextView[@text='Yes']"));
                element.click();
                break;
            case "ios":
                element=driver.findElement(By.xpath("(//XCUIElementTypeStaticText[@name=\"" + sectionName + "\"]/parent::XCUIElementTypeOther/..//XCUIElementTypeOther[contains(@name,'Yes')])[5]"));
                element.click();
                break;
            default:
                element=driver.findElement((By.xpath("//div[contains(text(),'"+sectionName+"')]/ancestor::div[@class='card-title-container']/following-sibling::div//div[text()='Yes']")));
                element.click();
                break;
        }
        return element;
    }
    @FindBy(xpath = "//div[contains(text(),'Absent from Work')]/ancestor::div[@class='card-title-container']/following-sibling::div//div[text()='Yes']/ancestor::div/following-sibling::div//input")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Absent from Work']//following-sibling::android.view.ViewGroup//android.widget.TextView[@text='Provide Details']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name=\"402\"]")
    public WebElement absentDetials;

    public void setCurrentSymptoms(String sectionName,String description){
        WebElement element;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                commonUtils.scrollIntoView(sectionName,driver);
                element=driver.findElement(By.xpath("//android.widget.TextView[@text='"+sectionName+"']//following-sibling::android.view.ViewGroup//android.widget.TextView[@text='Provide Details']"));
                element.sendKeys(description);
                break;
            case "ios":
                commonUtils.scrollIntoView(sectionName,driver);
                element=driver.findElement(By.xpath("//XCUIElementTypeStaticText[@name=\"Current Symptoms\"]"));
                element.sendKeys(description);

                break;
            default:
                //element  =driver.findElement(By.xpath("//div[contains(text(),'"+sectionName+"')]/ancestor::div[@class='card-title-container']/following-sibling::div//div[text()='Yes']/ancestor::div[@class='jss562']/following-sibling::div[contains(@class,'jss629')]//input"));
                this.absentDetials.sendKeys(description);
        }
    }
    public void setDoctorsDetails(String sectionName,String description){
        WebElement element;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                commonUtils.scrollIntoView(sectionName,driver);
                element=driver.findElement(By.xpath("//android.widget.TextView[@text='"+sectionName+"']//following-sibling::android.view.ViewGroup//android.widget.TextView[@text='Provide Details']"));
                element.sendKeys(description);
                break;
            case "ios":
                commonUtils.scrollIntoView(sectionName,driver);
                //XCUIElementTypeStaticText[@name="Details of Hospitalization"]
                element=driver.findElement(By.xpath("//XCUIElementTypeStaticText[@name=\"Doctor's Detail\"]"));
               // element=driver.findElement(By.xpath("//XCUIElementTypeTextField[@name=\"88\"]"));
                element.sendKeys(description);

                break;
            default:
                //element  =driver.findElement(By.xpath("//div[contains(text(),'"+sectionName+"')]/ancestor::div[@class='card-title-container']/following-sibling::div//div[text()='Yes']/ancestor::div[@class='jss562']/following-sibling::div[contains(@class,'jss629')]//input"));
                this.absentDetials.sendKeys(description);
        }
    }
    @FindBy(xpath = "//label[contains(text(),'Date of Last Consultation')]/parent::div//input[@id='DD']")
    @AndroidFindBy(xpath = "(//android.widget.TextView[@text='Date of Last Consultation']/..//android.widget.TextView[@text='DD'])[1]")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[contains(@name,'Date of Last Consultation')]/..//XCUIElementTypeOther[@name=\"day\"])[1]")
    public WebElement lastConsultationDay;

    public void lastConsultationday(String lastConsultationDay){
        WebElement day;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                day=driver.findElement(By.xpath("(//android.widget.TextView[@text='Date of Last Consultation']/..//android.widget.TextView[@text='DD'])[1]"));
                day.sendKeys(lastConsultationDay);
                break;
            case "ios":
                day=driver.findElement(By.xpath("(//XCUIElementTypeOther[contains(@name,'Date of Last Consultation')]/..//XCUIElementTypeOther[@name=\"day\"])[1]"));
                day.sendKeys(lastConsultationDay);
                break;
            default:
                day=driver.findElement(By.xpath("//label[contains(text(),'Date of Last Consultation')]/parent::div//input[@id='DD']"));
                day.sendKeys(lastConsultationDay);
                break;
        }
    }
    @FindBy(xpath = "//label[contains(text(),'Date of Last Consultation')]/parent::div//input[@id='MM']")
    @AndroidFindBy(xpath = "(//android.widget.TextView[@text='Date of Last Consultation']/..//android.widget.TextView[@text='MM'])[1]")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[contains(@name,'Date of Last Consultation')]/..//XCUIElementTypeOther[@name=\"month\"])[1]")
    public WebElement lastConsultationMonth;

    public void lastConsultationMonth(String lastConsultationMonth){
        WebElement month;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                month=driver.findElement(By.xpath("(//android.widget.TextView[@text='Date of Last Consultation']/..//android.widget.TextView[@text='MM'])[1]"));
                month.sendKeys(lastConsultationMonth);
                break;
            case "ios":
                month=driver.findElement(By.xpath("(//XCUIElementTypeOther[contains(@name,'Date of Last Consultation')]/..//XCUIElementTypeOther[@name=\"month\"])[1]"));
                month.sendKeys(lastConsultationMonth);
                break;
            default:
                month=driver.findElement(By.xpath("//label[contains(text(),'Date of Last Consultation')]/parent::div//input[@id='MM']"));
                month.sendKeys(lastConsultationMonth);
                break;
        }
    }
    @FindBy(xpath = "//label[contains(text(),'Date of Last Consultation')]/parent::div//input[@id='YYYY']")
    @AndroidFindBy(xpath = "(//android.widget.TextView[@text='Date of Last Consultation']/..//android.widget.TextView[@text='YYYY'])[1]")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[contains(@name,'Date of Last Consultation')]/..//XCUIElementTypeOther[@name=\"year\"])[1]")
    public WebElement lastConsultationYear;

    public void lastConsultationYear(String lastConsultationYear){
        WebElement year;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                year=driver.findElement(By.xpath("(//android.widget.TextView[@text='Date of Last Consultation']/..//android.widget.TextView[@text='YYYY'])[1]"));
                year.sendKeys(lastConsultationYear);
                break;
            case "ios":
                year=driver.findElement(By.xpath("(//XCUIElementTypeOther[contains(@name,'Date of Last Consultation')]/..//XCUIElementTypeOther[@name=\"year\"])[1]"));
                year.sendKeys(lastConsultationYear);
                break;
            default:
                year=driver.findElement(By.xpath("//label[contains(text(),'Date of Last Consultation')]/parent::div//input[@id='YYYY']"));
                year.sendKeys(lastConsultationYear);
                break;
        }
    }
    @FindBy(xpath = "//label[contains(text(),'Date of Diagnosis')]/parent::div//input[@id='DD']")
    @AndroidFindBy(xpath = "(//android.widget.TextView[@text='Date of Diagnosis']/..//android.widget.TextView[@text='DD'])[1]")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[contains(@name,'Date of Diagnosis')]/..//XCUIElementTypeOther[@name=\"day\"])[1]")
    public WebElement diagnosisday;

    public void diagnosisday(String diagnosisday){
        WebElement day;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                commonUtils.scrollIntoView("Date of Diagnosis",driver);
                day=driver.findElement(By.xpath("(//android.widget.TextView[@text='Date of Diagnosis']/..//android.widget.TextView[@text='DD'])[1]"));
                day.sendKeys(diagnosisday);
                break;
            case "ios":
                day=driver.findElement(By.xpath("(//XCUIElementTypeOther[contains(@name,'Date of Diagnosis')]/..//XCUIElementTypeOther[@name=\"day\"])[2]"));
                day.sendKeys(diagnosisday);
                break;
            default:
                day=driver.findElement(By.xpath("//label[contains(text(),'Date of Diagnosis')]/parent::div//input[@id='DD']"));
                day.sendKeys(diagnosisday);
                break;
        }
    }
    @FindBy(xpath = "//label[contains(text(),'Date of Diagnosis')]/parent::div//input[@id='MM']")
    @AndroidFindBy(xpath = "(//android.widget.TextView[@text='Date of Diagnosis']/..//android.widget.TextView[@text='MM'])[1]")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[contains(@name,'Date of Diagnosis')]/..//XCUIElementTypeOther[@name=\"month\"])[1]")
    public WebElement diagnosisMonth;

    public void diagnosisMonth(String diagnosisMonth){
        WebElement month;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                month=driver.findElement(By.xpath("(//android.widget.TextView[@text='Date of Diagnosis']/..//android.widget.TextView[@text='MM'])[1]"));
                month.sendKeys(diagnosisMonth);
                break;
            case "ios":
                month=driver.findElement(By.xpath("(//XCUIElementTypeOther[contains(@name,'Date of Diagnosis')]/..//XCUIElementTypeOther[@name=\"month\"])[1]"));
                month.sendKeys(diagnosisMonth);
                break;
            default:
                month=driver.findElement(By.xpath("//label[contains(text(),'Date of Diagnosis')]/parent::div//input[@id='MM']"));
                month.sendKeys(diagnosisMonth);
                break;
        }
    }
    @FindBy(xpath = "//label[contains(text(),'Date of Diagnosis')]/parent::div//input[@id='YYYY']")
    @AndroidFindBy(xpath = "(//android.widget.TextView[@text='Date of Diagnosis']/..//android.widget.TextView[@text='YYYY'])[1]")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[contains(@name,'Date of Diagnosis')]/..//XCUIElementTypeOther[@name=\"year\"])[1]")
    public WebElement diagnosisYear;

    public void diagnosisYear(String diagnosisYear){
        WebElement year;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                year=driver.findElement(By.xpath("(//android.widget.TextView[@text='Date of Diagnosis']/..//android.widget.TextView[@text='YYYY'])[1]"));
                year.sendKeys(diagnosisYear);
                break;
            case "ios":
                year=driver.findElement(By.xpath("(//XCUIElementTypeOther[contains(@name,'Date of Diagnosis')]/..//XCUIElementTypeOther[@name=\"year\"])[1]"));
                year.sendKeys(diagnosisYear);
                break;
            default:
                year=driver.findElement(By.xpath("//label[contains(text(),'Date of Diagnosis')]/parent::div//input[@id='YYYY']"));
                year.sendKeys(diagnosisYear);
                break;
        }
    }
    public void hospitalizationDetails(String sectionName,String description){
        WebElement element;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                element=driver.findElement(By.xpath("//android.widget.TextView[@text='"+sectionName+"']//following-sibling::android.view.ViewGroup//android.widget.TextView[@text='Provide Details']"));
                element.sendKeys(description);
                break;
            case "ios":
                element=driver.findElement(By.xpath("//XCUIElementTypeStaticText[@name=\"Details of Hospitalization\"]"));
                element.sendKeys(description);
                break;
            default:
                //element  =driver.findElement(By.xpath("//div[contains(text(),'"+sectionName+"')]/ancestor::div[@class='card-title-container']/following-sibling::div//div[text()='Yes']/ancestor::div[@class='jss562']/following-sibling::div[contains(@class,'jss629')]//input"));
                this.absentDetials.sendKeys(description);
        }
    }
    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text,'HEART ISSUES')]/ancestor::android.view.ViewGroup/..//android.widget.TextView[@text='Chest Pain']/..//android.widget.CheckBox[@content-desc='Chest Pain']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[contains(@name,'HEART ISSUES')]/..//XCUIElementTypeOther[@name='Heart Attack']/..//XCUIElementTypeOther[contains(@value,'checkbox')]")
    public WebElement selectDiseasCheckbox;

    public void selectDiseasCheckbox(String issueSection,String issueName){
        WebElement getissueName;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                commonUtils.scrollIntoView(issueSection,driver);
                getissueName=driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'"+issueSection+"')]/ancestor::android.view.ViewGroup/..//android.widget.TextView[@text=\""+issueName+"\"]/..//android.widget.CheckBox[@content-desc='"+issueName+"']"));
                getissueName.click();
                break;
            case "ios":
                commonUtils.scrollIntoView(issueSection,driver);
                getissueName=driver.findElement(By.xpath("//XCUIElementTypeOther[contains(@name,'"+issueSection+"')]/..//XCUIElementTypeOther[@name='"+issueName+"']/..//XCUIElementTypeOther[contains(@value,'checkbox')]"));
                getissueName.click();
                break;

            default:
                break;
        }

    }
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Please enter this field']")
    public WebElement textFieldErrorMessage;

    @AndroidFindBy(xpath = "(//android.widget.TextView[@text='Current Symptoms']/ancestor::android.view.ViewGroup//android.widget.TextView[@text='Please enter this field'])[1]")
    public WebElement getTextFieldErrorMessage1;

    @AndroidFindBy(xpath = "(//android.widget.TextView[@text='Doctor's Detail']/ancestor::android.view.ViewGroup//android.widget.TextView[@text='Please enter this field'])[2]")
    public WebElement getTextFieldErrorMessage2;

    @AndroidFindBy(xpath = "(//android.widget.TextView[@text='Hospitalization']/ancestor::android.view.ViewGroup//android.widget.TextView[@text='Please enter this field'])[2]")
    public WebElement getTextFieldErrorMessage3;

    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Enter Day']")
    public WebElement dayErrorMessage;

    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Enter month']")
    public WebElement monthErrorMessage;

    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Enter year']")
    public WebElement yearErrorMessage;
}
