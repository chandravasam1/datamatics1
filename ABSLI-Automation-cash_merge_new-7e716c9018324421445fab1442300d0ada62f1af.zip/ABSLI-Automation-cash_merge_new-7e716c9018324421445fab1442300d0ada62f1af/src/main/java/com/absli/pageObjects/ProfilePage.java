package com.absli.pageObjects;

import io.appium.java_client.MobileBy;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.List;

import static com.absli.logger.LoggingManager.logMessage;

public class ProfilePage extends Page {

        WebDriver driver;

        public ProfilePage(WebDriver driver) throws InterruptedException {
            this.driver = driver;
            PageFactory.initElements(driver, this);
            logMessage("Initializing the "+this.getClass().getSimpleName()+" elements");
            PageFactory.initElements(new AppiumFieldDecorator(driver), this);
        }

        @FindBy(xpath = "//a[@title='Log In'][1]")
        @AndroidFindBy(xpath = "//android.widget.TextView[@text='Profile']")
        @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name,\"Profile\")]")
        public WebElement eleProfileTitle;

        @FindBy(css = ".name")
        @AndroidFindBy(xpath = "(//android.widget.TextView[@index=1])[2]")
        @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name,\"Profile\")]")
        public WebElement eleProfileName;

        @FindBy(xpath = "(//p[@class='contact-info'])[1]")
        @AndroidFindBy(xpath = "//android.widget.TextView[@index=6]")
        @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[contains(@name, \"BRANCH NAME\")]")
        public WebElement eleProfileBranchNameText;



        @FindBy(xpath = "(//p[@class='contact-info'])[2]")
        @AndroidFindBy(xpath = "//android.widget.TextView[@index=7]")
        @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[contains(@name, \"RECEIPTING BRANCH\")]")
        public WebElement eleProfileBranchReceiptText;


        @FindBy(xpath = "(//p[@class='contact-info'])[3]")
        @AndroidFindBy(xpath = "//android.widget.TextView[@index=10]")
        @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"BRANCH CODE\"]")
        public WebElement eleProfileBranchCodeText;

        @FindBy(xpath = "(//p[@class='contact-info'])[4]")
        @AndroidFindBy(xpath = "//android.widget.TextView[@index=11]")
        @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[contains(@name, \"REPORTING MANAGER\")]")
        public WebElement eleProfileReportingManagerText;

        @FindBy(css = "#reportingManager")
        @AndroidFindBy(xpath = "//android.widget.TextView[@index=13]")
        @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"USER CODE\"]")
        public WebElement eleProfileUserCodeText;



        @FindBy(xpath = "(//p[@class='contact-info'])[5]")
        @AndroidFindBy(xpath = "//android.widget.TextView[@index=3]")
        @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"MOBILE NO.\"]")
        public WebElement eleProfileMobileText;

        @FindBy(xpath = "(//p[@class='contact-info'])[6]")
        @AndroidFindBy(xpath = "//android.widget.TextView[@index=5]")
        @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[contains(@name,\"EMAIL ADDRESS\")]")
        public WebElement eleProfileEmailText;


        @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[contains(@name, \"REPORTING MANAGER\")]")
        public WebElement iosParentCell;

        @FindBy(css = "#initialsOfName")
        public WebElement eleProfileImage;

        @FindBy(css = ".designation")
        public WebElement eleProfileDesg;


        public String getEmail() {
                String selector = "**/XCUIElementTypeOther[`name BEGINSWITH \"EMAIL\"`]/XCUIElementTypeStaticText[2]";
                WebElement ele = driver.findElement(MobileBy.iOSClassChain(selector));
                System.out.println(ele.getText());
                return ele.getText();
        }


        public String getMobileNo() {
                String selector = "**/XCUIElementTypeOther[`name BEGINSWITH \"MOBILE\"`]/XCUIElementTypeStaticText[2]";
                WebElement ele = driver.findElement(MobileBy.iOSClassChain(selector));
                System.out.println(ele.getText());
                return ele.getText();
        }

        public String getUserCode() {
                String selector = "**/XCUIElementTypeOther[`name BEGINSWITH \"USER CODE\"`]/XCUIElementTypeStaticText[2]";
                WebElement ele = driver.findElement(MobileBy.iOSClassChain(selector));
                System.out.println(ele.getText());
                return ele.getText();
        }

        public String getReportingManager() {
                String selector = "**/XCUIElementTypeOther[`name BEGINSWITH \"REPORTING MANAGER\"`]/XCUIElementTypeStaticText[2]";
                WebElement ele = driver.findElement(MobileBy.iOSClassChain(selector));
                System.out.println(ele.getText());
                return ele.getText();
        }

        public String getBranchCode() {
                String selector = "**/XCUIElementTypeOther[`name BEGINSWITH \"BRANCH CODE\"`]/XCUIElementTypeStaticText[2]";
                WebElement ele = driver.findElement(MobileBy.iOSClassChain(selector));
                System.out.println(ele.getText());
                return ele.getText();
        }

        public String getRecBranch() {
                String selector = "**/XCUIElementTypeOther[`name BEGINSWITH \"RECEIPTING BRANCH\"`]/XCUIElementTypeStaticText[2]";
                WebElement ele = driver.findElement(MobileBy.iOSClassChain(selector));
                System.out.println(ele.getText());
                return ele.getText();
        }

        public String getBranchName() {
                String selector = "**/XCUIElementTypeOther[`name BEGINSWITH \"BRANCH NAME\"`]/XCUIElementTypeStaticText[2]";
                WebElement ele = driver.findElement(MobileBy.iOSClassChain(selector));
                System.out.println(ele.getText());
                return ele.getText();
        }































    }

