package com.absli.pageObjects;

import com.absli.helpers.jsonReaders.ReadJson;
import com.absli.helpers.models.LoginModel;
import com.absli.helpers.models.ProposerModel;
import com.absli.utils.CommonUtils;
import com.absli.utils.WaitUtils;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import tests.BaseTest;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.absli.logger.LoggingManager.logMessage;

public class QualificationPage extends Page {
    WebDriver driver;
    CommonUtils commonUtils;
    ReadJson jsonObj;
    LoginModel loginModel;
    SignInPage signIn;
    DashboardPage dashPage;
    WaitUtils waitUtils;
    ProposerModel proposerModel;

    public QualificationPage(WebDriver driver) throws InterruptedException {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        logMessage("Initializing the " + this.getClass().getSimpleName() + " elements");
        PageFactory.initElements(new AppiumFieldDecorator(driver), QualificationPage.class);

        /*jsonObj = new ReadJson();
        signIn = new SignInPage(driver);
        dashPage = new DashboardPage(driver);*/
        waitUtils = new WaitUtils();
        commonUtils = new CommonUtils();
    }

    @FindBy(name = "emailId")
    @AndroidFindBy(accessibility = "emailId")
    @iOSXCUITFindBy(className = "emailId")
    public WebElement elePersonalEmailIdInput;

    @FindBy(name = "fatherSpouseName")
    @AndroidFindBy(accessibility = "fatherSpouseName")
    @iOSXCUITFindBy(className = "fatherSpouseName")
    public WebElement eleFatherSpouseNameInput;

    @FindBy(name = "motherName")
    @AndroidFindBy(accessibility = "motherName")
    @iOSXCUITFindBy(className = "motherName")
    public WebElement eleMotherNameInput;

    @FindBy(name = "maidenName")

    public WebElement eleMaidenNameInput;

    @FindBy(xpath = "//div[@id='mui-component-select-23']")
    @AndroidFindBy(accessibility = "'23'")
    //@AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"'23'\"]/android.view.ViewGroup[1]/android.widget.Button")
    @iOSXCUITFindBy(className = "'23'")
    public WebElement eleQualificationDrpBtn;

    @FindBy(xpath = "//input[@class='MuiInputBase-input MuiFilledInput-input'][@placeholder='Others']")
    public WebElement eleOthersInput;

    @FindBy(xpath = "//p[contains(text(),'Alert')]")
    @AndroidFindBy(id = "android:id/alertTitle")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeAlert[@name=\"Alert\"]")
    public WebElement eleAlertDialog;

    @FindBy(xpath = "//span[contains(text(),'OK')]")
    @AndroidFindBy(id = "android:id/button1")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"OK\"`]")
    private WebElement eleOkButton;

    public void acceptAlert() {
        this.eleOkButton.click();
    }


    public void inputPersonalFatherSpouseName(String FatherSpouseName){
        this.eleFatherSpouseNameInput.click();
        this.eleFatherSpouseNameInput.clear();
        this.eleFatherSpouseNameInput.sendKeys(FatherSpouseName);
        commonUtils.enterKey(eleFatherSpouseNameInput,driver);
    }

    public void inputPersonalEmailId(String PersonalEmailId){
        this.elePersonalEmailIdInput.click();
        this.elePersonalEmailIdInput.clear();
        this.elePersonalEmailIdInput.sendKeys(PersonalEmailId);
        commonUtils.enterKey(elePersonalEmailIdInput,driver);
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                driver.findElement(By.xpath("//android.widget.Button[@content-desc='rightIcon']/android.widget.TextView")).click();
                if (isAlertShown()) {
                    acceptAlert();
                }
                waitUtils.waitForElementToBeVisible(driver,eleFatherSpouseNameInput,10,"Element not loaded successfully");
                break;
            case "ios":

                break;
            default:

        }
    }


    public void inputPersonalMotherName(String MotherName){
        this.eleMotherNameInput.click();
        this.eleMotherNameInput.clear();
        this.eleMotherNameInput.sendKeys(MotherName);
        commonUtils.enterKey(eleMotherNameInput,driver);
    }

    public void inputPersonalMaidenName(String MaidenName){
        this.eleMaidenNameInput.click();
        this.eleMaidenNameInput.clear();
        this.eleMaidenNameInput.sendKeys(MaidenName);
        commonUtils.enterKey(eleMaidenNameInput,driver);
    }

    public Boolean isAlertShown() {
        try {
            waitUtils.waitForElementToBeVisible(driver, eleAlertDialog);
            logMessage("======== > alert is shown");
            return this.eleAlertDialog.isDisplayed();
        } catch (NoSuchElementException e) {
            return false;
        }
    }


    public void inputOthers(String Others){
        this.eleOthersInput.click();
        this.eleOthersInput.clear();
        this.eleOthersInput.sendKeys(Others);
        commonUtils.enterKey(eleOthersInput,driver);

    }

    public void chooseMaritalStatus(String MaritalStatus) {

        switch (baseTest.getPlatform().toLowerCase()) {
            case "android":
                switch (MaritalStatus) {
                    case "Single":
                        driver.findElement(By.xpath("//android.widget.TextView[@text='Single']")).click();
                        driver.findElement(By.xpath("//android.widget.TextView[@text='Single']")).click();
                        break;
                    case "Married":
                        driver.findElement(By.xpath("//android.widget.TextView[@text='Married']")).click();
                        driver.findElement(By.xpath("//android.widget.TextView[@text='Married']")).click();
                        break;
                    default:
                        driver.findElement(By.xpath("//android.widget.TextView[@text='"+MaritalStatus+"']")).click();
                        driver.findElement(By.xpath("//android.widget.TextView[@text='"+MaritalStatus+"']")).click();
                }
                break;
            case "ios":
                ((IOSDriver) driver).findElementByAccessibilityId(MaritalStatus).click();
                break;
            default:
                driver.findElement(By.xpath("//*[text()='" + MaritalStatus + "']")).click();
        }
    }


    public void validateQualificationList(){
        ArrayList<String> expectedQualificationList = new ArrayList<>(Arrays.asList("Illiterate","Below SSC","SSC","HSC","Graduate","Postgraduate","Professional"));
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                List<WebElement> androidqualificationDropDown = driver.findElements(By.xpath("//android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup"));
                ArrayList<String> actualListAndroid = new ArrayList<>();
                for(WebElement ele:androidqualificationDropDown){
                    actualListAndroid.add(ele.getText().trim());
                    System.out.println("ActualList: "+actualListAndroid.add(ele.getText().trim()));
                }
                actualListAndroid.contains(expectedQualificationList);

                break;
            case "ios":
                List<WebElement> iosqualificationDropDown = driver.findElements(By.xpath("//XCUIElementTypeScrollView"));
                ArrayList<String> actualListIOS = new ArrayList<>();
                for(WebElement ele:iosqualificationDropDown){
                    actualListIOS.add(ele.getText().trim());
                    System.out.println("ActualList: "+actualListIOS.add(ele.getText().trim()));
                }
                actualListIOS.contains(expectedQualificationList);

                break;
            default:
                List<WebElement> qualificationDropDown = driver.findElements(By.xpath("//ul[@class='MuiList-root MuiMenu-list MuiList-padding']/li/span[1]"));
                ArrayList<String> actualListWeb = new ArrayList<>();
                for(WebElement ele:qualificationDropDown){
                    actualListWeb.add(ele.getText().trim());
                    System.out.println("ActualList: "+actualListWeb.add(ele.getText().trim()));
                }
                actualListWeb.contains(expectedQualificationList);

        }

        //Assert.assertTrue(al.contains(expectedQualificationList),"Actual Qualification list should match with expected list");
    }

    public void chooseQualification(String value) {
        waitUtils.waitForElementToBeVisible(driver, eleQualificationDrpBtn, 50, "Qualification dropdown is not shown");
        this.eleQualificationDrpBtn.click();
        waitUtils.implicitWait(driver, 30000);
        if(baseTest.isWeb()) {
            logMessage("Qualification VALUE -----------"+baseTest.isWeb());
            waitUtils.waitForElementToBeVisible(driver, this.eleQualificationDrpBtn, 50, "Qualification dropdown values is not shown");
        }
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                //driver.findElement(By.xpath("*//android.widget.TextView[@text='"+names+"']")).click();
                commonUtils.clickElementOnScroll(driver, value);
                break;
            case "ios":
                value = "Others";
                WebElement ele = ((IOSDriver)driver).findElementByAccessibilityId("Parent Grandfather Grandmother Brother Sister Son Daughter Husband Wife");
                waitUtils.waitForElementToBeVisible(driver,ele);
                logMessage("Element Qualification :=============>"+ele);
                ele.findElement(By.xpath("//XCUIElementTypeOther[@name='Others']")).click();
                break;
            default:
                waitUtils.implicitWait(driver, 30000);
                driver.findElement(By.xpath("//ul[@role='listbox']/li/span[text()='"+value+"']")).click();
        }
    }

    public void selectGSTLaw(){
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                driver.findElement(By.xpath("//android.widget.TextView[@text='Yes']")).click();
                break;
            case "ios":
                break;
            default:
                waitUtils.implicitWait(driver, 30000);
                driver.findElement(By.xpath("//*[text()='Yes']")).click();
        }
    }

}