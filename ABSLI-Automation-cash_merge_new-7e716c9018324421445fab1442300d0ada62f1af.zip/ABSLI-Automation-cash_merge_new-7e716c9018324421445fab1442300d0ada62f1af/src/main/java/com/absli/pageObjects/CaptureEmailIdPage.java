package com.absli.pageObjects;

import com.absli.helpers.jsonReaders.ReadJson;
import com.absli.helpers.models.LoginModel;
import com.absli.helpers.models.ProposerModel;
import com.absli.utils.CommonUtils;
import com.absli.utils.WaitUtils;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import tests.BaseTest;

import java.util.List;

import static com.absli.logger.LoggingManager.logMessage;

public class CaptureEmailIdPage extends Page {
    WebDriver driver;
    CommonUtils commonUtils;
    ReadJson jsonObj;
    LoginModel loginModel;
    SignInPage signIn;
    DashboardPage dashPage;
    WaitUtils waitUtils;
    ProposerModel proposerModel;

    public CaptureEmailIdPage(WebDriver driver) throws InterruptedException {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        logMessage("Initializing the " + this.getClass().getSimpleName() + " elements");
        PageFactory.initElements(new AppiumFieldDecorator(driver), CaptureEmailIdPage.class);

        waitUtils = new WaitUtils();
        commonUtils = new CommonUtils();
    }

    @FindBy(xpath = "//input[@name='emailId']")
    @AndroidFindBy(xpath = "//android.widget.EditText[@content-desc='emailId']")
    @iOSXCUITFindBy(accessibility = "emailId")
    public WebElement emailID;

    public void setEmailID(String emailID) {
        switch (BaseTest.PLATFORM_NAME) {
            case "android":
                this.emailID.clear();
                this.emailID.sendKeys(emailID);
                break;
            case "ios":
                this.emailID.clear();
                this.emailID.sendKeys(emailID);
                break;
            default:
                this.emailID.clear();
                this.emailID.sendKeys(emailID);
        }
    }

    @FindBy(xpath = "//p[@class='MuiFormHelperText-root MuiFormHelperText-contained MuiFormHelperText-filled']")
    public WebElement inActiveMesage;


    @FindBy(xpath = "//*[contains(text(),'Married')]")
    @AndroidFindBy(accessibility = "maritalStatusList  ")
    @iOSXCUITFindBy(accessibility = "maritalStatusList  ")
    public WebElement maritalStatus;

    public void setMaritalStatus(String maritalStatus) {
        switch (BaseTest.PLATFORM_NAME) {
            case "android":
                driver.findElement(By.xpath("//android.widget.TextView[@text='"+maritalStatus+"']")).click();
                break;
            case "ios":
                driver.findElement(By.xpath("")).click();
                break;
            default:
                WebElement status = driver.findElement(By.xpath("//*[contains(text(),'" + maritalStatus + "')]"));
                status.click();
        }


    }

    @FindBy(xpath = "//input[@name='fatherSpouseName']")
    @AndroidFindBy(accessibility = "fatherSpouseName")
    @iOSXCUITFindBy(accessibility = "fatherSpouseName")
    private WebElement fatherSpouseName;

    public void setFatherSpouseName(String fatherSpouseName) {
        switch (BaseTest.PLATFORM_NAME) {
            case "android":
                this.fatherSpouseName.clear();
                this.fatherSpouseName.sendKeys(fatherSpouseName);
                break;
            case "ios":
                this.fatherSpouseName.clear();
                this.fatherSpouseName.sendKeys(fatherSpouseName);
                break;
            default:
                this.fatherSpouseName.clear();
                this.fatherSpouseName.sendKeys(fatherSpouseName);
                break;
        }
    }

    @FindBy(xpath = "//input[@name='motherName']")
    @AndroidFindBy(accessibility = "motherName")
    @iOSXCUITFindBy(accessibility = "motherName")
    private WebElement motherName;

    public void setMotherName(String motherName) {
        switch (BaseTest.PLATFORM_NAME) {
            case "android":
                this.motherName.clear();
                this.motherName.sendKeys(motherName);
                break;
            case "ios":
                this.motherName.clear();
                this.motherName.sendKeys(motherName);
                break;
            default:
                this.motherName.clear();
                this.motherName.sendKeys(motherName);
                break;
        }
    }

    @FindBy(xpath = "//div[@id='mui-component-select-23']")
    @AndroidFindBy(className = "android.view.ViewGroup")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"'23'\"])[5]")
    public WebElement qualificationText;

    public void setQualification() {
        switch (BaseTest.PLATFORM_NAME) {
            case "android":
                this.qualificationText.click();
                break;
            case "ios":
                this.qualificationText.click();
                break;
            default:
                this.qualificationText.click();

        }
    }

    @FindBy(xpath = "//ul[@class='MuiList-root MuiMenu-list MuiList-padding']/li/span[@class='MuiTouchRipple-root']/preceding-sibling::span")
    @AndroidFindBy(className = "android.widget.TextView")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"Below SSC SSC HSC Graduate Postgraduate Professional Others\"]")
    public List<WebElement> qualificationsList;

    public void getQualificationFromList(String qualificationName) throws Exception {
        switch (BaseTest.PLATFORM_NAME) {
            case "android":
                commonUtils.getValuesFromList(driver, qualificationsList, qualificationName);
                break;
            case "ios":
                commonUtils.getValuesFromList(driver, qualificationsList, qualificationName);
                break;
            default:
                waitUtils.WaitForListOfElementPresent(driver, qualificationsList, 10);
                commonUtils.getValuesFromList(driver, qualificationsList, qualificationName);
                break;
        }
    }

    @FindBy(xpath = "//div[@id='mui-component-select-24']")
    @AndroidFindBy(className = "android.view.ViewGroup")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"'24'\"])[5]")
    public WebElement occupationText;

    public void occupation() {
        switch (BaseTest.PLATFORM_NAME) {
            case "android":
                this.occupationText.click();
                break;
            case "ios":
                this.occupationText.click();
                break;
            default:
                this.occupationText.click();

        }
    }

    @FindBy(xpath = "//ul[@class='MuiList-root MuiMenu-list MuiList-padding']/li")
    @AndroidFindBy(className = "android.widget.TextView")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"Business Owner Service Professional Retired Student Housewife Agriculture Driver Armed Forces Skilled Worker Army/Navy/Police Jeweler Builder Scrap Dealer Doctor Lawyer Architech Others\"]")
    public List<WebElement> occupationsList;

    public void getOccupationList(String occupationName) throws Exception {
        switch (BaseTest.PLATFORM_NAME) {
            case "android":
                commonUtils.getValuesFromList(driver, occupationsList, occupationName);
                break;
            case "ios":
                commonUtils.getValuesFromList(driver, occupationsList, occupationName);
                break;
            default:
                commonUtils.getValuesFromList(driver, occupationsList, occupationName);
                break;
        }
    }

    @FindBy(xpath = "//input[@name='26']")
    @AndroidFindBy(xpath = "//*[@class='android.widget.EditText'and @accessibility='26']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name=\"'26'\"]")
    public WebElement employerName;

    public void setEmployerName(String employerName) {
        switch (BaseTest.PLATFORM_NAME) {
            case "android":
                this.employerName.clear();
                this.employerName.sendKeys(employerName);
                break;
            case "ios":
                this.employerName.clear();
                this.employerName.sendKeys(employerName);
                break;
            default:
                this.employerName.clear();
                this.employerName.sendKeys(employerName);
                break;

        }
    }

    @FindBy(xpath = "//input[@name='28']")
    @AndroidFindBy(xpath = "//*[@class='android.widget.EditText'and @accessibility='28']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name=\"'28'\"]")
    private WebElement nameOfBusiness;

    public void setNameOfBusiness(String nameOfBusiness) {
        switch (BaseTest.PLATFORM_NAME) {
            case "android":
                this.nameOfBusiness.clear();
                this.nameOfBusiness.sendKeys(nameOfBusiness);
                break;
            case "ios":
                this.nameOfBusiness.clear();
                this.nameOfBusiness.sendKeys(nameOfBusiness);
                break;
            default:
                this.nameOfBusiness.clear();
                this.nameOfBusiness.sendKeys(nameOfBusiness);
                break;

        }
    }

    @FindBy(xpath = "//*[@id='mui-component-select-29']")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"'29'\"])[3]")
    private WebElement organization;

    public void organization() {
        switch (BaseTest.PLATFORM_NAME) {
            case "android":
                this.organization.click();
                break;
            case "ios":
                this.organization.click();
                break;
            default:
                this.organization.click();

        }
    }

    @FindBy(xpath = "//ul[@class='MuiList-root MuiMenu-list MuiList-padding']/li")
    @AndroidFindBy(xpath = "//*[@class='android.widget.EditText'][1]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"NGO Trust Proprietorship Partnership HUF Private Ltd. Govt Society Public Ltd. Charity\"]")
    public List<WebElement> listOfOrgs;

    public void getOraNameFromList(String nameOfOrg) throws Exception {
        switch (BaseTest.PLATFORM_NAME) {
            case "android":
                commonUtils.getValuesFromList(driver, listOfOrgs, nameOfOrg);
                break;
            case "ios":
                commonUtils.getValuesFromList(driver, listOfOrgs, nameOfOrg);
                break;
            default:
                commonUtils.getValuesFromList(driver, listOfOrgs, nameOfOrg);
                break;
        }
    }

    @FindBy(xpath = "//input[@name='30']")
    @AndroidFindBy(xpath = "//*[@class='android.widget.EditText'and @accessibility='30']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name=\"'30'\"]")
    public WebElement nameOfDesignation;

    public void setnameOfDesignation(String nameOfDesignation) throws Exception {
        switch (BaseTest.PLATFORM_NAME) {
            case "android":
                this.nameOfDesignation.clear();
                this.nameOfDesignation.sendKeys(nameOfDesignation);
                break;
            case "ios":
                this.nameOfDesignation.clear();
                this.nameOfDesignation.sendKeys(nameOfDesignation);
                break;
            default:
                waitUtils.WaitForElementPresent(driver,this.nameOfDesignation,10);
                this.nameOfDesignation.sendKeys(nameOfDesignation);
                break;

        }
    }

    @FindBy(xpath = "//input[@placeholder='Annual Income']")
    @AndroidFindBy(xpath = "//*[@class='android.widget.EditText'and @accessibility='31']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name=\"'31'\"]")
    private WebElement annualIncome;

    public void setannualIncome(String annualIncome) {
        switch (BaseTest.PLATFORM_NAME) {
            case "android":
                this.annualIncome.clear();
                this.annualIncome.sendKeys(annualIncome);
                break;
            case "ios":
                this.annualIncome.clear();
                this.annualIncome.sendKeys(annualIncome);
                break;
            default:
                this.annualIncome.clear();
                this.annualIncome.sendKeys(annualIncome);
                break;

        }
    }



    @FindBy(xpath = "//div[@class='personal-details-card']//div[@id='mui-component-select-5']")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"'5'\"])[3]")
    public WebElement selectTextFiled;


    @FindBy(xpath = "//div[@class='personal-details-card']//div[@id='mui-component-select-7']")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"'7'\"])[3]")
    public WebElement selectTextFiled1;


    @FindBy(xpath = "//div[@class='personal-details-card']//div[@id='mui-component-select-5' or  @id='mui-component-select-7']")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"'5'\" or [@name=\"'7'\"])[3]")
    public List<WebElement> listOfAnswers;

    @FindBy(xpath = "//ul[@class='MuiList-root MuiMenu-list MuiList-padding']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeScrollView")
    public WebElement paddingElement;

    @FindBy(xpath = "//ul[@class='MuiList-root MuiMenu-list MuiList-padding']/li")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeScrollView/..//XCUIElementTypeOther")
    public List<WebElement> paddingEleLists;

    @FindBy(xpath = "//input[@name='6']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name=\"'6'\"]")
    public WebElement textFiled1;

    @FindBy(xpath = "//input[@name='8']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name=\"'8'\"]")
    public WebElement textField2;


    public void setQuestions(WebDriver driver, List<WebElement> element, String questionName) throws InterruptedException {

        List<WebElement> we = element;

        for (WebElement a : we) {
            //Thread.sleep(1000);
            if (a.getText().equalsIgnoreCase(questionName)) {

                commonUtils.scrollToElementAndClick(driver, a);
                Thread.sleep(5000);
                break;
            }
        }
    }



    public void capturedEmailID(String emailaddressValidations, String maritalStatus,String fathersNameOrSpouseName, String mothersName, String question1,String answer1,String valueToBeEnter,
                                String question2,String answer2,String valueToBeEnter2,
                                String question3,String answer3,String valueToBeEnter3,
                                String question4,String answer4,String valueToBeEnter4, String qualification,
                                String occupation, String employeerName, String nameOfBusinessOrduties, String typeOfOrganization, String designation, String annualIncome,String existingPolicyscreentitle ) throws Exception {
        setEmailID(emailaddressValidations);
        commonUtils.selectButtonByName(maritalStatus, driver);
        //captureEmailIdPage.setMaritalStatus(maritalStatus);
        setFatherSpouseName(fathersNameOrSpouseName);
        setMotherName(mothersName);
        setValueToQuestions(question1,answer1,valueToBeEnter);
        waitUtils.wait2Seconds();
        setValueToQuestions2(question2,answer2,valueToBeEnter2);
        waitUtils.wait2Seconds();
        setValueToQuestions3(question3,answer3,valueToBeEnter3);
        waitUtils.wait5Seconds();
        commonUtils.scrolldown(driver);
        setValueToQuestions4(question4,answer4,valueToBeEnter4);
        waitUtils.wait2Seconds();
        waitUtils.waitForElementToBeClickable(driver, qualificationText);
        commonUtils.scrollToElementAndClick(driver, qualificationText);
        waitUtils.wait2Seconds();
        waitUtils.WaitForListOfElementPresent(driver, qualificationsList, 10);
        getQualificationFromList(qualification);
        waitUtils.wait2Seconds();
        commonUtils.scrollToElementAndClick(driver, occupationText);

        getOccupationList(occupation);
        waitUtils.wait2Seconds();
        waitUtils.waitForElementToBeVisible(driver, employerName);
        setEmployerName(employeerName);
        setNameOfBusiness(nameOfBusinessOrduties);
        organization();

        getOraNameFromList(typeOfOrganization);
        waitUtils.wait2Seconds();
        commonUtils.scrolltopageend(driver);
        setnameOfDesignation(designation);
        setannualIncome(annualIncome);
        commonUtils.selectButtonByName("SAVE & CONTINUE", driver);
        waitUtils.wait5Seconds();
        Assert.assertEquals(validateScreenTitle(existingPolicyscreentitle), exPolicyscreenTitle.getText(), "Failure in navigation to existing policy screen");

    }

    public void selectQualificationandoccupationFromList(String answer) {
        switch (baseTest.getPlatform().toLowerCase()) {
            default:
                driver.findElement(By.xpath("//span[@class='MuiTouchRipple-root']/preceding-sibling::span[contains(text(),'" + answer + "')]")).click();
                break;
            case "android":
                WebElement androidElement = driver.findElement(By.xpath("//android.view.ViewGroup[@content-desc=\"isProposerInsuredSameQst\"]"));
                androidElement.findElement(By.xpath("(//android.view.ViewGroup[@content-desc='" + answer + "'])[1]")).click();
                break;
            case "ios":
                WebElement iosElement = driver.findElement(By.xpath("//XCUIElementTypeOther[@name=\"isProposerInsuredSameQst\"]"));
                iosElement.findElement(By.xpath("(//XCUIElementTypeOther[@name='" + answer + "'])[1]")).click();
                break;
        }
    }

    @FindBy(xpath = "//h2[text()='Existing Policy']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Existing Policy\"]")
    public WebElement exPolicyscreenTitle;

    public String validateScreenTitle(String screenTitle) {
        String actualScreenTitle=null;
        switch (BaseTest.PLATFORM_NAME) {
            case "android":
                actualScreenTitle  = driver.findElement(By.xpath("//android.widget.TextView[@text='" + screenTitle + "']")).getText();
                return actualScreenTitle;
            case "ios":
                actualScreenTitle=driver.findElement(By.xpath("//XCUIElementTypeStaticText[@name='"+screenTitle+"']")).getText();
                return actualScreenTitle;

            default:
                logMessage("Screen title======:" + exPolicyscreenTitle.getText());
                return this.exPolicyscreenTitle.getText();

        }

    }


    public void setValueToQuestions(String questionname, String optionName, String valueToEnter) {
        WebElement question;
        switch (BaseTest.PLATFORM_NAME) {
            case "android":
                break;

            case "ios":
                question=driver.findElement(By.xpath("//XCUIElementTypeStaticText[@name=\""+questionname+"\"]/../..//XCUIElementTypeOther[@name=\""+optionName+"\"]"));
                question.click();
                waitUtils.wait2Seconds();
                if (selectTextFiled.isDisplayed()) {
                    selectTextFiled.click();
                    waitUtils.wait2Seconds();
                    if (paddingElement.isDisplayed()) {
                        for (WebElement ele : paddingEleLists) {
                            if (ele.getText().equalsIgnoreCase(valueToEnter)) {
                                commonUtils.scrollToElementAndClick(driver, ele);
                                break;
                            }
                        }
                    }
                }

            default:
                question = driver.findElement(By.xpath("//h3[contains(text(),'" + questionname + "')]//following-sibling::div//div[contains(text(),'" + optionName + "')]"));
                commonUtils.scrollToElementAndClick(driver,question);
                //question.click();
                waitUtils.wait2Seconds();
                if (selectTextFiled.isDisplayed()) {
                    selectTextFiled.click();
                    waitUtils.wait2Seconds();
                    if (paddingElement.isDisplayed()) {
                        for (WebElement ele : paddingEleLists) {
                            if (ele.getText().equalsIgnoreCase(valueToEnter)) {
                                commonUtils.scrollToElementAndClick(driver, ele);
                                break;
                            }
                        }
                    }
                }
        }

    }

    public void setValueToQuestions2(String questionname, String optionName, String valueToEnter) {
        WebElement question;
        switch (BaseTest.PLATFORM_NAME) {
            case "android":
                break;

            case "ios":
                question=driver.findElement(By.xpath("//XCUIElementTypeStaticText[@name=\""+questionname+"\"]/../..//XCUIElementTypeOther[@name=\""+optionName+"\"]"));
               commonUtils.scrollToElement(driver,question);
                question.click();
                waitUtils.wait2Seconds();
                if (textFiled1.isDisplayed()) {
                    textFiled1.sendKeys(valueToEnter);
                }
                break;
            default:
                question  = driver.findElement(By.xpath("//h3[contains(text(),'" + questionname + "')]//following-sibling::div//div[contains(text(),'" + optionName + "')]"));
                commonUtils.scrollToElement(driver,question);
                question.click();
                waitUtils.wait2Seconds();
                if (textFiled1.isDisplayed()) {
                    textFiled1.sendKeys(valueToEnter);
                }
        }

    }
    public void setValueToQuestions3(String questionname, String optionName, String valueToEnter) {
        WebElement question;
        switch (BaseTest.PLATFORM_NAME) {
            case "android":
                break;

            case "ios":
                question=driver.findElement(By.xpath("//XCUIElementTypeStaticText[@name=\""+questionname+"\"]/../..//XCUIElementTypeOther[@name=\""+optionName+"\"]"));
                commonUtils.scrollToElement(driver,question);
                question.click();
                waitUtils.wait2Seconds();
                if (selectTextFiled1.isDisplayed()) {
                    commonUtils.scrollToElement(driver,selectTextFiled1);
                    selectTextFiled1.click();
                    waitUtils.wait2Seconds();
                    if (paddingElement.isDisplayed()) {
                        for (WebElement ele : paddingEleLists) {
                            if (ele.getText().equalsIgnoreCase(valueToEnter)) {
                                commonUtils.scrollToElementAndClick(driver, ele);
                                break;
                            }
                        }
                    }
                }
            default:
                question  = driver.findElement(By.xpath("//h3[contains(text(),'" + questionname + "')]//following-sibling::div//div[contains(text(),'" + optionName + "')]"));
                commonUtils.scrollToElement(driver,question);
                question.click();
                waitUtils.wait2Seconds();
                if (selectTextFiled1.isDisplayed()) {
                    commonUtils.scrollToElement(driver,selectTextFiled1);
                    selectTextFiled1.click();
                    waitUtils.wait2Seconds();
                    if (paddingElement.isDisplayed()) {
                        for (WebElement ele : paddingEleLists) {
                            if (ele.getText().equalsIgnoreCase(valueToEnter)) {
                                commonUtils.scrollToElementAndClick(driver, ele);
                                break;
                            }
                        }
                    }
                }
        }

    }
    public void setValueToQuestions4(String questionname, String optionName, String valueToEnter) {
        WebElement question;
        switch (BaseTest.PLATFORM_NAME) {
            case "android":
                break;

            case "ios":
                question=driver.findElement(By.xpath("//XCUIElementTypeStaticText[@name=\""+questionname+"\"]/../..//XCUIElementTypeOther[@name=\""+optionName+"\"]"));
                commonUtils.scrollToElement(driver,question);
                question.click();
                waitUtils.wait2Seconds();
                textField2.isDisplayed();
                textField2.sendKeys(valueToEnter);
                break;
            default:
                question = driver.findElement(By.xpath("//h3[contains(text(),'" + questionname + "')]//following-sibling::div//div[contains(text(),'" + optionName + "')]"));
                commonUtils.scrollToElement(driver,question);
                question.click();
                waitUtils.wait2Seconds();
                textField2.isDisplayed();
                textField2.sendKeys(valueToEnter);

        }

    }
}





