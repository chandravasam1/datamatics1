package com.absli.pageObjects;

import com.absli.helpers.jsonReaders.ReadJson;
import com.absli.helpers.models.LoginModel;
import com.absli.helpers.models.ProposerModel;
import com.absli.utils.CommonUtils;
import com.absli.utils.WaitUtils;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import tests.BaseTest;

import java.util.List;

import static com.absli.logger.LoggingManager.logMessage;

public class HealthPoliciesPage extends Page{
    WebDriver driver;
    CommonUtils commonUtils;
    ReadJson jsonObj;
    LoginModel loginModel;
    SignInPage signIn;
    DashboardPage dashPage;
    WaitUtils waitUtils;
    ProposerModel proposerModel;

    public HealthPoliciesPage(WebDriver driver) throws InterruptedException {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        logMessage("Initializing the " + this.getClass().getSimpleName() + " elements");
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);

        //jsonObj = new ReadJson();
        //signIn = new SignInPage(driver);
        //dashPage = new DashboardPage(driver);
        waitUtils = new WaitUtils();
        commonUtils = new CommonUtils();
    }

    @FindBy(xpath = "//*[contains(text(),'Health Details')]")
    public WebElement healthScreentitle;

    @FindBy(xpath = "//div[contains(@class,'btnTabs-tab')]/div[contains(text(),' ')]")
    public List<WebElement> healthOptionsList;

    @FindBy(xpath = "//div[@class='counter-feet']//div[@class='counter-header-value']/preceding-sibling::img")
    public WebElement feetdecrementOperator;

    @FindBy(xpath = "//div[@class='counter-feet']//div[@class='counter-header-value']/following-sibling::img")
    public WebElement feetincrementOperator;

    @FindBy(xpath = "//div[@class='counter-inches']//div[@class='counter-header-value']/preceding-sibling::img")
    public WebElement inchesdecrementOperator;

    @FindBy(xpath = "//div[@class='counter-inches']//div[@class='counter-header-value']/following-sibling::img")
    public WebElement inchesincrementOperator;

    @FindBy(xpath = "//input[@placeholder='Enter Weight']")
    @iOSXCUITFindBy(accessibility = "Enter Weight")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Enter Weight']")
    public WebElement weightInput;

    @FindBy(xpath = "//div[@class='jss14']//div[contains(text(),'Is there any weight change of over 5 kgs during the past one year?')]")
    public WebElement weightLoseQuestion;

    @FindBy(xpath = "//input[@placeholder='Provide Details']")
    public WebElement detailsOfWeightLose;

//Family Medicals
    @FindBy(xpath = "//div[@class='checklistwitheader']//label[contains(text(),'Have any of Family been diagnosed with/ suffering from/ have any of below disease')]")
    public WebElement anyOneofFamily;

    @FindBy(xpath = "//span[contains(text(),'')]//preceding-sibling::span/span/input[@class='jss179']")
    public  List<WebElement> listOfDiseases;

    @FindBy(xpath = "//span[contains(text(),'')]//preceding-sibling::span/span/input[@class='jss179']//ancestor::div[@class='checklistwitheader-checkbox']/following-sibling::div//input")
    public WebElement detailsOfDisease;

    @FindBy(xpath = "//span[text()='SAVE & CONTINUE']")
    @AndroidFindBy(accessibility = "continueButton")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"continueButton\"`]")
    public WebElement eleHealthPersNextBtn;

    @FindBy(xpath = "//div[text()='Covid 19 Details']")
    @AndroidFindBy(accessibility = "Covid19 Detail")
    @iOSXCUITFindBy(accessibility = "Covid19 Detail")
    public WebElement eleCovidTab;

    @FindBy(xpath = "//div[text()='Covid 19 Details']")
    @AndroidFindBy(accessibility = "Medical History")
    @iOSXCUITFindBy(accessibility = "Medical History")
    public WebElement eleMedHistoryTab;

    @FindBy(xpath = "//div[text()='Covid 19 Details']")
    @AndroidFindBy(accessibility = "Family Medical")
    @iOSXCUITFindBy(accessibility = "Family Medical")
    public WebElement elFamMedicalTab;

    @FindBy(xpath = "//div[text()='Covid 19 Details']")
    @AndroidFindBy(accessibility = "Lifestyle Detail")
    @iOSXCUITFindBy(accessibility = "Lifestyle Detail")
    public WebElement eleLifestyleTab;

    @AndroidFindBy(xpath = "//android.view.View[contains(@text,'Health')]")
    @FindBy(xpath = "//div[contains(text(),'Health')]")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeOther' AND name CONTAINS[cd] 'Health'")
    public WebElement eleHealthInfoNavText;


    public void provideDetailsOfDisease(String diseaseName,String diseaseDescription){
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                break;
            case "ios":
                break;
            default:
                WebElement element=driver.findElement(By.xpath("//span[contains(text(),'"+diseaseName+"')]//preceding-sibling::span/span/input[@class='jss179']//ancestor::div[@class='checklistwitheader-checkbox']/following-sibling::div//input"));
                element.sendKeys(diseaseDescription);
        }
    }

    @FindBy(xpath = "//div[contains(text(),'')]/parent::div[@class='card-title-container']/following-sibling::div")
    public List<WebElement>  listOfFamilycards;

    public void familyDetaislOndiseasesForLiving(String relationshipName,String age){

        switch (BaseTest.PLATFORM_NAME){
            case "android":
                break;
            case "ios":
                break;
            default:
                WebElement element=driver.findElement(By.xpath("//div[contains(text(),'')]/parent::div[@class='card-title-container']/following-sibling::div//input[@placeholder='Age']"));
                element.sendKeys(age);

        }
    }
    public void familyDetaislOndiseasesForDemise(String relationshipName,String age){

        switch (BaseTest.PLATFORM_NAME){
            case "android":
                break;
            case "ios":
                break;
            default:
                WebElement element=driver.findElement(By.xpath("//div[contains(text(),'')]/parent::div[@class='card-title-container']/following-sibling::div//input[@placeholder='Age at Death']"));
                element.sendKeys(age);

        }
    }

    @FindBy(xpath = "//ul[@class='MuiList-root MuiMenu-list MuiList-padding']//li")
    public  List<WebElement> listOfdiseases;


    public void inputWeight(String weightValue) {
        this.weightInput.click();
        this.weightInput.sendKeys(weightValue);
    }
}
