package com.absli.pageObjects;

import com.absli.helpers.jsonReaders.ReadJson;
import com.absli.helpers.models.LoginModel;
import com.absli.helpers.models.ProposerModel;
import com.absli.utils.CommonUtils;
import com.absli.utils.WaitUtils;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import tests.BaseTest;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.absli.logger.LoggingManager.logMessage;

public class OccupationPage extends Page{

    WebDriver driver;
    CommonUtils commonUtils;
    ReadJson jsonObj;
    LoginModel loginModel;
    SignInPage signIn;
    DashboardPage dashPage;
    WaitUtils waitUtils;
    ProposerModel proposerModel;

    public OccupationPage(WebDriver driver) throws InterruptedException {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        logMessage("Initializing the " + this.getClass().getSimpleName() + " elements");
        PageFactory.initElements(new AppiumFieldDecorator(driver), OccupationPage.class);

       /* jsonObj = new ReadJson();
        signIn = new SignInPage(driver);
        dashPage = new DashboardPage(driver);*/
        waitUtils = new WaitUtils();
        commonUtils = new CommonUtils();
    }

    @FindBy(name = "emailId")
    @AndroidFindBy(accessibility = "emailId")
    @iOSXCUITFindBy(className = "emailId")
    public WebElement elePersonalEmailIdInput;

    @FindBy(name = "fatherSpouseName")
    @AndroidFindBy(accessibility = "fatherSpouseName")
    @iOSXCUITFindBy(className = "fatherSpouseName")
    public WebElement eleFatherSpouseNameInput;

    @FindBy(name = "motherName")
    @AndroidFindBy(accessibility = "motherName")
    @iOSXCUITFindBy(className = "motherName")
    public WebElement eleMotherNameInput;

    @FindBy(name = "maidenName")
    public WebElement eleMaidenNameInput;

    @FindBy(xpath = "//input[@class='MuiInputBase-input MuiFilledInput-input'][@placeholder='Others']")
    public WebElement eleOthersInput;

    @FindBy(id = "mui-component-select-24")
    @AndroidFindBy(accessibility = "'24'")
    //@AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"'24'\"]/android.view.ViewGroup[1]/android.widget.Button")
    @iOSXCUITFindBy(className = "'24'")
    public WebElement eleOccupationDrpBtn;

    @FindBy(id = "mui-component-select-29")
    @iOSXCUITFindBy(className = "'29'")
    public WebElement eleTypeOfOgranisationDrpBtn;

    @FindBy(xpath = "//input[@name='25'][@placeholder='Name of Business']")
    @iOSXCUITFindBy(className = "'25'")
    public WebElement eleOccupationNameofBussiness;

    @FindBy(xpath = "//input[@name='26'][@placeholder='Name of Employer']")
    @iOSXCUITFindBy(className = "'26'")
    public WebElement eleOccupationNameOfEmployer;

    @FindBy(xpath = "//input[@name='28'][@placeholder='Nature of Business/Duties']")
    @iOSXCUITFindBy(className = "'28'")
    public WebElement eleOccupationNatureofBussiness;

    @FindBy(xpath = "//input[@name='30'][@placeholder='Designation']")
    @iOSXCUITFindBy(className = "'30'")
    public WebElement eleOccupationDesignation;

    @FindBy(xpath = "//input[@placeholder='Annual Income']")
    @iOSXCUITFindBy(className = "'31'")
    public WebElement eleOccupationAnnualIncome;

    @FindBy(xpath = "//input[@name='32'][@placeholder=\"Spouse's Annual Income\"]")
    @iOSXCUITFindBy(className = "'32'")
    public WebElement eleOccupationSpouseAnnualIncome;

    //@FindBy(xpath = "//input[@placeholder='Parent's Insurance Cover (Rs.)']")
    @FindBy(xpath = "//input[@placeholder='Parent's Insurance Cover (Rs.)'][@name='34']")
    @iOSXCUITFindBy(className = "'34'")
    public WebElement eleOccupationInsuranceCover;

    @FindBy(xpath = "//span[contains(text(),'OK')]")
    @AndroidFindBy(id = "android:id/button1")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"OK\"`]")
    private WebElement eleOkButton;

    @FindBy(xpath = "//p[contains(text(),'Alert')]")
    @AndroidFindBy(id = "android:id/alertTitle")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeAlert[@name=\"Alert\"]")
    public WebElement eleAlertDialog;

    public void inputPersonalFatherSpouseName(String FatherSpouseName){
        this.eleFatherSpouseNameInput.click();
        this.eleFatherSpouseNameInput.clear();
        this.eleFatherSpouseNameInput.sendKeys(FatherSpouseName);
        commonUtils.enterKey(eleFatherSpouseNameInput,driver);
    }

    public void inputPersonalEmailId(String PersonalEmailId){
        this.elePersonalEmailIdInput.click();
        this.elePersonalEmailIdInput.clear();
        this.elePersonalEmailIdInput.sendKeys(PersonalEmailId);
        commonUtils.enterKey(elePersonalEmailIdInput,driver);
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                driver.findElement(By.xpath("//android.widget.Button[@content-desc='rightIcon']/android.widget.TextView")).click();
                if (isAlertShown()) {
                    acceptAlert();
                }
                waitUtils.waitForElementToBeVisible(driver,eleFatherSpouseNameInput,10,"Element not loaded successfully");
                break;
            case "ios":

                break;
            default:

        }
    }
    public void acceptAlert() {
        this.eleOkButton.click();
    }

    public Boolean isAlertShown() {
        try {
            waitUtils.waitForElementToBeVisible(driver, eleAlertDialog);
            logMessage("======== > alert is shown");
            return this.eleAlertDialog.isDisplayed();
        } catch (NoSuchElementException e) {
            return false;
        }
    }

    public void inputPersonalMaidenName(String MaidenName){
        this.eleMaidenNameInput.click();
        this.eleMaidenNameInput.clear();
        this.eleMaidenNameInput.sendKeys(MaidenName);
        commonUtils.enterKey(eleMaidenNameInput,driver);
    }

    public void inputOthers(String Others){
        this.eleOthersInput.click();
        this.eleOthersInput.clear();
        this.eleOthersInput.sendKeys(Others);
        commonUtils.enterKey(eleOthersInput,driver);

    }

    public void inputPersonalMotherName(String MotherName){
        this.eleMotherNameInput.click();
        this.eleMotherNameInput.clear();
        this.eleMotherNameInput.sendKeys(MotherName);
        commonUtils.enterKey(eleMotherNameInput,driver);
    }

    public void validateOccupationList(){
        ArrayList<String> expectedOccupationList = new ArrayList<>(Arrays.asList("Business Owner","Service","Professional","Retired","Student","Housewife","Agriculture","Driver","Skilled Worker","Army/Navy/Police","Armed Forces","Jeweler","Builder","Scrap Dealer","Doctor","Lawyer","Architect","Others"));
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                List<WebElement> androidOccupationDropDown = driver.findElements(By.xpath("//android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup"));
                ArrayList<String> actualListAndroid = new ArrayList<>();
                for(WebElement ele:androidOccupationDropDown){
                    actualListAndroid.add(ele.getText().trim());
                    System.out.println("ActualList: "+actualListAndroid.add(ele.getText().trim()));
                }
                actualListAndroid.contains(expectedOccupationList);

                break;
            case "ios":
                List<WebElement> iosOccupationDropDown = driver.findElements(By.xpath("//XCUIElementTypeScrollView"));
                ArrayList<String> actualListIOS = new ArrayList<>();
                for(WebElement ele:iosOccupationDropDown){
                    actualListIOS.add(ele.getText().trim());
                    System.out.println("ActualList: "+actualListIOS.add(ele.getText().trim()));
                }
                actualListIOS.contains(expectedOccupationList);

                break;
            default:
                List<WebElement> occupationWebDropDown = driver.findElements(By.xpath("//ul[@class='MuiList-root MuiMenu-list MuiList-padding']/li/span[1]"));
                ArrayList<String> actualListWeb = new ArrayList<>();
                for(WebElement ele:occupationWebDropDown){
                    actualListWeb.add(ele.getText().trim());
                    System.out.println("ActualList: "+actualListWeb.add(ele.getText().trim()));
                }
                actualListWeb.contains(expectedOccupationList);
        }
    }

    public void validateOccupationFields(String value){
        switch (baseTest.getPlatform().toLowerCase()) {
            case "android":
                break;
            case "ios":
                break;
            default:
                if(value=="Student"){
                    eleOccupationAnnualIncome.isDisplayed();
                    eleOccupationInsuranceCover.isDisplayed();
                }
                else if (value=="Agriculture"){
                    eleOccupationAnnualIncome.isDisplayed();
                }
                else if (value=="Business Owner"){
                    eleOccupationNameofBussiness.isDisplayed();
                    eleOccupationNatureofBussiness.isDisplayed();
                    eleTypeOfOgranisationDrpBtn.isDisplayed();
                    eleOccupationAnnualIncome.isDisplayed();
                }
                else if (value=="Service"){
                    eleOccupationNameOfEmployer.isDisplayed();
                    eleOccupationNatureofBussiness.isDisplayed();
                    eleTypeOfOgranisationDrpBtn.isDisplayed();
                    eleOccupationDesignation.isDisplayed();
                    eleOccupationAnnualIncome.isDisplayed();
                }
                else if (value=="Retired"){
                    eleOccupationAnnualIncome.isDisplayed();
                    eleOccupationSpouseAnnualIncome.isDisplayed();
                }
                else if (value=="Housewife"){
                    eleOccupationSpouseAnnualIncome.isDisplayed();
                    eleOccupationInsuranceCover.isDisplayed();
                }

                else if(value == "Professional"){
                    eleOccupationNameOfEmployer.isDisplayed();
                    eleOccupationNatureofBussiness.isDisplayed();
                    eleOccupationDesignation.isDisplayed();
                    eleOccupationAnnualIncome.isDisplayed();
                }

                else if(value=="Driver"){
                    eleOccupationNameOfEmployer.isDisplayed();
                    eleOccupationNatureofBussiness.isDisplayed();
                    eleOccupationDesignation.isDisplayed();
                    eleOccupationAnnualIncome.isDisplayed();
                }
                else if(value=="Armed Forces"){
                    eleOccupationNatureofBussiness.isDisplayed();
                    eleOccupationDesignation.isDisplayed();
                    eleOccupationAnnualIncome.isDisplayed();
                }
                else if(value=="Skilled Worker"){
                    eleOccupationNameOfEmployer.isDisplayed();
                    eleOccupationNatureofBussiness.isDisplayed();
                    eleOccupationDesignation.isDisplayed();
                    eleOccupationAnnualIncome.isDisplayed();
                }
                else if(value=="Army/Navy/Police"){
                    eleOccupationNatureofBussiness.isDisplayed();
                    eleOccupationDesignation.isDisplayed();
                    eleOccupationAnnualIncome.isDisplayed();
                }
                else if(value=="Jeweler"){
                    eleOccupationNameOfEmployer.isDisplayed();
                    eleOccupationNatureofBussiness.isDisplayed();
                    eleOccupationDesignation.isDisplayed();
                    eleOccupationAnnualIncome.isDisplayed();
                }
                else if(value=="Builder"){
                    eleOccupationNameOfEmployer.isDisplayed();
                    eleOccupationNatureofBussiness.isDisplayed();
                    eleOccupationDesignation.isDisplayed();
                    eleOccupationAnnualIncome.isDisplayed();
                }
                else if(value=="Scrap Dealer"){
                    eleOccupationNameOfEmployer.isDisplayed();
                    eleOccupationNatureofBussiness.isDisplayed();
                    eleOccupationDesignation.isDisplayed();
                    eleOccupationAnnualIncome.isDisplayed();
                }
                else if(value=="Doctor"){
                    eleOccupationNameOfEmployer.isDisplayed();
                    eleOccupationNatureofBussiness.isDisplayed();
                    eleOccupationDesignation.isDisplayed();
                    eleOccupationAnnualIncome.isDisplayed();
                }
                else if(value=="Lawyer"){
                    eleOccupationNameOfEmployer.isDisplayed();
                    eleOccupationNatureofBussiness.isDisplayed();
                    eleOccupationDesignation.isDisplayed();
                    eleOccupationAnnualIncome.isDisplayed();
                }
                else if(value=="Architech"){
                    eleOccupationNameOfEmployer.isDisplayed();
                    eleOccupationNatureofBussiness.isDisplayed();
                    eleOccupationDesignation.isDisplayed();
                    eleOccupationAnnualIncome.isDisplayed();
                }

                else {
                    eleOccupationNatureofBussiness.isDisplayed();
                    eleOccupationDesignation.isDisplayed();
                    eleOccupationAnnualIncome.isDisplayed();
                }
        }
    }
    public void validateTypeofOrganisationList(){
        ArrayList<String> expectedOrganisationList = new ArrayList<>(Arrays.asList("NGO","Trust","Proprietorship","Partnership","HUF","Private Ltd.","Govt","Society","Public Ltd.","Charity"));
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                List<WebElement> androidOrganisationDropDown = driver.findElements(By.xpath("//android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup"));
                ArrayList<String> actualListAndroid = new ArrayList<>();
                for(WebElement ele:androidOrganisationDropDown){
                    actualListAndroid.add(ele.getText().trim());
                    System.out.println("ActualList: "+actualListAndroid.add(ele.getText().trim()));
                }
                actualListAndroid.contains(expectedOrganisationList);

                break;
            case "ios":

                break;
            default:
                List<WebElement> organisationWebDropDown = driver.findElements(By.xpath("//ul[@class='MuiList-root MuiMenu-list MuiList-padding']/li/span[1]"));
                ArrayList<String> actualListWeb = new ArrayList<>();
                for(WebElement ele:organisationWebDropDown){
                    actualListWeb.add(ele.getText().trim());
                    System.out.println("ActualList: "+actualListWeb.add(ele.getText().trim()));
                }
                actualListWeb.contains(expectedOrganisationList);
        }
    }

    public void chooseOccupation(String value) {
        waitUtils.waitForElementToBeVisible(driver, eleOccupationDrpBtn, 50, "Occupation dropdown is not shown");
        this.eleOccupationDrpBtn.click();
        waitUtils.implicitWait(driver, 30000);
        if(baseTest.isWeb()) {
            logMessage("Occupation VALUE -----------"+baseTest.isWeb());
            waitUtils.waitForElementToBeVisible(driver, this.eleOccupationDrpBtn, 50, "Occupation dropdown values is not shown");

        }
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                //driver.findElement(By.xpath("*//android.widget.TextView[@text='"+names+"']")).click();
                commonUtils.clickElementOnScroll(driver, value);
                break;
            case "ios":
                value = "Others";
                WebElement ele = ((IOSDriver)driver).findElementByAccessibilityId("Parent Grandfather Grandmother Brother Sister Son Daughter Husband Wife");
                waitUtils.waitForElementToBeVisible(driver,ele);
                logMessage("Element Occupation :=============>"+ele);
                ele.findElement(By.xpath("//XCUIElementTypeOther[@name='Others']")).click();
                break;
            default:
                waitUtils.implicitWait(driver, 30000);
                waitUtils.waitForElementToBeClickable(driver,driver.findElement(By.xpath("//ul[@role='listbox']/li/span[text()='" + value + "']")));
                //commonUtils.clickElementOnScroll(driver,value);
                driver.findElement(By.xpath("//ul[@role='listbox']/li/span[text()='" + value + "']")).click();
        }
    }
    public void chooseMaritalStatus(String MaritalStatus) {

        switch (baseTest.getPlatform().toLowerCase()) {
            case "android":
                switch (MaritalStatus) {
                    case "Single":
                        driver.findElement(By.xpath("//android.widget.TextView[@text='Single']")).click();
                        driver.findElement(By.xpath("//android.widget.TextView[@text='Single']")).click();
                        break;
                    case "Married":
                        driver.findElement(By.xpath("//android.widget.TextView[@text='Married']")).click();
                        driver.findElement(By.xpath("//android.widget.TextView[@text='Married']")).click();
                        break;
                    default:
                        driver.findElement(By.xpath("//android.widget.TextView[@text='"+MaritalStatus+"']")).click();
                        driver.findElement(By.xpath("//android.widget.TextView[@text='"+MaritalStatus+"']")).click();
                }
                break;
            case "ios":
                ((IOSDriver) driver).findElementByAccessibilityId(MaritalStatus).click();
                break;
            default:
                driver.findElement(By.xpath("//*[text()='" + MaritalStatus + "']")).click();
        }
    }

    public void chooseTypeOfOrganisation(String value) {
        waitUtils.waitForElementToBeVisible(driver, eleTypeOfOgranisationDrpBtn, 50, "Organisation dropdown is not shown");
        this.eleTypeOfOgranisationDrpBtn.click();
        waitUtils.implicitWait(driver, 30000);
        if(baseTest.isWeb()) {
            logMessage("Organisation VALUE -----------"+baseTest.isWeb());
            waitUtils.waitForElementToBeVisible(driver, this.eleTypeOfOgranisationDrpBtn, 50, "Organisation dropdown values is not shown");
        }
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                //driver.findElement(By.xpath("*//android.widget.TextView[@text='"+names+"']")).click();
                commonUtils.clickElementOnScroll(driver, value);
                break;
            case "ios":
                value = "Others";
                WebElement ele = ((IOSDriver)driver).findElementByAccessibilityId("Parent Grandfather Grandmother Brother Sister Son Daughter Husband Wife");
                waitUtils.waitForElementToBeVisible(driver,ele);
                logMessage("Element Occupation :=============>"+ele);
                ele.findElement(By.xpath("//XCUIElementTypeOther[@name='Others']")).click();
                break;
            default:
                waitUtils.implicitWait(driver, 30000);
                driver.findElement(By.xpath("//ul[@role='listbox']/li/span[text()='" + value + "']")).click();
        }
    }
}
