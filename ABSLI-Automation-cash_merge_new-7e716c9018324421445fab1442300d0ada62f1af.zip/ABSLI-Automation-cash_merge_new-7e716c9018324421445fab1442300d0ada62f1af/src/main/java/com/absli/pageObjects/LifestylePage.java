package com.absli.pageObjects;

import com.absli.helpers.jsonReaders.ReadJson;
import com.absli.helpers.models.LoginModel;
import com.absli.helpers.models.ProposerModel;
import com.absli.utils.CommonUtils;
import com.absli.utils.WaitUtils;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import tests.BaseTest;
import tests.journeys.Qualification;

import static com.absli.logger.LoggingManager.logMessage;

public class LifestylePage extends Page{
    WebDriver driver;
    CommonUtils commonUtils;
    ReadJson jsonObj;
    LoginModel loginModel;
    SignInPage signIn;
    DashboardPage dashPage;
    WaitUtils waitUtils;
    OccupationPage occupationPage;
    QualificationPage qualificationPage;
    ProposerModel proposerModel;

    public LifestylePage(WebDriver driver) throws InterruptedException {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        logMessage("Initializing the " + this.getClass().getSimpleName() + " elements");
        PageFactory.initElements(new AppiumFieldDecorator(driver), LifestylePage.class);

        jsonObj = new ReadJson();
        signIn = new SignInPage(driver);
        dashPage = new DashboardPage(driver);
        waitUtils = new WaitUtils();
        commonUtils = new CommonUtils();
        occupationPage = new OccupationPage(driver);
        qualificationPage = new QualificationPage(driver);
    }

    @FindBy(xpath = "//span[contains(text(),'Savings')]")
    @AndroidFindBy(xpath = "//android.widget.CheckBox[@content-desc='Q51.A2']")
    //@AndroidFindBy(accessibility = "Q51.A2")
    @iOSXCUITFindBy(className = "Q51.A2")
    public WebElement elePURPOSEOFINSURANCE;

    @FindBy(xpath = "//span[contains(text(),'NEXT')]")
    @AndroidFindBy(accessibility = "continueBtn")
    @iOSXCUITFindBy(className = "continueBtn")
    public WebElement elePURPOSEOFINSURANCENextBtn;

    @FindBy(xpath = "//input[@placeholder='Enter Weight']")
    @AndroidFindBy(accessibility = "'10'")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeTextField[`label == \"'10'\"`]")
    public WebElement elePersonalDetailsWeight;

    @FindBy(xpath = "//*[@type='submit']")
    @AndroidFindBy(accessibility = "continueButton")
    @iOSXCUITFindBy(className = "continueButton")
    public WebElement elePersonalDetailsSaveBtn;

    @FindBy(xpath = "//*[@placeholder='Annual Income']")
    public WebElement eleAnnualIncomeInput;

    @FindBy(xpath = "//input[@placeholder=\"Spouse's Annual Income\"]")
    public WebElement eleSpouseAnnualIncomeInput;

    @FindBy(xpath = "//button[@name='13']/span/div[contains(text(),'Yes')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Narcotics']/../android.view.ViewGroup[1]")
    public WebElement eleNarcoticsYesBtn;

    @FindBy(xpath = "//input[@name='18']")
    @iOSXCUITFindBy(className = "18")
    @AndroidFindBy(xpath = "//android.widget.EditText[@content-desc='18']")
    public WebElement eleNarcoticsDetailsInput;

    @FindBy(xpath = "//span[contains(text(),'SAVE & CONTINUE')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='SAVE AND CONTINUE']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='continueButton']")
    public WebElement eleLifestyleContinueBtn;

    @FindBy(xpath = "//button[@name='14']/span/div[contains(text(),'Yes')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Alcohol Consumption']/../android.view.ViewGroup[1]")

    public WebElement eleAlcoholConsumptionYesBtn;

    @FindBy(xpath = "//div[contains(text(),'Beer')]/../div[2]/div/label/span/span/input[@id='accordian-checkbox']")
    @AndroidFindBy(accessibility = "Q19A1")
    public WebElement eleTypeAlcoholConsumedBeer;

    @FindBy(xpath = "//button[@name='20']/span/div[contains(text(),'No')]")
    @AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc='mainContainer']/android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[5]")
    public WebElement eleAlcoholConsumptionIntakeNoBtn;

    @FindBy(xpath = "//button[@name='21']/span/div[contains(text(),'No')]")
    @AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc='mainContainer']/android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup[1]/android.view.ViewGroup[6]")
    public WebElement eleAlcoholConsumptionRecoveringAddictsNoBtn;

    @FindBy(xpath = "//button[@name='22']/span/div[contains(text(),'No')]")
    @AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc='mainContainer']/android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup[1]/android.view.ViewGroup[8]")
    public WebElement eleAlcoholConsumptionAdditionalInformationNoBtn;

    @FindBy(xpath = "//input[@name='19[0].text.quantity']")
    @AndroidFindBy(xpath= "//android.widget.EditText[@content-desc='quantity']")
    @iOSXCUITFindBy(className = "quantity")
    public  WebElement eleAlcoholBeerQuantity;

    @FindBy(xpath= "//*[@id='mui-component-select-19[0].text.frequency']")
    @AndroidFindBy(accessibility = "frequency")
    @iOSXCUITFindBy(className = "frequency")
    public WebElement eleAlcoholBeerFrequencyDrpBtn;

    @FindBy(xpath = "//input[@name='19[1].text.quantity']")
    @AndroidFindBy(xpath = "(//android.widget.EditText[@content-desc='quantity'])[2]")
    public WebElement eleAlcoholWineQuantity;

    @FindBy(xpath= "//*[@id='mui-component-select-19[1].text.frequency']")
    @AndroidFindBy(xpath = "(//android.view.ViewGroup[@content-desc='frequency'])[2]/android.view.ViewGroup[2]")
    public WebElement eleAlcoholWineFrequencyDrpBtn;

    @FindBy(xpath = "//input[@name='19[2].text.quantity']")
    @AndroidFindBy(xpath = "(//android.widget.EditText[@content-desc='quantity'])[2]")
    public WebElement eleAlcoholLiquorQuantity;

    @FindBy(xpath= "//*[@id='mui-component-select-19[2].text.frequency']")
    public WebElement eleAlcoholLiquorFrequencyDrpBtn;

    @FindBy(xpath = "//button[@name='15']/span/div[contains(text(),'Yes')]")
    @AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc='mainContainer']/android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup[3]/android.view.ViewGroup[1]")
    public WebElement eleNicotineYesBtn;

    @FindBy(xpath = "//div[contains(text(),'Cigarette')]/../div/div/label/span/span/input[@id='accordian-checkbox']")

    public WebElement eleFormOfTobaccoCigarette;

    @FindBy(xpath = "//*[@name='27[0].text.quantity']")
    public WebElement eleFormOfTobaccoCigaretteQuantity;

    @FindBy(xpath = "//*[@name='27[0].text.noOfYrs']")
    public WebElement eleFormOfTobaccoCigaretteYrs;

    @FindBy(xpath = "//*[@name='27[1].text.quantity']")
    public WebElement eleFormOfTobaccoBidiQuantity;

    @FindBy(xpath = "//*[@name='27[1].text.noOfYrs']")
    public WebElement eleFormOfTobaccoBidiYrs;

    @FindBy(xpath = "//*[@name='27[2].text.quantity']")
    public WebElement eleFormOfTobaccoPaanQuantity;

    @FindBy(xpath = "//*[@name='27[2].text.noOfYrs']")
    public WebElement eleFormOfTobaccoPaanYrs;

    @FindBy(xpath = "//*[@name='27[3].text.quantity']")
    public WebElement eleFormOfTobaccoQuantity;

    @FindBy(xpath = "//*[@name='27[3].text.noOfYrs']")
    public WebElement eleFormOfTobaccoYrs;

    @FindBy(xpath = "//button[@name='28']/span/div[contains(text(),'No')]")
    public WebElement eleNicotinePhysicianAdviceNoBtn;

    @FindBy(xpath = "//button[@name='16']/span/div[contains(text(),'Yes')]")
    @AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=/mainContainer']/android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup[1]/android.view.ViewGroup[1]")
    public WebElement eleHazardousActivitiesYesBtn;

    @FindBy(id = "mui-component-select-29")
    @AndroidFindBy(accessibility = "29")
    @iOSXCUITFindBy(className = "29")
    public WebElement eleHazardousActivitiesOptionDropdownBtn;

    @FindBy(xpath = "//*[@name='30']")
    @AndroidFindBy(accessibility = "30")
    @iOSXCUITFindBy(className = "30")
    public WebElement eleHazardousActivitiesYrs;

    @FindBy(id = "mui-component-select-31")
    @AndroidFindBy(accessibility = "31")
    @iOSXCUITFindBy(className = "31")
    public WebElement eleHazardousActivitiesTypeDrpDwnBtn;

    @FindBy(xpath = "//button[@name='17']/span/div[contains(text(),'Yes')]")
    @AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc='mainContainer']/android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup[2]/android.view.ViewGroup[1]")
    public WebElement eleTravelYesBtn;

    @FindBy(xpath = "//div[contains(text(),'Do you consume or have you ever consumed any narcotic substance?')]/../../div[3]/div/button/span[text()='SAVE']")
    public WebElement eleNarcoticsSaveBtn;

    @FindBy(xpath = "")
    public WebElement eleNarcoticsMentionDetailsError;

    @FindBy(xpath = "//div[contains(text(),'Do you consume Alcohol?')]/../../div[6]/div/button/span[text()='SAVE']")
    public WebElement eleAlcoholConsumptionSaveBtn;

    @FindBy(xpath = "")
    public WebElement eleAlcoholConsumptionQtError;

    @FindBy(xpath = "")
    public WebElement eleAlcoholConsumptionFrqError;

    @FindBy(xpath = "")
    public WebElement eleNicotineDurationError;

    @FindBy(xpath = "")
    public WebElement eleNicotineQtError;

    @FindBy(xpath = "")
    public WebElement eleNicotineFrqError;

    @FindBy(xpath = "//div[contains(text(),'Do you consume cigarettes/bidis/cigars or used any other tobacco/nicotine products in any form?')]/../../div[5]/div/button/span[text()='SAVE']")
    public WebElement eleNicotineSaveBtn;

    @FindBy(xpath = "//div[@id='parent']/../div[5]/div/button/span[text()='SAVE']")
    public WebElement eleHazardousActivitiesSaveBtn;

    @FindBy(xpath = "")
    public WebElement eleHazardousActivitiesOpt1Error;

    @FindBy(xpath = "")
    public WebElement eleHazardousActivitiesYrsError;

    @FindBy(xpath = "")
    public WebElement eleHazardousActivitiesOpt2Error;


    public void inputSpouseAnnualIncome(String SpouseAnnualIncome){
        this.eleSpouseAnnualIncomeInput.click();
        this.eleSpouseAnnualIncomeInput.clear();
        this.eleSpouseAnnualIncomeInput.sendKeys(SpouseAnnualIncome);
        commonUtils.enterKey(eleSpouseAnnualIncomeInput,driver);
    }

    public void inputAlcoholBeerQuantity(String AlcoholBeerQuantity){
        this.eleAlcoholBeerQuantity.sendKeys(AlcoholBeerQuantity);
        commonUtils.enterKey(eleAlcoholBeerQuantity,driver);
        eleAlcoholConsumptionYesBtn.click();
    }

    public void inputTobaccoCigaretteQuantity(String TobaccoQuantityConsumed){
        this.eleFormOfTobaccoCigaretteQuantity.click();
        this.eleFormOfTobaccoCigaretteQuantity.clear();
        this.eleFormOfTobaccoCigaretteQuantity.sendKeys(TobaccoQuantityConsumed);
        commonUtils.enterKey(eleFormOfTobaccoCigaretteQuantity,driver);
    }
    public void inputTobaccoCigaretteYrs(String TobaccoYrsConsumed){
        this.eleFormOfTobaccoCigaretteYrs.click();
        this.eleFormOfTobaccoCigaretteYrs.clear();
        this.eleFormOfTobaccoCigaretteYrs.sendKeys(TobaccoYrsConsumed);
        commonUtils.enterKey(eleFormOfTobaccoCigaretteYrs,driver);
    }
    public void inputHazardousActivitiesYrs(String HazardousActivitiesYrs){
        this.eleHazardousActivitiesYrs.click();
        this.eleHazardousActivitiesYrs.clear();
        this.eleHazardousActivitiesYrs.sendKeys(HazardousActivitiesYrs);
        commonUtils.enterKey(eleHazardousActivitiesYrs,driver);
    }

    public void inputAnnualIncome(String AnnualIncome){
        this.eleAnnualIncomeInput.click();
        this.eleAnnualIncomeInput.clear();
        this.eleAnnualIncomeInput.sendKeys(AnnualIncome);
        commonUtils.enterKey(eleAnnualIncomeInput,driver);
    }


    public void chooseBeerFrequency(String value) {
        //commonUtils.scrollToElementAndClick(driver,eleAlcoholBeerFrequencyDrpBtn);
        //waitUtils.waitForElementToBeVisible(driver, eleAlcoholBeerFrequencyDrpBtn, 50, "Beer Frequency dropdown is not shown");
        this.eleAlcoholBeerFrequencyDrpBtn.click();
        waitUtils.implicitWait(driver, 30000);
        if(baseTest.isWeb()) {
            logMessage("Occupation VALUE -----------"+baseTest.isWeb());
            waitUtils.waitForElementToBeVisible(driver, this.eleAlcoholBeerFrequencyDrpBtn, 50, "Beer Frequency dropdown values is not shown");

        }
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                commonUtils.clickElementOnScroll(driver, value);
                break;
            case "ios":
                value = "Occasionally";
                WebElement ele = ((IOSDriver)driver).findElementByAccessibilityId("Daily Weekly Occasionally");
                waitUtils.waitForElementToBeVisible(driver,ele);
                logMessage("Element Beer Frequency :=============>"+ele);
                ele.findElement(By.xpath("//XCUIElementTypeOther[@name='Occasionally']")).click();
                break;
            default:
                waitUtils.implicitWait(driver, 30000);
                waitUtils.waitForElementToBeClickable(driver,driver.findElement(By.xpath("//ul[@role='listbox']/li/span[text()='" + value + "']")));
                //commonUtils.clickElementOnScroll(driver,value);
                driver.findElement(By.xpath("//ul[@role='listbox']/li/span[text()='" + value + "']")).click();
        }
    }

    public void chooseHazardousActivitiesOption(String value) {
        waitUtils.waitForElementToBeVisible(driver, eleHazardousActivitiesOptionDropdownBtn, 50, "Hazardous Activities Option dropdown is not shown");
        this.eleHazardousActivitiesOptionDropdownBtn.click();
        waitUtils.implicitWait(driver, 30000);
        if(baseTest.isWeb()) {
            logMessage("Hazardous Activities Option VALUE -----------"+baseTest.isWeb());
            waitUtils.waitForElementToBeVisible(driver, this.eleHazardousActivitiesOptionDropdownBtn, 50, "Hazardous Activities Option dropdown values is not shown");

        }
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                commonUtils.clickElementOnScroll(driver, value);
                break;
            case "ios":
                value = "Hobby";
                WebElement ele = ((IOSDriver)driver).findElementByAccessibilityId("Hobby Profession");
                waitUtils.waitForElementToBeVisible(driver,ele);
                logMessage("Hazardous Activities Option :=============>"+ele);
                ele.findElement(By.xpath("//XCUIElementTypeOther[@name='Hobby']")).click();
                break;
            default:
                waitUtils.implicitWait(driver, 30000);
                waitUtils.waitForElementToBeClickable(driver,driver.findElement(By.xpath("//ul[@role='listbox']/li/span[text()='" + value + "']")));
                //commonUtils.clickElementOnScroll(driver,value);
                driver.findElement(By.xpath("//ul[@role='listbox']/li/span[text()='" + value + "']")).click();
        }
    }
    public void chooseHazardousActivitiesType(String value) {
        waitUtils.waitForElementToBeVisible(driver, eleHazardousActivitiesTypeDrpDwnBtn, 50, "Hazardous Activities Type dropdown is not shown");
        this.eleHazardousActivitiesTypeDrpDwnBtn.click();
        waitUtils.implicitWait(driver, 30000);
        if(baseTest.isWeb()) {
            logMessage("Hazardous Activities Type VALUE -----------"+baseTest.isWeb());
            waitUtils.waitForElementToBeVisible(driver, this.eleHazardousActivitiesOptionDropdownBtn, 50, "Hazardous Activities Type dropdown values is not shown");

        }
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                commonUtils.clickElementOnScroll(driver, value);
                break;
            case "ios":
                value = "Self";
                WebElement ele = ((IOSDriver)driver).findElementByAccessibilityId("Self Under professional guidance");
                waitUtils.waitForElementToBeVisible(driver,ele);
                logMessage("Hazardous Activities Option :=============>"+ele);
                ele.findElement(By.xpath("//XCUIElementTypeOther[@name='Self']")).click();
                break;
            default:
                waitUtils.implicitWait(driver, 30000);
                waitUtils.waitForElementToBeClickable(driver,driver.findElement(By.xpath("//ul[@role='listbox']/li/span[text()='" + value + "']")));
                //commonUtils.clickElementOnScroll(driver,value);
                driver.findElement(By.xpath("//ul[@role='listbox']/li/span[text()='" + value + "']")).click();
        }
    }

    public void fillPersonalDetails(String PersonalEmailId, String PersonalMaritalStatus, String FatherSpouseName, String MotherName, String MaidenName, String Qualification, String Occupation, String AnnualIncome,String SpouseAnnualIncome) throws InterruptedException{

        System.out.println("fill personal details method: ");
        waitUtils.waitForElementToBeClickable(driver,qualificationPage.elePersonalEmailIdInput);
        qualificationPage.inputPersonalEmailId(PersonalEmailId);
        waitUtils.waitForElementToBeVisible(driver,qualificationPage.eleFatherSpouseNameInput,20,"Element not visible");
        qualificationPage.chooseMaritalStatus(PersonalMaritalStatus);
        qualificationPage.inputPersonalFatherSpouseName(FatherSpouseName);
        qualificationPage.inputPersonalMotherName(MotherName);
        if(baseTest.isWeb()){
            qualificationPage.inputPersonalMaidenName(MaidenName);
        }
        commonUtils.scrollTillEndOfPage(driver);
        qualificationPage.chooseQualification(Qualification);
        waitUtils.implicitWait(driver,10000);
        occupationPage.chooseOccupation(Occupation);
        waitUtils.implicitWait(driver,1000);
        inputAnnualIncome(AnnualIncome);
        inputSpouseAnnualIncome(SpouseAnnualIncome);
        commonUtils.scrollTillEndOfPage(driver);
        //qualificationPage.selectGSTLaw();
        elePersonalDetailsSaveBtn.click();
    }


    public void inputNarcoticsDetails(String NarcoticsDetails){
        this.eleNarcoticsDetailsInput.click();
        this.eleNarcoticsDetailsInput.clear();
        this.eleNarcoticsDetailsInput.sendKeys(NarcoticsDetails);
        commonUtils.enterKey(eleNarcoticsDetailsInput,driver);
    }

    public void chooseNicotineDuration(String NicotineDuration) {

        switch (baseTest.getPlatform().toLowerCase()) {
            case "android":
                switch (NicotineDuration) {
                    case "Last 12 M":
                        driver.findElement(By.xpath("//android.widget.TextView[@text='Last 12 M']")).click();
                        driver.findElement(By.xpath("//android.widget.TextView[@text='Last 12 M']")).click();
                        break;
                    case "During 13 to 60 M":
                        driver.findElement(By.xpath("//android.widget.TextView[@text='During 13 to 60 M']")).click();
                        driver.findElement(By.xpath("//android.widget.TextView[@text='During 13 to 60 M']")).click();
                        break;
                    default:
                        driver.findElement(By.xpath("//android.widget.TextView[@text='"+NicotineDuration+"']")).click();
                        driver.findElement(By.xpath("//android.widget.TextView[@text='"+NicotineDuration+"']")).click();
                }
                break;
            case "ios":
                ((IOSDriver) driver).findElementByAccessibilityId(NicotineDuration).click();
                break;
            default:
                WebElement nicotineDuration = driver.findElement(By.xpath("//*[text()='" + NicotineDuration + "']"));
                commonUtils.scrollToElementAndClick(driver,nicotineDuration);
        }
    }

}
