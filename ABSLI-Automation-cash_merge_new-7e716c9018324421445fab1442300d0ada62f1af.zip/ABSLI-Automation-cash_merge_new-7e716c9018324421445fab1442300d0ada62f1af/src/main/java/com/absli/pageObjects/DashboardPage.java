package com.absli.pageObjects;

import com.absli.utils.CommonUtils;
import com.absli.utils.WaitUtils;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import tests.BaseTest;

import static com.absli.logger.LoggingManager.logMessage;

public class DashboardPage extends Page {

    WebDriver driver;


    public DashboardPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        logMessage("Initializing the "+this.getClass().getSimpleName()+" elements");
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
    }

    @FindBy(xpath = "//a[@title='Log In'][1]")
    @AndroidFindBy(xpath = "//android.view.View[@text='Dashboard']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[contains(@label, 'Log In')]")
    private WebElement eleDashboardTitle;

    @FindBy(css = ".navbar-container")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Profile']")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name=\"Profile\"])[2]")
    public WebElement eleProfileTitle;

    @FindBy(css = "img.hamburger-icon")
    @AndroidFindBy(xpath = "//android.view.View[@text='Dashboard']//..")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeOther[`label == \"Dashboard\"`][7]/XCUIElementTypeOther[1]")
    public WebElement eleDashboardHamburgerMenu;

    @FindBy(xpath = "//button[text()='Profile']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Profile']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Profile\"]")
    public WebElement eleProfileMenu;

    @FindBy(xpath = "//button[@class='MuiButtonBase-root MuiFab-root MuiSpeedDial-fab MuiFab-primary']")
    @AndroidFindBy(xpath = "//android.widget.ScrollView[@content-desc=\"applicantsList\"]//..//android.view.ViewGroup/android.widget.Button/android.view.ViewGroup/android.widget.ImageView")
    //@iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeOther' AND name BEGINSWITH[cd] 'applicantsList'")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeScrollView/../../../../child::XCUIElementTypeOther[2]")
    public WebElement eleCreateAppButton;

    @FindBy(css = "#createAppModal")
    public WebElement eleCreateAppModal;

    //@FindBy(xpath = "(//span[@class='MuiTypography-root MuiFormControlLabel-label MuiTypography-body1'])[1]")
    @AndroidFindBy(accessibility = "new")
    @iOSXCUITFindBy(accessibility = "new")
    public WebElement eleNewCustomerRadio;

    @FindBy(xpath = "//button[contains(@class,'create-app-button')]")
    @AndroidFindBy(accessibility = "createBtn")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"createBtn\"]")
    public WebElement eleNewApplButton;


    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"iChampButton\"`]")
    @AndroidFindBy(accessibility = "iChampButton")
    private WebElement eleiChampBtn;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"existingCustomerButton\"`]")
    @AndroidFindBy(accessibility = "existingCustomerButton")
    private WebElement eleExistingCustBtn;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"newCustomerButton\"`]")
    @AndroidFindBy(accessibility = "newCustomerButton")
    @FindBy(xpath = "//button[@title='New Customer']")
    public WebElement eleNewCustomerBtn;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"New Customer\"`]")
    private WebElement eleNewCustomerMenu;


    public void clickOnHamburgerMenu() {
        clickElement(eleDashboardHamburgerMenu);
    }

    public void clickOnProfileMenu() {
        clickElement(eleProfileMenu);
    }

    public void navigateToProfileScreen() {
        clickOnHamburgerMenu();
        clickOnProfileMenu();
    }

    public void clickOnCreateAppln() {
        if(new BaseTest().isIOS()) {
            /*System.out.println("I am in ios method ------");
            clickOnHamburgerMenu();
            System.out.println("--------> clicked on ham menu");
            eleNewCustomerMenu.click();
            System.out.println("--------> selected new customeer");*/
            eleCreateAppButton.findElement(By.className("XCUIElementTypeButton")).click();
        } else if (new BaseTest().isWeb()){
            clickElement(this.eleCreateAppButton);
        } else {
                clickElement(this.eleCreateAppButton);
        }

    }

    public CreateApplPage navigateToProposerScreen()  {
        new WaitUtils().waitUntilVisible(driver,eleNewApplButton,40);
        clickElement(eleNewApplButton);
        return new CreateApplPage(driver);
    }

//    public SignInPage chooseSignInOption() throws Exception {
//        clickElement(eleSignInBtn);
//    //    new SignInPage(driver).clickOnSignInTitle();
//        logMessage("Chosen signIn option");
//        return new SignInPage(driver);
//    }

//    public SignUpPage chooseSignUpOption() throws Exception {
//        clickElement(eleSignUpBtn);
//        logMessage("Chosen signUp option");
//        return new SignUpPage(driver);
//    }



}