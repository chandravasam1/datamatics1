package com.absli.pageObjects;

import com.absli.helpers.jsonReaders.ReadJson;
import com.absli.helpers.models.LoginModel;
import com.absli.helpers.models.ProposerModel;
import com.absli.utils.CommonUtils;
import com.absli.utils.WaitUtils;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import tests.BaseTest;

import java.util.List;

import static com.absli.logger.LoggingManager.logMessage;

public class ExistingPolicyPage extends Page{
    WebDriver driver;
    CommonUtils commonUtils;
    WaitUtils waitUtils;

    public ExistingPolicyPage(WebDriver driver) throws InterruptedException {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        logMessage("Initializing the " + this.getClass().getSimpleName() + " elements");
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
        waitUtils = new WaitUtils();
        commonUtils = new CommonUtils();

    }

    @FindBy(xpath = "//h2[text()='Existing Policy']")
    public WebElement exPolicyscreenTitle;

    @FindBy(xpath = "//span[contains(text(),'ADD EXISTING POLICY ')]")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"ADD NEW \"])[2]")
    public WebElement addExPolicy;

    @FindBy(xpath ="(//input[@id='insurerName'])[1]")
    @AndroidFindBy(accessibility = "insurerName")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name=\"insurerName\"]")
    public WebElement addInsurerName;

    public void setInsurerName(String insurerName){
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                this.addInsurerName.clear();
                this.addInsurerName.sendKeys(insurerName);
                break;
            case "ios":
                this.addInsurerName.clear();
                this.addInsurerName.sendKeys(insurerName);
                break;
            default:
                this.addInsurerName.clear();
                this.addInsurerName.sendKeys(insurerName);
                break;
        }

    }

@FindBy(xpath ="(//input[@id='sumAssured'])[1]")
@AndroidFindBy(accessibility = "sumAssured")
@iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name=\"sumAssured\"]")
public WebElement sumAssured;

    public void setsumAssured(Long sumAssured){
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                this.sumAssured.clear();
                this.sumAssured.sendKeys(sumAssured+"");
                break;
            case "ios":
                this.sumAssured.clear();
                this.sumAssured.sendKeys(sumAssured+"");
                break;
            default:
                this.sumAssured.clear();
                this.sumAssured.sendKeys(sumAssured+"");
                break;
        }

    }

    @FindBy(xpath ="//input[@id='policyNumber']")
    @AndroidFindBy(xpath = "(//android.view.ViewGroup[@content-desc=\"customInputMainView\"])[3]/android.view.ViewGroup/android.view.ViewGroup[1]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name=\"policyNumber\"]")
    public WebElement policyNumber;

    public void setpolicyNumber(String policyNumber){
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                this.policyNumber.clear();
                this.policyNumber.sendKeys(policyNumber);
                break;
            case "ios":
                this.policyNumber.clear();
                this.policyNumber.sendKeys(policyNumber);
                break;
            default:
                this.policyNumber.clear();
                this.policyNumber.sendKeys(policyNumber);
                break;
        }

    }

    @FindBy(xpath ="//input[@id='applicationYear']")
    @AndroidFindBy(xpath = "(//android.view.ViewGroup[@content-desc=\"customInputMainView\"])[4]/android.view.ViewGroup/android.view.ViewGroup[1]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name=\"applicationYear\"]")
    public WebElement applicationYear;

    public void setapplicationYear(String applicationYear){
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                this.applicationYear.clear();
                this.applicationYear.sendKeys(String.valueOf(applicationYear));
                break;
            case "ios":
                this.applicationYear.clear();
                this.applicationYear.sendKeys(String.valueOf(applicationYear));
                break;
            default:
                this.applicationYear.clear();
                this.applicationYear.sendKeys(String.valueOf(applicationYear));
                break;
        }

    }

    @FindBy(xpath ="//input[@id='basePlan']")
    @AndroidFindBy(xpath = "(//android.view.ViewGroup[@content-desc=\"customInputMainView\"])[5]/android.view.ViewGroup/android.view.ViewGroup[1]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name=\"basePlan\"]")
    public WebElement basePlan;

    public void setbasePlan(String basePlan){
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                this.basePlan.clear();
                this.basePlan.sendKeys(basePlan);
                break;
            case "ios":
                this.basePlan.clear();
                this.basePlan.sendKeys(basePlan);
                break;
            default:
                this.basePlan.clear();
                this.basePlan.sendKeys(basePlan);
                break;
        }

    }

    @FindBy(xpath ="//input[@id='annualPremium']")
    @AndroidFindBy(xpath = "(//android.view.ViewGroup[@content-desc=\"customInputMainView\"])[6]/android.view.ViewGroup/android.view.ViewGroup[1]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name=\"annualPremium\"]")
    public WebElement annualPremium;

    public void setannualPremium(String annualPremium){
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                this.annualPremium.clear();
                this.annualPremium.sendKeys(annualPremium);
                break;
            case "ios":
                this.annualPremium.clear();
                this.annualPremium.sendKeys(annualPremium);
                break;
            default:
                this.annualPremium.clear();
                this.annualPremium.sendKeys(annualPremium);
                break;
        }

    }

    @FindBy(xpath ="//input[@id='policyStatus']")
    @AndroidFindBy(xpath = "(//android.view.ViewGroup[@content-desc=\"customInputMainView\"])[7]/android.view.ViewGroup/android.view.ViewGroup[1]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name=\"policyStatus\"]")
    public WebElement policyStatus;

    public void setpolicyStatus(String policyStatus){
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                this.policyStatus.clear();
                this.policyStatus.sendKeys(policyStatus);
                break;
            case "ios":
                this.policyStatus.clear();
                this.policyStatus.sendKeys(policyStatus);
                break;
            default:
                this.policyStatus.clear();
                this.policyStatus.sendKeys(policyStatus);
                break;
        }

    }
    @FindBy(xpath ="//p[contains(text(),'Medical Policy?')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Medical Policy?\"]")
    public WebElement MedicalPolicy;

    @FindBy(xpath = "//div[@role='dialog']")
    public  WebElement dialogBox;


    @FindBy(xpath = "//span[@class='nomineeFormLabel' and contains(text(),'ADD EXISTING POLICY ')]")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther(contains[@name=\"ADD EXISTING POLICY\"]))[2]")
    public WebElement addExistingPolicy;

    @FindBy(xpath = "//span[text()='DO IT LATER ']")
    //@AndroidFindBy(accessibility = "doItLaterBtn")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='DO  IT LATER']")
    @iOSXCUITFindBy(iOSNsPredicate = "**/XCUIElementTypeButton[`label == ''`]")
    public WebElement eleDoItLaterBtn;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"policyNextButton\"`]")
    @AndroidFindBy(accessibility = "policyNextButton")
    //@AndroidFindBy(xpath = "//android.widget.TextView[@text='NEXT']")
    public WebElement eleExistingPolNextBtn;



    public void  addExistingPolicy(String insurerName,String sumAssured,String policyNumber,String yearofApplication,String basePlan,
                                   String annualPremium,String policyStatus) {

        if (addExistingPolicy.isDisplayed()) {
                addExistingPolicy.click();
                waitUtils.wait2Seconds();
                setInsurerName(insurerName);
                waitUtils.wait2Seconds();
                inputSumAssured("5000000");
                waitUtils.wait2Seconds();
                setpolicyNumber(policyNumber);
                setapplicationYear(yearofApplication);
                setbasePlan(basePlan);
                setannualPremium(annualPremium);
                setpolicyStatus(policyStatus);
                commonUtils.selectButtonByName("No",driver);
                waitUtils.wait2Seconds();
                commonUtils.selectButtonByName("SAVE",driver);
                waitUtils.wait2Seconds();
                commonUtils.selectButtonByName("NEXT",driver);
                waitUtils.wait2Seconds();
                commonUtils.selectButtonByName("NEXT",driver);


        }
    }
        public void removeOrEditPolicy(WebDriver driver,String type,String insurerName,String sumAssured){

        switch (type){
            case "REMOVE":
                commonUtils.selectButtonByName(type,driver);
                waitUtils.waitForElementToBeVisible(driver,dialogBox);
                commonUtils.selectButtonByName("Ok",driver);
                waitUtils.Asserting("equals",addExPolicy.getText(),"ADD EXISTING POLICY ");
                break;
            case "EDIT":
                commonUtils.selectButtonByName(type,driver);
                setInsurerName(insurerName);
                setsumAssured(Long.parseLong(sumAssured));
                waitUtils.wait2Seconds();
                commonUtils.selectButtonByName("SAVE",driver);
                break;

        }
    }

    @FindBy(xpath = "//*[contains(text(),'PURPOSE OF INSURANCE')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='PURPOSE OF INSURANCE']")
   // @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"PURPOSE OF INSURANCE\"]")
    @iOSXCUITFindBy(accessibility = "PURPOSE OF INSURANCE")
    public  WebElement purposeInsurTitle;

    @FindBy(xpath = "//span[@class='MuiTypography-root MuiFormControlLabel-label jss114 MuiTypography-body1']")
    public List<WebElement> listOfOptionsToSelectInsurance;

    public void getOptionForInsurance(WebDriver driver,String optionName) throws Exception {

        switch (BaseTest.PLATFORM_NAME){
            case "android":
                commonUtils.getValuesFromList(driver,this.listOfOptionsToSelectInsurance,optionName);
                break;
            case "ios":
                commonUtils.getValuesFromList(driver,this.listOfOptionsToSelectInsurance,optionName);
                break;
            default:
                commonUtils.getValuesFromList(driver,this.listOfOptionsToSelectInsurance,optionName);
        }
    }

    @FindBy(xpath = "//span[contains(text(),'')]/preceding-sibling::span//input")
    public List<WebElement> purposeInsurencesOptions;

    public void selectPurposeInsurence(String optionName){
        //waitUtils.waitForElementToBeVisible(driver,purposeInsurTitle);
        WebElement option;
        switch (BaseTest.PLATFORM_NAME){

            case "android":

                break;
            case "ios":
                option=driver.findElement(By.xpath(""));
                option.click();
                break;

            default:
                 option=driver.findElement(By.xpath("//span[contains(text(),'"+optionName+"')]/preceding-sibling::span//input"));
                 option.click();
                break;

        }

    }
    @FindBy(xpath = "//p[@id='insurerName-helper-text']")
    public WebElement insurerErrorMsg;

    public String getInsurerMessage(){
        return  this.insurerErrorMsg.getText();
    }


    @FindBy(xpath = "//p[@id='sumAssured-helper-text']")
    public WebElement sumAssuredErrorMsg;

    public String getSumAssuredMessage(){
        return  this.sumAssuredErrorMsg.getText();
    }

    public void multipleOptionsSelection() {
        int count = 0;
        waitUtils.wait2Seconds();
        try {
            waitUtils.WaitForElementPresent(driver,purposeInsurTitle, 60);
            waitUtils.wait5Seconds();
        } catch (Exception e1) {

            e1.printStackTrace();
        }
        List<WebElement> checkBoxes = purposeInsurencesOptions;

        for (int i = 0; i < checkBoxes.size(); i++) {
            WebElement ele = purposeInsurencesOptions.get(i);
            //Base.wait5Seconds();
            try {
               if (ele.isEnabled() == true && ele.isDisplayed() == true) {
                    count++;
                    waitUtils.wait2Seconds();
                    waitUtils.WaitForObjectToBeClick(driver,ele, 1000);
                    waitUtils.JavaScriptClick(driver,ele);
                    System.out.println("selected  checkboxes :" + i);
                    // ele.click();
                }

            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        if (count == 3) {
            System.out.println("Not able to select morethan 3 parts");
             for (int j = 0; j < count; j++) {
                WebElement ele = purposeInsurencesOptions.get(j);
                if (ele.isEnabled() == true && ele.isDisplayed() == true) {

                    try {
                        waitUtils.WaitForObjectToBeClick(driver,ele, 1000);
                    } catch (Exception e) {

                        e.printStackTrace();
                    }
                    waitUtils.JavaScriptClick(driver,ele);
                }
            }
        }
    }
    public void inputSumAssured(String sumAssuredAmount) {
        this.sumAssured.click();
        this.sumAssured.sendKeys(sumAssuredAmount);
        waitUtils.implicitWait(driver, 30000);
        //((AndroidDriver) driver).getKeyboard().pressKey("\n");
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                ((AndroidDriver<MobileElement>) driver).pressKey(new KeyEvent(AndroidKey.ENTER));
                //((AndroidDriver) driver).getKeyboard().pressKey("\n");
                break;
            case "ios":
                sumAssured.sendKeys(Keys.RETURN);
                break;
            default:
        }
    }
    @FindBy(xpath = "//div[contains(text(),'8.0 Health Details')]")
    @AndroidFindBy(xpath = "//android.view.View[@text='8.0 Health Details']")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"8.0 Health Details\"])[2]")
    public WebElement healthDetailsTitle;

    @iOSXCUITFindBy(accessibility = "Existing Policy ADD NEW")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Existing Policy']")
    public WebElement eleExistingPolicySection;
}


