package com.absli.pageObjects;

import com.absli.helpers.jsonReaders.ReadJson;
import com.absli.utils.CommonUtils;
import com.absli.utils.WaitUtils;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import tests.BaseTest;

import static com.absli.logger.LoggingManager.logMessage;

public class PersonalInfoPage extends Page {

    WebDriver driver;
    CommonUtils commonUtils;
    ReadJson jsonObj;
    SignInPage signIn;
    DashboardPage dashPage;
    WaitUtils waitUtils;


    public PersonalInfoPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        logMessage("Initializing the " + this.getClass().getSimpleName() + " elements");
        PageFactory.initElements(new AppiumFieldDecorator(driver), PersonalInfoPage.this);

        //jsonObj = new ReadJson();
        //signIn = new SignInPage(driver);
        //dashPage = new DashboardPage(driver);
        waitUtils = new WaitUtils();
        commonUtils = new CommonUtils();
    }
    @FindBy(name = "emailId")
    @AndroidFindBy(accessibility = "emailId")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeTextField[`name == \"emailId\"`]")
    public WebElement elePersonalEmailIdInput;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"emailIdrightIcon\"`]")
    @AndroidFindBy(accessibility = "emailIdrightIcon")
    private WebElement eleEmailArrowBtn;

    @FindBy(name = "fatherSpouseName")
    @AndroidFindBy(accessibility = "fatherSpouseName")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeTextField[`label == \"fatherSpouseName\"`]")
    public WebElement eleFatherSpouseNameInput;

    @FindBy(name = "motherName")
    @AndroidFindBy(accessibility = "motherName")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeTextField[`label == \"motherName\"`]")
    public WebElement eleMotherNameInput;

    @FindBy(name = "maidenName")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeTextField[`label == \"maidenName\"`]")
    public WebElement eleMaidenNameInput;

    @FindBy(xpath = "//span[text()='SAVE & CONTINUE']")
    //@AndroidFindBy(xpath = "(//android.widget.Button[@content-desc=\"continueBtn\"])[2]")
    @AndroidFindBy(accessibility = "personalInfoSaveButton")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"personalInfoSaveButton\"`]")
    public WebElement eleEmailSaveBtn;

    @FindBy(xpath = "//span[text()='SAVE & CONTINUE']")
    //@AndroidFindBy(xpath = "(//android.widget.Button[@content-desc=\"continueBtn\"])[2]")
    //@AndroidFindBy(xpath = "//android.widget.TextView[@text=\"NEXT\"]")
    @AndroidFindBy(accessibility = "personalInfoNextButton")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"personalInfoNextButton\"`]")
    public WebElement eleEmailNextBtn;

    @FindBy(xpath = "//div[@id='mui-component-select-23']")
    @AndroidFindBy(accessibility = "'23'")
    //@AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"'23'\"]/android.view.ViewGroup[1]/android.widget.Button")
    @iOSXCUITFindBy(className = "'23'")
    public WebElement eleQualificationDrpBtn;

    @FindBy(xpath = "//p[contains(text(),'Alert')]")
    @AndroidFindBy(id = "android:id/alertTitle")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeAlert[@name=\"Alert\"]")
    public WebElement eleAlertDialog;

    @FindBy(xpath = "//span[contains(text(),'OK')]")
    @AndroidFindBy(id = "android:id/button1")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"OK\"`]")
    private WebElement eleOkButton;

    @FindBy(xpath = "//span[text()='NEXT']")
    //@AndroidFindBy(xpath = "(//android.widget.Button[@content-desc=\"continueBtn\"])[3]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text=\"NEXT\"]")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"continueBtn\"`]")
    public WebElement elePersonalInfoNextBtn;

    public void acceptAlert() {
        this.eleOkButton.click();
    }

    public Boolean isAlertShown() {
        try {
            waitUtils.waitForElementToBeVisible(driver, eleAlertDialog);
            logMessage("======== > alert is shown");
            return this.eleAlertDialog.isDisplayed();
        } catch (NoSuchElementException e) {
            return false;
        }
    }


    public void inputPersonalEmailId(String PersonalEmailId){
        this.elePersonalEmailIdInput.click();
        this.elePersonalEmailIdInput.clear();
        this.elePersonalEmailIdInput.sendKeys(PersonalEmailId);
        //commonUtils.enterKey(elePersonalEmailIdInput,driver);
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                /*driver.findElement(By.xpath("//android.widget.Button[@content-desc='rightIcon']/android.widget.TextView")).click();
                driver.findElement(By.xpath("//android.widget.Button[@content-desc='rightIcon']/android.widget.TextView")).click();
*/
                ((AndroidDriver)driver).hideKeyboard();
                eleEmailArrowBtn.click();
                eleEmailArrowBtn.click();
                if (isAlertShown()) {
                    acceptAlert();
                }
                waitUtils.waitForElementToBeVisible(driver,eleFatherSpouseNameInput,10,"Element not loaded successfully");
                break;
            case "ios":
                commonUtils.enterKey(elePersonalEmailIdInput,driver);
                eleEmailArrowBtn.click();
                eleEmailArrowBtn.click();

                break;
            default:
        }
    }


    public void inputPersonalFatherSpouseName(String FatherSpouseName){
        this.eleFatherSpouseNameInput.click();
        this.eleFatherSpouseNameInput.clear();
        this.eleFatherSpouseNameInput.sendKeys(FatherSpouseName);
        //commonUtils.enterKey(eleFatherSpouseNameInput,driver);
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                ((AndroidDriver)driver).hideKeyboard();
                break;
            case "ios":
                commonUtils.enterKey(eleFatherSpouseNameInput,driver);
                //((IOSDriver)driver).hideKeyboard();
                break;
            default:
        }
    }

    public void inputPersonalMotherName(String MotherName){
        this.eleMotherNameInput.click();
        this.eleMotherNameInput.clear();
        this.eleMotherNameInput.sendKeys(MotherName);
        //commonUtils.enterKey(eleMotherNameInput,driver);
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                ((AndroidDriver)driver).hideKeyboard();
                break;
            case "ios":
                //((IOSDriver)driver).hideKeyboard();
                commonUtils.enterKey(eleMotherNameInput,driver);

                break;
            default:
        }
    }

    public void inputPersonalMaidenName(String MaidenName){
        this.eleMaidenNameInput.click();
        this.eleMaidenNameInput.clear();
        this.eleMaidenNameInput.sendKeys(MaidenName);
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                ((AndroidDriver)driver).hideKeyboard();
                break;
            case "ios":
                //((IOSDriver)driver).hideKeyboard();
                commonUtils.enterKey(eleMaidenNameInput,driver);
                break;
            default:
        }
        //commonUtils.enterKey(eleMaidenNameInput,driver);
    }

    public void fillPersonalInfo(String emailId,String maritalStatus,String spouseName,String motherName,String maidenName) {
        inputPersonalEmailId(emailId);
        waitUtils.waitForElementToBeVisible(driver,eleFatherSpouseNameInput,20,"Element not visible");
        chooseMaritalStatus(maritalStatus);
        inputPersonalFatherSpouseName(spouseName);
        inputPersonalMotherName(motherName);
        if(commonUtils.isDisplayed(driver,eleMaidenNameInput)) {
            inputPersonalMaidenName(maidenName);
        }
        commonUtils.scrollTillEndOfPage(driver);
        waitUtils.waitForElementToBeClickable(driver,eleEmailSaveBtn);
        commonUtils.chooseActionButton(eleEmailSaveBtn);
        Assert.assertEquals(eleQualificationDrpBtn.getText(),"");
    }

    public void fillPersonal(String emailId,String maritalStatus,String spouseName,String motherName,String maidenName) {
        //inputPersonalEmailId(emailId);
        this.elePersonalEmailIdInput.click();
        this.elePersonalEmailIdInput.clear();
        this.elePersonalEmailIdInput.sendKeys(emailId);
        //commonUtils.enterKey(elePersonalEmailIdInput,driver);
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                ((AndroidDriver)driver).hideKeyboard();
                break;
            case "ios":
                commonUtils.enterKey(elePersonalEmailIdInput,driver);
                ((IOSDriver)driver).hideKeyboard();
                break;
            default:
        }
        waitUtils.waitUntilVisible(driver,eleFatherSpouseNameInput,20);
        chooseMaritalStatus(maritalStatus);
        inputPersonalFatherSpouseName(spouseName);
        inputPersonalMotherName(motherName);
        if(commonUtils.isDisplayed(driver,eleMaidenNameInput)) {
            inputPersonalMaidenName(maidenName);
        }
        commonUtils.scrollTillEndOfPage(driver);
        waitUtils.waitForElementToBeClickable(driver,eleEmailSaveBtn);
        commonUtils.chooseActionButton(eleEmailSaveBtn);
        //Assert.assertEquals(eleQualificationDrpBtn.getText(),"");
    }
    public void chooseMaritalStatus(String MaritalStatus) {

        switch (baseTest.getPlatform().toLowerCase()) {
            case "android":
                switch (MaritalStatus) {
                    case "Single":
                        driver.findElement(By.xpath("//android.widget.TextView[@text='Single']")).click();
                        driver.findElement(By.xpath("//android.widget.TextView[@text='Single']")).click();
                        break;
                    case "Married":
                        driver.findElement(By.xpath("//android.widget.TextView[@text='Married']")).click();
                        driver.findElement(By.xpath("//android.widget.TextView[@text='Married']")).click();
                        break;
                    default:
                        driver.findElement(By.xpath("//android.widget.TextView[@text='"+MaritalStatus+"']")).click();
                        driver.findElement(By.xpath("//android.widget.TextView[@text='"+MaritalStatus+"']")).click();
                }
                break;
            case "ios":
                ((IOSDriver) driver).findElementByAccessibilityId(MaritalStatus).click();
                break;
            default:
                driver.findElement(By.xpath("//*[text()='" + MaritalStatus + "']")).click();
        }
    }
}
