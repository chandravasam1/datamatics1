package com.absli.pageObjects;

import com.absli.helpers.jsonReaders.ReadJson;
import com.absli.helpers.models.LoginModel;
import com.absli.helpers.models.ProposerModel;
import com.absli.utils.CommonUtils;
import com.absli.utils.WaitUtils;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import tests.BaseTest;

import static com.absli.logger.LoggingManager.logMessage;

public class Covid_19_DetailsPage extends Page{
    WebDriver driver;
    CommonUtils commonUtils;
    ReadJson jsonObj;
    LoginModel loginModel;
    SignInPage signIn;
    DashboardPage dashPage;
    WaitUtils waitUtils;
    ProposerModel proposerModel;

    public Covid_19_DetailsPage(WebDriver driver) throws InterruptedException {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        logMessage("Initializing the " + this.getClass().getSimpleName() + " elements");
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);

        waitUtils = new WaitUtils();
        commonUtils = new CommonUtils();
    }

    @FindBy(xpath = "//div[contains(text(),'8.0 Health Details')]")
    @AndroidFindBy(xpath = "//android.view.View[@text='8.0 Health Details']")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"8.0 Health Details\"])[2]")
    public WebElement healthDetailsTitle;

    public String getPageTitle(){
        String pageTitle = "";
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                pageTitle=this.healthDetailsTitle.getText();
                break;
            case "ios":
                pageTitle=this.healthDetailsTitle.getText();
                break;
            default:
                WebElement element=driver.findElement((By.xpath("//div[contains(text(),'8.0 Health Details')]")));
                pageTitle=element.getText();
        }
    return pageTitle;
    }
    @FindBy(xpath = "//div[contains(text(),'Covid 19 Details')]")
    @AndroidFindBy(accessibility = "Covid19 Detail")
    @iOSXCUITFindBy(accessibility = "Covid19 Detail")
    public WebElement moduleTitle;

    public void getModuleName(String nameOfModule){
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                commonUtils.scrollIntoView(nameOfModule,driver);
                this.moduleTitle.click();
                break;
            case "ios":
                commonUtils.scrollIntoView(nameOfModule,driver);
                this.moduleTitle.click();
                break;
            default:
                WebElement element=driver.findElement((By.xpath("//div[contains(text(),'"+nameOfModule+"')]")));
                commonUtils.scrollToElement(driver,element);
                element.click();
        }

    }
    //(//XCUIElementTypeStaticText[@name='Tests']/parent::XCUIElementTypeOther/..//XCUIElementTypeOther[contains(@name,'Yes')])[5]
    @FindBy(xpath = "//div[contains(text(),'Symptoms')]/ancestor::div[@class='card-title-container']/following-sibling::div//div[text()='Yes']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Symptoms']//following-sibling::android.view.ViewGroup//android.widget.TextView[@text='Yes']")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"Yes\"])[1]")
    public WebElement symptomsSection;

    public void gotoSection(String sectionName){
        WebElement element;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                element   =driver.findElement(By.xpath("//android.widget.TextView[@text='"+sectionName+"']//following-sibling::android.view.ViewGroup//android.widget.TextView[@text='Yes']"));
                element.click();
                break;
            case "ios":
                element=driver.findElement(By.xpath("(//XCUIElementTypeStaticText[@name=\"" + sectionName + "\"]/parent::XCUIElementTypeOther/..//XCUIElementTypeOther[contains(@name,'Yes')])[5]"));
                element.click();
                break;
            default:
                 element=driver.findElement((By.xpath("//div[contains(text(),'"+sectionName+"')]/ancestor::div[@class='card-title-container']/following-sibling::div//div[text()='Yes']")));
                element.click();
                break;
        }

    }
    public WebElement gotoSectionElement(String sectionName){
        WebElement element = null;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                element   =driver.findElement(By.xpath("//android.widget.TextView[@text='"+sectionName+"']//following-sibling::android.view.ViewGroup//android.widget.TextView[@text='Yes']"));
                element.click();
                break;
            case "ios":
                element=driver.findElement(By.xpath("(//XCUIElementTypeStaticText[@name=\"" + sectionName + "\"]/parent::XCUIElementTypeOther/..//XCUIElementTypeOther[contains(@name,'Yes')])[5]"));
                element.click();
                break;
            default:
                element=driver.findElement((By.xpath("//div[contains(text(),'"+sectionName+"')]/ancestor::div[@class='card-title-container']/following-sibling::div//div[text()='Yes']")));
                element.click();
                break;
        }
        return element;
    }
    @FindBy(xpath = "//div[contains(text(),'Symptoms')]/ancestor::div[@class='card-title-container']/following-sibling::div//div[text()='Yes']/ancestor::div/following-sibling::div//input")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Symptoms']//following-sibling::android.view.ViewGroup//android.widget.TextView[@text='Provide Details']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name=\"402\"]")
    public WebElement symptomsDetials;

    public void setSymptomsDetials(String sectionName,String description){
        WebElement element;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                element=driver.findElement(By.xpath("//android.widget.TextView[@text='"+sectionName+"']//following-sibling::android.view.ViewGroup//android.widget.TextView[@text='Provide Details']"));
                element.sendKeys(description);
                break;
            case "ios":
                element=driver.findElement(By.xpath("//XCUIElementTypeTextField[@name=\"402\"]"));
                element.sendKeys(description);
                break;
            default:
                //element  =driver.findElement(By.xpath("//div[contains(text(),'"+sectionName+"')]/ancestor::div[@class='card-title-container']/following-sibling::div//div[text()='Yes']/ancestor::div[@class='jss562']/following-sibling::div[contains(@class,'jss629')]//input"));
                this.symptomsDetials.sendKeys(description);
        }
    }
    @FindBy(xpath = "//div[contains(text(),'Tests')]/ancestor::div[@class='card-title-container']/following-sibling::div//div[text()='Yes']/ancestor::div/following-sibling::div//input")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Tests']/..//android.widget.TextView[@text='Yes']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name=\"404\"]")
    public WebElement valueTests;

    public void valueToBeEnterForTests(String sectionName,String description){
        WebElement element;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                commonUtils.scrollIntoView(sectionName,driver);
                element=driver.findElement(By.xpath("//android.widget.TextView[@text='"+sectionName+"']/..//android.widget.TextView[@text='Provide Details']"));
                element.sendKeys(description);
                break;
            case "ios":
                element=driver.findElement(By.xpath("//XCUIElementTypeTextField[@name=\"404\"]"));
                element.sendKeys(description);

                break;
            default:
                commonUtils.scrollIntoView(sectionName,driver);
                element =driver.findElement(By.xpath("//div[contains(text(),'"+sectionName+"')]/ancestor::div[@class='card-title-container']/following-sibling::div//div[text()='Yes']/ancestor::div/following-sibling::div//input"));
                element.sendKeys(description);
        }
    }
    @FindBy(xpath = "//div[contains(text(),'Covid Contact')]/ancestor::div[@class='card-title-container']/following-sibling::div//div[text()='Yes']/ancestor::div/following-sibling::div//input")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Covid Contact']/..//android.widget.TextView[@text='Yes']")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name='Covid Contact']/parent::XCUIElementTypeOther/..//XCUIElementTypeOther[contains(@name,'Yes')])[5]")
    public WebElement covidContact;

    public void valueToBeEnterForCovidContact(String sectionName,String description){
        WebElement element;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                element=driver.findElement(By.xpath("//android.widget.TextView[@text='"+sectionName+"']/..//android.widget.TextView[@text='Provide Details']"));
                element.sendKeys(description);
                break;
            case "ios":
                element=driver.findElement((By.xpath("//XCUIElementTypeTextField[@name=\"406\"]")));
                element.sendKeys(description);
                break;
            default:
                element =driver.findElement(By.xpath("//div[contains(text(),'"+sectionName+"')]/ancestor::div[@class='card-title-container']/following-sibling::div//div[text()='Yes']/ancestor::div/following-sibling::div//input"));
                element.sendKeys(description);
        }
    }

    @FindBy(xpath = "//div[contains(text(),'Quarantine')]/ancestor::div[@class='card-title-container']/following-sibling::div//div[text()='Yes']/ancestor::div/following-sibling::div//input")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Quarantine']/..//android.widget.TextView[@text='Yes']")
   @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name='Quarantine']/parent::XCUIElementTypeOther/..//XCUIElementTypeOther[contains(@name,'Yes')])[5]")
    public WebElement valueToQuarantine;

    public void textToBeEnter(String moduleName,String description){
        WebElement element;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                element=driver.findElement(By.xpath("//android.widget.TextView[@text='"+moduleName+"']/..//android.widget.TextView[@text='Provide Details']"));
                element.sendKeys(description);
                break;
            case "ios":
                element=driver.findElement(By.xpath("//XCUIElementTypeTextField[@name=\"408\"]"));
                element.sendKeys(description);
                break;
            default:
                element =driver.findElement(By.xpath("//div[contains(text(),'"+moduleName+"')]/ancestor::div[@class='card-title-container']/following-sibling::div//div[text()='Yes']/ancestor::div/following-sibling::div//input"));
                element.sendKeys(description);
        }
    }
    @FindBy(xpath = "//div[contains(text(),'Past Travel')]/ancestor::div[@class='card-title-container']/following-sibling::div//div[text()='Yes']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Past Travel']/..//android.widget.TextView[@text='Yes']")
   @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name='Past Travel']/parent::XCUIElementTypeOther/..//XCUIElementTypeOther[contains(@name,'Yes')])[5]")
    public WebElement pastTravelYes;


    public void setPastTravelCountry(String countryName){
        WebElement country;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                country=driver.findElement(By.xpath("//android.widget.TextView[@text='Past Travel']/..//android.widget.EditText[@content-desc='country']"));
                country.sendKeys(countryName);
                break;
            case "ios":
                country=driver.findElement(By.xpath("//XCUIElementTypeTextField[@name=\"country\"]"));
                country.sendKeys(countryName);
                break;
            default:
                country=driver.findElement(By.xpath("//input[@id='country']"));
                country.sendKeys(countryName);
                break;
        }
    }
    @FindBy(xpath = "//input[@id='city']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Past Travel']/..//android.widget.EditText[@content-desc='city']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name=\"city\"]")
    public WebElement cityName;

    public void setPastTravelCity(String cityName){
        WebElement city;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                city=driver.findElement(By.xpath("//android.widget.TextView[@text='Past Travel']/..//android.widget.EditText[@content-desc='city']"));
                city.sendKeys(cityName);
                break;
            case "ios":
                city=driver.findElement(By.xpath("//XCUIElementTypeTextField[@name=\"city\"]"));
                city.sendKeys(cityName);
                break;
            default:
                city=driver.findElement(By.xpath("//input[@id='city']"));
                city.sendKeys(cityName);
                break;
        }
    }

    @FindBy(xpath = "//label[contains(text(),'Date of Arrival')]/parent::div//input[@id='DD']")
    @AndroidFindBy(xpath = "(//android.widget.TextView[@text='Date of Arrival']/..//android.widget.TextView[@text='DD'])[1]")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[contains(@name,'Date of Arrival')]/..//XCUIElementTypeOther[@name=\"day\"])[1]")
    public WebElement dateOfArrialDay;

    public void dateOfArrialDay(String dateOfArrivalDay){
        WebElement day;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                day=driver.findElement(By.xpath("(//android.widget.TextView[@text='Date of Arrival']/..//android.widget.TextView[@text='DD'])[1]"));
                day.sendKeys(dateOfArrivalDay);
                break;
            case "ios":
                day=driver.findElement(By.xpath("(//XCUIElementTypeOther[contains(@name,'Date of Arrival')]/..//XCUIElementTypeOther[@name=\"day\"])[1]"));
                day.sendKeys(dateOfArrivalDay);
                break;
            default:
                day=driver.findElement(By.xpath("//label[contains(text(),'Date of Arrival')]/parent::div//input[@id='DD']"));
                day.sendKeys(dateOfArrivalDay);
                break;
        }
    }
    @FindBy(xpath = "//label[contains(text(),'Date of Arrival')]/parent::div//input[@id='MM']")
    @AndroidFindBy(xpath = "(//android.widget.TextView[@text='Date of Arrival']/..//android.widget.TextView[@text='MM'])[1]")
   @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[contains(@name,'Date of Arrival')]/..//XCUIElementTypeOther[@name=\"month\"])[1]")
    public WebElement dateOfArrivalMonth;

    public void dateOfArrivalMonth(String dateOfArrivalMonth){
        WebElement month;
         switch (BaseTest.PLATFORM_NAME){
            case "android":
                month=driver.findElement(By.xpath("(//android.widget.TextView[@text='Date of Arrival']/..//android.widget.TextView[@text='MM'])[1]"));
                month.sendKeys(dateOfArrivalMonth);
                break;
            case "ios":
                month=driver.findElement(By.xpath("(//XCUIElementTypeOther[contains(@name,'Date of Arrival')]/..//XCUIElementTypeOther[@name=\"month\"])[1]"));
                month.sendKeys(dateOfArrivalMonth);
                break;
            default:
                month=this.dateOfArrivalMonth;
                month.sendKeys(dateOfArrivalMonth);
                break;
        }
    }
    @FindBy(xpath = "//label[contains(text(),'Date of Arrival')]/parent::div//input[@id='YYYY']")
    @AndroidFindBy(xpath = "(//android.widget.TextView[@text='Date of Arrival']/..//android.widget.TextView[@text='YYYY'])[1]")
   @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[contains(@name,'Date of Arrival')]/..//XCUIElementTypeOther[@name=\"year\"])[1]")
    public WebElement dateOfArrialYear;

    public void dateOfArrialYear(String dateOfArrialYear){
        WebElement year;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                year=driver.findElement(By.xpath("(//android.widget.TextView[@text='Date of Arrival']/..//android.widget.TextView[@text='YYYY'])[1]"));
                year.sendKeys(dateOfArrialYear);
                break;
            case "ios":
                year=driver.findElement(By.xpath("(//XCUIElementTypeOther[contains(@name,'Date of Arrival')]/..//XCUIElementTypeOther[@name=\"year\"])[1]"));
                year.sendKeys(dateOfArrialYear);
                break;
            default:
                year=this.dateOfArrialYear;
                year.sendKeys(dateOfArrialYear);
                break;
        }
    }
    @FindBy(xpath = "//label[contains(text(),'Date of Departure')]/parent::div//input[@id='DD']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Date of Departure']/../android.widget.TextView[@text='DD']")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[contains(@name,'Date of Departure')]/..//XCUIElementTypeOther[@name=\"day\"])[2]")
    public WebElement dateOfDepartureDay;

    public void dateOfDepartureDay(String departureDay){
        WebElement day;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                day=driver.findElement(By.xpath("//android.widget.TextView[@text='Date of Departure']/../android.widget.TextView[@text='DD']"));
                day.sendKeys(departureDay);
                break;
            case "ios":
                day=driver.findElement(By.xpath("(//XCUIElementTypeOther[contains(@name,'Date of Departure')]/..//XCUIElementTypeOther[@name=\"day\"])[2]"));
                day.sendKeys(departureDay);
                break;
            default:
                day=dateOfDepartureDay;
                day.sendKeys(departureDay);
                break;
        }
    }
    @FindBy(xpath = "//label[contains(text(),'Date of Departure')]/parent::div//input[@id='MM']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Date of Departure']/..//android.widget.TextView[@text='MM']")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[contains(@name,'Date of Departure')]/..//XCUIElementTypeOther[@name=\"month\"])[2]")
    public WebElement departureMonth;

    public void departureMonth(String depatureMonth){
        WebElement month;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                month=driver.findElement(By.xpath("//android.widget.TextView[@text='Date of Departure']/..//android.widget.TextView[@text='MM']"));
                month.sendKeys(depatureMonth);
                break;
            case "ios":
                month=driver.findElement(By.xpath("(//XCUIElementTypeOther[contains(@name,'Date of Departure')]/..//XCUIElementTypeOther[@name=\"month\"])[2]"));
                month.sendKeys(depatureMonth);
                break;
            default:
                month=this.departureMonth;
                month.sendKeys(depatureMonth);
                break;
        }
    }
    @FindBy(xpath = "//label[contains(text(),'Date of Departure')]/parent::div//input[@id='YYYY']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Date of Departure']/..//android.widget.TextView[@text='YYYY']")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[contains(@name,'Date of Departure')]/..//XCUIElementTypeOther[@name=\"year\"])[2]")
    public WebElement departureYear;

    public void departureYear(String departureYear){
        WebElement year;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                year=driver.findElement(By.xpath("//android.widget.TextView[@text='Date of Departure']/..//android.widget.TextView[@text='YYYY']"));
                year.sendKeys(departureYear);
                break;
            case "ios":
                year=driver.findElement(By.xpath("(//XCUIElementTypeOther[contains(@name,'Date of Departure')]/..//XCUIElementTypeOther[@name=\"year\"])[2]"));
                year.sendKeys(departureYear);
                break;
            default:
                this.departureYear.sendKeys(departureYear);
                break;
        }
    }

    @FindBy(xpath = "//div[contains(text(),'Future travel')]//ancestor::div[@class='card-container-common']//input[@id='country']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Future travel']/..//android.widget.EditText[@content-desc='country']")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeTextField[@name=\"country\"])[2]")
    public WebElement futureTravelCountry;

    public void getFutureTravelCountry(String futureTravelCountryName){
        WebElement countryName;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                countryName=driver.findElement(By.xpath("//android.widget.TextView[@text='Future travel']/..//android.widget.EditText[@content-desc='country']"));
                countryName.sendKeys(futureTravelCountryName);
                break;
            case "ios":
                countryName=driver.findElement(By.xpath("(//XCUIElementTypeTextField[@name=\"country\"])[2]"));
                countryName.sendKeys(futureTravelCountryName);
                break;
            default:
                this.futureTravelCountry.sendKeys(futureTravelCountryName);
                break;
        }
    }
    @FindBy(xpath = "//div[contains(text(),'Past Travel')]//ancestor::div[@class='card-container-common']//input[@id='city']")
    @AndroidFindBy(xpath = "(//android.widget.TextView[@text='Future travel']/..//android.widget.EditText[@content-desc='city'])[1]")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeTextField[@name=\"city\"])[2]")
    public WebElement futureTravelCity;

    public void getFutureTravelCity(String futureTravelCityName){
        WebElement cityName;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                cityName=driver.findElement(By.xpath("(//android.widget.TextView[@text='Future travel']/..//android.widget.EditText[@content-desc='city'])[1]"));
                cityName.sendKeys(futureTravelCityName);
                break;
            case "ios":
                cityName=driver.findElement(By.xpath("(//XCUIElementTypeTextField[@name=\"city\"])[2]"));
                cityName.sendKeys(futureTravelCityName);
                break;
            default:
                this.futureTravelCity.sendKeys(futureTravelCityName);
                break;
        }
    }

    @FindBy(xpath = "//div[contains(text(),'Future travel')]//ancestor::div[@class='card-container-common']//input[@id='DD']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Future travel']/..//android.widget.TextView[@text='Date of Arrival']/..//android.widget.TextView[@text='DD']")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[contains(@name,'Date of Arrival')]/..//XCUIElementTypeOther[@name=\"day\"])[3]")
    WebElement futureTravelDay;

    public void futureTravelDay(String futureTravelDay){
        WebElement day;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                day=driver.findElement(By.xpath("//android.widget.TextView[@text='Future travel']/..//android.widget.TextView[@text='Date of Arrival']/..//android.widget.TextView[@text='DD']"));
                day.sendKeys(futureTravelDay);
                break;
            case "ios":
                day=driver.findElement(By.xpath("(//XCUIElementTypeOther[contains(@name,'Date of Arrival')]/..//XCUIElementTypeOther[@name=\"day\"])[3]"));
                day.sendKeys(futureTravelDay);
                break;
            default:
                this.futureTravelDay.sendKeys(futureTravelDay);
                break;
        }
    }
    @FindBy(xpath = "//div[contains(text(),'Future travel')]//ancestor::div[@class='card-container-common']//input[@id='MM']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Future travel']/..//android.widget.TextView[@text='Date of Arrival']/..//android.widget.TextView[@text='MM']")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[contains(@name,'Date of Arrival')]/..//XCUIElementTypeOther[@name=\"month\"])[3]")
    WebElement futureTravelMonth;

    public void futureTravelMonth(String futureTravelMonth){
        WebElement month;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                month=driver.findElement(By.xpath("//android.widget.TextView[@text='Future travel']/..//android.widget.TextView[@text='Date of Arrival']/..//android.widget.TextView[@text='MM']"));
                month.sendKeys(futureTravelMonth);
                break;
            case "ios":
                month=driver.findElement(By.xpath("(//XCUIElementTypeOther[contains(@name,'Date of Arrival')]/..//XCUIElementTypeOther[@name=\"month\"])[3]"));
                month.sendKeys(futureTravelMonth);
                break;
            default:
                this.futureTravelMonth.sendKeys(futureTravelMonth);
                break;
        }
    }
    @FindBy(xpath = "//div[contains(text(),'Future travel')]//ancestor::div[@class='card-container-common']//input[@id='YYYY']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Future travel']/..//android.widget.TextView[@text='Date of Arrival']/..//android.widget.TextView[@text='YYYY']")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[contains(@name,'Date of Arrival')]/..//XCUIElementTypeOther[@name=\"year\"])[3]")
    WebElement futureTravelYear;

    public void futureTravelYear(String futuretravelYear){
        WebElement year;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                year=driver.findElement(By.xpath("//android.widget.TextView[@text='Future travel']/..//android.widget.TextView[@text='Date of Arrival']/..//android.widget.TextView[@text='YYYY']"));
                year.sendKeys(futuretravelYear);
                break;
            case "ios":
                year=driver.findElement(By.xpath("(//XCUIElementTypeOther[contains(@name,'Date of Arrival')]/..//XCUIElementTypeOther[@name=\"year\"])[3]"));
                year.sendKeys(futuretravelYear);
                break;
            default:
                this.futureTravelYear.sendKeys(futuretravelYear);
                break;
        }
    }
    @FindBy(xpath = "//div[contains(text(),'Future travel')]//ancestor::div[@class='card-container-common']//input[@id='noOfDays']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Intended Duration']/..//android.widget.TextView[@text='No. of Days']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name=\"noDays\"]")
    public WebElement noOfDays;

    public void noOfDays(String numberOfDays){
        WebElement days;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                days=driver.findElement(By.xpath("//android.widget.TextView[@text='Intended Duration']/..//android.widget.TextView[@text='No. of Days']"));
                days.sendKeys(numberOfDays);
                break;
            case "ios":
                days=driver.findElement(By.xpath("//XCUIElementTypeTextField[@name=\"noDays\"]"));
                days.sendKeys(numberOfDays);
                break;
            default:
                this.noOfDays.sendKeys(numberOfDays);
                break;
        }
    }
    @FindBy(xpath = "//div[contains(text(),'Covid Vaccination')]//ancestor::div[@class='card-container-common']//label[contains(text(),'Date of administration of the first dose')]/parent::div//input[@id='DD']")
    @AndroidFindBy(xpath = "(//android.widget.TextView[@text='Covid Vaccination']/..//android.widget.TextView[@text='Date of administration of the first dose']/..//android.widget.TextView[@text='DD'])[1]")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[contains(@name,'Date of administration of the first dose')]/..//XCUIElementTypeOther[@name=\"day\"])[4]")
    public  WebElement vaccinationDay;

    public void vaccinationDay(String vaccinationDay){
        WebElement day;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                day=driver.findElement(By.xpath("(//android.widget.TextView[@text='Covid Vaccination']/..//android.widget.TextView[@text='Date of administration of the first dose']/..//android.widget.TextView[@text='DD'])[1]"));
                day.sendKeys(vaccinationDay);
                break;
            case "ios":
                day=driver.findElement(By.xpath("(//XCUIElementTypeOther[contains(@name,'Date of administration of the first dose')]/..//XCUIElementTypeOther[@name=\"day\"])[4]"));
                day.sendKeys(vaccinationDay);
                break;
            default:
                this.vaccinationDay.sendKeys(vaccinationDay);
                break;
        }
    }
    @FindBy(xpath = "//div[contains(text(),'Covid Vaccination')]//ancestor::div[@class='card-container-common']//label[contains(text(),'Date of administration of the first dose')]/parent::div//input[@id='MM']")
    @AndroidFindBy(xpath = "(//android.widget.TextView[@text='Covid Vaccination']/..//android.widget.TextView[@text='Date of administration of the first dose']/..//android.widget.TextView[@text='MM'])[1]")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[contains(@name,'Date of administration of the first dose')]/..//XCUIElementTypeOther[@name=\"month\"])[4]")
    public  WebElement vaccinationMonth;
    public void vaccinationMonth(String vaccinationMonth){
        WebElement month;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                month=driver.findElement(By.xpath("(//android.widget.TextView[@text='Covid Vaccination']/..//android.widget.TextView[@text='Date of administration of the first dose']/..//android.widget.TextView[@text='MM'])[1]"));
                month.sendKeys(vaccinationMonth);
                break;
            case "ios":
                month=driver.findElement(By.xpath("(//XCUIElementTypeOther[contains(@name,'Date of administration of the first dose')]/..//XCUIElementTypeOther[@name=\"month\"])[4]"));
                month.sendKeys(vaccinationMonth);
                break;
            default:
                this.vaccinationMonth.sendKeys(vaccinationMonth);
                break;
        }
    }
    @FindBy(xpath = "//div[contains(text(),'Covid Vaccination')]//ancestor::div[@class='card-container-common']//label[contains(text(),'Date of administration of the first dose')]/parent::div//input[@id='YYYY']")
    @AndroidFindBy(xpath = "(//android.widget.TextView[@text='Covid Vaccination']/..//android.widget.TextView[@text='Date of administration of the first dose']/..//android.widget.TextView[@text='YYYY'])[1]")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[contains(@name,'Date of administration of the first dose')]/..//XCUIElementTypeOther[@name=\"year\"])[4]")
    public  WebElement vaccinationYear;

    public void vaccinationYear(String vaccinationYear){
        WebElement year;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                year=driver.findElement(By.xpath("(//android.widget.TextView[@text='Covid Vaccination']/..//android.widget.TextView[@text='Date of administration of the first dose']/..//android.widget.TextView[@text='YYYY'])[1]"));
                year.sendKeys(vaccinationYear);
                break;
            case "ios":
                year=driver.findElement(By.xpath("(//XCUIElementTypeOther[contains(@name,'Date of administration of the first dose')]/..//XCUIElementTypeOther[@name=\"year\"])[4]"));
                year.sendKeys(vaccinationYear);
                break;
            default:
                this.vaccinationYear.sendKeys(vaccinationYear);
                break;
        }
    }
    @FindBy(xpath = "//div[contains(text(),'Covid Vaccination')]//ancestor::div[@class='card-container-common']//label[contains(text(),'Date of administration of the second dose')]/parent::div//input[@id='DD']")
    @AndroidFindBy(xpath = "(//android.widget.TextView[@text='Covid Vaccination']/..//android.widget.TextView[@text='Date of administration of the second dose']/..//android.widget.TextView[@text='DD'])[2]")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[contains(@name,'Date of administration of the second dose')]/..//XCUIElementTypeOther[@name=\"day\"])[5]")
    public  WebElement vaccination2Day;
    public void vaccination2Day(String vaccination2Day){
        WebElement day;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                day=driver.findElement(By.xpath("(//android.widget.TextView[@text='Covid Vaccination']/..//android.widget.TextView[@text='Date of administration of the second dose']/..//android.widget.TextView[@text='DD'])[2]"));
                day.sendKeys(vaccination2Day);
                break;
            case "ios":
                day=driver.findElement(By.xpath("(//XCUIElementTypeOther[contains(@name,'Date of administration of the second dose')]/..//XCUIElementTypeOther[@name=\"day\"])[5]"));
                day.sendKeys(vaccination2Day);
                break;
            default:
                this.vaccination2Day.sendKeys(vaccination2Day);
                break;
        }
    }
    @FindBy(xpath = "//div[contains(text(),'Covid Vaccination')]//ancestor::div[@class='card-container-common']//label[contains(text(),'Date of administration of the second dose')]/parent::div//input[@id='MM']")
    @AndroidFindBy(xpath = "(//android.widget.TextView[@text='Covid Vaccination']/..//android.widget.TextView[@text='Date of administration of the second dose']/..//android.widget.TextView[@text='MM'])[2]")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[contains(@name,'Date of administration of the second dose')]/..//XCUIElementTypeOther[@name=\"month\"])[5]")
    public  WebElement vaccination2Month;

    public void vaccination2Month(String vaccination2Month){
        WebElement month;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                month=driver.findElement(By.xpath("(//android.widget.TextView[@text='Covid Vaccination']/..//android.widget.TextView[@text='Date of administration of the second dose']/..//android.widget.TextView[@text='MM'])[2]"));
                month.sendKeys(vaccination2Month);
                break;
            case "ios":
                month=driver.findElement(By.xpath("(//XCUIElementTypeOther[contains(@name,'Date of administration of the second dose')]/..//XCUIElementTypeOther[@name=\"dmonth\"])[5]"));
                month.sendKeys(vaccination2Month);
                break;
            default:
                this.vaccination2Month.sendKeys(vaccination2Month);
                break;
        }
    }
    @FindBy(xpath = "//div[contains(text(),'Covid Vaccination')]//ancestor::div[@class='card-container-common']//label[contains(text(),'Date of administration of the second dose')]/parent::div//input[@id='YYYY']")
    @AndroidFindBy(xpath = "(//android.widget.TextView[@text='Covid Vaccination']/..//android.widget.TextView[@text='Date of administration of the second dose']/..//android.widget.TextView[@text='YYYY'])[2]")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[contains(@name,'Date of administration of the second dose')]/..//XCUIElementTypeOther[@name=\"year\"])[5]")
    public  WebElement vaccination2Year;


    public void vaccination2Year(String vaccination2year){
        WebElement year;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                year=driver.findElement(By.xpath("(//android.widget.TextView[@text='Covid Vaccination']/..//android.widget.TextView[@text='Date of administration of the second dose']/..//android.widget.TextView[@text='YYYY'])[2]"));
                year.sendKeys(vaccination2year);
                break;
            case "ios":
                year=driver.findElement(By.xpath("(//XCUIElementTypeOther[contains(@name,'Date of administration of the second dose')]/..//XCUIElementTypeOther[@name=\"year\"])[5]"));
                year.sendKeys(vaccination2year);
                break;
            default:
                this.vaccination2Year.sendKeys(vaccination2year);
                break;
        }
    }
    @FindBy(xpath = "//input[@placeholder='Name of vaccine']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Covid Vaccination']/..//android.widget.TextView[@text='Name of vaccine']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name=\"417\"]")
    public  WebElement vaccineName;

    public void setVaccineName(String vaccineName){
        WebElement vacName;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                vacName=driver.findElement(By.xpath("//android.widget.TextView[@text='Covid Vaccination']/..//android.widget.TextView[@text='Name of vaccine']"));
                vacName.sendKeys(vaccineName);
                break;
            case "ios":
                vacName=driver.findElement(By.xpath("//XCUIElementTypeTextField[@name=\"417\"]"));
                vacName.sendKeys(vaccineName);
                break;
            default:
                this.vaccineName.sendKeys(vaccineName);
                break;
        }
    }
    //input[@placeholder='Enter Details']
    @FindBy(xpath = "//div[contains(text(),'2. Have you experienced any adverse reaction post vaccination?')]/following-sibling::div//div[text()='Yes']")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"Yes\"])[9]")
    public WebElement postVaccinationExperienced;

    @FindBy(xpath = "//input[@placeholder='Enter Details']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='please share details including treatment taken for the same and date of complete recovery']/..//android.widget.TextView[@text='Enter Details']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name=\"419\"]")
    public  WebElement exOnPostVaccination;

    public void exOnPostVaccination(String postVacciName){
        WebElement vacciName;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                vacciName=driver.findElement(By.xpath("//android.widget.TextView[@text='please share details including treatment taken for the same and date of complete recovery']/..//android.widget.TextView[@text='Enter Details']"));
                vacciName.sendKeys(postVacciName);
                break;
            case "ios":
                vacciName=dateOfArrialDay.findElement(By.xpath("//XCUIElementTypeTextField[@name=\"419\"]"));
                vacciName.sendKeys(postVacciName);
                break;
            default:
                this.exOnPostVaccination.sendKeys(postVacciName);
                break;
        }
    }

    @FindBy(xpath = "//div[contains(text(),'For Health Workers Only')]//ancestor::div[@class='card-container-common']//input[@placeholder='Medical Specialty']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Medical Specialty']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name=\"423\"]")
    public WebElement enterMedicalSpecialty;

    public void enterMedicalSpecialty(String medicalSpecialty){
        WebElement medical;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                medical=driver.findElement(By.xpath("//android.widget.TextView[@text='Medical Specialty']"));
                medical.sendKeys(medicalSpecialty);
                break;
            case "ios":
                medical=driver.findElement(By.xpath("//XCUIElementTypeTextField[@name=\"423\"]"));
                medical.sendKeys(medicalSpecialty);
                break;
            default:
                this.enterMedicalSpecialty.sendKeys(medicalSpecialty);
                break;
        }
    }
    @FindBy(xpath = "//div[contains(text(),'For Health Workers Only')]//ancestor::div[@class='card-container-common']//input[@placeholder='Enter Occupation']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Enter Occupation']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name=\"422\"]")
    public WebElement enterOccupation;

    public void enterOccupation(String occupationName){
        WebElement occupation;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                occupation=driver.findElement(By.xpath("//android.widget.TextView[@text='Enter Occupation']"));
                occupation.sendKeys(occupationName);
                break;
            case "ios":
                occupation=driver.findElement(By.xpath("//XCUIElementTypeTextField[@name=\"422\"]"));
                occupation.sendKeys(occupationName);
                break;
            default:
                this.enterOccupation.sendKeys(occupationName);
                break;
        }
    }
    @FindBy(xpath = "//div[contains(text(),'For Health Workers Only')]//ancestor::div[@class='card-container-common']//input[@placeholder='Exact nature of duties']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Exact nature of duties']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name=\"425\"]")
    public WebElement exactnatureofduties;

    public void exactnatureofduties(String natureOfDuties){
        WebElement duties;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                duties=driver.findElement(By.xpath("//android.widget.TextView[@text='Exact nature of duties']"));
                duties.sendKeys(natureOfDuties);
                break;
            case "ios":
                duties=driver.findElement(By.xpath("//XCUIElementTypeTextField[@name=\"425\"]"));
                duties.sendKeys(natureOfDuties);
                break;
            default:
                this.exactnatureofduties.sendKeys(natureOfDuties);
                break;
        }
    }
    @FindBy(xpath = "//div[contains(text(),'For Health Workers Only')]//ancestor::div[@class='card-container-common']//input[@placeholder='Name of Healthcare facility']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Name of Healthcare facility']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name=\"426\"]")
    public WebElement nameofHealthcarefacility;

    public void nameofHealthcarefacility(String nameOfHealthcarae){
        WebElement healthCarename;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                healthCarename=driver.findElement(By.xpath("//android.widget.TextView[@text='Name of Healthcare facility']"));
                healthCarename.sendKeys(nameOfHealthcarae);
                break;
            case "ios":
                healthCarename=driver.findElement(By.xpath("//XCUIElementTypeTextField[@name=\"426\"]"));
                healthCarename.sendKeys(nameOfHealthcarae);
                break;
            default:this.nameofHealthcarefacility.sendKeys(nameOfHealthcarae);
                break;
        }
    }
    @FindBy(xpath = "//div[contains(text(),'For Health Workers Only')]//ancestor::div[@class='card-container-common']//input[@placeholder='Address of Healthcare facility']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Address of Healthcare facility']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name=\"427\"]")
    public WebElement addressOfHealthcarefacility;

    public void addressOfHealthcarefacility(String addressOfHealthCare){
        WebElement address;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                address=driver.findElement(By.xpath("//android.widget.TextView[@text='Address of Healthcare facility']"));
                address.sendKeys(addressOfHealthCare);
                break;
            case "ios":
                address=driver.findElement(By.xpath("//XCUIElementTypeTextField[@name=\"427\"]"));
                address.sendKeys(addressOfHealthCare);
                break;
            default:
                this.addressOfHealthcarefacility.sendKeys(addressOfHealthCare);
                break;
        }
    }
    @FindBy(xpath = "//div[contains(text(),'For Health Workers Only')]//ancestor::div[@class='card-container-common']//input[@placeholder='Health Authority you are registered under']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Health Authority you are registered under']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name=\"428\"]")
    public WebElement healthAuthorityyouareregisteredunder;

    public void healthAuthorityyouareregisteredunder(String healthAuthority){
        WebElement authority;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                authority=driver.findElement(By.xpath("//android.widget.TextView[@text='Health Authority you are registered under']"));
                authority.sendKeys(healthAuthority);
                break;
            case "ios":
                authority=driver.findElement(By.xpath("//XCUIElementTypeTextField[@name=\"428\"]"));
                authority.sendKeys(healthAuthority);
                break;
            default:
                this.healthAuthorityyouareregisteredunder.sendKeys(healthAuthority);
                break;
        }
    }
        @FindBy(xpath = "//div[contains(text(),'Are you working in a Hospital with a Covid-19 ward or treating or in contact with Covid-19 infected individuals. ')]/following-sibling::div//div[text()='Yes']")
        @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"Yes\"])[12]")
        public WebElement getProvideDetails2;

        @FindBy(xpath = "//div[contains(text(),'For Health Workers Only')]//ancestor::div[@class='card-container-common']//input[@placeholder='Provide Details']")
        @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text,'Are you working in a Hospital with a Covid-19 ward')]/..//android.widget.TextView[@text='Provide Details']")
        @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name=\"430\"]")
        public WebElement provideDetails2;

        public void provideDetails2(String provideDetials){
            WebElement details;
            switch (BaseTest.PLATFORM_NAME){
                case "android":
                    details=driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'Are you working in a Hospital with a Covid-19 ward')]/..//android.widget.TextView[@text='Provide Details']"));
                    details.sendKeys(provideDetials);
                    break;
                case "ios":
                    details=driver.findElement(By.xpath("//XCUIElementTypeTextField[@name=\"430\"]"));
                    details.sendKeys(provideDetials);
                    break;
                default:this.provideDetails2.sendKeys(provideDetials);
                    break;
            }
    }
    @FindBy(xpath = "//div[contains(text(),'Recovered from Covid19')]/ancestor::div[@class='card-title-container']/following-sibling::div//div[text()='Yes']")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name='Recovered from Covid19']/parent::XCUIElementTypeOther/..//XCUIElementTypeOther[contains(@name,'Yes')])[5]")
    public WebElement recoveredOption;

    public void recoveredOption(){
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                break;
            case "ios":
                break;
            default:
                break;
        }
    }

    @FindBy(xpath = "//div[contains(text(),'Recovered from Covid19')]//ancestor::div[@class='card-container-common']//label[contains(text(),'Mention date of Diagnosis')]/parent::div//input[@id='DD']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Mention date of Diagnosis']/..//android.widget.TextView[@text='DD']")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[contains(@name,'Mention date of Diagnosis')]/..//XCUIElementTypeOther[@name=\"day\"])[6]")
    public WebElement recoveredDay;

    public void recoveredDay(String diagnosDay){
        WebElement day;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                day=driver.findElement(By.xpath("//android.widget.TextView[@text='Mention date of Diagnosis']/..//android.widget.TextView[@text='DD']"));
                day.sendKeys(diagnosDay);
                break;
            case "ios":
                day=driver.findElement(By.xpath("(//XCUIElementTypeOther[contains(@name,'Mention date of Diagnosis')]/..//XCUIElementTypeOther[@name=\"day\"])[6]"));
                day.sendKeys(diagnosDay);
                break;
            default:
                this.recoveredDay.sendKeys(diagnosDay);
                break;
        }
    }
    @FindBy(xpath = "//div[contains(text(),'Recovered from Covid19')]//ancestor::div[@class='card-container-common']//label[contains(text(),'Mention date of Diagnosis')]/parent::div//input[@id='MM']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Mention date of Diagnosis']/..//android.widget.TextView[@text='MM']")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[contains(@name,'Mention date of Diagnosis')]/..//XCUIElementTypeOther[@name=\"month\"])[6]")
    public WebElement recoveredMonth;

    public void recoveredMonth(String diagnosMonth){
        WebElement month;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                month=driver.findElement(By.xpath("//android.widget.TextView[@text='Mention date of Diagnosis']/..//android.widget.TextView[@text='DD']"));
                month.sendKeys(diagnosMonth);
                break;
            case "ios":
                month=driver.findElement(By.xpath("(//XCUIElementTypeOther[contains(@name,'Mention date of Diagnosis')]/..//XCUIElementTypeOther[@name=\"month\"])[6]"));
                month.sendKeys(diagnosMonth);
                break;
            default:this.recoveredMonth.sendKeys(diagnosMonth);
                break;
        }
    }
    @FindBy(xpath = "//div[contains(text(),'Recovered from Covid19')]//ancestor::div[@class='card-container-common']//label[contains(text(),'Mention date of Diagnosis')]/parent::div//input[@id='YYYY']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Mention date of Diagnosis']/..//android.widget.TextView[@text='YYYY']")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[contains(@name,'Mention date of Diagnosis')]/..//XCUIElementTypeOther[@name=\"year\"])[6]")
    public WebElement recoveredYear;

    public void recoveredYear(String diagnosYear){
        WebElement year;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                year=driver.findElement(By.xpath("//android.widget.TextView[@text='Mention date of Diagnosis']/..//android.widget.TextView[@text='YYYY']"));
                year.sendKeys(diagnosYear);
                break;
            case "ios":
                year=driver.findElement(By.xpath("(//XCUIElementTypeOther[contains(@name,'Mention date of Diagnosis')]/..//XCUIElementTypeOther[@name=\"year\"])[6]"));
                year.sendKeys(diagnosYear);
                break;
            default:this.recoveredYear.sendKeys(diagnosYear);

                break;
        }
    }

    @FindBy(xpath = "//div[contains(text(),'Why did you receive a COVID-19 test? Select One Option')]/parent::div//div[contains(text(),'Heart Attack')]/following-sibling::div//input[@id='accordian-checkbox']")
    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text,'Why did you receive a COVID-19 test?')]/..//android.view.ViewGroup//android.widget.TextView[@text='Heart Attack']/..//android.widget.CheckBox")
    public WebElement covidTestOptionToBeSelect;

    public void covidTestOptionToBeSelect(String selectOption){
        WebElement option;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                option=driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'Why did you receive a COVID-19 test?')]/..//android.view.ViewGroup//android.widget.TextView[@text='"+selectOption+"']/..//android.widget.CheckBox"));
                option.click();
                break;
            case "ios":
                break;
            default:
                option=driver.findElement(By.xpath("//div[contains(text(),'Why did you receive a COVID-19 test? Select One Option')]/parent::div//div[contains(text(),'"+selectOption+"')]/following-sibling::div//input[@id='accordian-checkbox']"));
                option.click();
                break;
        }
    }
    @FindBy(xpath = "//div[contains(text(),'What symptoms do you have at this time?')]/parent::div//div[contains(text(),'Fever')]/following-sibling::div//input[@id='accordian-checkbox']")
    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text,'What symptoms do you have at this time?')]/..//android.view.ViewGroup//android.widget.TextView[@text='No symptoms']/..//android.widget.CheckBox")
    public WebElement symptomsOptions;

    @FindBy(xpath = "//div[contains(text(),'Why did you receive a COVID-19 test? Select One Option')]/parent::div//div[contains(text(),'Other')]/parent::div/following-sibling::div//input[@placeholder='Provide details']")
    public WebElement otherSymptomsOption;

    public void symptomsOptions(String symptomsOption){
        WebElement option;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                if(symptomsOption.equalsIgnoreCase("Others")){
                    option = driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'What symptoms do you have at this time?')]/..//android.view.ViewGroup//android.widget.TextView[@text='" + symptomsOption + "']/..//android.widget.CheckBox"));
                    option.click();
                    waitUtils.waitForElementToBeVisible(driver,otherSymptomsOption);
                    this.otherSymptomsOption.sendKeys("got from another person");
                }else {
                    option = driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'What symptoms do you have at this time?')]/..//android.view.ViewGroup//android.widget.TextView[@text='" + symptomsOption + "']/..//android.widget.CheckBox"));
                    option.click();
                }
                break;
            case "ios":
                break;
            default:
                if(symptomsOption.equalsIgnoreCase("Others")) {
                    option = driver.findElement(By.xpath("//div[contains(text(),'What symptoms do you have at this time?')]/parent::div//div[contains(text(),'" + symptomsOption + "')]/following-sibling::div//input[@id='accordian-checkbox']"));
                    option.click();
                    waitUtils.waitForElementToBeVisible(driver, otherSymptomsOption);
                    this.otherSymptomsOption.sendKeys("got from another person");
                    break;
                }else{
                    option = driver.findElement(By.xpath("//div[contains(text(),'What symptoms do you have at this time?')]/parent::div//div[contains(text(),'" + symptomsOption + "')]/following-sibling::div//input[@id='accordian-checkbox']"));
                    option.click();
                    break;
                }

        }
    }

    @FindBy(xpath = "//div[contains(text(),'Recovered from Covid19')]//ancestor::div[@class='card-container-common']//label[contains(text(),'Metion Complete recovery date')]/parent::div//input[@id='DD']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Metion Complete recovery date']/..//android.widget.TextView[@text='DD']")
    public WebElement recoveredFromCovidDay;

    public void recoveredFromCovidDay(String recoveredDay){
        WebElement day;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                day=driver.findElement(By.xpath("//android.widget.TextView[@text='Metion Complete recovery date']/..//android.widget.TextView[@text='DD']"));
                day.sendKeys(recoveredDay);
                break;
            case "ios":
                break;
            default:this.recoveredFromCovidDay.sendKeys(recoveredDay);
                break;
        }
    }
    @FindBy(xpath = "//div[contains(text(),'Recovered from Covid19')]//ancestor::div[@class='card-container-common']//label[contains(text(),'Metion Complete recovery date')]/parent::div//input[@id='MM']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Metion Complete recovery date']/..//android.widget.TextView[@text='MM']")
    public WebElement recoveredFromCovidMonth;

    public void recoveredFromCovidMonth(String recoveredMonth){
        WebElement month;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                month=driver.findElement(By.xpath("//android.widget.TextView[@text='Metion Complete recovery date']/..//android.widget.TextView[@text='MM']"));
                month.sendKeys(recoveredMonth);
                break;
            case "ios":
                break;
            default:this.recoveredFromCovidMonth.sendKeys(recoveredMonth);
                break;
        }
    }
    @FindBy(xpath = "//div[contains(text(),'Recovered from Covid19')]//ancestor::div[@class='card-container-common']//label[contains(text(),'Metion Complete recovery date')]/parent::div//input[@id='YYYY']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Metion Complete recovery date']/..//android.widget.TextView[@text='YYYY']")
    public WebElement recoveredFromCovidYear;

    public void recoveredFromCovidYear(String recoveredYear){
        WebElement year;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                year=driver.findElement(By.xpath("//android.widget.TextView[@text='Metion Complete recovery date']/..//android.widget.TextView[@text='YYYY']"));
                year.sendKeys(recoveredYear);
                break;
            case "ios":
                break;
            default:this.recoveredFromCovidYear.sendKeys(recoveredYear);
                break;
        }
    }
    @FindBy(xpath = "//div[contains(text(),'Recovered from Covid19')]/ancestor::div[@class='card-title-container']/following-sibling::div//div[contains(text(),'Do you have any pending or recommended follow-up appointments or tests related to your COVID-19 diagnosis?')]/following-sibling::div//div[text()='Yes']")
    @AndroidFindBy(xpath = "(//android.widget.TextView[contains(@text,'Do you have any pending or recommended follow-up appointments')]/..//android.widget.TextView[@text='Yes'])[2]")
    public WebElement penddingAppointments;

    @FindBy(xpath = "//div[contains(text(),'Recovered from Covid19')]//ancestor::div[@class='card-container-common']//input[@id='testName']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Mention Tests Name']")
    public WebElement covidTestName;

    public void setCovidTestName(String testName) {
        WebElement test;
        switch (BaseTest.PLATFORM_NAME) {
            case "android":
                test=driver.findElement(By.xpath("//android.widget.TextView[@text='Mention Tests Name']"));
                test.sendKeys(testName);
                break;
            case "ios":
                break;
            default:this.covidTestName.sendKeys(testName);
                break;
        }
    }
//
    @FindBy(xpath = "//div[contains(text(),'Recovered from Covid19')]//ancestor::div[@class='card-container-common']//label[contains(text(),'Date when test was taken')]/parent::div//input[@id='YYYY']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Date when test was taken']/..//android.widget.TextView[@text='YYYY']")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[contains(@name,'Date when test was taken')]/..//XCUIElementTypeOther[@name=\"year\"])[3]")
    public WebElement testTakenYear;

    public void testTakenYear(String testYear) {
        WebElement year;
        switch (BaseTest.PLATFORM_NAME) {
            case "android":
                year=driver.findElement(By.xpath("//android.widget.TextView[@text='Date when test was taken']/..//android.widget.TextView[@text='YYYY']"));
                year.sendKeys(testYear);
                break;
            case "ios":
                year=driver.findElement(By.xpath("(//XCUIElementTypeOther[contains(@name,'Date when test was taken')]/..//XCUIElementTypeOther[@name=\"year\"])[3]"));
                year.sendKeys(testYear);
                break;
            default:this.testTakenYear.sendKeys(testYear);
                break;
        }
    }
        @FindBy(xpath = "//div[contains(text(),'Recovered from Covid19')]//ancestor::div[@class='card-container-common']//label[contains(text(),'Date when test was taken')]/parent::div//input[@id='MM']")
        @AndroidFindBy(xpath = "//android.widget.TextView[@text='Date when test was taken']/..//android.widget.TextView[@text='MM']")
        @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[contains(@name,'Date when test was taken')]/..//XCUIElementTypeOther[@name=\"month\"])[3]")
        public WebElement testTakenMonth;

        public void testTakenMonth(String testMonth) {
            WebElement month;
            switch (BaseTest.PLATFORM_NAME) {
                case "android":
                    month=driver.findElement(By.xpath("//android.widget.TextView[@text='Date when test was taken']/..//android.widget.TextView[@text='MM']"));
                    month.sendKeys(testMonth);
                    break;
                case "ios":
                    month=driver.findElement(By.xpath("(//XCUIElementTypeOther[contains(@name,'Date when test was taken')]/..//XCUIElementTypeOther[@name=\"month\"])[3]"));
                    month.sendKeys(testMonth);
                    break;
                default:this.testTakenMonth.sendKeys(testMonth);
                    break;
            }
        }
            @FindBy(xpath = "//div[contains(text(),'Recovered from Covid19')]//ancestor::div[@class='card-container-common']//label[contains(text(),'Date when test was taken')]/parent::div//input[@id='DD']")
            @AndroidFindBy(xpath = "//android.widget.TextView[@text='Date when test was taken']/..//android.widget.TextView[@text='DD']")
            @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[contains(@name,'Date when test was taken')]/..//XCUIElementTypeOther[@name=\"day\"])[3]")
            public WebElement testTakenDay;

            public void testTakenDay(String testDay){
                WebElement day;
                switch (BaseTest.PLATFORM_NAME){
                    case "android":
                        day=driver.findElement(By.xpath("//android.widget.TextView[@text='Date when test was taken']/..//android.widget.TextView[@text='DD']"));
                        day.sendKeys(testDay);
                        break;
                    case "ios":
                        day=driver.findElement(By.xpath("(//XCUIElementTypeOther[contains(@name,'Date when test was taken')]/..//XCUIElementTypeOther[@name=\"day\"])[3]"));
                        day.sendKeys(testDay);
                        break;
                    default:this.testTakenDay.sendKeys(testDay);
                        break;
                }
    }

    @FindBy(xpath = "//div[contains(text(),'Recovered from Covid19')]/ancestor::div[@class='card-title-container']/following-sibling::div//div[contains(text(),'If employed, have you been certified to return to work on an unrestricted and full-capacity basis?')]/following-sibling::div//div[text()='Yes']")
    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text,'If employed, have you been certified to return to work')]/..//android.widget.TextView[@text='Yes']")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"Yes\"])[14]")
    public WebElement returnToWorkCertified;


    @FindBy(xpath = "//div[contains(text(),'Recovered from Covid19')]/ancestor::div[@class='card-title-container']/following-sibling::div//div[contains(text(),'If employed, have you been certified to return to work on an unrestricted and full-capacity basis?')]/parent::div/following-sibling::div//input[@placeholder='Provide Details']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name=\"449\"]")
    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text,'If employed, have you been certified to return to work')]/..//android.widget.TextView[@text='Provide Details']")
    public WebElement returnToWorkCertifiedDetails;

    public void returnToWorkCertifiedDetails(String certificateDetails){
        WebElement details;
        switch (BaseTest.PLATFORM_NAME){
            case "android":

                details=driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'If employed, have you been certified to return to work')]/..//android.widget.TextView[@text='Provide Details']"));
                details.sendKeys(certificateDetails);
                break;
            case "ios":
                details=driver.findElement(By.xpath("//XCUIElementTypeTextField[@name=\"449\"]"));
                details.sendKeys(certificateDetails);
                break;
            default:this.returnToWorkCertifiedDetails.sendKeys(certificateDetails);
                break;
        }
    }

    @FindBy(xpath = "//div[contains(text(),'Was admission for observation')]/following-sibling::div//div[contains(text(),'Yes')]")
    WebElement admissionForObservation;

    public void admissionForObservation(){
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                break;
            case "ios":
                break;
            default:
                break;

        }
    }


    @FindBy(xpath = "//div[contains(text(),'9.0 Review & Acceptance')]")
    public WebElement reviewAndAcceptanceTitle;

    @FindBy(xpath = "//div[contains(text(),'Recovered from Covid19')]//ancestor::div[@class='card-container-common']//label[contains(text(),'Date of admission')]/parent::div//input[@id='YYYY']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Metion Complete recovery date']/..//android.widget.TextView[@text='YYYY']")
    public WebElement dateOFAdmissionYear;

    public void dateOFAdmissionYear(String recoveredYear){
        WebElement year;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                year=driver.findElement(By.xpath("//android.widget.TextView[@text='Date of admission']/..//android.widget.TextView[@text='year']"));
                year.sendKeys(recoveredYear);
                break;
            case "ios":
                break;
            default:this.recoveredFromCovidYear.sendKeys(recoveredYear);
                break;
        }
    }
    @FindBy(xpath = "//div[contains(text(),'Recovered from Covid19')]//ancestor::div[@class='card-container-common']//label[contains(text(),'Date of admission')]/parent::div//input[@id='DD']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Metion Complete recovery date']/..//android.widget.TextView[@text='day']")
    public WebElement dateOFAdmissionDay;

    public void dateOFAdmissionDay(String dateOFAdmissionDay){
        WebElement day;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                day=driver.findElement(By.xpath("//android.widget.TextView[@text='Date of admission']/..//android.widget.TextView[@text='day']"));
                day.sendKeys(dateOFAdmissionDay);
                break;
            case "ios":
                break;
            default:this.recoveredFromCovidYear.sendKeys(dateOFAdmissionDay);
                break;
        }
    }
    @FindBy(xpath = "//div[contains(text(),'Recovered from Covid19')]//ancestor::div[@class='card-container-common']//label[contains(text(),'Date of admission')]/parent::div//input[@id='MM']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Metion Complete recovery date']/..//android.widget.TextView[@text='MM']")
    public WebElement dateOFAdmissionMonth;

    public void dateOFAdmissionYearMonth(String admissionMonth){
        WebElement month;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                month=driver.findElement(By.xpath("//android.widget.TextView[@text='Date of admission']/..//android.widget.TextView[@text='MM']"));
                month.sendKeys(admissionMonth);
                break;
            case "ios":
                break;
            default:this.recoveredFromCovidYear.sendKeys(admissionMonth);
                break;
        }
    }
    @FindBy(xpath = "//div[contains(text(),'Recovered from Covid19')]//ancestor::div[@class='card-container-common']//label[contains(text(),'Date of Discharge')]/parent::div//input[@id='YYYY']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Date of Discharge']/..//android.widget.TextView[@text='YYYY']")
    public WebElement dateOfDischargeYear;

    public void dateOfDischargeYear(String dateOfDischargeYear){
        WebElement year;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                year=driver.findElement(By.xpath("//android.widget.TextView[@text='Date of Discharge']/..//android.widget.TextView[@text='year']"));
                year.sendKeys(dateOfDischargeYear);
                break;
            case "ios":
                break;
            default:this.recoveredFromCovidYear.sendKeys(dateOfDischargeYear);
                break;
        }
    }
    @FindBy(xpath = "//div[contains(text(),'Recovered from Covid19')]//ancestor::div[@class='card-container-common']//label[contains(text(),'Date of Discharge')]/parent::div//input[@id='DD']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Date of Discharge']/..//android.widget.TextView[@text='day']")
    public WebElement dateOfDischargeDay;

    public void dateOfDischargeDay(String dateOfDischargeDay){
        WebElement day;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                day=driver.findElement(By.xpath("//android.widget.TextView[@text='Date of admission']/..//android.widget.TextView[@text='day']"));
                day.sendKeys(dateOfDischargeDay);
                break;
            case "ios":
                break;
            default:this.recoveredFromCovidYear.sendKeys(dateOfDischargeDay);
                break;
        }
    }
    @FindBy(xpath = "//div[contains(text(),'Recovered from Covid19')]//ancestor::div[@class='card-container-common']//label[contains(text(),'Date of Discharge')]/parent::div//input[@id='MM']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Date of Discharge]/..//android.widget.TextView[@text='MM']")
    public WebElement dateOfDischargeMonth;

    public void dateOfDischargeMonth(String dischargeMonth) {
        WebElement month;
        switch (BaseTest.PLATFORM_NAME) {
            case "android":
                month = driver.findElement(By.xpath("//android.widget.TextView[@text='Date of Discharge']/..//android.widget.TextView[@text='MM']"));
                month.sendKeys(dischargeMonth);
                break;
            case "ios":
                break;
            default:
                this.recoveredFromCovidYear.sendKeys(dischargeMonth);
                break;
        }
    }
}
