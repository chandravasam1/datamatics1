package com.absli.pageObjects;

import com.absli.helpers.jsonReaders.ReadJson;
import com.absli.helpers.models.LoginModel;
import com.absli.helpers.models.ProposerModel;
import com.absli.utils.CommonUtils;
import com.absli.utils.WaitUtils;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import tests.BaseTest;

import static com.absli.logger.LoggingManager.logMessage;

public class RefusedPolicyPage extends Page{
    WebDriver driver;
    CommonUtils commonUtils;
    ReadJson jsonObj;
    LoginModel loginModel;
    SignInPage signIn;
    DashboardPage dashPage;
    WaitUtils waitUtils;
    ProposerModel proposerModel;
    ExistingPolicyPage existingPolicyPage;

    public RefusedPolicyPage(WebDriver driver) throws InterruptedException {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        logMessage("Initializing the " + this.getClass().getSimpleName() + " elements");
        PageFactory.initElements(new AppiumFieldDecorator(driver), RefusedPolicyPage.class);

        waitUtils = new WaitUtils();
        commonUtils = new CommonUtils();
        existingPolicyPage=new ExistingPolicyPage(driver);
    }

    @FindBy(xpath = "//h2[contains(text(),'Refused Policy')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Refused Policy\"]")
    public WebElement refeusedPolicy;

    @FindBy(xpath ="//input[@id='insurerName']")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeTextField[@name=\"insurerName\"])[2]")
    @AndroidFindBy(accessibility = "insurerName")
    public WebElement addInsurerName;

    public void setInsurerName(String insurerName){
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                this.addInsurerName.clear();
                this.addInsurerName.sendKeys(insurerName);
                break;
            case "ios":
                this.addInsurerName.clear();
                this.addInsurerName.sendKeys(insurerName);
                break;
            default:
                this.addInsurerName.clear();
                this.addInsurerName.sendKeys(insurerName);
                break;
        }

    }

    @FindBy(xpath ="(//input[@id='sumAssured'])[3]")
    @AndroidFindBy(accessibility = "sumAssured")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeTextField[@name=\"sumAssured\"])[2]")
    public WebElement sumAssured;

    public void setsumAssured(Long sumAssured){
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                this.sumAssured.clear();
                this.sumAssured.sendKeys(String.valueOf(sumAssured));
                break;
            case "ios":
                this.sumAssured.clear();
                this.sumAssured.sendKeys(String.valueOf(sumAssured));
                break;
            default:
                this.sumAssured.clear();
                this.sumAssured.sendKeys(String.valueOf(sumAssured));
                break;
        }

    }
    @FindBy(xpath = "//input[@id='reason']")
    @AndroidFindBy(accessibility = "reason")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name=\"reason\"]")
    public WebElement reasonToRefeused;

    public void setReasonToRefeused(String reason){
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                this.reasonToRefeused.clear();
                this.reasonToRefeused.sendKeys(reason);
                break;
            case "ios":
                this.reasonToRefeused.clear();
                this.reasonToRefeused.sendKeys(reason);
                break;
            default:
                this.reasonToRefeused.clear();
                this.reasonToRefeused.sendKeys(reason);

 }
    }

    @FindBy(xpath = "//span[@class='nomineeFormLabel' and contains(text(),'REFUSED POLICY ')]")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther(contains[@name=\"REFUSED POLICY\"]))[1]")
    public WebElement addRefusedPolicy;
    public void  addRefusedPolicy(String insurerName,String sumAssured,String reasonToRefeused) {

       // waitUtils.waitForElementToBeVisible(driver,addRefusedPolicy);
        if (addRefusedPolicy.isDisplayed()) {
            addRefusedPolicy.click();
            waitUtils.wait2Seconds();
            setInsurerName(insurerName);
            waitUtils.wait2Seconds();
            inputSumAssured(sumAssured);
            waitUtils.wait2Seconds();
             setReasonToRefeused(reasonToRefeused);
           // commonUtils.selectButtonByName("No",driver);
            waitUtils.wait2Seconds();
            commonUtils.selectButtonByName("SAVE",driver);
            waitUtils.wait2Seconds();
            commonUtils.selectButtonByName("NEXT",driver);

        }


    }


    public void inputSumAssured(String sumAssuredAmount) {
        this.sumAssured.click();
        this.sumAssured.sendKeys(sumAssuredAmount);
        waitUtils.implicitWait(driver, 30000);
        //((AndroidDriver) driver).getKeyboard().pressKey("\n");
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                ((AndroidDriver<MobileElement>) driver).pressKey(new KeyEvent(AndroidKey.ENTER));
                //((AndroidDriver) driver).getKeyboard().pressKey("\n");
                break;
            case "ios":
                sumAssured.sendKeys(Keys.RETURN);
                break;
            default:
        }
    }

}
