package com.absli.pageObjects;
import com.absli.helpers.jsonReaders.ReadJson;
import com.absli.helpers.models.LoginModel;
import com.absli.helpers.models.ProposerModel;
import com.absli.utils.CommonUtils;
import com.absli.utils.WaitUtils;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import io.appium.java_client.pagefactory.AndroidFindBy;
import org.openqa.selenium.WebElement;

import static com.absli.logger.LoggingManager.logMessage;

public class HealthDetailsPage extends Page{
    WebDriver driver;
    CommonUtils commonUtils;
    ReadJson jsonObj;
    LoginModel loginModel;
    SignInPage signIn;
    DashboardPage dashPage;
    WaitUtils waitUtils;
    OccupationPage occupationPage;
    QualificationPage qualificationPage;
    ChequePage chequePage;
    ProposerModel proposerModel;
    CashPage cashPage;

    public HealthDetailsPage(WebDriver driver) throws InterruptedException {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        logMessage("Initializing the " + this.getClass().getSimpleName() + " elements");
        PageFactory.initElements(new AppiumFieldDecorator(driver), CashPage.class);

        /*jsonObj = new ReadJson();
        signIn = new SignInPage(driver);
        dashPage = new DashboardPage(driver);*/
        waitUtils = new WaitUtils();
        commonUtils = new CommonUtils();
        //occupationPage = new OccupationPage(driver);
        //qualificationPage = new QualificationPage(driver);
    }
    @FindBy(xpath = "//div[text()='Yes']")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeTextField[`label == \"'11'\"`]")
    public WebElement eleWeightChangeYesBtn;

    @FindBy(xpath = "//p[text()='Please Enter Weight']")
    public WebElement eleEnterWeightError;

    @FindBy(xpath = "//p[text()='Please enter reasons']")
    public WebElement eleEnterReasonError;

    @FindBy(xpath = "//img[@class='opacity-6'][1]")
    public WebElement eleInchesUpBtn;

    @FindBy(xpath = "//img[@class='opacity-6'][2]")
    public WebElement eleInchesDownBtn;

    @FindBy(xpath = "//div[text()='FEET']/../../img[1]")
    public WebElement eleFeetUpBtn;

    @FindBy(xpath = "//div[text()='FEET']/../../img[2]")
    public WebElement eleFeetDownBtn;

    @FindBy(xpath = "//input[@name='12']")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeTextField[`label == \"'12'\"`]")
    public WebElement eleEnterWtLossReason;
}