package com.absli.pageObjects;

import com.absli.helpers.jsonReaders.ReadJson;
import com.absli.helpers.models.LoginModel;
import com.absli.helpers.models.ProposerModel;
import com.absli.utils.CommonUtils;
import com.absli.utils.WaitUtils;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import static com.absli.logger.LoggingManager.logMessage;

public class CashPage extends Page{
    WebDriver driver;
    CommonUtils commonUtils;
    ReadJson jsonObj;
    LoginModel loginModel;
    SignInPage signIn;
    DashboardPage dashPage;
    WaitUtils waitUtils;
    OccupationPage occupationPage;
    QualificationPage qualificationPage;
    ChequePage chequePage;
    ProposerModel proposerModel;
    CashPage cashPage;

    public CashPage(WebDriver driver) throws InterruptedException {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        logMessage("Initializing the " + this.getClass().getSimpleName() + " elements");
        PageFactory.initElements(new AppiumFieldDecorator(driver), CashPage.class);

        /*jsonObj = new ReadJson();
        signIn = new SignInPage(driver);
        dashPage = new DashboardPage(driver);*/
        waitUtils = new WaitUtils();
        commonUtils = new CommonUtils();
        occupationPage = new OccupationPage(driver);
        qualificationPage = new QualificationPage(driver);
    }

    @FindBy(xpath = "//div[text()='CASH']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='CASH']/following-sibling::android.widget.TextView")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == 'CASH \uDB80\uDD40'`]")
    public WebElement eleCashDrpBtn;

    @FindBy(xpath = "//div[text()='Click Submit to Complete Payment.']/../button/span[text()='Submit']")
    @AndroidFindBy(xpath = "(//android.widget.Button[@content-desc='continueButton'])[1]/android.view.ViewGroup")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == 'continueButton'`]")
    public WebElement eleCashSubmitBtn;

    @FindBy(xpath = "//span[text()='Payment Sucessful']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Payment Sucessful']")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeTextField[`label == 'Payment Sucessful'`]")
    public WebElement eleCashPaymentSuccessMsg;

    @FindBy(xpath = "//span[text()='NEXT']")
    @AndroidFindBy(accessibility = "continueButton")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == 'continueButton'`]")
    public WebElement eleCashPaymentNxtBtn;



}
