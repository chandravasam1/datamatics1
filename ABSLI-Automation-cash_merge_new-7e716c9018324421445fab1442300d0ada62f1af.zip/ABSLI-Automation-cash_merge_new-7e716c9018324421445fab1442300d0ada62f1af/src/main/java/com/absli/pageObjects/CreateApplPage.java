package com.absli.pageObjects;

import com.absli.enums.PlatformName;
import com.absli.enums.ScrollDirection;
import com.absli.helpers.jsonReaders.ReadJson;
import com.absli.helpers.models.LoginModel;
import com.absli.helpers.models.ProposerModel;
import com.absli.utils.CommonUtils;
import com.absli.utils.WaitUtils;
import com.google.common.collect.ImmutableMap;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.IOSElement;
import io.appium.java_client.pagefactory.*;
import org.openqa.selenium.*;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.remote.server.handler.interactions.touch.Scroll;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import tests.BaseTest;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.TimeUnit;

import static com.absli.logger.LoggingManager.logMessage;

public class CreateApplPage extends Page {

    WebDriver driver;
    CommonUtils commonUtils;
    ReadJson jsonObj;
    LoginModel loginModel;
    SignInPage signIn;
    DashboardPage dashPage;
    WaitUtils waitUtils;
    ProposerModel proposerModel;

    public CreateApplPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        logMessage("Initializing the " + this.getClass().getSimpleName() + " elements");
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);

        jsonObj = new ReadJson();
        signIn = new SignInPage(driver);
        dashPage = new DashboardPage(driver);
        waitUtils = new WaitUtils();
        commonUtils = new CommonUtils();
    }

    @FindBy(xpath = "(//button[@role='tab'])[1]")
    @AndroidFindBy(accessibility = "PROPOSER")
    @iOSXCUITFindBy(accessibility = "PROPOSER")
    public WebElement eleProposerTab;

    @FindBy(xpath = "(//button[@role='tab'])[2]")
    @AndroidFindBy(accessibility = "TO BE INSURED")
    @iOSXCUITFindBy(accessibility = "TO BE INSURED")
    public WebElement eleToBeInsuredTab;

    @FindBy(css = "#leadId")
    @AndroidFindBy(xpath = "//android.widget.EditText[@content-desc=\"leadId\"]")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeTextField' AND name BEGINSWITH[c] 'leadId'")
    //@iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name=\"leadId\"]")
    public WebElement eleLeadIdInput;

    @FindBy(xpath = "//button[@type='submit']")
    @AndroidFindBy(accessibility = "verifyButton")
    //@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"verifyButton\"]")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeButton' AND name BEGINSWITH[c] 'verifyButton'")
    private WebElement eleNextButton;

    @FindBy(css = "#leadId-helper-text")
    @AndroidFindBy(accessibility = "inputHelperText")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"inputHelperText\"]")
    private WebElement eleLeadIdMsg;

    @FindBy(css = "#captureMobile-label")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Mobile Number']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name=\"mobileNumber\"]")
    private WebElement eleCaptureMobileLabel;

    @FindBy(xpath = "//div[@aria-haspopup='listbox']")
    @AndroidFindBy(accessibility = "proposerInsuredRelationshipQst")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"proposerInsuredRelationshipQst\"])[2]")
    private WebElement eleRelationDropdownListLabel;

    @FindBy(xpath = "//label[text()=\"Would The Proposer Like A Joint Life Policy With the Spouse?\"]")
    @AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"isProposerAndInsurerSameView\"]")
    @iOSXCUITFindBy(accessibility = "Would The Proposer Like A Joint Life Policy With the Spouse?")
    private WebElement eleJointPolicyText;

    @AndroidFindBy(accessibility = "isJointLifePolicyQst")
    private WebElement eleJoinLifePolicyQst;

    @FindBy(xpath = "//div[@class='mar-top-35']")
    private WebElement eleRelationSubLevel;

    @FindBy(xpath = "//label[text()='Is to be insured a minor?']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Is to be insured a minor?']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"isInsuredMinorQst\"]")
    private WebElement eleInsuredMinorlabelText;

    @AndroidFindBy(xpath = "(//android.widget.EditText[@content-desc=\"mobileNumber\"])[2]")
    private WebElement elePrefillMobileText;

    @FindBy(xpath = "//div[@class='navbar-container']/img[@class='hamburger-icon']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name='\uE5CB']")
    private WebElement eleNavigationBack;

    @iOSXCUITFindBy(accessibility = "isProposerInsuredSameQst")
    public WebElement eleProposerInsuredQst;

    public void clearLeadId() {
        eleLeadIdInput.clear();
    }

    public void selectIsProposerInsuredSameQst(String answer) {
        switch (new BaseTest().getPlatform().toLowerCase()) {
            case "ios":
                logMessage("In IOS method:::::::");
                waitUtils.waitUntilVisible(driver,eleProposerInsuredQst,30);
                eleProposerInsuredQst.findElement(By.xpath("(//XCUIElementTypeOther[@name=\"" + answer + "\"])[1]")).click();
                break;
            case "android":
                logMessage("In android method:::::::");
                WebElement androidElement = driver.findElement(By.xpath("//android.view.ViewGroup[@content-desc=\"isProposerInsuredSameQst\"]"));
                androidElement.findElement(By.xpath("(//android.view.ViewGroup[@content-desc=\"" + answer + "\"])[1]")).click();
                break;
            default:
                driver.findElement(By.xpath("//input[@name='isProposerInsuredSameQst' and @value=\"" + answer + "\"]")).click();
                break;
        }
        waitUtils.wait1Seconds();
    }

    public void selectIsNriQst(String answer) {
        switch (baseTest.getPlatform().toLowerCase()) {
            case "android":
                WebElement androidLocator = driver.findElement(By.xpath("//android.view.ViewGroup[@content-desc=\"isProposerNriQst\"]"));
                androidLocator.findElement(By.xpath("//android.view.ViewGroup[@content-desc=\"" + answer + "\"]")).click();
                break;
            case "ios":
                //WebElement iosLocator = driver.findElement(By.xpath("//XCUIElementTypeOther[@name=\"isProposerNriQst\"]"));
                //iosLocator.findElement(By.xpath("//XCUIElementTypeOther[@name=\"" + answer + "\"]")).click();
                WebElement iosLocator = ((IOSDriver)driver).findElementByIosClassChain("**/XCUIElementTypeOther[`name == \"isProposerNriQst\"`]");
                ((IOSElement)iosLocator).findElementByIosClassChain("**/XCUIElementTypeOther[`name == \"" + answer + "\"`]").click();
                break;
            default:
                driver.findElement(By.xpath("//input[@name='isProposerNriQst' and @value=\"" + answer + "\"]")).click();
        }
    }

    public void inputLeadId(String leadId) {
        waitUtils.waitForElementToBeVisible(driver,eleLeadIdInput);
        this.eleLeadIdInput.clear();
        this.eleLeadIdInput.click();
        this.eleLeadIdInput.sendKeys(leadId);
        waitUtils.implicitWait(driver,10000);
        switch (baseTest.getPlatform().toLowerCase()) {
            case "android":
                //((AndroidDriver) driver).getKeyboard().pressKey("\n");

                //latest code below
                ((AndroidDriver) driver).hideKeyboard();
                break;
            case "ios":
                //((IOSDriver) driver).hideKeyboard();
                //((IOSDriver) driver).getKeyboard().pressKey(Keys.ARROW_DOWN);
                    //((IOSDriver) driver).hideKeyboard();
                    eleLeadIdInput.sendKeys(Keys.RETURN);

                /*Dimension size = commonUtils.getWindowSize(driver);
                int width = size.getWidth();
                int height = size.getHeight();
                commonUtils.mobileTap(driver,eleProposerInsuredQst);*/
                break;
            default:
                eleLeadIdInput.sendKeys(Keys.TAB);
        }



    }

    public void selectNextButton() {
        this.eleNextButton.click();
    }

    public boolean verifyLeadIdErrorMessageShown() {
        waitUtils.implicitWait(driver,100);
        try {
            return this.eleLeadIdMsg.isDisplayed();
        } catch (NoSuchElementException e) {
            logMessage("Element not found :" + this.eleLeadIdMsg);
            return false;
        }
    }

    public boolean verifyJointPolicyTextIsShown() {
        return this.eleJointPolicyText.isDisplayed();
    }

    public boolean verifyIsInsuredMinorLabelDisplayed() {
        return this.eleInsuredMinorlabelText.isDisplayed();
    }


    public String getLeadId() {
        return this.eleLeadIdInput.getText();
    }

    public void leadIdOutOfFocus() {
        commonUtils.enterKey(this.eleLeadIdInput, driver);
    }

    public String getErrorMessage() {
        return this.eleLeadIdMsg.getText();
    }

    public boolean isCaptureMobileScreenDisplayed() {
        return this.eleCaptureMobileLabel.isDisplayed();
    }

    public void selectRelationFromList(String relationType, String optionAnswer) throws InterruptedException {
        WebElement element = null;
        relationType = relationType.trim();
        waitUtils.waitForElementToBeVisible(driver,eleRelationDropdownListLabel);
        clickElement(this.eleRelationDropdownListLabel);

        switch (baseTest.getPlatform().toLowerCase()) {
            case "android":
                //commonUtils.clickElementOnScroll(driver,relationType);
                //commonUtils.scrollToTheText(((AndroidDriver<MobileElement>) driver),relationType);
                //driver.findElement(By.xpath("//android.widget.TextView[@text='" + relationType + "']")).click();
                //element = driver.findElement(By.xpath("//android.widget.TextView[@text='" + relationType + "']"));
                //commonUtils.clickOnScrollForIos(driver,element);
                //relationType = "Father";
                //commonUtils.clickElementOnScroll(driver,relationType);
                System.out.println("FROM EXCEL SHEET =====>"+ relationType);
                relationType = "Father";
                //waitUtils.wait5Seconds();
                /*List<WebElement> elements = driver.findElements(By.className("android.widget.TextView"));
                System.out.println("FROM EXCEL SHEET =====>"+ relationType);
                System.out.println("list of elements from pop up:"+ elements.size());
                for(WebElement s: elements) {
                    System.out.println("=========== >"+s.getText());
                    if(s.getText().contains(relationType)) {
                        s.click();
                        return;
                    }
                }*/
                //commonUtils.clickElementOnScroll(driver,relationType);
                //commonUtils.scrollToTheText(driver,relationType);

                driver.findElement(By.xpath("//android.widget.TextView[@text=\"" + relationType + "\"]//..")).click();
                break;
            case "ios":
                driver.findElement(By.xpath("//XCUIElementTypeOther[@name=\"" + relationType + "\"]")).click();
                break;
            default:
                new WaitUtils().waitForElementToBeVisible(driver, driver.findElement(By.xpath("//ul[@role='listbox']")));
                //driver.findElement(By.xpath("//li[@data-value='" + relationType + "']")).click();
                 element = driver.findElement(By.xpath("//li/span[text()='" + relationType + "']"));
                commonUtils.clickElementByJS(element, driver);

        }

        commonUtils.scrollTillEndOfPage(driver);
        // select the sub option answer
        switch (relationType.toLowerCase()) {
            case "spouse":
                if (baseTest.getPlatform().toLowerCase().equalsIgnoreCase("android")) {
                    waitUtils.waitUntilVisible(driver,eleJoinLifePolicyQst,30);
                    chooseAnswerForRelationshipQst("//android.view.ViewGroup[@content-desc=\"isJointLifePolicyQst\"]", optionAnswer);
                } else if (baseTest.getPlatform().toLowerCase().equalsIgnoreCase("ios")) {
                    chooseAnswerForRelationshipQst("//XCUIElementTypeOther[@name=\"isJointLifePolicyQst\"]", optionAnswer);

                } else {
                    chooseAnswerForRelationshipQst("//input[@name='isJointLifePolicyQst']", optionAnswer);
                }
                break;
            case "father":
            case "mother":
            case "grandfather":
            case "grandmother":
            case "legal guardian":
                if (baseTest.getPlatform().toLowerCase().equalsIgnoreCase("android")) {
                    chooseAnswerForRelationshipQst("//android.view.ViewGroup[@content-desc=\"isInsuredMinorQst\"]", optionAnswer);
                } else if (baseTest.getPlatform().toLowerCase().equalsIgnoreCase("ios")) {
                    chooseAnswerForRelationshipQst("//XCUIElementTypeOther[@name=\"isInsuredMinorQst\"]", optionAnswer);
                } else {
                    chooseAnswerForRelationshipQst("//input[@name='isInsuredMinorQst']", optionAnswer);
                }
                break;
        }
    }

    public void chooseAnswerForRelationshipQst(String parentNode, String optionAnswer) throws InterruptedException {
        switch (baseTest.getPlatform().toLowerCase()) {
            case "android":
                Thread.sleep(1000);
                WebElement androidlocator = driver.findElement(By.xpath(parentNode));
                androidlocator.findElement(By.xpath("//android.view.ViewGroup[@content-desc=\"" + optionAnswer + "\"]")).click();
                androidlocator.findElement(By.xpath("//android.view.ViewGroup[@content-desc=\"" + optionAnswer + "\"]")).click();
                break;
            case "ios":
                WebElement ioslocator = driver.findElement(By.xpath(parentNode));
                ioslocator.findElement(By.xpath("//XCUIElementTypeOther[@name=\"" + optionAnswer + "\"]")).click();
                break;
            default:
                String ele = parentNode + "//..//input[@value='" + optionAnswer + "']";
                driver.findElement(By.xpath(ele)).click();
        }
    }

    public boolean verifySubSelectionForRelationIsVisible() {

        try {
            return this.eleRelationSubLevel.isDisplayed();
        } catch (NoSuchElementException e) {
            logMessage("Element not found :" + this.eleRelationSubLevel);
            return false;
        }
    }

    public void chooseSignInNavigateToCaptureMobilePanNoScreen() throws IOException, InterruptedException {

        chooseSignInGoToDashboard("jhdjfhjfhjd","hdjhfdjfhdjh");
        dashPage.clickOnCreateAppln();
        dashPage.clickElement(dashPage.eleNewCustomerBtn);
        //CreateApplPage createApplPage = dashPage.navigateToProposerScreen();
        CreateApplPage createApplPage = new CreateApplPage(driver);
        commonUtils.verifyElementIsVisible(createApplPage.eleProposerTab);
        createApplPage.inputLeadId("12345678912345");
        commonUtils.enterKey(this.eleLeadIdInput, driver);
        createApplPage.selectIsProposerInsuredSameQst("YES");
        createApplPage.selectIsNriQst("YES");
        createApplPage.selectNextButton();
    }

    public void fillProposerMobilePanChooseInsuredTab() throws IOException {
        ProposerModel panProposerModel = jsonObj.readProposerJson().getDataByTestCase("validpan");
        ProposerModel mobileProposerModel = jsonObj.readProposerJson().getDataByTestCase("validmobile");
        inputMobileNo("proposer", mobileProposerModel.getMobileNo());
        inputPan("proposer", panProposerModel.getPan());
        chooseInsuredTab();
    }

    public void fillProposerDetailsChooseInsuredTab(String mobNo, String panNo) throws IOException {
        inputMobileNo("proposer", mobNo);
        inputPan("proposer", panNo);
        selectPanMobileNextButton();
        waitUtils.waitForElementToBeVisible(driver,eleProposerTab);
        if(commonUtils.isDisplayed(driver,eleToBeInsuredTab)) {
            chooseInsuredTab();
        }
    }

    public void chooseInsuredTab() {
        waitUtils.waitForElementToBeVisible(driver,eleToBeInsuredTab);
        eleToBeInsuredTab.click();
    }

    public void signInAndNavigateToCaptureLeadIdScreen()  {

        //loginModel = jsonObj.readLoginJson().getDataByTestCase("validlogin");
        signIn.signIn("IN073662", "April@0052");
        waitUtils.waitForElementToBeVisible(driver, signIn.eleDashboardTitle);
        dashPage.clickOnCreateAppln();
        dashPage.clickElement(dashPage.eleNewCustomerRadio);
        //CreateApplPage createApplPage = dashPage.navigateToProposerScreen();
        waitUtils.waitForElementToBeVisible(driver, eleProposerTab);
    }

    public void chooseCreateAppNavigateToCaptureLeadIdScreen()  {

        //loginModel = jsonObj.readLoginJson().getDataByTestCase("validlogin");
        //signIn.signIn("IN073662", "April@0052");
        waitUtils.waitForElementToBeVisible(driver, signIn.eleDashboardTitle);
        dashPage.clickOnCreateAppln();
        dashPage.clickElement(dashPage.eleNewCustomerRadio);
        CreateApplPage createApplPage = dashPage.navigateToProposerScreen();
        waitUtils.waitForElementToBeVisible(driver, eleProposerTab);
    }

    public void chooseSignAndGoToLeadIdScreen(String username, String password, String policy) throws IOException, InterruptedException {

        signIn.signIn(username, password);
        waitUtils.waitForElementToBeVisible(driver, signIn.eleDashboardTitle);
        logMessage("Signed in success");
        waitUtils.waitForElementToBeVisible(driver, dashPage.eleCreateAppButton);
        dashPage.clickOnCreateAppln();
        choosePolicy(policy);
        waitUtils.waitForElementToBeVisible(driver, eleProposerTab);
    }

    public void choosePolicy(String policy) {
        if (policy.trim().equalsIgnoreCase("new customer")) {
            waitUtils.waitUntilVisible(driver,dashPage.eleNewCustomerBtn,40);
            commonUtils.clickElement(dashPage.eleNewCustomerBtn);
        }
        /*if(new BaseTest().isWeb()) {
            if (policy.trim().equalsIgnoreCase("new customer")) {
                //waitUtils.waitUntilVisible(driver,dashPage.eleNewCustomerRadio,40);
                //commonUtils.clickElement(dashPage.eleNewCustomerBtn);
                //dashPage.navigateToProposerScreen();
                waitUtils.waitUntilVisible(driver,dashPage.eleNewCustomerBtn,40);
                commonUtils.clickElement(dashPage.eleNewCustomerBtn);
            } else {
                //
            }
        } else if(new BaseTest().isAndroid()) {
            if (policy.trim().equalsIgnoreCase("new customer")) {
                waitUtils.waitUntilVisible(driver,dashPage.eleNewCustomerBtn,40);
                commonUtils.clickElement(dashPage.eleNewCustomerBtn);
            } else {
                //
            }
        }*/
    }

    public void fillLeadIdChooseNextWhenProposerInsuredAreSame() throws IOException {
        proposerModel = jsonObj.readProposerJson().getDataByTestCase("validleadid");
        inputLeadId(proposerModel.getLeadId());
        selectIsProposerInsuredSameQst("YES");
        selectIsNriQst("YES");
        selectNextButton();
        waitUtils.implicitWait(driver, 30000);
        //waitUtils.waitForElementToBeVisible(driver,this.eleCaptureMobileLabel);
    }

    public void fillLeadIdChooseNextWhenProposerInsuredAreNotSame(String proposerRelationType, String optionAnswer) throws IOException, InterruptedException {
        proposerModel = jsonObj.readProposerJson().getDataByTestCase("validleadid");
        inputLeadId(proposerModel.getLeadId());
        commonUtils.enterKey(this.eleLeadIdInput, driver);
        selectIsProposerInsuredSameQst("NO");
        selectRelationFromList(proposerRelationType, optionAnswer);
        selectIsNriQst("NO");
        selectNextButton();
        //waitUtils.waitForElementToBeVisible(driver,this.eleCaptureMobileLabel);

    }

    public void chooseSignInGoToDashboard(String username,String password) throws InterruptedException, IOException {
        loginModel = jsonObj.readLoginJson().getDataByTestCase("validlogin");
        signIn.signIn(loginModel.getUsername(), loginModel.getPassword());
        waitUtils.waitForElementToBeVisible(driver, signIn.eleDashboardTitle);
        signIn.elementIsDisplayed(signIn.eleDashboardTitle);
    }

    /*
    Capture Mobile Pan
    * */


    @FindBy(xpath = "//input[@name=\"proposer.mobileNumber\"]")
    @AndroidFindBy(xpath = "//android.widget.EditText[@content-desc=\"mobileNumber\"]")
    //@iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name=\"mobileNumber\"]")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeTextField' AND name BEGINSWITH[c] 'mobileNumber'")
    public WebElement eleProposerMobileNoInputField;

    @FindBy(xpath = "//input[@name='insured.mobileNumber']")
    @AndroidFindBy(xpath = "//android.widget.EditText[@content-desc=\"mobileNumber\"]")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeTextField[`label == \"mobileNumber\"`]")
    public WebElement eleInsuredMobileNoInputField;

    @FindBy(xpath = "//input[@name='proposer.panNumber']")
    @AndroidFindBy(xpath = "//android.widget.EditText[@content-desc=\"panNumber\"]")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeTextField' AND name BEGINSWITH[c] 'panNumber'")
    //@iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name=\"panNumber\"]")
    public WebElement eleProposerPanInputField;

    @FindBy(xpath = "//input[@name='insured.panNumber']")
    @AndroidFindBy(xpath = "//android.widget.EditText[@content-desc=\"panNumber\"]")
    //@iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name=\"panNumber\"]")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeTextField[`label == \"panNumber\"`]")
    public WebElement eleInsuredPanInputField;

    @FindBy(xpath = "//p[text()='Please enter Mobile Number']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"inputHelperText\" and @text='Please enter Mobile Number']")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"mobileView\"])[2]//XCUIElementTypeStaticText[@name=\"inputHelperText\"]")
    private WebElement eleEnterMobileNoErrorMessage;

    @FindBy(css = "#captureMobile-helper-text")
    @AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"inputHelperText\" and @text='Invalid mobile no.']")
    //@iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"mobileView\"])[2]//XCUIElementTypeStaticText[@name=\"inputHelperText\"]")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"inputHelperText\"`][1]")
    private WebElement eleMobleErrorMessage;

    @FindBy(xpath = "//p[text()='Mobile Number should be min 10 digits']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"inputHelperText\"]")
    //@iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"mobileView\"])[2]//XCUIElementTypeStaticText[@name=\"inputHelperText\"]")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"inputHelperText\"`][1]")
    private WebElement eleMinDigitsMobileNoErrorMessage;

    @FindBy(xpath = "//p[text()='Invalid mobile no.']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"inputHelperText\" and @text='Invalid mobile no.']")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"mobileView\"])[2]//XCUIElementTypeStaticText[@name=\"inputHelperText\"]")
    public WebElement eleInvalidMobileNoErrorMessage;

    @FindBy(xpath = "//p[text()='Invalid PAN']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"inputHelperText\" and @text='Invalid PAN']")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"panView\"])[2]//XCUIElementTypeStaticText[@name=\"inputHelperText\"]")
    private WebElement eleInvalidPanErrorMessage;

    @AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"inputHelperText\" and @text='Please enter Pan Number']")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"panView\"])[2]//XCUIElementTypeStaticText[@name=\"inputHelperText\"]")
    private WebElement eleEnterPanErrorMessage;

    @FindBy(xpath = "//p[text()='Pan Number should be 10 characters']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"inputHelperText\" and @text='Pan Number should be 10 characters']")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"inputHelperText\"`][2]")
    private WebElement eleMinCharPanErrorMessage;

    @FindBy(xpath = "//div[contains(@class,'mobile-and-pan-btns')]/button")
    @AndroidFindBy(accessibility = "nextBtn")
    //@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"nextBtn\"]")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeButton' AND name BEGINSWITH[c] 'nextBtn'")
    private WebElement eleMobilePanNextBtn;

    @FindBy(xpath = "(//input[@id='firstname'])[1]")
    @AndroidFindBy(xpath = "//android.widget.EditText[@content-desc=\"firstName\"]")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeTextField' AND name BEGINSWITH[c] 'firstName'")
    //@iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name=\"firstName\"]")
    public WebElement eleFirstnameInputField;

    @AndroidFindBy(xpath = "//android.widget.EditText[@content-desc=\"lastName\"]")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeTextField' AND name BEGINSWITH[c] 'lastName'")
    //@iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name=\"lastName\"]")
    @FindBy(xpath = "(*//input[@id='lastname'])[1]")
    private WebElement eleLastnameInputField;

    @FindBy(xpath = "(//input[@id='middlename'])[1]")
    @AndroidFindBy(xpath = "//android.widget.EditText[@content-desc=\"middleName\"]")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeTextField' AND name BEGINSWITH[c] 'middleName'")
    //@iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name=\"middleName\"]")
    private WebElement eleMiddlenameInputField;

    //@AndroidFindBy(xpath = "//android.widget.EditText[@content-desc=\"day\"]")
    @AndroidFindBy(accessibility = "proposerday")
    //@iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name=\"day\"]")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeTextField' AND name CONTAINS[cd] 'day'")
    @FindBy(xpath = "(//input[@name='day'])[1]")
    public WebElement eleDOBDayInput;


    //@AndroidFindBy(xpath = "//android.widget.EditText[@content-desc=\"month\"]")
    @AndroidFindBy(accessibility = "proposermonth")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeTextField' AND name CONTAINS[cd] 'month'")
    //@iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name=\"month\"]")
    @FindBy(xpath = "(//input[@name='month'])[1]")
    private WebElement eleDOBMonthInput;

    //@AndroidFindBy(xpath = "//android.widget.EditText[@content-desc=\"year\"]")
    @AndroidFindBy(accessibility = "proposeryear")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeTextField' AND name CONTAINS[cd] 'year'")
    //@iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name=\"year\"]")
    @FindBy(xpath = "(//input[@name='year'])[1]")
    private WebElement eleDOBYearInput;

    @FindBy(xpath = "(//input[@id='firstname'])[2]")
    @AndroidFindBy(xpath = "//android.widget.EditText[@content-desc=\"firstName\"]")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeTextField' AND name BEGINSWITH[c] 'firstName'")
    //@iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name=\"firstName\"]")
    public WebElement eleInsuredFirstnameInputField;

    @AndroidFindBy(xpath = "//android.widget.EditText[@content-desc=\"lastName\"]")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeTextField' AND name BEGINSWITH[c] 'lastName'")
    //@iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name=\"lastName\"]")
    @FindBy(xpath = "(*//input[@id='lastname'])[2]")
    private WebElement eleInsuredLastnameInputField;

    @FindBy(xpath = "(//input[@id='middlename'])[2]")
    @AndroidFindBy(xpath = "//android.widget.EditText[@content-desc=\"middleName\"]")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeTextField' AND name BEGINSWITH[c] 'middleName'")
    //@iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name=\"middleName\"]")
    private WebElement eleInsuredMiddlenameInputField;

    @AndroidFindBy(xpath = "//android.widget.EditText[@content-desc=\"day\"]")
    //@iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name=\"day\"]")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeTextField' AND name BEGINSWITH[c] 'day'")
    @FindBy(xpath = "(//input[@name='day'])[2]")
    public WebElement eleInsuredDOBDayInput;


    @AndroidFindBy(xpath = "//android.widget.EditText[@content-desc=\"month\"]")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeTextField' AND name BEGINSWITH[c] 'month'")
    //@iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name=\"month\"]")
    @FindBy(xpath = "(//input[@name='month'])[2]")
    public WebElement eleInsuredDOBMonthInput;

    @AndroidFindBy(xpath = "//android.widget.EditText[@content-desc=\"year\"]")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeTextField' AND name BEGINSWITH[c] 'year'")
    //@iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name=\"year\"]")
    @FindBy(xpath = "(//input[@name='year'])[2]")
    public WebElement eleInsuredDOBYearInput;

    @FindBy(xpath = "(//div[text()='Lead ID'])[1]")
    private WebElement eleLeadIdLabel;

    @FindBy(xpath = "//*[text()='CONTINUE']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='CONTINUE']")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`name == \"nextBtn\"`]")
    public WebElement eleQuoteSummaryContinueBtn;

    /*
     * Prefill details screen
     * */

    @AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"inputHelperText\" and @text='Please enter first name']")
    @FindBy(xpath = "//p[text()='Please enter first name']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"inputHelperText\"]")
    public WebElement eleFirstNameErrorMsg;

    @AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"inputHelperText\" and @text='Please enter last name']")
    @FindBy(xpath = "//p[text()='Please enter last name']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"inputHelperText\"]")
    public WebElement eleLastNameErrorMsg;

    @AndroidFindBy(xpath = "(//android.widget.TextView[@content-desc=\"inputHelperText\" and @text='Enter Day'])[position()<=3]")
    @FindBy(css = "#dd-helper-text")
    @iOSXCUITFindBy(accessibility="DD DD proposerday inputHelperText")
    public WebElement eleDOBDayErrorMsg;

    @AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"inputHelperText\" and @text='Enter month']")
    @FindBy(css = "#mm-helper-text")
    @iOSXCUITFindBy(accessibility = "MM MM proposermonth inputHelperText")
    public WebElement eleDOBMonthErrorMsg;

    @AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"inputHelperText\" and contains(@text,'Enter year')]")
    @FindBy(css = "#yy-helper-text")
    @iOSXCUITFindBy(accessibility = "YYYY YYYY proposeryear inputHelperText")
    public WebElement eleDOBYearErrorMsg;

    @AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"inputHelperText\" and contains(@text,'Min')]")
    @FindBy(css = "#dd-helper-text")
    @iOSXCUITFindBy(iOSClassChain="**/XCUIElementTypeOther[`label == \"DD DD day inputHelperText\"`]")
    public WebElement eleDOBMinDayErrorMsg;

    @AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"inputHelperText\" and contains(@text,'Min')]")
    @FindBy(css = "#mm-helper-text")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeOther[`label == \"MM MM month inputHelperText\"`]")
    public WebElement eleDOBMinMonthErrorMsg;

    @AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"inputHelperText\" and contains(@text,'Min 1940')]")
    @FindBy(css = "#yy-helper-text")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeOther[`label == \"YYYY YYYY year inputHelperText\"`]")
    public WebElement eleDOBMinYearErrorMsg;

    @AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"inputHelperText\" and @text='Please select Gender']")
    public WebElement eleGenderErrorMsg;

    /*@AndroidFindAll({
            @AndroidBy(xpath = "//android.widget.TextView[@text=\"NEXT\"]",priority = 1),
            @AndroidBy(xpath = "(//android.widget.Button[@content-desc=\"nextBtn\"])[3]"),
            @AndroidBy(xpath = "//android.widget.Button[@content-desc=\"nextBtn\"]")
    })*/
    @FindBy(css = ".verified-tick")
    @AndroidFindBy(xpath = "(//android.widget.Button[@content-desc=\"leftIcon\"])[1]")
    //@iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeButton' AND name BEGINSWITH[cd] 'leftIcon'")
    @iOSXCUITFindAll({
            @iOSXCUITBy(iOSClassChain = "**/XCUIElementTypeButton[`name == \"leftIcon\"`][2]",priority = 2),
            @iOSXCUITBy(iOSClassChain = "**/XCUIElementTypeButton[`name == \"leftIcon\"`][1]",priority = 1)
    })
    public WebElement eleVerifiedTick;

    @FindBy(xpath = "//div[text()='You are editing the name.']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='android:id/message']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='You are editing the name.']")
    public WebElement eleEditNameAlertText;


    @FindBy(xpath = "//button/span[text()='OK']")
    @AndroidFindBy(id = "android:id/button1")
    //@AndroidFindBy(xpath = "//android.widget.TextView[@text='OK']")
    //@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='rightBtn']")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeButton' AND name BEGINSWITH[cd] 'OK'")
    private WebElement eleEditNameAlertOkButton;

    @FindBy(xpath = "//button/span[text()='YES I AM SURE']")
    //@AndroidFindBy(accessibility = "rightBtn")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='YES I AM SURE']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='rightBtn']")
    private WebElement eleDOBIncorrectAlertYesButton;

    @AndroidFindBy(xpath = "//android.widget.TextView[@text='DOB is incorrect.']")
    @FindBy(xpath = "//div[text()='DOB is incorrect.']")
    private WebElement alertDOB;

    @AndroidFindBy(accessibility = "leftBtn")
    private WebElement alertDOBEditBtn;

    @AndroidFindBy(accessibility = "selectPlanBtn")
    @FindBy(xpath = "//button/span[text()='SELECT PLAN']")
    //@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='selectPlanBtn']")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeButton' AND name BEGINSWITH[c] 'selectPlanBtn'")
    private WebElement eleSelectPlanBtn;


    @FindBy(xpath = "(//span[text()='Save'])[1]")
    //@iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"nextBtn\"`]")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"saveBtn\"`]")
    @AndroidFindBy(accessibility = "saveBtn")
    public WebElement elePrefillProposerSaveBtn;

    @FindBy(xpath = "(//span[text()='Save'])[2]")
    @AndroidFindBy(xpath = "//android.widget.Button[@content-desc=\"nextBtn\"]")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"nextBtn\"`]")
    public WebElement elePrefillInsuredSaveBtn;

    @FindBy(xpath = "(//span[text()='Save'])[1]")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"addInsuredBtn\"`]")
    @AndroidFindBy(accessibility = "addInsuredBtn")
    public WebElement elePrefillNextBtn;

    @FindBy(xpath = "(//span[text()='Save'])[1]")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"nextBtn\"`]")
    @AndroidFindBy(xpath = "(//android.widget.Button[@content-desc=\"nextBtn\"])[2]")
    public WebElement elePrefillInsuredNextBtn;


    @FindBy(xpath = "//span[@class='error-messsage' and contains(text(),'18 years')]")
    @iOSXCUITFindBy(accessibility = "inputHelperText")
    @AndroidFindBy(accessibility = "inputHelperText")
    public WebElement eleDOBAgeErrorMsg;

    @FindBy(xpath = "//span[@class='error-messsage' and contains(text(),'DOB cannot be greater')]")
    //@AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"inputHelperText\" and contains(@text,'Max 2021')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"inputHelperText\" and contains(@text,'DOB cannot be greater')]")
    //@AndroidFindBy(accessibility = "inputHelperText")
    //@iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeOther[`label == \"YYYY YYYY year inputHelperText\"`]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[contains(@name,\"Date of Birth\")]/XCUIElementTypeStaticText[@name=\"inputHelperText\"]")
    public WebElement eleDOBFutureYearErrorMsg;

    public void inputMobileNo(String type, String value) {

        switch (type.toLowerCase()) {
            case "proposer":
                waitUtils.fluentWaitUntilElementVisible(driver,eleProposerMobileNoInputField,10);
                this.eleProposerMobileNoInputField.click();
                this.eleProposerMobileNoInputField.clear();
                this.eleProposerMobileNoInputField.sendKeys(value);
                commonUtils.enterKey(eleProposerMobileNoInputField, driver);
                break;
            case "insured":
                waitUtils.fluentWaitUntilElementVisible(driver,eleInsuredMobileNoInputField,10);
                this.eleInsuredMobileNoInputField.click();
                this.eleInsuredMobileNoInputField.clear();
                this.eleInsuredMobileNoInputField.sendKeys(value);
                commonUtils.enterKey(eleInsuredMobileNoInputField, driver);

                break;
            default:
                logMessage("Invalid type parameter");
        }
    }

    public void clearMobile(String type) {
        switch (type.toLowerCase()) {
            case "proposer":
                this.eleProposerMobileNoInputField.click();
                this.eleProposerMobileNoInputField.clear();
                commonUtils.enterKey(eleProposerMobileNoInputField, driver);
                break;
            case "insured":
                this.eleInsuredMobileNoInputField.click();
                this.eleInsuredMobileNoInputField.clear();
                commonUtils.enterKey(eleInsuredMobileNoInputField, driver);
                break;
            default:
                logMessage("Invalid type parameter");
        }
    }

    public boolean isVerified() {
        waitUtils.implicitWait(driver,100);
        if (new BaseTest().isIOS()) {
            if (getFirstName().isEmpty()) {
                return  false;
            }
            else {
                return true;
            }
        }
        else {
            try {
                return this.eleVerifiedTick.isDisplayed();
            } catch (NoSuchElementException e) {
                logMessage("Not visible -------->"+eleVerifiedTick);
                return false;
            } catch (TimeoutException e) {
                logMessage("Not visible -------->"+eleVerifiedTick);
                return false;
            }
        }

    }


    public void verifyMobileNoFieldIsVisible(String type) {
        switch (type.toLowerCase()) {
            case "proposer":
                waitUtils.fluentWaitUntilElementVisible(driver,eleProposerMobileNoInputField,50);
                this.eleProposerMobileNoInputField.isDisplayed();
                break;
            case "insured":
                waitUtils.fluentWaitUntilElementVisible(driver,eleInsuredMobileNoInputField,50);
                this.eleInsuredMobileNoInputField.isDisplayed();
                break;
            default:
                logMessage("Invalid type parameter");
        }
    }

    public String getMobileNo(String type) {
        switch (type.toLowerCase()) {
            case "proposer":
                return this.eleProposerMobileNoInputField.getText();
            case "insured":
                return this.eleInsuredMobileNoInputField.getText();
            default:
                logMessage("Invalid type parameter");
        }
        return null;
    }

    public boolean verifyEnterMobileNoErrorMessage() {
        try {
            return this.eleEnterMobileNoErrorMessage.isDisplayed();
        } catch (NoSuchElementException e) {
            logMessage("Element not found:" + this.eleEnterMobileNoErrorMessage);
            return false;
        }
    }

    public boolean verifyMobileErrorMessage() {
        try {
            return this.eleMobleErrorMessage.isDisplayed();
        } catch (NoSuchElementException e) {
            logMessage("Element not found:" + this.eleMobleErrorMessage);
            return false;
        }

    }

    public boolean verifyInvalidMobileNoErrorMessage() {
        try {
            return this.eleInvalidMobileNoErrorMessage.isDisplayed();
        } catch (NoSuchElementException e) {
            logMessage("Element not found:" + this.eleInvalidMobileNoErrorMessage);
            return false;
        }


    }

    public boolean verifyMobilePanNextButtonIsDisabled() {
        try {
            return this.eleMobilePanNextBtn.isDisplayed();
        } catch (NoSuchElementException e) {
            logMessage("Element not found:" + this.eleMobilePanNextBtn);
            return false;
        }
    }

    public void selectPanMobileNextButton() {
        this.eleMobilePanNextBtn.click();
    }

    public boolean verifyInvalidPanErrorMessage() {
        waitUtils.implicitWait(driver,300);
        try {
            return this.eleInvalidPanErrorMessage.isDisplayed();
        } catch (NoSuchElementException e) {
            logMessage("Element not found:" + this.eleInvalidPanErrorMessage);
            return false;
        }
    }

    public boolean verifyMinCharPanErrorMessage() {
        waitUtils.implicitWait(driver,300);

        try {
            return this.eleMinCharPanErrorMessage.isDisplayed();
        } catch (NoSuchElementException e) {
            logMessage("Element not found:" + this.eleMinCharPanErrorMessage);
            return false;
        }
    }

    public boolean verifyMinDigitsMobileErrorMessage() {
        try {
            return this.eleMinDigitsMobileNoErrorMessage.isDisplayed();
        } catch (NoSuchElementException e) {
            logMessage("Element not found:" + this.eleMinDigitsMobileNoErrorMessage);
            return false;
        }
    }

    public void inputPan(String type, String value) {
        switch (type.toLowerCase()) {
            case "proposer":
                this.eleProposerPanInputField.clear();
                this.eleProposerPanInputField.sendKeys(value);
                commonUtils.enterKey(eleProposerPanInputField, driver);
                break;
            case "insured":
                if(commonUtils.isEnabled(driver,eleInsuredPanInputField)) {
                    this.eleInsuredPanInputField.clear();
                    this.eleInsuredPanInputField.sendKeys(value);
                    commonUtils.enterKey(eleInsuredPanInputField, driver);
                }
                break;
            default:
                logMessage("Invalid type parameter");
        }

        /*switch (BaseTest.PLATFORM_NAME) {
            case "android" :
                ((AndroidDriver)driver).hideKeyboard();
                break;
            case "ios":
                ((IOSDriver)driver).hideKeyboard();

                break;
            default:
        }*/

    }

    public boolean verifyFirstnameFieldIsVisible(String type) {
        try {
            return this.eleFirstnameInputField.isDisplayed();
        } catch (Exception e) {
            logMessage("Element not found:" + eleFirstnameInputField);
            return false;
        }
    }

    public String getMobileNoWithLessThanMinDigits() {
        return "90987873";
    }

    public String getMobileNoWithMaxDigits() {
        return "98783787483748347";
    }

    public boolean verifyLeadIdLabelIsVisible() {
        return this.eleLeadIdLabel.isDisplayed();
    }

    public void selectGender(String genderValue,String type) {
        genderValue = genderValue.toLowerCase();

        switch (baseTest.getPlatform().toLowerCase()) {
            case "android":
                if(type.equalsIgnoreCase("proposer")) {
                    //driver.findElement(By.xpath("//android.view.ViewGroup[@content-desc=\"" + genderValue + "\"]")).click();
                    //waitUtils.waitUntilElementIsVisibleByText(driver,10,genderValue,"");
                    /*driver.findElement(By.xpath("//android.widget.TextView[@text='" + genderValue + "']")).click();
                    driver.findElement(By.xpath("//android.widget.TextView[@text='" + genderValue + "']")).click();*/
                    //((AndroidDriver)driver).findElementByAccessibilityId("\"" + genderValue + "\"").click();
                    driver.findElement(By.xpath("//android.view.ViewGroup[@content-desc=\"" + genderValue + "\"]")).click();

                }
                else {
                    driver.findElement(By.xpath("//android.view.ViewGroup[@content-desc=\"" + genderValue + "\"]")).click();
                }
                break;
            case "ios":
                WebElement genderEle = ((IOSDriver)driver).findElementByAccessibilityId("gender");
                if(type.equalsIgnoreCase("proposer")) {
                    genderEle.findElement(By.xpath("(//XCUIElementTypeOther[@name=\"" + genderValue + "\"])[1]")).click();
                }
                else {
                    genderEle.findElement(By.xpath("(//XCUIElementTypeOther[@name=\"" + genderValue + "\"])[1]")).click();
                }
                break;
            default:
                //genderValue = genderValue.toLowerCase();
                if(type.equalsIgnoreCase("proposer")) {
                    driver.findElement(By.xpath("(//button[@value=\"" + genderValue + "\"])[1]")).click();
                }
                else {
                    driver.findElement(By.xpath("(//button[@value=\"" + genderValue + "\"])[2]")).click();

                }
        }
    }

    public void selectButtonByText(String buttonName) {
        switch (baseTest.getPlatform().toLowerCase()) {
            case "android":
                driver.findElement(By.xpath("//android.widget.TextView[@text=\"" + buttonName + "\"]")).click();
                break;
            case "ios":
                break;
            default:
                WebElement button = null;
                waitUtils.implicitWait(driver, 100);
                try {
                    button = driver.findElement(By.xpath("(//*[text()='" + buttonName + "'])[1]"));
                    if (button.isDisplayed()) {
                        button.click();
                    }
                } catch (NoSuchElementException e) {
                    logMessage("element not found:" + By.xpath("(//*[text()='" + buttonName + "'])[2]"));
                } catch (ElementClickInterceptedException e) {
                    logMessage("element not found:" + eleEditNameAlertText);
                }
                waitUtils.implicitWait(driver, 100);

                try {
                    button = driver.findElement(By.xpath("(//*[text()='" + buttonName + "'])[2]"));
                    if (button.isDisplayed()) {
                        button.click();
                    }
                } catch (NoSuchElementException e) {
                    logMessage("element not found:" + By.xpath("(//*[text()='" + buttonName + "'])[1]"));
                }
                waitUtils.implicitWait(driver, 100);

                try {
                    button = driver.findElement(By.xpath("//*[text()='" + buttonName + "']"));
                    if (button.isDisplayed()) {
                        button.click();
                    }
                } catch (NoSuchElementException e) {
                    logMessage("element not found:" + By.xpath("//*[text()='" + buttonName + "']"));
                }

        }
        waitUtils.implicitWait(driver, 30000);

    }

    public void fillFirstName(String name,String type) {
        switch (type) {
            case "proposer":
                this.eleFirstnameInputField.clear();
                this.eleFirstnameInputField.sendKeys(name);
                //commonUtils.enterKey(eleFirstnameInputField, driver);
                break;
            case "insured":
                this.eleInsuredFirstnameInputField.clear();
                this.eleInsuredFirstnameInputField.sendKeys(name);
                //commonUtils.enterKey(eleInsuredFirstnameInputField, driver);
                break;
        }
    }

    public void fillLastName(String name,String type) {
        switch (type) {
            case "proposer":
                this.eleLastnameInputField.clear();
                this.eleLastnameInputField.sendKeys(name);
                //commonUtils.enterKey(eleLastnameInputField, driver);
                break;
            case "insured":
                this.eleInsuredLastnameInputField.clear();
                this.eleInsuredLastnameInputField.sendKeys(name);
                //commonUtils.enterKey(eleInsuredLastnameInputField, driver);
                break;
        }
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                ((AndroidDriver) driver).hideKeyboard();
                break;
            case "ios":
                ((IOSDriver) driver).getKeyboard().pressKey("\n");
                break;
            default:
                //
        }
    }

    public void fillMiddleName(String name,String type) {
        switch (type) {
            case "proposer":
                this.eleMiddlenameInputField.clear();
                this.eleMiddlenameInputField.sendKeys(name);
                this.eleMiddlenameInputField.sendKeys(name);

                break;
            case "insured":
                this.eleInsuredMiddlenameInputField.clear();
                this.eleInsuredMiddlenameInputField.sendKeys(name);
                commonUtils.enterKey(eleInsuredMiddlenameInputField, driver);
                break;
        }
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                ((AndroidDriver) driver).hideKeyboard();
                break;
            case "ios":
                ((IOSDriver) driver).getKeyboard().pressKey("\n");
                break;
            default:
                //
        }

    }

    public String getMobileNo() {
        return getText(this.eleProposerMobileNoInputField);
    }

    public String getPan() {
        return getText(this.eleProposerPanInputField);

    }

    public void enterDOB(ProposerModel model) {
        this.eleDOBDayInput.sendKeys(model.getDay());
        this.eleDOBMonthInput.sendKeys(model.getMonth());
        this.eleDOBYearInput.sendKeys(model.getYear());
        //commonUtils.enterKey(eleDOBYearInput, driver);
        switch (BaseTest.PLATFORM_NAME) {
            case "android":
                ((AndroidDriver) driver).hideKeyboard();
                break;
            case "ios":
                ((IOSDriver)driver).hideKeyboard();
                break;
            default:
        }

    }

    public void fillDOB(String day, String month, String year,String type) {
        switch (type) {
            case "proposer":
                this.eleDOBDayInput.clear();
                this.eleDOBDayInput.sendKeys(day);
                commonUtils.enterKey(eleDOBDayInput, driver);

                this.eleDOBMonthInput.clear();
                this.eleDOBMonthInput.sendKeys(month);
                commonUtils.enterKey(eleDOBMonthInput, driver);

                this.eleDOBYearInput.clear();
                this.eleDOBYearInput.sendKeys(year);
                commonUtils.enterKey(eleDOBYearInput, driver);
                break;
            case "insured":
                this.eleInsuredDOBDayInput.clear();
                this.eleInsuredDOBDayInput.sendKeys(day);
                commonUtils.enterKey(eleInsuredDOBDayInput, driver);

                this.eleInsuredDOBMonthInput.clear();
                this.eleInsuredDOBMonthInput.sendKeys(month);
                commonUtils.enterKey(eleInsuredDOBMonthInput, driver);

                eleInsuredDOBYearInput.clear();
                this.eleInsuredDOBYearInput.sendKeys(year);
                commonUtils.enterKey(eleInsuredDOBYearInput, driver);
                break;
        }

    }


    public boolean verifyEnterFirstNameErrorIsShown() {
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.MILLISECONDS);
        try {
            return this.eleFirstNameErrorMsg.isDisplayed();
        } catch (NoSuchElementException e) {
            logMessage("Element not found:" + this.eleFirstNameErrorMsg);
            return false;
        }
    }

    public boolean verifyEnterLastNameErrorIsShown() {
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.MILLISECONDS);
        try {
            return this.eleLastNameErrorMsg.isDisplayed();
        } catch (NoSuchElementException e) {
            logMessage("Element not found:" + this.eleLastNameErrorMsg);
            return false;
        }
    }

    public boolean verifyEnterDOBDayErrorShown() {
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.MILLISECONDS);
        try {
            return this.eleDOBDayErrorMsg.isDisplayed();

        } catch (NoSuchElementException e) {
            logMessage("Element not found:" + this.eleDOBDayErrorMsg);
            return false;
        } catch (TimeoutException e) {
            logMessage("Element not found:" + this.eleDOBDayErrorMsg);
            return false;
        }
    }

    public boolean verifyEnterDOBMonthErrorShown() {
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.MILLISECONDS);
        try {
            return this.eleDOBMonthErrorMsg.isDisplayed();

        } catch (NoSuchElementException e) {
            logMessage("Element not found:" + this.eleDOBMonthErrorMsg);
            return false;
        } catch (TimeoutException e) {
            logMessage("Element not found:" + this.eleDOBMonthErrorMsg);
            return false;
        }
    }

    public boolean verifyEnterDOBYearErrorShown() {
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.MILLISECONDS);
        try {
            return this.eleDOBYearErrorMsg.isDisplayed();

        } catch (NoSuchElementException e) {
            logMessage("Element not found:" + this.eleDOBYearErrorMsg);
            return false;
        } catch (TimeoutException e) {
            logMessage("Element not found:" + this.eleDOBYearErrorMsg);
            return false;
        }
    }

    public String getFirstName() {
        return eleFirstnameInputField.getAttribute("value").toLowerCase();
    }

    public String getLastName() {
        return eleLastnameInputField.getAttribute("value").toLowerCase();
    }

    public String getMiddleName() {
        return eleMiddlenameInputField.getAttribute("value").toLowerCase();
    }

    public String getSelectedGender() {
        return driver.findElement(By.xpath("//*[@class='verified-tick-radioButton']")).getText();
    }




    /*  plan selection
    * */


    @FindBy(xpath = "//span[@class='MuiButton-label' and text()='CONTINUE']")
    @AndroidFindBy(accessibility = "continueBtn")
    @iOSXCUITFindBy(iOSClassChain  ="**/XCUIElementTypeButton[`label == \"continueBtn\"`]")
    public WebElement elePlanSelectionNextbtn;

    @AndroidFindBy(accessibility = "cselectPlanBtn")
    @FindBy(xpath = "//button[contains(@class,'select-plan-button')]")
    @iOSXCUITFindBy(accessibility = "selectPlanBtn")
    private WebElement alertSelectPlanProceedBtn;

    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Health & Pure Term Plans']//..//android.view.ViewGroup[position()=1]")
    @FindBy(xpath = "//span[text()='Health & Pure Term Plans']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name='true']")
    private WebElement radioTermPlan;

    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Recommend Plans']//..//android.view.ViewGroup[position()=1]")
    @FindBy(xpath = "//span[text()='Recommend Plans']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name='false']")
    private WebElement radioRecommendPlan;

    @AndroidFindBy(accessibility = "isProposerStateSameQst")
    @FindBy(xpath = "//input[@name='hideProposerState']")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeOther[`label == \"isProposerStateSameQst\"`][2]")
    private WebElement eleProposerStateSameQtn;

    @AndroidFindBy(xpath = "//android.view.View[@text='HEALTH & PURE TERM PLAN']")
    @FindBy(xpath = "//div[@class='pathname' and text()='HEALTH & PURE TERM PLAN']")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeOther[`name == \"HEALTH & PURE TERM PLAN\"`]")
    public WebElement elePlanSelectionNavText;

    @AndroidFindBy(accessibility = "productNameQst")
    @FindBy(css = "#productNameQst")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name='productNameQst']")
    private WebElement elePlanDropdown;

    @AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"stateIdQst\"]//..//..//android.widget.TextView[@content-desc=\"inputHelperText\"]")
    @FindBy(xpath = "//p[@class='MuiFormHelperText-root' and text()='Required']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='inputHelperText']")
    private WebElement eleStateHelperText;

    @AndroidFindBy(accessibility = "stateIdQst")
    @FindBy(css = "#stateIdQst")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name='stateIdQst']")
    private WebElement eleStateDropdown;

    @AndroidFindBy(xpath = "//android.view.View[@text='View Quote']")
    @FindBy(xpath = "//div[@class='pathname' and text()='View Quote']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name='View Quote']")
    public WebElement eleViewQuoteNavText;

    @iOSXCUITFindBy(accessibility = "illustrationBtn ridersBtn")
    public WebElement eleRiderSection;

    @AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"Non-Smoker\"]")
    @FindBy(xpath = "//span[text()='Non-Smoker']")
    @iOSXCUITFindBy(xpath = "Non-Smoker")
    private WebElement eleNonSmoker;

    @AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"Smoker\"]")
    @FindBy(xpath = "//span[text()='Smoker']")
    @iOSXCUITFindBy(iOSNsPredicate = "label == \"Smoker\" AND name == \"Smoker\" AND type == \"XCUIElementTypeOther\"")
    private WebElement eleSmoker;

    @AndroidFindBy(xpath = "//android.widget.Button[@content-desc=\"rightIcon\"]/android.widget.TextView")
    public WebElement eleDefaultSumAssuredIcon;

    @AndroidFindBy(xpath = "//android.widget.EditText[@content-desc=\"sumAssuredQst\"]")
    @FindBy(xpath = "//input[@name='sumAssuredQst']")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeTextField[`label == \"sumAssuredQst\"`]")
    public WebElement eleSumAssuredInput;

    @AndroidFindBy(accessibility = "productNameOptionQst")
    @FindBy(css = "#mui-component-select-productNameOptionQst")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name='productNameOptionQst']")
    private WebElement elePlanSelectionOptionsDropdown;

    @AndroidFindBy(accessibility = "ecs")
    @FindBy(css = "#ecsCheckbox")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name='ECS']")
    private WebElement eleECSCheckbox;

    @AndroidFindBy(accessibility = "policyTermYearsQst")
    @FindBy(xpath = "//input[@name='policyTermYearsQst']")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeTextField[`label == \"policyTermYearsQst\"`]")
    public WebElement elePolicyTermInput;

    @AndroidFindBy(accessibility = "ppt")
    @FindBy(css = "#mui-component-select-premiumPayTermQst")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name='ppt']")
    private WebElement elePPTIDropdown;

    @AndroidFindBy(accessibility = "increasingLevel")
    @FindBy(css = "#mui-component-select-increasingLevelQst")
    //@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name='increasingLevel']")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeOther[`label == \"increasingLevel\"`][4]")
    private WebElement eleIncreasingLevelDropdownInput;

    @AndroidFindBy(accessibility = "illustrationBtn")
    @FindBy(xpath = "//span[text()='DOWNLOAD ILLUSTRATION']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='illustrationBtn']")
    private WebElement eleIllustrationBtn;

    @AndroidFindBy(accessibility = "ridersBtn")
    @FindBy(xpath = "//span[text()='RIDERS']")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"ridersBtn\"`]")
    public WebElement eleRidersBtn;

    @AndroidFindBy(accessibility = "Mode")
    private WebElement eleModeArrow;

    @FindBy(xpath = "//div[@class='amount-in-numbers']")
    @AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"mainContainer\"]/android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup[2]/android.view.ViewGroup[2]/android.widget.TextView[1]")
    @iOSXCUITFindBy(xpath = "//*XCUIElementTypeScrollView/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther[2]/XCUIElementTypeOther/XCUIElementTypeOther[1]/XCUIElementTypeOther/XCUIElementTypeOther[1]/XCUIElementTypeStaticText")
    ////XCUIElementTypeStaticText[@name="(GST inclusive for first year)”]//..//XCUIElementTypeOther/XCUIElementTypeOther[2]/XCUIElementTypeStaticText[1]
    private WebElement elePremiumAmountText;

    @FindBy(xpath = "//span[text()='CLOSE']")
    private WebElement eleMinSumAssuredAlertCloseButton;

    @FindBy(css = "#mui-component-select-premiumPayPeriodQst")
    //@FindBy(xpath = "//input[@name='premiumPayPeriodQst']")
    @AndroidFindBy(accessibility = "Mode")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name='Mode']")
    public WebElement elePremiumPayPeriod;

    @FindBy(xpath = "//div[@class='amount-in-numbers']")
    @AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"mainContainer\"]/android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup[2]/android.view.ViewGroup[2]/android.widget.TextView[1]")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeOther' AND name BEGINSWITH[cd] 'Mode'")
            //"//*XCUIElementTypeScrollView/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther[2]/XCUIElementTypeOther/XCUIElementTypeOther[1]/XCUIElementTypeOther/XCUIElementTypeOther[1]/XCUIElementTypeStaticText")
    private WebElement elePremiumAmout;

    @FindBy(xpath = "//ul[@role='listbox']")
    @AndroidFindBy(className = "android.widget.ScrollView")
    @iOSXCUITFindBy(className = "XCUIElementTypeScrollView")
    private WebElement eleQuoteGenericDropdownList;

    @FindBy(xpath = "//div[@id='mui-component-select-productNameOptionQst']/span")
    @AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"productNameOptionQst\"]/android.view.ViewGroup[1]/android.widget.EditText")
    private WebElement eleDefaultPlanOptionText;

    @FindBy(xpath = "//div[@id='mui-component-select-increasingLevelQst']/span")
    @AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"increasingLevel\"]/android.view.ViewGroup[1]/android.widget.EditText")
    private WebElement eleDefaultIncreasingLevelText;

    @FindBy(xpath = "//div[@id='mui-component-select-premiumPayTermQst']/span")
    @AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"ppt\"]/android.view.ViewGroup[1]/android.widget.EditText")
    private WebElement eleDefaultPptText;

    @FindBy(xpath = "//div[@id='mui-component-select-premiumPayPeriodQst']/span")
    @AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"Mode\"]/android.view.ViewGroup[1]/android.widget.EditText")
    private WebElement eleDefaultPremiumText;

    @FindBy(xpath = "//p[contains(text(),'Alert')]")
    @AndroidFindBy(id = "android:id/alertTitle")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeAlert[@name=\"Alert\"]")
    public WebElement eleAlertDialog;

    @FindBy(xpath = "//span[contains(text(),'OK')]")
    @AndroidFindBy(id = "android:id/button1")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"OK\"`]")
    private WebElement eleOkButton;

    @FindBy(xpath = "//*[text()='SAVE']")
    @AndroidFindBy(accessibility = "quoteSaveButton")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`name == \"quoteSaveButton\"`]")
    private WebElement eleQuoteSaveBtn;

    @FindBy(xpath = "//*[text()='SAVE']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='SAVE']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"verifyButton\"]")
    private WebElement eleQuoteSaveBtn1;

    @FindBy(xpath = "//p[contains(@class,'MuiFormHelperText-root')]")
    @AndroidFindBy(accessibility = "inputHelperText")
    public WebElement eleQuoteError;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == \"Alert\"`]")
    @FindBy(xpath = "//p[contains(text(),'Alert')]")
    @AndroidFindBy(id = "android:id/alertTitle")
    private WebElement eleMobileAlert;


    public boolean verifyDOBAlertIsDisplayed() {
        waitUtils.implicitWait(driver, 10);
        try {
            return this.alertDOB.isDisplayed();
        } catch (NoSuchElementException e) {
            logMessage("Element not displayed:" + this.alertDOB);
            return false;
        }
    }

    public void chooseDOBAlertOption(String optionType) {
        switch (optionType.toLowerCase()) {
            case "edit":
                this.alertDOBEditBtn.clear();
                break;
            case "continue":
                this.eleDOBIncorrectAlertYesButton.click();
                break;
            default:
                logMessage("None of the options are selected");
        }
    }

    public void chooseSelectPlanButton() {
        this.eleSelectPlanBtn.click();
    }

    public void choosePlan(String planType) {
        switch (planType.toLowerCase()) {
            case "term":
                this.radioTermPlan.click();
                break;
            case "recommend":
                this.radioRecommendPlan.click();
                break;
            default:
                logMessage("Plan selected is invalid");
        }

        choosePlanSelectProceedButton();
    }

    public void choosePlanSelectProceedButton() {
        waitUtils.waitForElementToBeVisible(driver,this.alertSelectPlanProceedBtn);
        this.alertSelectPlanProceedBtn.click();
    }

    public void selectProposerStateSameAsAdvisorCheckbox() {
        this.eleProposerStateSameQtn.click();
    }

    public Boolean isProposerStateCheckboxSelected() {
        if(new BaseTest().isAndroid()) {
            return Boolean.valueOf(this.eleProposerStateSameQtn.getAttribute("checked"));
        }
        else if(new BaseTest().isIOS()) {
            try {
                return Boolean.valueOf(this.eleProposerStateSameQtn.getAttribute("value").contains("checkbox, checked"));
            } catch (NullPointerException e) {
                return this.eleProposerStateSameQtn.isSelected();
            }
        }
        else {
            return this.eleProposerStateSameQtn.isSelected();
        }
    }


    /*
    * BSLI Cancer Shield Plan
        BSLI CritiShield Plan
        BSLI Life Shield
        * ABSLI Digishield Plan

     * */
    public void choosePlanFromDropdown(String planName) {
        waitUtils.waitForElementToBeVisible(driver,elePlanDropdown);
        this.elePlanDropdown.click();
        waitUtils.wait2Seconds();
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                driver.findElement(By.xpath("//android.widget.TextView[@text='" + planName + "']")).click();
                break;
            case "ios":
                waitUtils.waitForElementToBeVisible(driver,driver.findElement(By.xpath("//XCUIElementTypeOther[@name='" + planName + "']")));
                driver.findElement(By.xpath("//XCUIElementTypeOther[@name='" + planName + "']")).click();
                break;
            default:
                //waitUtils.waitForElementToBeVisible(driver,driver.findElement(By.xpath("//span[text()='" + planName + "']")));
                //driver.findElement(By.xpath("//span[text()='" + planName + "']")).click();
                waitUtils.waitForElementToBeVisible(driver,driver.findElement(By.xpath("//li[@data-value='" + planName + "']")));
                driver.findElement(By.xpath("//li[@data-value='" + planName + "']")).click();
        }
    }

    public boolean verifyStateRequiredMessage() {
        return this.eleStateHelperText.isDisplayed();
    }

    public void chooseStateFromDropdown() {
        this.eleStateDropdown.click();
    }

    public void chooseStateFromDropdown(String stateName) {
        this.eleStateDropdown.click();
        waitUtils.wait5Seconds();
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                driver.findElement(By.xpath("//android.widget.TextView[@text='" + stateName + "']")).click();
                break;
            case "ios":
                driver.findElement(By.xpath("//XCUIElementTypeOther[@name='" + stateName + "']")).click();
                break;
            default:
                this.eleStateDropdown.sendKeys(stateName);
        }
    }

    public void chooseSmoker(String value) {
        switch (value.toLowerCase()) {
            case "smoker":
                if (!isSmokerSelected()) {
                    System.out.println("SMOKER selected");
                    this.eleSmoker.click();
                    this.eleSmoker.click();
                }
                break;
            case "non-smoker":
                if (isSmokerSelected()) {
                    this.eleNonSmoker.click();
                    this.eleNonSmoker.click();
                }
                break;

        }

    }

    public Boolean minSumAssuredAlertDisplayed() {
        waitUtils.implicitWait(driver, 100);
        try {
            return this.eleMinSumAssuredAlertCloseButton.isDisplayed();
        } catch (NoSuchElementException e) {
            return false;
        } catch (TimeoutException e) {
            return false;
        }
    }



    public boolean quoteErrorDisplayed() {
        return this.eleQuoteError.isDisplayed();
    }

    public void clearSumAssuredInputValue() {
        this.eleSumAssuredInput.click();

        if(baseTest.isWeb()) {
            for(int i=0;i<20;i++) {
                eleSumAssuredInput.sendKeys(Keys.BACK_SPACE);
                eleSumAssuredInput.sendKeys(" ");
                eleSumAssuredInput.sendKeys(Keys.DELETE);
            }
        }
        else  {
            this.eleSumAssuredInput.click();
            eleSumAssuredInput.sendKeys(Keys.DELETE);
            this.eleSumAssuredInput.clear();
        }
    }

    public void inputSumAssured(String sumAssuredAmount) {
        clearSumAssuredInputValue();
        this.eleSumAssuredInput.sendKeys(sumAssuredAmount);
        //((AndroidDriver) driver).getKeyboard().pressKey("\n");
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                ((AndroidDriver<MobileElement>) driver).pressKey(new KeyEvent(AndroidKey.BACK));
                //((AndroidDriver) driver).getKeyboard().pressKey("\n");
                break;
            case "ios":
                eleSumAssuredInput.sendKeys(Keys.RETURN);
                break;
            default:
        }
    }

    public void inputPolicyTerm(String policyTerm)  {
        this.elePolicyTermInput.click();
        this.clearPolicyTerm();
        this.elePolicyTermInput.sendKeys(policyTerm);
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                //((AndroidDriver) driver).pressKey(new KeyEvent(AndroidKey.NUMPAD_ENTER));
                /*((AndroidDriver) driver).getKeyboard().pressKey(Keys.RETURN);
                elePolicyTermInput.sendKeys(Keys.ENTER);
*/
                //((AndroidDriver<MobileElement>) driver).pressKey(new KeyEvent(AndroidKey.ENTER));
                //elePolicyTermInput.sendKeys(Keys.ENTER);
                ((AndroidDriver<MobileElement>) driver).pressKey(new KeyEvent(AndroidKey.ENTER));
                ((AndroidDriver<MobileElement>) driver).pressKey(new KeyEvent(AndroidKey.BACK));
                //elePolicyTermInput.sendKeys(Keys.RETURN);


                //elePolicyTermInput.sendKeys(Keys.);

                //((AndroidDriver<MobileElement>) driver).pressKey(new KeyEvent(AndroidKey.ENTER));
                //((AndroidDriver<MobileElement>) driver).pressKey(new KeyEvent(AndroidKey.TA));

                break;
            case "ios":
                //((IOSDriver) driver).getKeyboard().pressKey("\n");
                //((IOSDriver) driver).getKeyboard().pressKey(Keys.RETURN);
                ((IOSDriver) driver).getKeyboard().pressKey(Keys.RETURN);
                elePolicyTermInput.sendKeys(Keys.ENTER);


                break;
            default:
        }
    }

    public void clearPolicyTerm() {
        for(int i =0;i<10;i++) {
            if(baseTest.isWeb()) {
                elePolicyTermInput.sendKeys(Keys.BACK_SPACE);
                elePolicyTermInput.sendKeys(Keys.DELETE);
            }
            else if(baseTest.isIOS()){
                elePolicyTermInput.click();
                elePolicyTermInput.sendKeys(Keys.DELETE);
                elePolicyTermInput.clear();
            }
            elePolicyTermInput.click();
            elePolicyTermInput.clear();
         }
    }

    public void selectECSCheckBox() {
        if (!this.eleECSCheckbox.isSelected()) {
            this.eleECSCheckbox.click();
        }
    }

    public void unselectECSCheckBox() {
        if (this.eleECSCheckbox.isSelected()) {
            this.eleECSCheckbox.click();
        }
    }

    public void chooseIncreasingLevelFromDropdown(String level) {
        level = level.trim();

        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                if (!(getIncreasingLevelDefaultValue().equalsIgnoreCase(level))) {
                    if (this.eleIncreasingLevelDropdownInput.isEnabled()) {
                        this.eleIncreasingLevelDropdownInput.click();
                        waitUtils.implicitWait(driver, 100);
                        try {
                            this.eleQuoteGenericDropdownList.isDisplayed();
                        } catch (NoSuchElementException e) {
                            return;
                        }
                        waitUtils.implicitWait(driver, 10000);
                        //driver.findElement(By.xpath("*//android.widget.TextView[@text='"+level+"']")).click();
                        commonUtils.clickElementOnScroll(driver, level);
                    }
                }
                break;
            case "ios":
                if (this.eleIncreasingLevelDropdownInput.isEnabled()) {
                    this.eleIncreasingLevelDropdownInput.click();
                    waitUtils.implicitWait(driver, 100);
                    try {
                        this.eleQuoteGenericDropdownList.isDisplayed();
                    } catch (NoSuchElementException e) {
                        return;
                    }
                    waitUtils.implicitWait(driver, 40000);
                    commonUtils.clickOnScrollForIos(driver, level);
                }
                break;
            default:
                if (!(getIncreasingLevelDefaultValue().equalsIgnoreCase(level))) {
                    if (this.eleIncreasingLevelDropdownInput.isEnabled()) {
                        waitUtils.waitForElementToBeVisible(driver,eleIncreasingLevelDropdownInput);
                        this.eleIncreasingLevelDropdownInput.click();
                        waitUtils.waitForElementToBeVisible(driver,eleQuoteGenericDropdownList);
                        waitUtils.wait5Seconds();
                        //driver.findElement(By.xpath("//ul[@role='listbox']/li/span[text()='" + level + "']")).click();
                        //String mySelector = "By.xpath(\"//li[@role='option']\")";
                        /*List<WebElement> myElements = driver.findElements(By.xpath("//li[@role='option']"));
                        for(WebElement e : myElements) {
                            if (e.getText().equalsIgnoreCase(level)) {
                                e.click();
                            }
                        }*/

                        commonUtils.selectDropdownOption(driver,By.xpath("//li[@role='option']"),level);
                        waitUtils.wait5Seconds();
                        }
                }
                if (!this.eleIncreasingLevelDropdownInput.isSelected()) {
                    logMessage("incresing level dropdown not selected , need to select second time");
                }
        }
    }


    /*
    Level Term Assurance
    Increasing Term Assurance
    Decreasing Term Assurance
    Return of Premium
    * */
    public void chooseProductOptionsFromDropdown(String names) {
        names = names.trim();

        //waitUtils.waitForElementToBeVisible(driver, eleQuoteGenericDropdownList, 30, "Product dropdown options list is not shown");
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                if (!(getPlanOptionsDefaultValue().equalsIgnoreCase(names.trim()))) {
                    waitUtils.waitForElementToBeVisible(driver, this.elePlanSelectionOptionsDropdown, 30, "Plan selection dropdown is not shown");
                    this.elePlanSelectionOptionsDropdown.click();
                    waitUtils.implicitWait(driver, 30000);
                    commonUtils.clickElementOnScroll(driver, names);
                }
                break;
            case "ios":
                waitUtils.waitForElementToBeVisible(driver, this.elePlanSelectionOptionsDropdown, 30, "Plan selection dropdown is not shown");
                this.elePlanSelectionOptionsDropdown.click();
                waitUtils.waitForElementToBeVisible(driver, this.eleQuoteGenericDropdownList, 30, "Plan selection dropdown is not shown");
                waitUtils.implicitWait(driver, 30000);
                JavascriptExecutor js = (JavascriptExecutor) driver;
                MobileElement list = (MobileElement) driver.findElement(By.className("XCUIElementTypeScrollView"));
                MobileElement listElement = (MobileElement) driver.findElement(By.xpath("//XCUIElementTypeOther[contains(@name,'" + names + "')]"));
                Map<String, Object> params = new HashMap<>();
                params.put("direction", "down");
                params.put("velocity", 2500);
                params.put("element", listElement.getId());
                js.executeScript("mobile: swipe", params);
                //commonUtils.clickOnScrollForIos(driver,names);
                //driver.findElement(By.xpath("//XCUIElementTypeOther[contains(@name,'"+names +"')]")).click();
                break;
            default:
                if (!(getPlanOptionsDefaultValue().equalsIgnoreCase(names.trim()))) {
                    waitUtils.waitForElementToBeVisible(driver, this.elePlanSelectionOptionsDropdown, 30, "Plan selection dropdown is not shown");
                    this.elePlanSelectionOptionsDropdown.click();
                    waitUtils.implicitWait(driver, 30000);
                    driver.findElement(By.xpath("//ul[@role='listbox']/li/span[text()='" + names + "']")).click();
                }
        }
        waitUtils.implicitWait(driver, 30000);

    }

    public void choosePPTDropdown(String names) {
        names = names.trim();

        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                if (!(getPptDefaultValue().equalsIgnoreCase(names))) {
                    this.elePPTIDropdown.click();
                    waitUtils.waitForElementToBeVisible(driver, this.eleQuoteGenericDropdownList, 30, "PPT dropdown is not shown");
                    //driver.findElement(By.xpath("*//android.widget.TextView[@text='"+names+"']")).click();
                    commonUtils.clickElementOnScroll(driver, names);
                }

                break;
            case "ios":
                this.elePPTIDropdown.click();
                waitUtils.implicitWait(driver, 30000);
                waitUtils.waitForElementToBeVisible(driver, this.eleQuoteGenericDropdownList, 30, "PPT dropdown is not shown");
                commonUtils.clickOnScrollForIos(driver, names);
                break;
            default:
                if (!(getPptDefaultValue().equalsIgnoreCase(names))) {
                    this.elePPTIDropdown.click();
                    waitUtils.implicitWait(driver, 30000);
                    waitUtils.waitForElementToBeVisible(driver, this.eleQuoteGenericDropdownList, 30, "PPT dropdown is not shown");
                    driver.findElement(By.xpath("//ul[@role='listbox']/li/span[text()='" + names + "']")).click();
                }
        }

    }

    public void signInAndNavigateTillPlanSelection() throws IOException, InterruptedException {
        signInAndNavigateToCaptureLeadIdScreen();
        fillLeadIdChooseNextWhenProposerInsuredAreSame();
        ProposerModel customerProposerModel = jsonObj.readProposerJson().getDataByTestCase("validcustomerprofile");
        waitUtils.waitForElementToBeVisible(driver, eleProposerMobileNoInputField, 30, "Mobile no input field is not displayed");
        inputMobileNo("proposer", customerProposerModel.getMobileNo());
        inputPan("proposer", customerProposerModel.getPan());
        selectPanMobileNextButton();
        waitUtils.waitForElementToBeVisible(driver, eleFirstnameInputField);
        if (!isVerifiedTick()) {
            fillFirstName(customerProposerModel.getFirstName(),"proposer");
            fillLastName(customerProposerModel.getLastName(),"proposer");
            fillMiddleName(customerProposerModel.getMiddleName(),"proposer");
            commonUtils.scrollTillEndOfPage(driver);
            selectGender(customerProposerModel.getGender(),"proposer");
            waitUtils.implicitWait(driver, 20000);
        }
        commonUtils.scrollTillEndOfPage(driver);
        enterDOB(customerProposerModel);
        clickProceedGoToPlanSelection();
        dismissPrefillScreenAlerts();
        chooseSelectPlanButton();
    }

    public void fillLeadIdAndProceedTo(String leadId, String proposersame, String relationwithinsured, String isrelationanswer, String isNri) throws InterruptedException {

        Thread.sleep(1000);
        inputLeadId(leadId.trim());
        //waitUtils.waitForElementToBeVisible(driver,eleProposerInsuredQst);
        selectIsProposerInsuredSameQst(proposersame.trim());
        if (proposersame.equalsIgnoreCase("no")) {
            Thread.sleep(1000);
            commonUtils.scrollTillEndOfPage(driver);
            //spouse
            selectRelationFromList(relationwithinsured.trim(), isrelationanswer.trim());
            //commonUtils.scrollTillEndOfPage(driver);
            //Assert.assertTrue(verifyJointPolicyTextIsShown(),"On selection of Spouse relation joint policy text label is not shown");

        }
        commonUtils.scrollTillEndOfPage(driver);
        selectIsNriQst(isNri);
        selectNextButton();
        waitUtils.fluentWaitUntilElementVisible(driver, eleProposerMobileNoInputField,80);

    }

    public void fillLeadIdAndProceed(String leadId, String proposersame, String isNri) throws InterruptedException {
        inputLeadId(leadId.trim());
        selectIsProposerInsuredSameQst(proposersame.trim());
        if (proposersame.equalsIgnoreCase("no")) {
            //
        }
        selectIsNriQst(isNri);
        selectNextButton();
        waitUtils.implicitWait(driver, 30000);
        waitUtils.waitForElementToBeVisible(driver, eleProposerMobileNoInputField, 30, "Mobile noe input field is not displayed");

    }

    public void captureMobilePanAndProceed(String mobile, String pan) {
        inputMobileNo("proposer", mobile);
        inputPan("proposer", pan);
        selectPanMobileNextButton();
        /*if (isAlertShown()) {
            acceptAlert();
        }*/
        /*if(commonUtils.isDisplayed(driver,eleMobileAlert)) {
            waitUtils.fluentWaitUntilElementVisible(driver,eleOkButton,5);
            acceptAlert();
        }*/
        waitUtils.waitForElementToBeVisible(driver, eleFirstnameInputField);
    }

    public void chooseProposerTab() {
        eleProposerTab.click();
    }

    public void captureMobilePanAndProceed1(String mobile, String pan,String proposersame,String imobile,String ipan) throws InterruptedException {

        inputMobileNo("proposer", mobile);
        inputPan("proposer", pan);
        //selectPanMobileNextButton();

        if(proposersame.equalsIgnoreCase("no")) {
            commonUtils.scrollTopOfPage(driver);
            chooseInsuredTab();
            Thread.sleep(3000);
            //waitUtils.fluentWaitUntilElementVisible(driver,eleInsuredMobileNoInputField,50);
            verifyMobileNoFieldIsVisible("insured");
            inputMobileNo("insured", mobile);
            inputPan("insured", pan);
            commonUtils.scrollTillEndOfPage(driver);
            waitUtils.waitForElementToBeVisible(driver,eleMobilePanNextBtn);
        }
        selectPanMobileNextButton();

        if(commonUtils.isDisplayed(driver,eleMobileAlert)) {
            acceptAlert();
        }
        /*if (isAlertShown()) {
            acceptAlert();
        }*/
        //waitUtils.waitForElementToBeVisible(driver, eleFirstnameInputField);

        waitUtils.fluentWaitUntilElementVisible(driver,eleFirstnameInputField,80);

    }

    public void prefillDetails(String firstname, String lastname, String middlename, String day, String month, String year, String gender) {
        if (!isVerified()) {
            fillFirstName(firstname,"proposer");
            fillLastName(lastname,"proposer");
            //fillMiddleName(middlename,"proposer");
            commonUtils.scrollTillEndOfPage(driver);
            selectGender(gender,"proposer");
            waitUtils.implicitWait(driver, 20000);
        }
        commonUtils.scrollTillEndOfPage(driver);
        waitUtils.waitUntilVisible(driver, eleDOBDayInput, 30);
        fillDOB("19", "06", "1982","proposer");
        clickProceedGoToPlanSelection();
        dismissPrefillScreenAlerts();
        chooseSelectPlanButton();
    }

    public void fillPlanSelectionDetails(ProposerModel proposerModel) {
        waitUtils.implicitWait(driver, 20000);
        choosePlan("term");
        //choosePlanSelectProceedButton();
        waitUtils.waitForElementToBeVisible(driver, elePlanSelectionNavText);

        commonUtils.scrollTillEndOfPage(driver);

        if (!isProposerStateCheckboxSelected()) {
            selectProposerStateSameAsAdvisorCheckbox();
        }
        choosePlanFromDropdown(proposerModel.getPlanName());

        commonUtils.selectButtonByName("CONTINUE", driver);
        waitUtils.waitForElementToBeVisible(driver, eleViewQuoteNavText);
    }

    public void choosePlanAndProceedToViewQuote(String planjourney, String proposerstate, String advisorstatesame, String plan) throws InterruptedException {

        waitUtils.implicitWait(driver, 20000);
        choosePlan(planjourney);
        waitUtils.waitForElementToBeVisible(driver, elePlanSelectionNavText);
        commonUtils.scrollTillEndOfPage(driver);
        if (advisorstatesame.equalsIgnoreCase("YES")) {
            if (!isProposerStateCheckboxSelected()) {
                selectProposerStateSameAsAdvisorCheckbox();
            }
        } else {
            chooseStateFromDropdown(proposerstate);
        }

        choosePlanFromDropdown(plan.trim());
        waitUtils.waitForElementToBeVisible(driver,elePlanSelectionNextbtn);
        waitUtils.wait2Seconds();
        chooseActionButton(elePlanSelectionNextbtn);
        waitUtils.fluentWaitUntilElementVisible(driver, eleViewQuoteNavText,50);

    }

    public void fillPlanDetails(String planjourney, String proposerstate, String advisorstatesame, String plan) throws InterruptedException {

        if (advisorstatesame.equalsIgnoreCase("YES")) {
            if (!isProposerStateCheckboxSelected()) {
                selectProposerStateSameAsAdvisorCheckbox();
            }
        } else {
            chooseStateFromDropdown(proposerstate);
        }
        commonUtils.scrollTillEndOfPage(driver);
        choosePlanFromDropdown(plan.trim());
        waitUtils.waitForElementToBeVisible(driver,elePlanSelectionNextbtn);
        chooseActionButton(elePlanSelectionNextbtn);
        waitUtils.fluentWaitUntilElementVisible(driver, eleViewQuoteNavText,40);

    }

    public void goToCreateQuoteScreen(ProposerModel proposerModel) throws IOException, InterruptedException {
        signInAndNavigateTillPlanSelection();
        fillPlanSelectionDetails(proposerModel);
    }

    public void fillQuote(String sumassured, String smokertype, String planoptions, String increasinglevel, String ecs,
                          String term, String ppt, String premiumterm, String premiumamount) {
        waitUtils.waitForElementToBeVisible(driver, eleViewQuoteNavText);
        chooseSmoker(smokertype);
        inputSumAssured(sumassured);
        if (ecs.equalsIgnoreCase("yes")) {
            selectECSCheckBox();
        } else {
            unselectECSCheckBox();

        }
        chooseProductOptionsFromDropdown(planoptions);
        waitUtils.implicitWait(driver, 30000);

        if (planoptions.contains("Increasing")) {
            chooseIncreasingLevelFromDropdown(increasinglevel);
        }

        if(new BaseTest().isIOS()) {
            commonUtils.clickOnScrollForIos(driver,eleQuoteSaveBtn);
        }
        else if(new BaseTest().isAndroid()) {
            commonUtils.elementOnScroll(driver,"Annual");
        }
        inputPolicyTerm(term);
        waitUtils.waitForElementToBeClickable(driver, elePPTIDropdown);
        choosePPTDropdown(ppt);
        waitUtils.implicitWait(driver, 30000);
        commonUtils.scrollTillEndOfPage(driver);
        //commonUtils.scrollIntoView(elePremiumPayPeriod,driver);
        if(!ppt.equalsIgnoreCase("Single Pay")) {
            logMessage("=============  Insidee pppptt   dropdown ==============");
            if(new BaseTest().isIOS()) {
                commonUtils.clickOnScrollForIos(driver,elePremiumPayPeriod);
            }
            waitUtils.waitForElementToBeVisible(driver, elePremiumPayPeriod, 30, "Premium period dropdown not shown in view quote screen");
            waitUtils.waitForElementToBeClickable(driver, elePremiumPayPeriod);
            choosePremiumPeriod(premiumterm);
        }
        try {
            Thread.sleep(1000);

        } catch (Exception e) {
            //
        }

        //waitUtils.waitForElementToBeVisible(driver, eleQuoteSaveBtn);
    }


    public void createQuote(String sumassured, String smokertype, String planoptions, String increasinglevel, String ecs,
                            String term, String ppt, String premiumterm, String premiumamount) throws InterruptedException {

        // TO DO : need to uncomment once add address issue is checked
        /*fillQuote( sumassured,  smokertype,  planoptions,  increasinglevel,  ecs,
                 term,  ppt,  premiumterm,  premiumamount);
*/
        waitUtils.waitForElementToBeClickable(driver, eleQuoteSaveBtn,20);
        Thread.sleep(2000);
        this.eleQuoteSaveBtn.click();
        waitUtils.waitUntilVisible(driver, elePlanSummaryNavText, 30);

    }

    public boolean verifyGenderIsSelected(String gender) throws IOException {
        //proposerModel = jsonObj.readProposerJson().getDataByTestCase("validcustomerprofile");
        if(new BaseTest().isWeb()) {
            return driver.findElement(By.xpath("//button[@value=\"" + gender.toLowerCase() + "\"]/span/img[@class='verified-tick-radioButton']")).isDisplayed();
        } else  {
            return true;
        }
    }

    public boolean verifyEditNameAlertDisplayed() {
        waitUtils.waitUntilVisible(driver, this.elePrefillAlert, 30);
        return elePrefillAlert.isDisplayed();
    }

    @FindBy(xpath = "//p[text()='ALERT']")
    @AndroidFindBy(id = "android:id/alertTitle")
    //@iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`name == \"ALERT\"`]")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeOther' AND name BEGINSWITH[cd] 'ALERT'")
    private WebElement elePrefillAlert;

    @FindBy(xpath = "//span[text()='OK']")
    @AndroidFindBy(id = "android:id/button1")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeButton' AND name BEGINSWITH[cd] 'OKrightBtn'")
    private WebElement elePrefillOkBtn;

    public void dismissPrefillScreenAlerts() {
        /*try {
            if (verifyEditNameAlertDisplayed()) {
                this.eleEditNameAlertOkButton.click();
            }
        } catch (NoSuchElementException e) {
            logMessage("element notr found:" + eleEditNameAlertOkButton);

        }
        try {
            waitUtils.waitForElementToBeVisible(driver, eleDOBIncorrectAlertYesButton, 5, "DOB incorrect alert is not shown");
            waitUtils.implicitWait(driver, 50);
            if (this.eleDOBIncorrectAlertYesButton.isDisplayed()) {
                this.eleDOBIncorrectAlertYesButton.click();
            }
        } catch (NoSuchElementException e) {
            logMessage("element notr found:" + eleDOBIncorrectAlertYesButton);

        }*/

        try {
            //waitUtils.waitUntilVisible(driver,elePrefillOkBtn,50);
            waitUtils.wait1Seconds();
            if(commonUtils.isDisplayed(driver, elePrefillAlert)) {
                waitUtils.implicitWait(driver,100);
                if(new BaseTest().isIOS()) {
                    try {
                        driver.switchTo().alert().accept();
                    } catch (NoAlertPresentException e) {
                        elePrefillOkBtn.click();
                    }
                } else {
                    elePrefillOkBtn.click();
                    this.eleDOBIncorrectAlertYesButton.click();
                }
            } else {
                this.eleEditNameAlertOkButton.click();
                this.eleDOBIncorrectAlertYesButton.click();

            }

        } catch (NoSuchElementException e) {
            //
        } catch (TimeoutException e) {
            //
        }


    }

    public void ProceedNext(String buttonName) {
        driver.findElement(By.xpath("//button/span[text()='Save']")).click();
    }

    public void clickProceedGoToPlanSelection() {
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                //driver.findElement(By.xpath("//android.widget.TextView[@text='NEXT']")).click();
                waitUtils.waitUntilVisible(driver,driver.findElement(By.xpath("//android.widget.Button[@content-desc=\"nextBtn\"]")),30);
                driver.findElement(By.xpath("//android.widget.Button[@content-desc=\"nextBtn\"]")).click();
                break;
            case "ios":
                waitUtils.waitUntilVisible(driver,driver.findElement(By.xpath("//XCUIElementTypeButton[@name='nextBtn']")),30);
                driver.findElement(By.xpath("//XCUIElementTypeButton[@name='nextBtn']")).click();
                break;
            default:
                driver.findElement(By.xpath("//button/span[text()='Save']")).click();
        }

        System.out.println("--------clicked on plan select before alert button----------");
    }

    public void clearAllPrefilDetailsFieldValues(String type) {
        switch (type) {
            case "proposer":
                eleLastnameInputField.click();
                eleLastnameInputField.clear();
                if (new BaseTest().isIOS()) {
                    eleLastnameInputField.sendKeys(Keys.DELETE);
                    eleLastnameInputField.sendKeys(Keys.BACK_SPACE);
                }
                commonUtils.enterKey(eleLastnameInputField,driver);
                eleFirstnameInputField.click();
                eleFirstnameInputField.clear();
                if (new BaseTest().isIOS()) {
                    eleFirstnameInputField.sendKeys(Keys.DELETE);
                    eleFirstnameInputField.sendKeys(Keys.BACK_SPACE);
                }
                commonUtils.enterKey(eleFirstnameInputField,driver);

                //eleMiddlenameInputField.click();
                /*eleMiddlenameInputField.click();
                eleMiddlenameInputField.clear();*/
                //commonUtils.hideKeyboard(driver);
                eleDOBYearInput.clear();
                eleDOBMonthInput.clear();
                eleDOBDayInput.clear();
                break;
            case "insured":

                eleInsuredLastnameInputField.click();
                eleInsuredLastnameInputField.clear();
                if (new BaseTest().isIOS()) {
                    eleLastnameInputField.sendKeys(Keys.DELETE);
                    eleLastnameInputField.sendKeys(Keys.BACK_SPACE);
                }
                commonUtils.enterKey(eleLastnameInputField,driver);
                eleInsuredFirstnameInputField.click();
                eleInsuredFirstnameInputField.clear();
                if (new BaseTest().isIOS()) {
                    eleFirstnameInputField.sendKeys(Keys.DELETE);
                    eleFirstnameInputField.sendKeys(Keys.BACK_SPACE);
                }
                commonUtils.enterKey(eleFirstnameInputField,driver);

                //eleMiddlenameInputField.click();
                /*eleMiddlenameInputField.click();
                eleMiddlenameInputField.clear();*/
                //commonUtils.hideKeyboard(driver);
                eleInsuredDOBYearInput.clear();
                eleInsuredDOBMonthInput.clear();
                eleInsuredDOBDayInput.clear();
                break;
        }
        switch (BaseTest.PLATFORM_NAME) {
            case "android":
                ((AndroidDriver) driver).getKeyboard().pressKey("\n");
                //((AndroidDriver) driver).hideKeyboard();

                break;
            case "ios":
                //((IOSDriver)driver).hideKeyboard("Return");
                ((IOSDriver) driver).getKeyboard().pressKey("\n");
                break;
            default:
        }



    }

    public void choosePremiumPeriod(String period) {
        period = period.trim();
        waitUtils.waitUntilVisible(driver,elePremiumPayPeriod,30);
        this.elePremiumPayPeriod.click();
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                //commonUtils.clickElementOnScroll(driver,period);
                /*WebElement element = driver.findElement(MobileBy.AndroidUIAutomator("new UiScrollable("
                        + "new UiSelector().scrollable(true)).scrollIntoView("
                        + "new UiSelector().textContains(\"" + period + "\"));"));
                element.click();*/
                //commonUtils.selectDropdownOption(driver,By.className("android.widget.TextView"),period);
                waitUtils.fluentWaitUntilElementVisible(driver,driver.findElement(By.className("android.widget.ScrollView")),10);
                WebElement element = driver.findElement(By.className("android.widget.ScrollView"));
                element.findElement(By.xpath("//android.widget.TextView[@text='"+period+"']")).click();
                break;
            case "ios":
                driver.findElement(By.xpath("//XCUIElementTypeOther[@name='" + period + "']")).click();
                break;
            default:
                waitUtils.waitForElementToBeVisible(driver,this.eleQuoteGenericDropdownList,30,"Premium dropdown list is not shown");
                driver.findElement(By.xpath("//ul[@role='listbox']/li/span[text()='" + period + "']")).click();
        }
    }

    public String getPremiumAmount() throws InterruptedException {
        waitUtils.implicitWait(driver, 80000);
        Thread.sleep(1000);

        waitUtils.waitForElementToBeVisible(driver, this.elePremiumAmout);
        if(baseTest.getPlatform().equalsIgnoreCase("ios")) {

            String[] str = elePremiumAmout.getText().split(" ");
            //String numberOnly = elePremiumAmout.getText().replaceAll("[^0-9]", "");
            return str[1];

        }
        else {
            return this.elePremiumAmout.getText().trim();
        }
    }


    public String getPlanOptionsDefaultValue() {
        logMessage("##### default text seelction for plan option s:" + this.eleDefaultPlanOptionText.getText());
        return this.eleDefaultPlanOptionText.getText().trim();
    }

    public String getIncreasingLevelDefaultValue() {
        logMessage("##### default text seelction for level:" + this.eleDefaultIncreasingLevelText.getText());

        return this.eleDefaultIncreasingLevelText.getText().trim();
    }

    public String getPptDefaultValue() {
        logMessage("##### default text seelction for ppt:" + this.eleDefaultPptText.getText().trim());


        return this.eleDefaultPptText.getText();
    }

    public String getPremiumDefaultValue() {
        logMessage("##### default text seelction for ppt:" + this.eleDefaultPptText.getText().trim());

        return this.eleDefaultPptText.getText().trim();
    }

    public String getTermDefaultValue() {
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                break;
            case "ios":
                break;
            default:
                return this.elePolicyTermInput.getAttribute("value");
        }
        return "";
    }

    public String getSumAssuredDefaultValue() {
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                break;
            case "ios":
                break;
            default:
                return this.eleSumAssuredInput.getAttribute("value");
        }
        return "";
    }

    public Boolean isSmokerSelected() {
        if (BaseTest.PLATFORM_NAME.equalsIgnoreCase("android")) {
            return eleSmoker.isSelected();

        } else if (BaseTest.PLATFORM_NAME.equalsIgnoreCase("ios")) {
            return eleSmoker.isSelected();
        } else {
            Boolean selected = Boolean.valueOf(driver.findElement(By.xpath("//span[text()='Smoker']//..//..")).getAttribute("aria-pressed"));
            logMessage("SNoker selected ------------" + selected);
            return selected;
        }

    }

    public Boolean isAlertShown() {
        try {
            waitUtils.waitForElementToBeVisible(driver, eleAlertDialog);
            logMessage("======== > alert is shown");
            return this.eleAlertDialog.isDisplayed();
        } catch (NoSuchElementException e) {
            return false;
        }
    }

    public Boolean isVerifiedTick() {
        try {
            waitUtils.implicitWait(driver, 100);
            return this.eleVerifiedTick.isDisplayed();
        } catch (Exception e) {
            logMessage("Verified tick is not displayed ----------");
            return false;
        }
    }

    /*
        Riders
    * */

    @FindBy(xpath = "//input[@type='text']")
    private WebElement eleRiderInput;

    @FindBy(css = "#accordian-checkbox")
    private WebElement eleRidersCheckBox;

    @AndroidFindBy(xpath = "//android.view.View[@text='Add Riders']")
    @FindBy(xpath = "//div[@class='pathname' and text()='Add Riders']")
    public WebElement eleRidersNavText;

    @AndroidFindBy(xpath = "//android.view.View[contains(@text,'Bank Details')]")
    @FindBy(xpath = "//div[@class='pathname' and text()='4.0 Bank Details']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[contains(@name,'Bank Details')]")
    public WebElement eleBankNavText;

    @AndroidFindBy(xpath = "//android.view.View[@text='Plan Info']")
    @FindBy(xpath = "//div[@class='pathname' and text()='Plan Info']")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeOther[`name == \"Plan Info\"`][2]")
    public WebElement elePlanSummaryNavText;

    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text,'Renewal Premium')]")
    @FindBy(xpath = "//div[@class='title-header' and text()='Renewal Premium']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[contains(@name,'Renewal Premium')]")
    public WebElement eleRenewNavText;

    @AndroidFindBy(xpath = "//android.view.View[contains(@text,'Add Nominee')]")
    @FindBy(xpath = "//h2[text()='ADD NOMINEE']")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeOther' AND name CONTAINS[cd] 'ADD NOMINEE'")
    //@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[contains(@name='Add Nominee')]")
    public WebElement eleNomineeNavText;

    @AndroidFindBy(xpath = "//android.view.View[contains(@text,'Address')]")
    @FindBy(xpath = "//h2[text()='Address']")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeOther' AND name BEGINSWITH[c] 'Address'")
    public WebElement eleAddressNavText;

    @AndroidFindBy(xpath = "//android.view.View[contains(@text,'Personal')]")
    @FindBy(xpath = "//h2[contains(text(),'Personal')]")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeOther' AND name BEGINSWITH[c] 'Personal'")
    public WebElement elePersonalInfoNavText;




    /*
    Nirmala's code
    * */

    @FindBy(xpath = "//span[text()='OK']")
    private WebElement uploadPan_popup_Ok;

    @FindBy(xpath = "//p[@id='ifscCode-helper-text']")
    private WebElement invalidIFSCCodeErrorMessage;

    @FindBy(xpath = "//p[@id='accountNo-helper-text']")
    private WebElement invalidAccNumberErrorMessage;

    @FindBy(xpath = "//div[@class='MuiSelect-root MuiSelect-select MuiSelect-selectMenu MuiSelect-filled MuiInputBase-input MuiFilledInput-input']")
    private WebElement eleRelationDropdown;

    @FindBy(xpath = "//input[@id='percentageShare']")
    private WebElement eleShareInputValue;

    @FindBy(xpath = "//input[@id='ifscCode']")
    public WebElement eleInputIfscCode;

    @FindBy(xpath = "//input[@id='accountNo']")
    @AndroidFindBy(accessibility = "accountNo")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name=\"accountNo\"]")
    public WebElement eleInputAccNumber;

    @FindBy(xpath = "//input[@id='accountHolderName']")
    @AndroidFindBy(accessibility = "accountHolderName")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name=\"accountHolderName\"]")
    public WebElement eleInputAccHolderName;

    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"verifyButton\"`]")
    @FindBy(xpath = "//*[contains(text(),'\" + buttonName + \"')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='\"+buttonName+\"']")
    //@iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeOther[`label == \"verifyButton\"`][2]")
    public WebElement eleRiderAddBtn;

    public void selectRider(String riderName) {
        riderName = riderName.trim();
        commonUtils.scrollIntoView(riderName, driver);
        waitUtils.implicitWait(driver, 20000);

        switch (BaseTest.PLATFORM_NAME) {
            case "android":
                switch (riderName.toLowerCase()) {
                    case "accidental death and disability":
                        ((AndroidDriver)driver).findElementByAccessibilityId("accidentDeathAndDisabilitySumAssuredQstCheckbox").click();
                        break;
                    case "critical illness":
                        ((AndroidDriver)driver).findElementByAccessibilityId("criticalIllnessSumAssuredQstCheckbox").click();
                        break;
                    case "surgical care":
                        ((AndroidDriver)driver).findElementByAccessibilityId("surgicalCareSumAssuredQstCheckbox").click();
                        break;
                    case "hospital care":
                        ((AndroidDriver)driver).findElementByAccessibilityId("hospitalCareSumAssuredQstCheckbox").click();
                        break;
                    case "adb plus":
                        ((AndroidDriver)driver).findElementByAccessibilityId("adbPlusSumAssuredQstCheckbox").click();
                        break;
                }
                /*waitUtils.waitForElementToBeVisible(driver,driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'" + riderName + "')]")));
                driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'" + riderName + "')]")).click();*/
                break;
            case "ios":
                switch (riderName.toLowerCase()) {
                    case "accidental death and disability":
                        ((IOSDriver)driver).findElementByIosClassChain("**/XCUIElementTypeOther[`label == \"ACCIDENTAL DEATH AND DISABILITY accidentDeathAndDisabilitySumAssuredQstCheckbox\"`][3]").click();
                        break;
                    case "critical illness":
                        ((IOSDriver)driver).findElementByIosClassChain("**/XCUIElementTypeOther[`label == \"CRITICAL ILLNESS criticalIllnessSumAssuredQstCheckbox\"`]").click();
                        break;
                    case "surgical care":
                        ((IOSDriver)driver).findElementByIosClassChain("**/XCUIElementTypeOther[`label == \"SURGICAL CARE surgicalCareSumAssuredQstCheckbox\"`][3]").click();
                        break;
                    case "hospital care":
                        ((IOSDriver)driver).findElementByIosClassChain("**/XCUIElementTypeOther[`label == \"HOSPITAL CARE hospitalCareSumAssuredQstCheckbox\"`][3]").click();
                        break;
                    case "adb plus":
                        ((IOSDriver)driver).findElementByIosClassChain("**/XCUIElementTypeOther[`label == \"ADB PLUS adbPlusSumAssuredQstCheckbox\"`][3]").click();
                        break;
                }
                break;
            default:
                /*waitUtils.waitForElementToBeClickable(driver, driver.findElement(By.xpath("//div[@id='" + riderName + "']//div//label[@for='accordian-checkbox']")));
                this.driver.findElement(By.xpath("//div[@id='" + riderName + "']//div//label[@for='accordian-checkbox']")).click();*/

                waitUtils.waitForElementToBeVisible(driver,driver.findElement(By.xpath("//div[@for='accordian-checkbox' and contains(text(),'" + riderName + "')]")));
                driver.findElement(By.xpath("//div[@for='accordian-checkbox' and contains(text(),'" + riderName + "')]")).click();
        }
    }

    public void unSelectRider(String riderName) {
        switch (BaseTest.PLATFORM_NAME) {
            case "android":
                switch (riderName.toLowerCase()) {
                    case "accidentail death and disability":
                        ((AndroidDriver)driver).findElementByAccessibilityId("accidentDeathAndDisabilitySumAssuredQstCheckbox").click();
                }
                break;
            case "ios":
                break;
            default:
                clearRider(riderName);
                WebElement element = driver.findElement(By.xpath("//div[@id='" + riderName + "']//div//label[@for='accordian-checkbox']"));
                element.click();
        }
    }

    public void inputRiderAmount(String amount, String riderName) {
        WebElement element = null;
        switch (BaseTest.PLATFORM_NAME) {
            case "android":
                switch (riderName.toLowerCase()) {
                    case "accidental death and disability":
                        element = ((AndroidDriver)driver).findElementByAccessibilityId("accidentDeathAndDisabilitySumAssuredQst");
                        break;
                        case "critical illness":
                        element = ((AndroidDriver)driver).findElementByAccessibilityId("criticalIllnessSumAssuredQst");
                        break;
                    case "surgical care":
                        element = ((AndroidDriver)driver).findElementByAccessibilityId("surgicalCareSumAssuredQst");
                        break;
                    case "hospital care":
                        element = ((AndroidDriver)driver).findElementByAccessibilityId("hospitalCareSumAssuredQst");
                        break;
                    case "adb plus":
                        element = ((AndroidDriver)driver).findElementByAccessibilityId("adbPlusSumAssuredQst");
                        break;
                }
                element.click();
                element.clear();
                element.sendKeys(amount);
                ((AndroidDriver)driver).hideKeyboard();
                break;
            case "ios":
                switch (riderName.toLowerCase()) {
                    case "accidental death and disability":
                        element = ((IOSDriver)driver).findElementByIosClassChain("**/XCUIElementTypeTextField[`label == \"accidentDeathAndDisabilitySumAssuredQst\"`]");
                        break;
                        case "critical illness":
                        element = ((IOSDriver)driver).findElementByIosClassChain("**/XCUIElementTypeTextField[`label == \"criticalIllnessSumAssuredQst\"`]");
                        break;
                    case "surgical care":
                        element = ((IOSDriver)driver).findElementByIosClassChain("**/XCUIElementTypeTextField[`label == \"surgicalCareSumAssuredQst\"`]");
                        break;
                    case "hospital care":
                        element = ((IOSDriver)driver).findElementByIosClassChain("**/XCUIElementTypeTextField[`label == \"hospitalCareSumAssuredQst\"`]");
                        break;
                    case "adb plus":
                        element = ((IOSDriver)driver).findElementByIosClassChain("**/XCUIElementTypeTextField[`label == \"adbPlusSumAssuredQst\"`]");
                        break;
                }
                element.click();
                element.clear();
                element.sendKeys(amount);
                //((IOSDriver)driver).hideKeyboard();
                ((IOSDriver) driver).getKeyboard().pressKey(Keys.RETURN);
                //element.sendKeys(Keys.SHIFT);

                break;
            default:
                //commonUtils.scrollIntoView(riderName,driver);
                waitUtils.waitForElementToBeVisible(driver, driver.findElement(By.xpath("//input[@value='" + riderName + "']//..//descendant::div[3]/input")), 40, "Input field is not dsiplayed");
                element = driver.findElement(By.xpath("//input[@value='" + riderName + "']//..//descendant::div[3]/input"));
                element.click();
                element.clear();
                element.sendKeys(amount);
        }
    }

    public void clearRider(String riderName) {
        switch (BaseTest.PLATFORM_NAME) {
            case "android":
                switch (riderName.toLowerCase()) {
                    case "accidental death and disability":
                        ((AndroidDriver)driver).findElementByAccessibilityId("accidentDeathAndDisabilitySumAssuredQstCheckbox").click();
                        break;
                    case "critical illness":
                        ((AndroidDriver)driver).findElementByAccessibilityId("criticalIllnessSumAssuredQstCheckbox").click();
                        break;
                    case "surgical care":
                        ((AndroidDriver)driver).findElementByAccessibilityId("surgicalCareSumAssuredQstCheckbox").click();
                        break;
                    case "hospital care":
                        ((AndroidDriver)driver).findElementByAccessibilityId("hospitalCareSumAssuredQstCheckbox").click();
                        break;
                    case "adb plus":
                        ((AndroidDriver)driver).findElementByAccessibilityId("adbPlusSumAssuredQstCheckbox").click();
                        break;
                }
                break;
            case "ios":
                break;
            default:
//                waitUtils.waitForElementToBeVisible(driver,driver.findElement(By.xpath("//input[@value='"+riderName + "']//..//descendant::div[3]/input")),30,"Input field is not dsiplayed");
//                WebElement element = driver.findElement(By.xpath("//input[@value='"+riderName + "']//..//descendant::div[3]/input"));
//                element.click();
//                element.clear();
                waitUtils.waitForElementToBeVisible(driver, driver.findElement(By.xpath("//input[@value='" + riderName + "']//..//descendant::div[3]/input")), 30, "Input field is not dsiplayed");
                WebElement element = driver.findElement(By.xpath("//input[@value='" + riderName + "']//..//descendant::div[3]/input"));
                element.click();
                element.clear();
        }
    }

    public Boolean isRiderEnabled(String riderName) {
        waitUtils.implicitWait(driver, 100);
        try {
            switch (BaseTest.PLATFORM_NAME) {
                case "android":
                    switch (riderName.toLowerCase()) {
                        case "accidental death and disability":
                            ((AndroidDriver)driver).findElementByAccessibilityId("accidentDeathAndDisabilitySumAssuredQstCheckbox").click();
                            return true;
                            case "critical illness":
                            ((AndroidDriver)driver).findElementByAccessibilityId("criticalIllnessSumAssuredQstCheckbox").click();
                                return true;
                        case "surgical care":
                            ((AndroidDriver)driver).findElementByAccessibilityId("surgicalCareSumAssuredQstCheckbox").click();
                            return true;
                        case "hospital care":
                            ((AndroidDriver)driver).findElementByAccessibilityId("hospitalCareSumAssuredQstCheckbox").click();
                            return true;
                        case "adb plus":
                            ((AndroidDriver)driver).findElementByAccessibilityId("adbPlusSumAssuredQstCheckbox").click();
                            return true;
                    }
                    break;
                case "ios":
                    break;
                default:
                    driver.findElement(By.xpath("//div[@id='" + riderName + "']//div//label[@for='accordian-checkbox']")).click();
                    return true;
            }
        } catch (Exception e) {
            logMessage("Rider is disabled:" + riderName);
            return false;
        }
        return false;
    }


    public void chooseRiderButton() {
        waitUtils.waitUntilVisible(driver, eleRidersBtn,30);
        this.eleRidersBtn.click();
    }

    public void selectRiders(String names, String amount) throws InterruptedException {
        waitUtils.waitForElementToBeClickable(driver, eleRidersBtn);
        this.eleRidersBtn.click();

        this.driver.findElement(By.xpath("//div[@id='" + names + "']//div//label[@for='accordian-checkbox']")).click();
        this.driver.findElement(By.xpath("//input[@type='text']")).sendKeys(amount);
        this.driver.findElement(By.xpath("//button[@type='submit']")).click();
    }

    public boolean alertMessage(String message) {
        WebElement element = driver.findElement(By.xpath("//p[text()='" + message + "']"));
        return element.isDisplayed();
    }

    public void downloadIllustration() {
        this.eleIllustrationBtn.click();
    }


    public String VerifyPlanSelectionNavText() {
        return elePlanSelectionNavText.getText();
    }

    /*public void inputIfscCode(String code) {
        this.eleInputIfscCode.sendKeys(Keys.chord(Keys.CONTROL,"a",Keys.DELETE));
        this.eleInputIfscCode.sendKeys(code);
        *//*if(code.length()==11) {
            String Firstfour;
            String Middle;
        }*//*
    }*/


    public boolean verifyInvalidIFSCCodeErrorMessage() {
        if (this.invalidIFSCCodeErrorMessage.isDisplayed())
            return true;
        else
            return false;
    }

    public boolean verifyInvalidAccNumberErrorMessage() {
        if (this.invalidAccNumberErrorMessage.isDisplayed())
            return true;
        else
            return false;
    }

    public void goToBankDetailsScreen(ProposerModel proposerModel) throws IOException, InterruptedException {

        /*inputIfscCode(proposerModel.getIfscCode());
        inputAccNumber(proposerModel.getAccNumber());
        selectButtonByText("VERIFY");
        if(alertMessage(proposerModel.getAlert()))
        {
            selectButtonByText("OK");
        }
        selectButtonByText("NEXT");
*/
    }

    public void selectDivButtonByText(String name) {
        //driver.findElement(By.xpath("//button[@value='"+name+"']")).click();
        driver.findElement(By.xpath("//div[normalize-space()='" + name + "']")).click();

    }

    public void goToDirectBillSelectScreen() throws IOException {
        proposerModel = jsonObj.readProposerJson().getDataByTestCase("directbilldetails");
        /*selectDivButtonByText(proposerModel.getPaymentMethod());
        if(proposerModel.getTestCase().contains("nach")) {
            selectDivButtonByText(proposerModel.getpreferreddrawdate());
        }
        selectDivButtonByText(proposerModel.getSourceOfFunds());*/
        selectButtonByText("SAVE");
        selectButtonByText("NEXT");
    }

    public void inputNomineeText(String name, String value) {
        WebElement element;
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                driver.findElement(By.xpath("//android.widget.TextView[@text='" + name + "']")).click();
                break;
            case "ios":
                break;
            default:
                element = driver.findElement(By.xpath("//input[@id='" + name + "']"));
                element.sendKeys(value);
        }


    }

    public void chooseRelationFromDropDown(String relationName) {
        waitUtils.waitForElementToBeClickable(driver, eleRelationDropdown);
        this.eleRelationDropdown.click();
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                driver.findElement(By.xpath("//android.widget.TextView[@text='" + relationName + "']")).click();
                break;
            case "ios":
                break;
            default:
                driver.findElement(By.xpath("//span[normalize-space()='" + relationName + "']")).click();
        }
    }

    public void inputShareValue(String value) {
        this.eleShareInputValue.sendKeys(value);
    }

    public String getRiderMinAmount(String minAmount) {

        int amount = Integer.valueOf(minAmount);
        amount = amount - 1;

        return String.valueOf(amount);
    }

    public String getRiderMaxAmount(String maxAmount) {
        int amount = Integer.valueOf(maxAmount);
        amount = amount + 1;

        return String.valueOf(amount);
    }

    public void chooseNavBack(String navText) {
        switch (BaseTest.PLATFORM_NAME) {
            case "android":
                break;
            case "ios":
                break;
            default:
                waitUtils.waitForElementToBeVisible(driver, driver.findElement(By.xpath("//div[@class='pathname' and text()='" + navText + "']//..//img[@class='hamburger-icon']")), 30,
                        "Navigation back is not displayed");
                driver.findElement(By.xpath("//div[@class='pathname' and text()='" + navText + "']//..//img[@class='hamburger-icon']")).click();
        }
    }

    public Boolean verifyRiderErrorMessage(String riderName) {
        String element;
        switch (BaseTest.PLATFORM_NAME) {
            case "android":
                element = "//android.widget.TextView[@content-desc=\"inputHelperText\"]";
                waitUtils.waitUntilVisible(driver,driver.findElement(By.xpath(element)),30);
                return driver.findElement(By.xpath("//android.widget.TextView[@content-desc=\"inputHelperText\"]")).isDisplayed();
            case "ios":
                waitUtils.waitUntilVisible(driver,((IOSDriver)driver).findElementByAccessibilityId("inputHelperText"),30);
                return ((IOSDriver)driver).findElementByAccessibilityId("inputHelperText").isDisplayed();
            default:
                //return driver.findElement(By.xpath("//input[@value='" + riderName + "']//..//descendant::p[contains(@class,'MuiFormHelperText-root')]")).isDisplayed();
                waitUtils.waitUntilVisible(driver,driver.findElement(By.xpath("//p[contains(@class,'MuiFormHelperText-root')]")),30);
                return driver.findElement(By.xpath("//p[contains(@class,'MuiFormHelperText-root')]")).isDisplayed();
        }
    }

    public void clearAllRiders() {
        switch (BaseTest.PLATFORM_NAME) {
            case "android":
                break;
            case "ios":
                break;
            default:
                List<WebElement> list = driver.findElements(By.cssSelector("#accordian-checkbox"));
                int count = 1;
                for (WebElement ele : list) {
                    ele.click();
                    driver.findElement(By.xpath("(//input[@type='text' and @placeholder='Enter Amount'])[position=" + count + "]")).sendKeys("test");
                    commonUtils.clearTextFieldValue(driver.findElement(By.xpath("(//input[@type='text' and @placeholder='Enter Amount'])[position=" + count + "]")), driver);
                    count++;
                }

        }

    }

    /*
     * bank details
     * */

    @FindBy(css = "#ifscCode")
    @AndroidFindBy(accessibility = "ifscCode")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name=\"ifscCode\"]")
    private WebElement eleIfscCodeInput;

    @FindBy(xpath = "//img[@alt='endicon']")
    @AndroidFindBy(accessibility = "ifscCoderightIcon")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"ifscCoderightIcon\"]")
    public WebElement eleIfscVerifyTick;

    //@FindBy(xpath = "//p[@id='ifscCode-helper-text' and contains(text(),'Please enter IFSC Code')]")
    @FindBy(xpath = "//p[@id='ifscCode-helper-text']")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name=\"inputHelperText\"])[1]")
    public WebElement eleIfscErrorMessage;

    //@FindBy(xpath = "//p[@id='accountNo-helper-text' and contains(text(),'Please Enter Account No')]")
    @FindBy(css = "#accountNo-helper-text")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name=\"inputHelperText\"])[2]")
    @AndroidFindBy(accessibility = "inputHelperText")
    public WebElement eleAccNoErrorMessage;

    @FindBy(css = "#bankName")
    @AndroidFindBy(accessibility = "bankName")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name=\"bankName\"]")
    public WebElement elebankName;

    @FindBy(css = "#branchName")
    @AndroidFindBy(accessibility = "branchName")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name=\"branchName\"]")
    public WebElement elebranchName;

    @FindAll({@FindBy(css = ".title-header"),
    @FindBy(css = ".page-header-name")})
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Address']")
    private WebElement eleScreenTitle;

    @FindBy(css = "#accountHolderName")
    private WebElement eleAccHolderNameInput;

    @FindBy(xpath = "(//div[@class='data-label-value'])[position()=1]//div[position()=2]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='INITIAL PREMIUM']/following-sibling::android.widget.TextView[1]")
    @iOSXCUITFindBy(accessibility = "INITIAL PREMIUM")
    private WebElement elePremiumAmountFromRenewalScreen;

    @FindBy(xpath = "(//div[@class='data-label-value'])[position()=2]//div[position()=2]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='PAYMENT FREQUENCY']/following-sibling::android.widget.TextView[1]")
    @iOSXCUITFindBy(accessibility = "PAYMENT FREQUENCY")
    private WebElement elePaymentFreqFromRenewalScreen;

    @FindBy(xpath = "(//div[@class='data-label-value'])[position()=3]//div[position()=2")
    private WebElement elePeriodFromRenewalScreen;

    @AndroidFindBy(accessibility = "nextButton")
    @FindBy(xpath = "//span[text()='NEXT']")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`name == \"nextButton\"`]")
    public WebElement eleBankNextBtn;

    //@AndroidFindBy(xpath = "(//android.widget.Button[@content-desc=\"verifyButton\"])[3]")
    //@AndroidFindBy(xpath = "//android.widget.Button[@content-desc=\"verifyButton\"]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='VERIFY']")
    @FindBy(xpath = "//span[text()='VERIFY']")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeOther[`name == \"verifyButton\"`]")
    public WebElement eleVerifyBtn;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"nextBtn\"]")
    @FindBy(xpath = "//*[text()='CONTINUE']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='CONTINUE']")
    public WebElement eleQuoteContinueBtn;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"nextBtn\"]")
    @FindBy(xpath = "//*[text()='CONTINUE']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='CONTINUE'")
    public WebElement elePlanContinueBtn;

    public void inputAccHolderName(String accHolderName) {
        this.eleInputAccNumber.clear();
        this.eleInputAccNumber.sendKeys(accHolderName);

    }

    @AndroidFindBy(accessibility = "ifscCoderightIcon")
    private WebElement eleIfscCodeArrow;

    public void inputIfscCode(String ifscCode) {
        this.eleIfscCodeInput.clear();
        this.eleIfscCodeInput.click();
        this.eleIfscCodeInput.sendKeys(ifscCode);
        waitUtils.implicitWait(driver, 30000);
        switch (BaseTest.PLATFORM_NAME) {
            case "android":
                //driver.findElement(By.xpath("//android.widget.Button[@content-desc='rightIcon']")).click();
                //((AndroidDriver) driver).getKeyboard().pressKey("\n");
                ((AndroidDriver) driver).hideKeyboard();
                eleIfscCodeArrow.click();
                eleIfscCodeArrow.click();
                break;
            case "ios":
                ((IOSDriver) driver).getKeyboard().pressKey("\n");
                break;
            default:
        }
    }

    public void inputAccNo(String accNo) {
        this.eleInputAccNumber.clear();
        this.eleInputAccNumber.click();
        this.eleInputAccNumber.sendKeys(accNo);
        switch (BaseTest.PLATFORM_NAME) {
            case "android":
                //((AndroidDriver) driver).getKeyboard().pressKey("\n");
                //((AndroidDriver) driver).hideKeyboard();
                //eleInputAccNumber.sendKeys(Keys.ENTER);   /// this code was working in pcloudy
                //((AndroidDriver) driver).getKeyboard().pressKey(Keys.RETURN);
                ((AndroidDriver) driver).pressKey(new KeyEvent(AndroidKey.NUMPAD_ENTER));
                ((AndroidDriver) driver).hideKeyboard();
                //chooseActionButton(eleVerifyBtn);
                //chooseActionButton(eleVerifyBtn);

                break;
            case "ios":
                //((IOSDriver)driver).hideKeyboard("Return");
                //((IOSDriver) driver).getKeyboard().pressKey("\n");
                //((IOSDriver)driver).hideKeyboard();
                eleInputAccNumber.sendKeys(Keys.ENTER);   /// this code was working in pcloudy
                break;
            default:
        }
    }

    public Boolean verifyIfscErrorMessage() {
        waitUtils.implicitWait(driver, 100);
        try {
            this.eleIfscErrorMessage.isDisplayed();
        } catch (NoSuchElementException e) {
            logMessage("Element not found:" + eleIfscErrorMessage);
        }
        return false;
    }

    public void chooseAccountType(String accType) {
        switch (BaseTest.PLATFORM_NAME) {
            case "android":
                driver.findElement(By.xpath("//android.widget.TextView[@text='" + accType + "']")).click();
                break;
            case "ios":
                //driver.findElement(By.xpath("//XCUIElementTypeOther[contains(@name,'" + accType + "')]")).click();
                ((IOSDriver)driver).findElementByIosNsPredicate("type == 'XCUIElementTypeOther' AND name CONTAINS[cd] '"+ accType +"' ").click();
                break;
            default:
                driver.findElement(By.xpath("//span[text()='" + accType + "']")).click();
        }
    }

    public String getScreenTitle() {
        logMessage("Scrren title======:" + eleScreenTitle.getText());
        return this.eleScreenTitle.getText();
    }

    public String validateScreenTitle(WebElement element) {
        String actualScreenTitle = null;
        switch (BaseTest.PLATFORM_NAME) {
            case "android":
                //String actualScreenTitle = driver.findElement(By.xpath("//android.widget.TextView[@text='"+screenTitle+"']")).getText();
                return actualScreenTitle = element.getText();
            case "ios":
                return actualScreenTitle = element.getText();
            default:
                logMessage("Screen title======:" + eleScreenTitle.getText());
                return this.eleScreenTitle.getText();

        }
    }

    public String validateScreenTitle(String screenTitle) {
        switch (BaseTest.PLATFORM_NAME) {
            case "android":
                String actualScreenTitle = driver.findElement(By.xpath("//android.widget.TextView[@text='"+screenTitle+"']")).getText();
                return actualScreenTitle;
            case "ios":
                String actualIOSScreenTitle = driver.findElement(By.xpath("//XCUIElementTypeStaticText[@name='"+screenTitle+"']")).getText();
                //return actualIOSScreenTitle;
                break;
            default:
                logMessage("Screen title======:"+eleScreenTitle.getText());
                return this.eleScreenTitle.getText();

        }
        return null;
    }

    /*
        E-Mandate / E-NACH
        Direct Bill
        SI - Credit Card
        NACH / Direct Debit
    * */

    @FindBy(xpath = "//button[contains(@class,'save-btn')]")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`name == \"saveBtn\"`]")
    @AndroidFindBy(accessibility = "saveBtn")
    public WebElement eleRenewSaveBtn;

    @FindBy(xpath = "//*[text='DO IT LATER']")
    @AndroidFindBy(xpath = "//android.widget.Button[@content-desc=\"laterBtn\"]")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"laterBtn\"`]")
    private WebElement eleRenewLaterBtn;

    @FindBy(xpath = "//button[contains(@class,'save-btn')]")
    @AndroidFindBy(accessibility = "renewalNextBtn")
    /*@AndroidFindBy(uiAutomator = "new UiSelector().className(\"android.widget.Button\").descriptionContains(\"nextBtn\").index(0)")
    @AndroidFindAll({
            @AndroidBy(xpath = "//android.widget.TextView[@text=\"NEXT\"]",priority = 1),
            @AndroidBy(xpath = "(//android.widget.Button[@content-desc=\"nextBtn\"])[3]"),
            @AndroidBy(xpath = "//android.widget.Button[@content-desc=\"nextBtn\"]")
    })*/
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"renewalNextBtn\"`]")
    public WebElement eleRenewNextBtn;

    @FindBy(xpath = "//button[@type='submit']/span[text()='OK']")
    @iOSXCUITFindBy(accessibility = "OK")
    @AndroidFindBy(id = "android:id/button1")
    public WebElement eleBankAlertOkBtn;

    @FindBy(css = "#customized-dialog-title")
    @iOSXCUITFindBy(accessibility = "Super! The Bank account is verified. No cheque copy is required!")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text=\"Alert\"]")
    private WebElement eleBankAlert;


    public void choosePaymentMethod(String paymentMethod) {
        paymentMethod = paymentMethod.trim();
        switch (BaseTest.PLATFORM_NAME) {
            case "android":
                driver.findElement(By.xpath("//android.widget.TextView[starts-with(@text,'" + paymentMethod + "')]/..")).click();
                break;
            case "ios":
                String selector = "**/XCUIElementTypeOther[`name BEGINSWITH \"paymentMethodList\"`]/**/XCUIElementTypeOther[`name BEGINSWITH[cd] \"" + paymentMethod + "\" `]";;
                WebElement element = driver.findElement(MobileBy.iOSClassChain(selector));

                String sel = "type == 'XCUIElementTypeOther' AND name BEGINSWITH '" + paymentMethod + "'";
                element.findElement(MobileBy.iOSNsPredicateString(sel)).click();
                //element.findElement(By.xpath("//XCUIElementTypeOther[@name='"+paymentMethod+"']")).click();
                break;
            default:
                WebElement ele = driver.findElement(By.cssSelector(".toggle-btn-container"));
                waitUtils.waitUntilVisible(driver,ele,30);
                //ele.findElement(By.xpath("//div[contains(text(),'" + paymentMethod + "')]")).click();
                ele.findElement(By.xpath("//button[starts-with(@value,'" + paymentMethod + "')]")).click();
        }
    }

    public void chooseDrawDate(String drawDate) {
        switch (BaseTest.PLATFORM_NAME) {
            case "android":
                driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'" + drawDate + "')]/..")).click();
                break;
            case "ios":
                if (drawDate.contains("Premium")) {
                    driver.findElement(By.xpath("//XCUIElementTypeOther[@name='" + drawDate + "']")).click();
                } else {
                    driver.findElement(By.xpath("(//XCUIElementTypeOther[@name='" + drawDate + "'])[2]")).click();
                }
                break;
            default:
                driver.findElement(By.xpath("//button[@value='" + drawDate + "']")).click();
        }
    }

    public void chooseSourceOfFund(String source) {
        switch (BaseTest.PLATFORM_NAME) {
            case "android":
                driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'" + source + "')]/..")).click();
                break;
            case "ios":
                ((IOSDriver) driver).findElementByAccessibilityId(source).click();
                break;
            default:
                WebElement ele = driver.findElement(By.cssSelector(".source-toggle"));
                waitUtils.waitUntilVisible(driver,ele,30);
                ele.findElement(By.xpath("//button[contains(@value,'" + source + "')]")).click();

                //ele.findElement(By.xpath("//div[text()='" + source + "']")).click();
        }
    }

    public String getPremiumValueFromRenewalScreen() {
        return this.elePremiumAmountFromRenewalScreen.getText();
    }

    public String getPaymentFreqFromRenewalScreen() {
        return this.elePaymentFreqFromRenewalScreen.getText();
    }



    /*
     * Add nominee
     * */


    @FindBy(css = "input#firstName")
    /*@AndroidFindAll({
            @AndroidBy(xpath = "(//android.widget.EditText[@content-desc=\"firstName\"])[2]",priority = 1),
            @AndroidBy(xpath = "//android.widget.EditText[@content-desc=\"firstName\"]"),
    })*/
    @AndroidFindBy(accessibility = "nomineeFirstName")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeTextField' AND name BEGINSWITH[c] 'nomineeFirstName'")
    public WebElement eleNomineeFirstNameInput;

    @FindBy(css = "input#lastName")
    /*@AndroidFindAll({
            @AndroidBy(xpath = "(//android.widget.EditText[@content-desc=\"lastName\"])[2]",priority = 1),
            @AndroidBy(xpath = "//android.widget.EditText[@content-desc=\"lastName\"]"),
    })*/
    @AndroidFindBy(accessibility = "nomineeLastName")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeTextField' AND name BEGINSWITH[c] 'nomineeLastName'")
    public WebElement eleNomineeLastNameInput;

    @FindBy(css = "input#dd")
    //@AndroidFindBy(xpath = "(//android.widget.EditText[@content-desc=\"day\"])[2]")
    @AndroidFindBy(accessibility = "nomineeday")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeTextField' AND name BEGINSWITH[c] 'nomineeday'")
    public WebElement eleNomineeDayInput;

    @FindBy(css = "input#mm")
    //@AndroidFindBy(xpath = "(//android.widget.EditText[@content-desc=\"month\"])[2]")
    @AndroidFindBy(accessibility = "nomineemonth")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeTextField' AND name BEGINSWITH[c] 'nomineemonth'")
    private WebElement eleNomineeMonthInput;

    @FindBy(css = "input#yy")
    //@AndroidFindBy(xpath = "(//android.widget.EditText[@content-desc=\"year\"])[2]")
    @AndroidFindBy(accessibility = "nomineeyear")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeTextField' AND name BEGINSWITH[c] 'nomineeyear'")
    public WebElement eleNomineeYearInput;

    @FindBy(css = "#parent")
    @AndroidFindBy(accessibility = "relationshipWithProposer")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeOther' AND name BEGINSWITH[c] 'relationshipWithProposer'")
    public WebElement eleNomineeRelationshipDowndown;

    @FindBy(css = "#percentageShare")
    @AndroidFindBy(accessibility = "percentageShare")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeTextField' AND name BEGINSWITH[c] 'percentageShare'")
    private WebElement eleNomineeShareInput;

    @FindBy(xpath = "//span[text()='EDIT']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='EDIT']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"editButton\"]")
    public WebElement eleEditBtn;

    @FindBy(css = "#firstName-helper-text")
    @AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"inputHelperText\" and contains(@text,'Please enter first name')]")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name=\"inputHelperText\"])[1]")
    public WebElement eleNomineeFirstNameError;

    @FindBy(css = "#lastName-helper-text")
    @AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"inputHelperText\" and contains(@text,'Please enter last name')]")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name=\"inputHelperText\"])[2]")
    public WebElement eleNomineeLastNameError;

    @FindBy(css = "#dd-helper-text")
    @AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"inputHelperText\" and contains(@text,'Enter Day')]")
    @iOSXCUITFindBy(accessibility = "DD DD day inputHelperText")
    public WebElement eleNomineeDOBDayError;

    @FindBy(css = "#mm-helper-text")
    @AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"inputHelperText\" and contains(@text,'Enter month')]")
    @iOSXCUITFindBy(accessibility = "MM MM month inputHelperText")
    public WebElement eleNomineeDOBMonthError;

    @FindBy(css = "#yy-helper-text")
    @AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"inputHelperText\" and contains(@text,'Enter year')]")
    @iOSXCUITFindBy(accessibility = "YYYY YYYY year inputHelperText")
    public WebElement eleNomineeDOBYearError;

    @FindBy(css = "#dd-helper-text")
    @AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"inputHelperText\" and contains(@text,'Min')]")
    @iOSXCUITFindBy(accessibility = "DD DD day inputHelperText")
    public WebElement eleNomineeMinDOBDayError;

    @FindBy(css = "#mm-helper-text")
    @AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"inputHelperText\" and contains(@text,'Min')]")
    @iOSXCUITFindBy(accessibility = "MM MM month inputHelperText")
    public WebElement eleNomineeMinDOBMonthError;

    @FindBy(css = "#yy-helper-text")
    @AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"inputHelperText\" and contains(@text,'Min')]")
    @iOSXCUITFindBy(accessibility = "YYYY YYYY year inputHelperText")
    public WebElement eleNomineeMinDOBYearError;

    @FindBy(css = "#yy-helper-text")
    @AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"inputHelperText\" and contains(@text,'Max')]")
    @iOSXCUITFindBy(accessibility = "YYYY YYYY year inputHelperText")
    public WebElement eleNomineeMaxDOBYearError;

    @FindBy(css = "#percentageShare-helper-text")
    //@AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"inputHelperText\" and contains(@text,'Please Enter Nominee Share')]")
    @AndroidFindBy(xpath = "//android.widget.EditText[@content-desc=\"percentageShare\"]//..//..//android.widget.TextView[@content-desc=\"inputHelperText\"]")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name=\"inputHelperText\"])[8]")
    public WebElement eleNomineeShareError;

    @FindBy(xpath = "//label[text()='Relationship with Proposer']//..//p[contains(@class,'MuiFormHelperText')]")
    @AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"relationshipWithProposer\"]//..//..//android.widget.TextView[@content-desc=\"inputHelperText\"]")
    @iOSXCUITFindBy(accessibility = "relationshipWithProposer inputHelperText")
    public WebElement eleNomineeRelationshipError;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name=\"inputHelperText\"])[6]")
    private WebElement eleNomineeGenderError;

    @FindBy(xpath = "(//span[@class='error-messsage'])[1]")
    public WebElement eleDOBNomineeAgeError;

    @FindBy(id ="addTypeID")
    @AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"addTypeID\"]")
    //@iOSXCUITFindBy(className = "addTypeID")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeOther[`name == \"addTypeID\"`]")
    public WebElement eleCommunicationAddressDowndown;

    @FindBy(id="pinCodeId")
    @AndroidFindBy(accessibility = "pinCodeId")
    //@iOSXCUITFindBy(className = "pinCodeId")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeTextField[`name == \"pinCodeId\"`]")
    public WebElement eleAddressPinCodeInput;

    @FindBy(id="add1Id")
    //@iOSXCUITFindBy(className = "add1Id")
    @AndroidFindBy(accessibility = "add1Id")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeTextField[`name == \"add1Id\"`]")
    public WebElement  eleAddress1Input;

    @FindBy(id="add2Id")
    @AndroidFindBy(accessibility = "add2Id")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeTextField[`label == \"add2Id\"`]")
    //@iOSXCUITFindBy(className = "add2Id")
    public WebElement  eleAddress2Input;

    @FindBy(id="add3Id")
    @AndroidFindBy(accessibility = "add3Id")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeTextField[`label == \"add3Id\"`]")
    //@iOSXCUITFindBy(className = "add3Id")
    public WebElement  eleAddress3Input;

    @FindBy(xpath="//div[contains(text(),'CITY')]/following-sibling::div")
    @AndroidFindBy(accessibility = "state")
    @iOSXCUITFindBy(className = "state")
    public WebElement eleCityNameFromAddAddress;

    //**/XCUIElementTypeTextField[`label == "city"`]
    //**/XCUIElementTypeOther[`label == "state"`]
    //**/XCUIElementTypeTextField[`label == "country"`]

    @FindBy(id="languageId")
    @AndroidFindBy(accessibility = "languageId")
    @iOSXCUITFindBy(className = "languageId")
    public WebElement eleCommunicationPreferredLanguage;

    @FindBy(id = "mobNumId")
    @AndroidFindBy(accessibility = "mobNumId")
    @iOSXCUITFindBy(className = "mobNumId")
    public WebElement eleAlernateNumber;

    @FindBy(id = "resTelNO")
    @AndroidFindBy(accessibility = "resTelNO")
    @iOSXCUITFindBy(className = "resTelNO")
    public WebElement eleResidenceTelNo;

    //@AndroidFindBy(accessibility = "saveBtn")
    @AndroidFindBy(xpath = "//android.widget.Button[@content-desc='saveBtn']")
    @FindBy(xpath = "//*[contains(text(),'NEXT')]")
    @iOSXCUITFindBy(className = "saveBtn")
    public WebElement eleAddressNextButton;

    @FindBy(name = "emailId")
    @AndroidFindBy(accessibility = "emailId")
    @iOSXCUITFindBy(className = "emailId")
    public WebElement elePersonalEmailIdInput;

    @FindBy(name = "fatherSpouseName")
    @AndroidFindBy(accessibility = "fatherSpouseName")
    @iOSXCUITFindBy(className = "fatherSpouseName")
    public WebElement eleFatherSpouseNameInput;

    @FindBy(name = "motherName")
    @AndroidFindBy(accessibility = "motherName")
    @iOSXCUITFindBy(className = "motherName")
    public WebElement eleMotherNameInput;

    @FindBy(name = "maidenName")
    public WebElement eleMaidenNameInput;

    @FindBy(xpath = "//div[@id='mui-component-select-23']")
    @AndroidFindBy(accessibility = "'23'")
    //@AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"'23'\"]/android.view.ViewGroup[1]/android.widget.Button")
    @iOSXCUITFindBy(className = "'23'")
    public WebElement eleQualificationDrpBtn;

    @FindBy(xpath = "//input[@class='MuiInputBase-input MuiFilledInput-input'][@placeholder='Others']")
    public WebElement eleOthersInput;

    @FindBy(id = "mui-component-select-24")
    @AndroidFindBy(accessibility = "'24'")
    //@AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"'24'\"]/android.view.ViewGroup[1]/android.widget.Button")
    @iOSXCUITFindBy(className = "'24'")
    public WebElement eleOccupationDrpBtn;

    @FindBy(id = "mui-component-select-29")
    public WebElement eleTypeOfOgranisationDrpBtn;

    @FindBy(xpath = "//input[@name='25'][@placeholder='Name of Business']")
    public WebElement eleOccupationNameofBussiness;

    @FindBy(xpath = "//input[@name='26'][@placeholder='Name of Employer']")
    public WebElement eleOccupationNameOfEmployer;

    @FindBy(xpath = "//input[@name='28'][@placeholder='Nature of Business/Duties']")
    public WebElement eleOccupationNatureofBussiness;

    @FindBy(xpath = "//input[@name='30'][@placeholder='Designation']")
    public WebElement eleOccupationDesignation;

    @FindBy(xpath = "//input[@placeholder='Annual Income']")
    public WebElement eleOccupationAnnualIncome;

    @FindBy(xpath = "//input[@name='32'][@placeholder=\"Spouse's Annual Income\"]")
    public WebElement eleOccupationSpouseAnnualIncome;

    //@FindBy(xpath = "//input[@placeholder='Parent's Insurance Cover (Rs.)']")
    @FindBy(xpath = "//input[@placeholder='Parent's Insurance Cover (Rs.)'][@name='34']")
    public WebElement eleOccupationInsuranceCover;


    public void chooseEditBtn() {
        this.eleEditBtn.click();
    }

    public WebElement getEleNomineeFirstNameInput() {
        return eleNomineeFirstNameInput;
    }

    public void chooseNomineeGender(String genderValue) {

        switch (baseTest.getPlatform().toLowerCase()) {
            case "android":
                /*String selector = "new UiSelector().className(\"ScrollView\").childSelector(new " +
                        "UiSelector().className(\"android.view.ViewGroup\").index(0))";
                WebElement element = driver.findElement(MobileBy.AndroidUIAutomator(selector));
                //WebElement element = driver.findElement(MobileBy.AndroidUIAutomator("new UiSelector().className(\"ScrollView\")).childSelector("
                 //       + "new UiSelector().className(\"android.view.ViewGroup\"))"));
                //WebElement element1 = element.findElement(MobileBy.AndroidUIAutomator("new UiSelector().text(\"Female\")"));
                element.findElement(By.xpath("//android.widget.TextView[contains(@text,'"+ genderValue +"')]")).click();*/

                //WebElement element = driver.findElement(By.xpath("//android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup[1]"));
                //driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'"+ genderValue +"')]")).click();
                driver.findElement(By.xpath("(//android.view.ViewGroup[@content-desc=\"nomineeGender\"])[1]/android.widget.TextView[@text='Male']")).click();

                switch (genderValue.toLowerCase().trim()) {
                    case "male":
                        logMessage("Gender selected :------"+genderValue.toLowerCase());
                        //driver.findElement(By.xpath("(//android.view.ViewGroup[@content-desc=\"mainContainer\"])[3]/android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup[2]/android.view.ViewGroup[6]")).click();
                        //driver.findElement(By.xpath("(//android.view.ViewGroup[@content-desc=\"mainContainer\"])[3]/android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup[2]/android.view.ViewGroup[6]")).click();
                        driver.findElement(By.xpath("(//android.view.ViewGroup[@content-desc=\"nomineeGender\"])[1]/android.widget.TextView[@text='Male']")).click();
                        break;
                    case "female":
                        logMessage("Gender selected :------"+genderValue.toLowerCase());
                        /*driver.findElement(By.xpath("(//android.view.ViewGroup[@content-desc=\"mainContainer\"])[3]/android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup[2]/android.view.ViewGroup[7]")).click();
                        driver.findElement(By.xpath("(//android.view.ViewGroup[@content-desc=\"mainContainer\"])[3]/android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup[2]/android.view.ViewGroup[7]")).click();*/
                        driver.findElement(By.xpath("(//android.view.ViewGroup[@content-desc=\"nomineeGender\"])[2]/android.widget.TextView[@text='Female']")).click();
                        break;
                    default:
                        logMessage("Gender selected :------"+genderValue.toLowerCase());
                        //driver.findElement(By.xpath("(//android.view.ViewGroup[@content-desc=\"mainContainer\"])[3]/android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup[2]/android.view.ViewGroup[8]")).click();
                        //driver.findElement(By.xpath("(//android.view.ViewGroup[@content-desc=\"mainContainer\"])[3]/android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup[2]/android.view.ViewGroup[8]")).click();
                        driver.findElement(By.xpath("(//android.view.ViewGroup[@content-desc=\"nomineeGender\"])[3]/android.widget.TextView[@text='Transgender']")).click();
                }
                break;
            case "ios":
                switch (genderValue.toLowerCase()) {
                    case "male":
                        ((IOSDriver) driver).findElementByIosClassChain("**/XCUIElementTypeOther[`label == \"nomineeGender\"`][1]").click();
                        break;
                    case "female":
                        ((IOSDriver) driver).findElementByIosClassChain("**/XCUIElementTypeOther[`label == \"nomineeGender\"`][2]").click();
                        break;
                    default:
                        ((IOSDriver) driver).findElementByIosClassChain("**/XCUIElementTypeOther[`label == \"nomineeGender\"`][3]").click();
                }
                //String str = "type == 'XCUIElementTypeOther' AND name BEGINSWITH[c] 'relationshipWithProposer'";
                break;
            default:
                driver.findElement(By.xpath("//*[text()='" + genderValue + "']")).click();
        }
    }

    public void inputFirstName(String name) {
        WebElement element = null;
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                /*//((AndroidDriver) driver).getKeyboard().pressKey("\n");
                //((AndroidDriver) driver).getKeyboard().pressKey("\n");
                element = driver.findElement(MobileBy.AndroidUIAutomator("new UiSelector().description(\"firstName\").index(0)"));

                //element = ((AndroidDriver) driver).findElementByAndroidUIAutomator("new UiSelector().description(\"firstName\")");
                element.click();
                element.clear();
                element.sendKeys(name);*/
                this.eleNomineeFirstNameInput.click();
                this.eleNomineeFirstNameInput.clear();
                this.eleNomineeFirstNameInput.sendKeys(name);
                ((AndroidDriver)driver).hideKeyboard();
                break;
            case "ios":
                this.eleNomineeFirstNameInput.click();
                this.eleNomineeFirstNameInput.clear();
                this.eleNomineeFirstNameInput.sendKeys(name);
                ((IOSDriver) driver).getKeyboard().pressKey("\n");
                break;
            default:
                this.eleNomineeFirstNameInput.click();
                this.eleNomineeFirstNameInput.clear();
                this.eleNomineeFirstNameInput.sendKeys(name);
        }
    }

    public void inputNomineeLastName(String name) {
        WebElement element = null;
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
               /* //((AndroidDriver) driver).getKeyboard().pressKey("\n");
                //((AndroidDriver) driver).getKeyboard().pressKey("\n");
                *//*element = driver.findElement(MobileBy.AndroidUIAutomator("new UiSelector().descriptionContains(\"lastName\").index(0).instance(0)"));
                //element = ((AndroidDriver) driver).findElementByAndroidUIAutomator("new UiSelector().description(\"lastName\")");
                element.click();
                element.clear();
                element.sendKeys(name);*//*
                this.eleNomineeLastNameInput.click();
                this.eleNomineeLastNameInput.clear();
                this.eleNomineeLastNameInput.sendKeys(name);*/
                this.eleNomineeLastNameInput.click();
                this.eleNomineeLastNameInput.clear();
                this.eleNomineeLastNameInput.sendKeys(name);
                ((AndroidDriver)driver).hideKeyboard();
                break;
            case "ios":
                this.eleNomineeLastNameInput.click();
                this.eleNomineeLastNameInput.clear();
                this.eleNomineeLastNameInput.sendKeys(name);
                ((IOSDriver) driver).getKeyboard().pressKey("\n");
                break;
            default:
                this.eleNomineeLastNameInput.click();
                this.eleNomineeLastNameInput.clear();
                this.eleNomineeLastNameInput.sendKeys(name);
        }
    }

    public void inputNomineeDOB(String day, String month, String year) {
        this.eleNomineeDayInput.click();
        this.eleNomineeDayInput.clear();
        this.eleNomineeDayInput.sendKeys(day);
        //commonUtils.enterKey(eleNomineeDayInput,driver);

        this.eleNomineeMonthInput.click();
        this.eleNomineeMonthInput.clear();
        this.eleNomineeMonthInput.sendKeys(month);
        //commonUtils.enterKey(eleNomineeMonthInput,driver);
        this.eleNomineeYearInput.click();
        this.eleNomineeYearInput.clear();
        this.eleNomineeYearInput.sendKeys(year);
        //commonUtils.enterKey(eleNomineeYearInput,driver);
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                //((AndroidDriver)driver).hideKeyboard();
                //((AndroidDriver) driver).getKeyboard().pressKey("\n");
                ((AndroidDriver) driver).pressKey(new KeyEvent(AndroidKey.NUMPAD_ENTER));
                //((AndroidDriver) driver).getKeyboard().pressKey("\n");
                ((AndroidDriver)driver).hideKeyboard();
                break;
            case "ios":
                ((IOSDriver) driver).getKeyboard().pressKey("\n");
                break;
            default:
        }
    }

    public void chooseNomineeRelationship(String value) {
        waitUtils.waitForElementToBeClickable(driver, eleNomineeRelationshipDowndown, 50);
        waitUtils.wait2Seconds();
        this.eleNomineeRelationshipDowndown.click();
        waitUtils.wait2Seconds();
        if(baseTest.isWeb()) {
            logMessage("VALUE -----------"+baseTest.isWeb());
            waitUtils.waitForElementToBeVisible(driver, this.eleQuoteGenericDropdownList, 50, "Nominee relationship dropdown is not shown");
        }
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                //driver.findElement(By.xpath("*//android.widget.TextView[@text='"+names+"']")).click();
                commonUtils.clickElementOnScroll(driver, value);
                break;
            case "ios":
                value = "Parent";
                //WebElement ele = ((IOSDriver)driver).findElementByAccessibilityId("Parent Grandfather Grandmother Brother Sister Son Daughter Husband Wife");
                waitUtils.wait2Seconds();
                //waitUtils.waitForElementToBeVisible(driver,ele);
                //logMessage("Element relationship :=============>"+ele);
                ((IOSDriver)driver).findElementByIosClassChain("**/XCUIElementTypeOther[`name == \"Parent\"`][1]").click();

                //ele.findElement(By.xpath("//XCUIElementTypeOther[@name=\"Parent\"]")).click();
                break;
            default:
                waitUtils.implicitWait(driver, 30000);
                driver.findElement(By.xpath("//ul[@role='listbox']/li/span[text()='" + value + "']")).click();
        }
    }

    public void inputNomineeShare(String shareValue) {
        this.eleNomineeShareInput.click();
        commonUtils.scrollTillEndOfPage(driver);
        this.eleNomineeShareInput.clear();
        this.eleNomineeShareInput.sendKeys(shareValue);
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                ((AndroidDriver<MobileElement>) driver).pressKey(new KeyEvent(AndroidKey.ENTER));
                break;
            case "ios":
                //((IOSDriver) driver).hideKeyboard();
                ((IOSDriver) driver).getKeyboard().pressKey("\n");
                break;
            default:
        }

    }

    public String getNomineeFirstName() {
        return this.eleNomineeFirstNameInput.getText();
    }

    public String getNomineeLastName() {
        return this.eleNomineeLastNameInput.getText();
    }

    public String getNomineeDayInput() {
        return eleNomineeDayInput.getText();
    }


    public String getNomineeMonthInput() {
        return eleNomineeMonthInput.getText();
    }


    public String getNomineeYearInput() {
        return eleNomineeYearInput.getText();
    }

    @AndroidFindBy(xpath = "(//android.widget.Button[@content-desc=\"saveBtn\"])[1]") // REMOVE
    private WebElement eleNomineeRemoveBtn;

    @AndroidFindBy(xpath = "(//android.widget.Button[@content-desc=\"saveBtn\"])[2]") // EDIT
    private WebElement eleNomineeEditBtn;

    @iOSXCUITFindBy(accessibility = "Select Gender")
    private WebElement eleNomineeGenderHeading;

    public void addNominee(String firstName, String lastName, String day, String month, String year, String gender, String relation, String share, String ismwppolicy) {
        inputFirstName(firstName);
        waitUtils.wait2Seconds();
        waitUtils.waitUntilVisible(driver,eleNomineeLastNameInput,30);
        inputNomineeLastName(lastName);
        inputNomineeDOB(day, month, year);
        waitUtils.wait2Seconds();
        if(new BaseTest().isIOS()) {
            commonUtils.clickOnScrollForIos(driver,eleNomineeGenderHeading);
        }
        chooseNomineeGender(gender);
        waitUtils.wait2Seconds();

        if (new BaseTest().isAndroid()) {
            commonUtils.scrollTillEndOfPage(driver);
        }
        if(new BaseTest().isIOS()) {
            commonUtils.iosScroll(driver,"type == 'XCUIElementTypeOther' AND name == 'relationshipWithProposer'",ScrollDirection.DOWN.getDir());
            //commonUtils.iosScroll(driver,"type == 'XCUIElementTypeOther' AND value == 'Date of Birth'",ScrollDirection.UP.getDir());
            commonUtils.iosScroll(driver,"type == 'XCUIElementTypeStaticText' AND value == 'Select Gender'",ScrollDirection.UP.getDir());
        }
        chooseNomineeRelationship(relation);
        commonUtils.scrollTillEndOfPage(driver);

        if (new BaseTest().isAndroid()) {
            commonUtils.scrollByText("SAVE",driver);
        }

        waitUtils.waitForElementToBeClickable(driver, eleNomineeShareInput,30);
        inputNomineeShare(share);
        if (relation.equalsIgnoreCase("wife")) {
            selectMwpPolicy(ismwppolicy);
        }
        commonUtils.scrollTillEndOfPage(driver);
        waitUtils.waitUntilVisible(driver,eleFormSave,30);
        saveForm();
    }

    public void clickAddNomieeSubmit() {
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":

                break;
            case "ios":
                break;
            default:
                waitUtils.implicitWait(driver, 30000);
        }
    }


    public void collapse() {
        driver.findElement(By.xpath("//div[@class='MuiButtonBase-root MuiAccordionSummary-root Mui-expanded']")).click();
    }

    public void unCollapse() {
        driver.findElement(By.xpath("(//label[contains(@class,'add-nominee')])[2]")).click();
    }

    public void chooseCommunicationAddress(String value) {
        waitUtils.waitUntilVisible(driver, eleCommunicationAddressDowndown, 30);
        waitUtils.wait2Seconds();
        this.eleCommunicationAddressDowndown.click();
        waitUtils.implicitWait(driver, 3000);
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                commonUtils.clickElementOnScroll(driver, value);
                break;
            case "ios":
                commonUtils.clickOnScrollForIos(driver,value);
                break;
            default:
                waitUtils.implicitWait(driver, 30000);
                driver.findElement(By.xpath("//ul[@role='listbox']/li/span[text()='" + value + "']")).click();
        }
    }


    /*@AndroidFindAll({
            @AndroidBy(xpath = "(//android.widget.Button[@content-desc=\"rightIcon\"])[4]",priority = 1),
            @AndroidBy(xpath = "//android.widget.Button[@content-desc=\"rightIcon\"]")
    })*/
    @AndroidFindBy(accessibility = "pinCodeIdrightIcon")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`name == \"pinCodeIdrightIcon\"`]")
    public WebElement elePincodeRightClick;

    public void inputPincode(String addresspin) throws InterruptedException {
        this.eleAddressPinCodeInput.click();
        this.eleAddressPinCodeInput.clear();
        this.eleAddressPinCodeInput.sendKeys(addresspin);
       // commonUtils.enterKey(eleAddressPinCodeInput,driver);
        switch (BaseTest.PLATFORM_NAME) {
            case "android" :
                commonUtils.enterKey(eleAddressPinCodeInput,driver);
                ((AndroidDriver)driver).hideKeyboard();
                elePincodeRightClick.click();
                elePincodeRightClick.click();
                break;
            case "ios":
                commonUtils.enterKey(eleAddressPinCodeInput,driver);
                ((IOSDriver)driver).hideKeyboard();
                elePincodeRightClick.click();
                elePincodeRightClick.click();
                elePincodeRightClick.click();
                break;

            default:
                this.eleAddressPinCodeInput.click();
                this.eleAddressPinCodeInput.clear();
                this.eleAddressPinCodeInput.sendKeys(addresspin);
                break;
        }
    }

    public void inputAddress1(String address1) {
        this.eleAddress1Input.click();
        this.eleAddress1Input.clear();
        this.eleAddress1Input.sendKeys(address1);
        commonUtils.enterKey(eleAddress1Input,driver);
    }

    public  void inputAddress2(String address2){
        this.eleAddress2Input.click();
        this.eleAddress2Input.clear();
        this.eleAddress2Input.sendKeys(address2);
        commonUtils.enterKey(eleAddress2Input,driver);
    }

    public  void inputAddress3(String address3){
        this.eleAddress3Input.click();
        this.eleAddress3Input.clear();
        this.eleAddress3Input.sendKeys(address3);
        commonUtils.enterKey(eleAddress3Input,driver);
    }

    public void fillBankDetails(String ifsccode, String bankaccno, String accounttype, String clickverify, String pennyalert) throws InterruptedException {
        //waitUtils.waitForElementToBeVisible(driver, eleIfscCodeInput);
        inputIfscCode("HDFC0000133");
        //waitUtils.waitForElementToBeVisible(driver, eleIfscVerifyTick);  // to do :add correct loactor for ios
        commonUtils.scrollTillEndOfPage(driver);
        inputAccNo("50100022859343");
        commonUtils.scrollTillEndOfPage(driver);
        chooseAccountType(accounttype);
        chooseActionButton(eleVerifyBtn);
        if(new BaseTest().isIOS()) {
            if(commonUtils.isDisplayed(driver,eleVerifyBtn)) {
                chooseActionButton(eleVerifyBtn);
            }
            if (commonUtils.isDisplayed(driver,eleBankAlertOkBtn)) {
                waitUtils.wait2Seconds();
                driver.switchTo().alert().dismiss();
            }
        } else  {
            waitUtils.fluentWaitUntilElementVisible(driver, eleBankAlert, 50);
            waitUtils.wait2Seconds();
            if(commonUtils.isDisplayed(driver,eleBankAlertOkBtn)) {
                    chooseActionButton(eleBankAlertOkBtn);
                }
        }
        waitUtils.waitForElementToBeVisible(driver, eleInputAccHolderName);
        Assert.assertNotNull(eleInputAccHolderName.getText());
        commonUtils.scrollTillEndOfPage(driver);
        waitUtils.waitForElementToBeClickable(driver, eleBankNextBtn);
        chooseActionButton(eleBankNextBtn);
        waitUtils.waitForElementToBeVisible(driver, eleRenewNavText);
    }

    public void fillRenewalDetails(String paymentmethod, String drawdate, String fundsource, String premiumamount, String premiumterm, String nomineescreentitle) {
        logMessage("Payment method seleceted:============= >" + paymentmethod);
        choosePaymentMethod(paymentmethod);
        chooseDrawDate(drawdate);
        commonUtils.scrollTillEndOfPage(driver);
        chooseSourceOfFund(fundsource);

        //Assert.assertEquals(getPremiumValueFromRenewalScreen(),commonUtils.decimalFormatter(premiumamount),"Premium amount shown in renewal screen is different than quote");
        //Assert.assertTrue(getPaymentFreqFromRenewalScreen().contains(premiumterm),"Premium period shown in renewal screen is different than quote");
        chooseActionButton(this.eleRenewSaveBtn);
        commonUtils.scrollTillEndOfPage(driver);
        waitUtils.wait2Seconds();
        waitUtils.waitUntilVisible(driver, this.eleRenewNextBtn, 30);
        chooseActionButton(this.eleRenewNextBtn);
        if(!commonUtils.isDisplayed(driver,eleNomineeNavText)) {
            chooseActionButton(this.eleRenewNextBtn);
        }
        waitUtils.waitForElementToBeVisible(driver, eleNomineeNavText);
    }

    //@AndroidFindBy(accessibility = "saveBtn")
    @AndroidFindBy(accessibility = "appointeeNomineeSaveBtn")
    @FindBy(xpath = "//*[text()='SAVE']")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeButton' AND name == 'appointeeNomineeSaveBtn'")
    public WebElement eleFormSave;

    //@AndroidFindBy(xpath = "(//android.widget.Button[@content-desc='nextBtn'])[3]")
    @AndroidFindBy(accessibility = "nomineeVerifyButton")
    //@FindBy(xpath = "//span[text()='NEXT']")
    @FindBy(xpath = "//button[contains(@class,'save-btn')]")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeButton' AND name == 'nomineeVerifyButton'")
    public WebElement eleFormNext;


    public void selectMwpPolicy(String value) {
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                driver.findElement(By.xpath("//android.widget.TextView[@text='" + value + "']")).click();
                break;
            case "ios":
                break;
            default:
                waitUtils.implicitWait(driver, 30000);
                driver.findElement(By.xpath("//*[text()='" + value + "']")).click();
        }
    }

    public void saveForm() {
        this.eleFormSave.click();
    }

    public void nextForm() {
        eleFormNext.click();
    }

    public void acceptAlert() {
        this.eleOkButton.click();
    }

    public void chooseActionButton(WebElement element) {
        commonUtils.clickElement(element);
    }

    public void chooseCommunicationInfoPreferredLanguage(String value){
        waitUtils.waitForElementToBeVisible(driver, eleCommunicationPreferredLanguage, 50, "Communication Preferred Language dropdown in Add Address is not shown");
        this.eleCommunicationPreferredLanguage.click();
        waitUtils.implicitWait(driver, 50000);
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                commonUtils.clickElementOnScroll(driver, value);
                break;
            case "ios":
                commonUtils.clickOnScrollForIos(driver,value);
                break;
            default:
                waitUtils.implicitWait(driver, 30000);
                driver.findElement(By.xpath("//ul[@role='listbox']/li/span[text()='" + value + "']")).click();
        }
    }

    public  void inputAlernateNumber(String alernateNumber){
        this.eleAlernateNumber.click();
        this.eleAlernateNumber.clear();
        this.eleAlernateNumber.sendKeys(alernateNumber);
        commonUtils.enterKey(eleAlernateNumber,driver);
    }

    public  void inputResidenceTelNo(String residenceTelNumber){
        this.eleResidenceTelNo.click();
        this.eleResidenceTelNo.clear();
        this.eleResidenceTelNo.sendKeys(residenceTelNumber);
        commonUtils.enterKey(eleResidenceTelNo,driver);
    }

   public void setEleAddressNextButton(){
        waitUtils.waitForElementToBeClickable(driver, eleAddressNextButton);
        try {
            if (eleAddressNextButton.isDisplayed()) {
                this.eleAddressNextButton.click();
            }
        }catch(Exception e){
            System.out.println("element not displayed");
        }
    }

    public void navigationBackFromUI(){
        waitUtils.waitForElementToBeVisible(driver,eleNavigationBack);
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                this.eleNavigationBack.click();
                break;
            case "ios":
                this.eleNavigationBack.click();
                break;
            default:
                this.eleNavigationBack.click();
        }
    }
    public String getCityNameFromAddAddressScreen() throws InterruptedException {
        return this.eleCityNameFromAddAddress.getText();
    }
    public void add_Nominee(String nomineescreentitle, String nomineefirstname, String nomineelastname, String nomineeday,
                            String nomineemonth, String nomineeyear, String nomineegender, String relationshipwithproposer, String nomineeshare,
                            String ismwppolicy,String addressscreentitle) throws InterruptedException {
        //createApplPage.getScreenTitle().contains(nomineescreentitle);
        //validateScreenTitle(nomineescreentitle).contains(nomineescreentitle);
        inputFirstName(nomineefirstname);
        inputNomineeLastName(nomineelastname);
        inputNomineeDOB(nomineeday,nomineemonth,nomineeyear);
        //waitUtils.implicitWait(driver,10000);
        waitUtils.waitUntilElementIsVisibleByText(driver,10,nomineegender,"Nominee select gender field value is not displayed");
        chooseNomineeGender(nomineegender);
        commonUtils.scrollTillEndOfPage(driver);
        Thread.sleep(3000);
        chooseNomineeRelationship(relationshipwithproposer);
        commonUtils.scrollTillEndOfPage(driver);
        waitUtils.implicitWait(driver,30000);
        inputNomineeShare(nomineeshare);
        saveForm();
        waitUtils.waitUntilElementIsVisibleByText(driver,20,"NEXT","Next button is not displayed");
        waitUtils.wait2Seconds();
        nextForm();
        waitUtils.wait2Seconds();
        nextForm();
        waitUtils.waitUntilElementIsVisibleByText(driver, 30, addressscreentitle, "add address screen is not displayed");
        waitUtils.implicitWait(driver,100);
        Assert.assertEquals(validateScreenTitle(addressscreentitle), addressscreentitle, "Failure in navigation to add address screen");

    }

    /*@AndroidFindAll({
            @AndroidBy(xpath = "(//android.widget.Button[@content-desc=\"saveBtn\"])[3]"),
            @AndroidBy(xpath = "//android.widget.TextView[@text='SAVE']")
    })*/
    @AndroidFindBy(accessibility = "addressSaveBtn")
    @FindBy(xpath = "//*[text()='SAVE']")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`name == \"addressSaveBtn\"`]")
    public WebElement eleAddressSaveBtn;

    /*@AndroidFindAll({
            @AndroidBy(xpath = "(//android.widget.Button[@content-desc=\"saveBtn\"])[3]"),
            @AndroidBy(xpath = "//android.widget.TextView[@text='NEXT']")
    })*/
    @AndroidFindBy(accessibility = "addressNextBtn")
    @FindBy(xpath = "//*[text()='NEXT']")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"addressNextBtn\"`]")
    public WebElement eleAddressNextBtn;

    public void add_Address(String addressscreentitle,String typeofaddress,String addresspincode,String address1,String address2,String address3,String personalDetailsscreentitle) throws InterruptedException {

        Assert.assertEquals(getScreenTitle(), addressscreentitle, "Failure in navigation to add address screen");

        waitUtils.implicitWait(driver, 1000);
        commonUtils.selectButtonByName("NEXT", driver);
        waitUtils.implicitWait(driver, 1000);
        commonUtils.selectButtonByName("NEXT", driver);
        chooseCommunicationAddress(typeofaddress);
        inputPincode(addresspincode);
/*        waitUtils.waitUntilElementIsVisibleByText(driver, 30, cityName, "City Name is not displayed");
        waitUtils.implicitWait(driver, 1000);
        Assert.assertEquals(createApplPage.getCityNameFromAddAddressScreen(), cityName, "Failure to fetch city name data");*/

        inputAddress1(address1);
        inputAddress2(address2);
        inputAddress3(address3);
        commonUtils.scrollTillEndOfPage(driver);
        commonUtils.selectButtonByName("SAVE", driver);
        waitUtils.implicitWait(driver, 1000);
        commonUtils.scrollTillEndOfPage(driver);
        waitUtils.wait2Seconds();
        commonUtils.selectButtonByName("NEXT", driver);
        waitUtils.implicitWait(driver, 1000);
        waitUtils.waitUntilElementIsVisibleByText(driver, 30, personalDetailsscreentitle, "Personal Details screen is not displayed");
        waitUtils.implicitWait(driver, 1000);
        Assert.assertEquals(getScreenTitle(), personalDetailsscreentitle, "Failure in navigation to Personal Details screen");

    }

    public void addAddress(String addressscreentitle,String typeofaddress,String addresspincode,String address1,String address2,String address3,String personalDetailsscreentitle)
            throws InterruptedException {

        System.out.println("In address screen");
        chooseCommunicationAddress(typeofaddress);
        inputPincode("560068");
        waitUtils.waitUntilVisible(driver,eleAddress1Input,30);

        if(BaseTest.PLATFORM_NAME.equalsIgnoreCase("android")) {
            commonUtils.elementOnScroll(driver,"Address 2");
        }
        inputAddress1(address1);
        inputAddress2(address2);
        inputAddress3(address3);
        commonUtils.scrollTillEndOfPage(driver);
        commonUtils.chooseActionButton(eleAddressSaveBtn);
        commonUtils.scrollTillEndOfPage(driver);
        waitUtils.wait2Seconds();
        commonUtils.chooseActionButton(eleAddressNextBtn);
        //waitUtils.waitUntilElementIsVisibleByText(driver, 30, personalDetailsscreentitle, "Personal Details screen is not displayed");
        //Assert.assertEquals(getScreenTitle(), personalDetailsscreentitle, "Failure in navigation to Personal Details screen");
    }



    public void home(WebDriver driver) {

        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
            String activity = ((AndroidDriver) driver).currentActivity();
            ((AndroidDriver) driver).pressKey(new KeyEvent(AndroidKey.HOME));
            //((AndroidDriver) driver).pressKey(new KeyEvent(AndroidKey.BACK));
            //((AndroidDriver) driver).startActivity(new Activity("com.absli.leap",activity));
            ((AndroidDriver) driver).launchApp();
                break;
            case "ios":
                ImmutableMap<String, String> pressHome = ImmutableMap.of("name", "home");
                ((JavascriptExecutor)driver).executeScript("mobile: pressButton", pressHome);
                ((JavascriptExecutor)driver).executeScript("mobile: pressButton", pressHome);
                HashMap<String, Object> args = new HashMap<>();
                args.put("bundleId", "com.absli.leap");
                //((JavascriptExecutor)driver).executeScript("mobile: activateApp", args);
                ((JavascriptExecutor)driver).executeScript("mobile: launchApp", args);
                break;
        }
    }

    public void fillNomineeDetails(String nomineefirstname,String nomineelastname,String nomineeday,String nomineemonth,
                                   String nomineeyear,String nomineegender,String relationshipwithproposer) throws InterruptedException {
        inputFirstName(nomineefirstname);
        inputNomineeLastName(nomineelastname);
        inputNomineeDOB(nomineeday,nomineemonth,nomineeyear);
        chooseNomineeGender(nomineegender);
        waitUtils.implicitWait(driver, 30000);
        chooseNomineeRelationship(relationshipwithproposer);
        commonUtils.scrollTillEndOfPage(driver);
        waitUtils.implicitWait(driver,30000);
        inputNomineeShare("100");
        waitUtils.implicitWait(driver,10000);
        commonUtils.scrollTillEndOfPage(driver);
        waitUtils.implicitWait(driver,10000);
        waitUtils.waitForElementToBeVisible(driver,eleFormSave);
        saveForm();
        Thread.sleep(500);
        waitUtils.fluentWaitUntilElementVisible(driver,eleFormNext,60);
        nextForm();
        waitUtils.fluentWaitUntilElementVisible(driver,eleFormNext,60);
        nextForm();
        waitUtils.wait2Seconds();
    }
    public void fillAddressDetails(String typeofaddress,String addresspincode,String address1,String address2,String address3,String personalDetailsscreentitle) throws InterruptedException {

        System.out.println("In address screen");
        chooseCommunicationAddress(typeofaddress);
        inputPincode("560068");
        waitUtils.waitUntilVisible(driver,eleAddress1Input,30);

        if(BaseTest.PLATFORM_NAME.equalsIgnoreCase("android")) {
            commonUtils.elementOnScroll(driver,"Address 2");
        }
        inputAddress1(address1);
        inputAddress2(address2);
        inputAddress3(address3);
        commonUtils.scrollTillEndOfPage(driver);
        commonUtils.chooseActionButton(eleAddressSaveBtn);
        commonUtils.scrollTillEndOfPage(driver);
        waitUtils.wait2Seconds();
        commonUtils.chooseActionButton(eleAddressNextBtn);
    }

    public void inputPersonalEmailId(String PersonalEmailId){
        this.elePersonalEmailIdInput.click();
        this.elePersonalEmailIdInput.clear();
        this.elePersonalEmailIdInput.sendKeys(PersonalEmailId);
        commonUtils.enterKey(elePersonalEmailIdInput,driver);
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                driver.findElement(By.xpath("//android.widget.Button[@content-desc='rightIcon']/android.widget.TextView")).click();
                if (isAlertShown()) {
                    acceptAlert();
                }
                waitUtils.waitForElementToBeVisible(driver,eleFatherSpouseNameInput,10,"Element not loaded successfully");
                break;
            case "ios":

                break;
            default:

        }
    }


    public void inputPersonalFatherSpouseName(String FatherSpouseName){
        this.eleFatherSpouseNameInput.click();
        this.eleFatherSpouseNameInput.clear();
        this.eleFatherSpouseNameInput.sendKeys(FatherSpouseName);
        commonUtils.enterKey(eleFatherSpouseNameInput,driver);
    }

    public void inputPersonalMotherName(String MotherName){
        this.eleMotherNameInput.click();
        this.eleMotherNameInput.clear();
        this.eleMotherNameInput.sendKeys(MotherName);
        commonUtils.enterKey(eleMotherNameInput,driver);
    }

    public void inputPersonalMaidenName(String MaidenName){
        this.eleMaidenNameInput.click();
        this.eleMaidenNameInput.clear();
        this.eleMaidenNameInput.sendKeys(MaidenName);
        commonUtils.enterKey(eleMaidenNameInput,driver);
    }

    public void validateQualificationList(){
        ArrayList<String> expectedQualificationList = new ArrayList<>(Arrays.asList("Illiterate","Below SSC","SSC","HSC","Graduate","Postgraduate","Professional"));
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                List<WebElement> androidqualificationDropDown = driver.findElements(By.xpath("//android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup"));
                ArrayList<String> actualListAndroid = new ArrayList<>();
                for(WebElement ele:androidqualificationDropDown){
                    actualListAndroid.add(ele.getText().trim());
                    System.out.println("ActualList: "+actualListAndroid.add(ele.getText().trim()));
                }
                actualListAndroid.contains(expectedQualificationList);

                break;
            case "ios":
                List<WebElement> iosqualificationDropDown = driver.findElements(By.xpath("//XCUIElementTypeScrollView"));
                ArrayList<String> actualListIOS = new ArrayList<>();
                for(WebElement ele:iosqualificationDropDown){
                    actualListIOS.add(ele.getText().trim());
                    System.out.println("ActualList: "+actualListIOS.add(ele.getText().trim()));
                }
                actualListIOS.contains(expectedQualificationList);

                break;
            default:
                List<WebElement> qualificationDropDown = driver.findElements(By.xpath("//ul[@class='MuiList-root MuiMenu-list MuiList-padding']/li/span[1]"));
                ArrayList<String> actualListWeb = new ArrayList<>();
                for(WebElement ele:qualificationDropDown){
                    actualListWeb.add(ele.getText().trim());
                    System.out.println("ActualList: "+actualListWeb.add(ele.getText().trim()));
                }
                actualListWeb.contains(expectedQualificationList);

        }

        //Assert.assertTrue(al.contains(expectedQualificationList),"Actual Qualification list should match with expected list");
    }

    public void validateOccupationList(){
        ArrayList<String> expectedOccupationList = new ArrayList<>(Arrays.asList("Business Owner","Service","Professional","Retired","Student","Housewife","Agriculture","Driver","Skilled Worker","Army/Navy/Police","Armed Forces","Jeweler","Builder","Scrap Dealer","Doctor","Lawyer","Architect","Others"));
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                List<WebElement> androidOccupationDropDown = driver.findElements(By.xpath("//android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup"));
                ArrayList<String> actualListAndroid = new ArrayList<>();
                for(WebElement ele:androidOccupationDropDown){
                    actualListAndroid.add(ele.getText().trim());
                    System.out.println("ActualList: "+actualListAndroid.add(ele.getText().trim()));
                }
                actualListAndroid.contains(expectedOccupationList);

                break;
            case "ios":
                List<WebElement> iosOccupationDropDown = driver.findElements(By.xpath("//XCUIElementTypeScrollView"));
                ArrayList<String> actualListIOS = new ArrayList<>();
                for(WebElement ele:iosOccupationDropDown){
                    actualListIOS.add(ele.getText().trim());
                    System.out.println("ActualList: "+actualListIOS.add(ele.getText().trim()));
                }
                actualListIOS.contains(expectedOccupationList);

                break;
            default:
                List<WebElement> occupationWebDropDown = driver.findElements(By.xpath("//ul[@class='MuiList-root MuiMenu-list MuiList-padding']/li/span[1]"));
                ArrayList<String> actualListWeb = new ArrayList<>();
                for(WebElement ele:occupationWebDropDown){
                    actualListWeb.add(ele.getText().trim());
                    System.out.println("ActualList: "+actualListWeb.add(ele.getText().trim()));
                }
                actualListWeb.contains(expectedOccupationList);
        }
    }

    public void validateOccupationFields(String value){
        switch (baseTest.getPlatform().toLowerCase()) {
            case "android":
                break;
            case "ios":
                break;
            default:
                if(value=="Student"){
                    eleOccupationAnnualIncome.isDisplayed();
                    eleOccupationInsuranceCover.isDisplayed();
                }
                else if (value=="Agriculture"){
                    eleOccupationAnnualIncome.isDisplayed();
                }
                else if (value=="Business Owner"){
                    eleOccupationNameofBussiness.isDisplayed();
                    eleOccupationNatureofBussiness.isDisplayed();
                    eleTypeOfOgranisationDrpBtn.isDisplayed();
                    eleOccupationAnnualIncome.isDisplayed();
                }
                else if (value=="Service"){
                    eleOccupationNameOfEmployer.isDisplayed();
                    eleOccupationNatureofBussiness.isDisplayed();
                    eleTypeOfOgranisationDrpBtn.isDisplayed();
                    eleOccupationDesignation.isDisplayed();
                    eleOccupationAnnualIncome.isDisplayed();
                }
                else if (value=="Retired"){
                    eleOccupationAnnualIncome.isDisplayed();
                    eleOccupationSpouseAnnualIncome.isDisplayed();
                }
                else if (value=="Housewife"){
                    eleOccupationSpouseAnnualIncome.isDisplayed();
                    eleOccupationInsuranceCover.isDisplayed();
                }

/*            case "Student":
                eleOccupationAnnualIncome.isDisplayed();
                eleOccupationInsuranceCover.isDisplayed();
                break;

            case "Agriculture":
                eleOccupationAnnualIncome.isDisplayed();
                break;

            case "Business Owner":
                eleOccupationNameofBussiness.isDisplayed();
                eleOccupationNatureofBussiness.isDisplayed();
                eleTypeOfOgranisationDrpBtn.isDisplayed();
                eleOccupationAnnualIncome.isDisplayed();
                break;*/
        }
    }
    public void validateTypeofOrganisationList(){
        ArrayList<String> expectedOrganisationList = new ArrayList<>(Arrays.asList("NGO","Trust","Proprietorship","Partnership","HUF","Private Ltd.","Govt","Society","Public Ltd.","Charity"));
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                List<WebElement> androidOrganisationDropDown = driver.findElements(By.xpath("//android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup"));
                ArrayList<String> actualListAndroid = new ArrayList<>();
                for(WebElement ele:androidOrganisationDropDown){
                    actualListAndroid.add(ele.getText().trim());
                    System.out.println("ActualList: "+actualListAndroid.add(ele.getText().trim()));
                }
                actualListAndroid.contains(expectedOrganisationList);

                break;
            case "ios":

                break;
            default:
                List<WebElement> organisationWebDropDown = driver.findElements(By.xpath("//ul[@class='MuiList-root MuiMenu-list MuiList-padding']/li/span[1]"));
                ArrayList<String> actualListWeb = new ArrayList<>();
                for(WebElement ele:organisationWebDropDown){
                    actualListWeb.add(ele.getText().trim());
                    System.out.println("ActualList: "+actualListWeb.add(ele.getText().trim()));
                }
                actualListWeb.contains(expectedOrganisationList);
        }
    }

    public void inputOthers(String Others){
        this.eleOthersInput.click();
        this.eleOthersInput.clear();
        this.eleOthersInput.sendKeys(Others);
        commonUtils.enterKey(eleOthersInput,driver);

    }

    public void chooseMaritalStatus(String MaritalStatus) {

        switch (baseTest.getPlatform().toLowerCase()) {
            case "android":
                switch (MaritalStatus) {
                    case "Single":
                        driver.findElement(By.xpath("//android.widget.TextView[@text='Single']")).click();
                        driver.findElement(By.xpath("//android.widget.TextView[@text='Single']")).click();
                        break;
                    case "Married":
                        driver.findElement(By.xpath("//android.widget.TextView[@text='Married']")).click();
                        driver.findElement(By.xpath("//android.widget.TextView[@text='Married']")).click();
                        break;
                    default:
                        driver.findElement(By.xpath("//android.widget.TextView[@text='"+MaritalStatus+"']")).click();
                        driver.findElement(By.xpath("//android.widget.TextView[@text='"+MaritalStatus+"']")).click();
                }
                break;
            case "ios":
                ((IOSDriver) driver).findElementByAccessibilityId(MaritalStatus).click();
                break;
            default:
                driver.findElement(By.xpath("//*[text()='" + MaritalStatus + "']")).click();
        }
    }

    public void chooseQualification(String value) {
        waitUtils.waitForElementToBeVisible(driver, eleQualificationDrpBtn, 50, "Qualification dropdown is not shown");
        this.eleQualificationDrpBtn.click();
        waitUtils.implicitWait(driver, 30000);
        if(baseTest.isWeb()) {
            logMessage("Qualification VALUE -----------"+baseTest.isWeb());
            waitUtils.waitForElementToBeVisible(driver, this.eleQualificationDrpBtn, 50, "Qualification dropdown values is not shown");
        }
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                //driver.findElement(By.xpath("*//android.widget.TextView[@text='"+names+"']")).click();
                commonUtils.clickElementOnScroll(driver, value);
                break;
            case "ios":
                value = "Others";
                WebElement ele = ((IOSDriver)driver).findElementByAccessibilityId("Parent Grandfather Grandmother Brother Sister Son Daughter Husband Wife");
                waitUtils.waitForElementToBeVisible(driver,ele);
                logMessage("Element Qualification :=============>"+ele);
                ele.findElement(By.xpath("//XCUIElementTypeOther[@name='Others']")).click();
                break;
            default:
                waitUtils.implicitWait(driver, 30000);
                driver.findElement(By.xpath("//ul[@role='listbox']/li/span[text()='"+value+"']")).click();
        }
    }

    public void chooseOccupation(String value) {
        waitUtils.waitForElementToBeVisible(driver, eleOccupationDrpBtn, 50, "Occupation dropdown is not shown");
        this.eleOccupationDrpBtn.click();
        waitUtils.implicitWait(driver, 30000);
        if(baseTest.isWeb()) {
            logMessage("Occupation VALUE -----------"+baseTest.isWeb());
            waitUtils.waitForElementToBeVisible(driver, this.eleOccupationDrpBtn, 50, "Occupation dropdown values is not shown");

        }
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                //driver.findElement(By.xpath("*//android.widget.TextView[@text='"+names+"']")).click();
                commonUtils.clickElementOnScroll(driver, value);
                break;
            case "ios":
                value = "Others";
                WebElement ele = ((IOSDriver)driver).findElementByAccessibilityId("Parent Grandfather Grandmother Brother Sister Son Daughter Husband Wife");
                waitUtils.waitForElementToBeVisible(driver,ele);
                logMessage("Element Occupation :=============>"+ele);
                ele.findElement(By.xpath("//XCUIElementTypeOther[@name='Others']")).click();
                break;
            default:
                waitUtils.implicitWait(driver, 30000);
                waitUtils.waitForElementToBeClickable(driver,driver.findElement(By.xpath("//ul[@role='listbox']/li/span[text()='" + value + "']")));
                //commonUtils.clickElementOnScroll(driver,value);
                driver.findElement(By.xpath("//ul[@role='listbox']/li/span[text()='" + value + "']")).click();
        }
    }

    public void chooseTypeOfOrganisation(String value) {
        waitUtils.waitForElementToBeVisible(driver, eleTypeOfOgranisationDrpBtn, 50, "Organisation dropdown is not shown");
        this.eleTypeOfOgranisationDrpBtn.click();
        waitUtils.implicitWait(driver, 30000);
        if(baseTest.isWeb()) {
            logMessage("Organisation VALUE -----------"+baseTest.isWeb());
            waitUtils.waitForElementToBeVisible(driver, this.eleTypeOfOgranisationDrpBtn, 50, "Organisation dropdown values is not shown");
        }
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                //driver.findElement(By.xpath("*//android.widget.TextView[@text='"+names+"']")).click();
                commonUtils.clickElementOnScroll(driver, value);
                break;
            case "ios":
                value = "Others";
                WebElement ele = ((IOSDriver)driver).findElementByAccessibilityId("Parent Grandfather Grandmother Brother Sister Son Daughter Husband Wife");
                waitUtils.waitForElementToBeVisible(driver,ele);
                logMessage("Element Occupation :=============>"+ele);
                ele.findElement(By.xpath("//XCUIElementTypeOther[@name='Others']")).click();
                break;
            default:
                waitUtils.implicitWait(driver, 30000);
                driver.findElement(By.xpath("//ul[@role='listbox']/li/span[text()='" + value + "']")).click();
        }
    }



//Insta verify

    @FindBy(xpath = "//div[@class='pathname' and text()='INSTA Verify']")
    @AndroidFindBy(xpath = "//android.view.View[@text=\"Insta Verify\"]")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"Insta Verify\"])[2]")
    public WebElement instaVerifyScreenTitle;

    @FindBy(xpath = "//span[contains(text(),'PHOTO VERIFICATION')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text=\"PHOTO VERIFICATION\"]")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeButton[@name=\"continueBtn\"])[1]")
    public WebElement photoVerificationTab;

    @FindBy(xpath = "//span[contains(text(),'DO IT LATER ')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='DO IT LATER']")
    @iOSXCUITFindBy(className = "//XCUIElementTypeButton[@name='laterBtn']")
    public WebElement doItLaterBtn;

    @FindBy(xpath = "//div[text()='Photo Verification']")
    //@AndroidFindBy(xpath = "//android.widget.TextView[@text=\"Photo Verification\"]")
    @AndroidFindBy(xpath = "(//android.widget.Button[@content-desc='continueBtn'])[1]")
    @iOSXCUITFindBy(accessibility = "Photo Verification")
    public WebElement photoVerificationText;

    @FindBy(xpath = "//span[contains(text(),'VIDEO VERIFICATION')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text=\"VIDEO VERIFICATION \"]")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeButton[@name=\"continueBtn\"])[2]")
    public WebElement videoVerificationTab;

    @FindBy(xpath = "//img[@alt='camera']")
    @AndroidFindBy(xpath = "(//android.widget.ImageView)[31]")
    public WebElement cameraTab;


    @FindBy(xpath = "//div[contains(text(),'Selfie Tips')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text=\"Selfie Tips\"]")
    public WebElement selfieScreenTitle;

    @FindBy(xpath = "//button[contains(text(),'Proceed to Take Selfie')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text=\"Proceed to Take Selfie\"]")
    public WebElement takeSelfieTab;

    @FindBy(xpath = "//div[contains(text(),'Capture Now')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text=\"Capture Now\"]")
    public WebElement waitForCapture;

    @FindBy(xpath = "//a[@id='hv-camera-capture-button']//img")
    @AndroidFindBy(id = "camera_icon")
    public WebElement captureImage;

    @FindBy(xpath = "//div[contains(text(),'Capture ID Proof')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text=\"Capture ID Proof\"]")
    public WebElement captureIDProofText;

    @FindBy(xpath = "//button/span[contains(text(),'SELECT ID PROOF TYPE')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text=\"SELECT ID PROOF TYPE\"]")
    public WebElement selectIDProofType;

    @FindBy(xpath = "//div[contains(text(),'Select type of ID Proof')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text=\"Select Type Of ID Proof\"]")
    public WebElement selectIDProofText;

    @FindBy(xpath = "//div[@role='button']")
    @AndroidFindBy(xpath = "//android.widget.EditText")
    public WebElement selectTypeOfProof;

    @FindBy(xpath = "//ul//li/span[contains(text(),' ')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text,' ')]")
    public List<WebElement> listOfIDProofs;

    public void selectIDproof(String proofName){
        switch (BaseTest.PLATFORM_NAME.toLowerCase()){
            case "android":
                WebElement proof=driver.findElement(By.xpath("//android.widget.TextView[contains(@text='"+proofName+" ')]"));
                proof.click();
                break;
            case "ios":
                break;
            default:
                break;
        }
    }

    @AndroidFindBy(id = "com.absli.leap:id/title_text")
    public WebElement IDCaptureTips;

    @AndroidFindBy(id="com.absli.leap:id/proceed_button")
    public WebElement proceedToCapture;

    @AndroidFindBy(id="com.absli.leap:id/title_text")
    public WebElement docsCaptureTitle;

    @AndroidFindBy(id="com.absli.leap:id/camera_bubble")
    public WebElement captureFrontSide;

    @AndroidFindBy(id="com.absli.leap:id/title_text")
    public WebElement reviewPhoto;

    @AndroidFindBy(id="com.absli.leap:id/camera_bubble")
    public WebElement captureBackSide;


    @FindBy(xpath = "//input[@id='uploadedFile']")
    //@FindBy(xpath = "//*[text()='Upload document from device']")
    WebElement uploadFile;

    @FindBy(xpath = "//button[text()='Use this Document']")
    @AndroidFindBy(id="com.absli.leap:id/confirm_button")
    WebElement useThisDoc;

    @FindBy(xpath = "//div[contains(text(),'Photo Captured')]")
    @AndroidFindBy(xpath = "//android.view.View[@text=\"Identity Verification\"]")
    WebElement summaryPhoto;

//video verification
    @iOSXCUITFindBy(accessibility = "Video Verification")
    @AndroidFindBy(xpath = "//android.widget.TextView[(@text='Video Verification')]")
    public WebElement videoVerificationText;


    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"Start Video Verification\"]/XCUIElementTypeOther")
    @AndroidFindBy(xpath = "(//android.view.ViewGroup[@index='2']/android.widget.ImageView)[2]")
    public WebElement startVideo;

    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Select Language']")
    public WebElement selectLanguageText;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"ENGLISH\"])[2]")
    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text,'ENGLISH')]")
    public WebElement selectLanguage;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[contains(@name,\"hereby confirm that I have understood the details of the (BSLI Life Shield) and agree to the terms and conditions explained to me. I hereby provide my consent to process this application.\")])[8]/XCUIElementTypeOther[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther[2]")
    @AndroidFindBy(xpath = "(//android.widget.ImageView)[35]")
    public WebElement startVideoButton;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[contains(@name,\"Secs\")])[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther")
    public WebElement stopVideoButton;

    public void instaVerifyPage() throws Exception {
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                    waitUtils.waitForElementToBeVisible(driver, instaVerifyScreenTitle);
                    commonUtils.scrollToElementAndClick(driver, photoVerificationTab);
                    waitUtils.waitForElementToBeVisible(driver, photoVerificationText);
                    commonUtils.scrollToElementAndClick(driver, cameraTab);
                    waitUtils.wait2Seconds();
                    waitUtils.waitForElementToBeVisible(driver, selfieScreenTitle);
                    commonUtils.scrollToElementAndClick(driver, takeSelfieTab);
                    waitUtils.wait2Seconds();
                    waitUtils.waitForElementToBeVisible(driver, waitForCapture);
                    // waitUtils.wait5Seconds();
                    //driver.switchTo().alert().accept();
                    commonUtils.scrollToElementAndClick(driver, captureImage);
                    waitUtils.wait5Seconds();
                    commonUtils.selectButtonByName("PROCEED", driver);
                    waitUtils.wait2Seconds();
                    waitUtils.waitForElementToBeVisible(driver, captureIDProofText);
                    commonUtils.scrollToElementAndClick(driver, selectIDProofType);
                    waitUtils.waitForElementToBeVisible(driver, selectIDProofText);
                    commonUtils.scrollToElementAndClick(driver, selectTypeOfProof);
                    waitUtils.wait5Seconds();
                    commonUtils.getValuesFromList(driver, listOfIDProofs, "Aadhaar Card");
                    waitUtils.wait5Seconds();
                    waitUtils.waitForElementToBeVisible(driver, IDCaptureTips);
                    commonUtils.scrollToElementAndClick(driver, proceedToCapture);
                    waitUtils.wait2Seconds();
                    waitUtils.waitForElementToBeVisible(driver, docsCaptureTitle);
                    commonUtils.scrollToElementAndClick(driver, captureFrontSide);
                    waitUtils.waitForElementToBeVisible(driver, reviewPhoto);
                    commonUtils.scrollToElementAndClick(driver, useThisDoc);
                    waitUtils.wait2Seconds();
                    waitUtils.waitForElementToBeVisible(driver, docsCaptureTitle);
                    commonUtils.scrollToElementAndClick(driver, captureBackSide);
                    waitUtils.waitForElementToBeVisible(driver, reviewPhoto);
                    commonUtils.scrollToElementAndClick(driver, useThisDoc);
                    waitUtils.waitForElementToBeVisible(driver, summaryPhoto);

                    waitUtils.wait10Seconds();
                    commonUtils.selectButtonByName("PROCEED", driver);
                    break;
               /*


                    waitUtils.waitForElementToBeVisible(driver, instaVerifyScreenTitle);
                    commonUtils.scrollToElementAndClick(driver,videoVerificationTab);
                    waitUtils.waitForElementToBeVisible(driver,videoVerificationText);
                   // commonUtils.scrollToElementAndClick(driver,startVideo);
                    this.startVideo.click();
                    waitUtils.wait2Seconds();
                    waitUtils.waitForElementToBeVisible(driver,selectLanguageText);
                    commonUtils.scrollToElementAndClick(driver,selectLanguage);
                    commonUtils.selectButtonByName("CONTINUE",driver);
                    waitUtils.waitForElementToBeVisible(driver,instaVerifyScreenTitle);
                   //commonUtils.scrollToElementAndClick(driver,);
*/

            case "ios":
                break;
            default:

            waitUtils.waitForElementToBeVisible(driver, instaVerifyScreenTitle);
            commonUtils.scrollToElementAndClick(driver, photoVerificationTab);
            waitUtils.waitForElementToBeVisible(driver, photoVerificationText);
            waitUtils.waitForElementToBeVisible(driver,cameraTab,20,"Element not visible");
            commonUtils.scrollToElementAndClick(driver, cameraTab);
            waitUtils.wait2Seconds();
            waitUtils.waitForElementToBeVisible(driver, selfieScreenTitle);
            commonUtils.scrollToElementAndClick(driver, takeSelfieTab);
            waitUtils.wait2Seconds();
            waitUtils.waitForElementToBeVisible(driver, waitForCapture);
            waitUtils.wait2Seconds();
            //driver.switchTo().alert().accept();
            commonUtils.scrollToElementAndClick(driver, captureImage);
            waitUtils.wait5Seconds();
            commonUtils.selectButtonByName("PROCEED", driver);
            waitUtils.wait2Seconds();
            waitUtils.waitForElementToBeVisible(driver, captureIDProofText);
            commonUtils.scrollToElementAndClick(driver, selectIDProofType);
            waitUtils.waitForElementToBeVisible(driver, selectIDProofText);
            commonUtils.scrollToElementAndClick(driver, selectTypeOfProof);
            waitUtils.wait5Seconds();
            commonUtils.getValuesFromList(driver, listOfIDProofs, "Aadhaar Card");
            waitUtils.wait5Seconds();
            commonUtils.selectButtonByName("CONTINUE", driver);
            this.uploadFile.sendKeys("C:\\Users\\datamatics\\Documents\\Aadhar_Card.pdf");
            waitUtils.wait2Seconds();
            this.useThisDoc.click();
            waitUtils.wait5Seconds();
            this.uploadFile.sendKeys("C:\\Users\\datamatics\\Documents\\Aadhar_Card.pdf");
            waitUtils.wait2Seconds();
            this.useThisDoc.click();
            waitUtils.wait10Seconds();
            commonUtils.selectButtonByName("PROCEED", driver);
                break;
        }
    }

    public void skipInstaVerifyPage() throws Exception {
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                waitUtils.waitForElementToBeVisible(driver, instaVerifyScreenTitle);
                photoVerificationTab.click();
                doItLaterBtn.click();
                waitUtils.waitForElementToBeVisible(driver,eleBankNavText,20,"Element not visible");
                break;

            case "ios":
                break;
            default:
                waitUtils.waitForElementToBeVisible(driver, instaVerifyScreenTitle);
                commonUtils.scrollToElementAndClick(driver, photoVerificationTab);
                commonUtils.scrollTillEndOfPage(driver);
                doItLaterBtn.click();
                //commonUtils.scrollToElementAndClick(driver,doItLaterBtn);
                break;
        }
    }

    /*public void fillNomineeDetails(String nomineefirstname,String nomineelastname,String nomineeday,String nomineemonth,String nomineeyear,String nomineegender,String relationshipwithproposer){

        inputFirstName(nomineefirstname);
        inputNomineeLastName(nomineelastname);
        inputNomineeDOB(nomineeday,nomineemonth,nomineeyear);
        chooseNomineeGender(nomineegender);
        waitUtils.implicitWait(driver, 30000);
        chooseNomineeRelationship(relationshipwithproposer);
        commonUtils.scrollTillEndOfPage(driver);
        waitUtils.implicitWait(driver,30000);
        inputNomineeShare("100");
        commonUtils.scrollTillEndOfPage(driver);
        waitUtils.implicitWait(driver,10000);
        waitUtils.waitForElementToBeVisible(driver,eleFormSave);
        saveForm();
        //waitUtils.waitForElementToBeVisible(driver,eleFormNext);
        commonUtils.scrollTillEndOfPage(driver);
        waitUtils.waitUntilElementIsVisibleByText(driver,10,"NEXT","Next button is not visible");
        commonUtils.selectButtonByName("NEXT", driver);
        commonUtils.scrollTillEndOfPage(driver);
        waitUtils.waitUntilElementIsVisibleByText(driver,10,"NEXT","Next button is not visible");
        commonUtils.selectButtonByName("NEXT", driver);
        waitUtils.waitForElementToBeVisible(driver, eleAddressNavText, 30, "add address screen is not displayed");
        waitUtils.implicitWait(driver,100);
    }
    public void fillAddressDetails(String typeofaddress,String addresspincode,String address1,String address2,String address3,String personalDetailsscreentitle) throws InterruptedException {
        chooseCommunicationAddress(typeofaddress);
        inputPincode(addresspincode);
        inputAddress1(address1);
        inputAddress2(address2);
        inputAddress3(address3);
        commonUtils.scrollTillEndOfPage(driver);
        commonUtils.selectButtonByName("SAVE", driver);
        waitUtils.implicitWait(driver, 1000);
        commonUtils.scrollTillEndOfPage(driver);
        commonUtils.selectButtonByName("NEXT", driver);
        //waitUtils.implicitWait(driver, 1000);
        waitUtils.waitUntilElementIsVisibleByText(driver,10,"NEXT","Next button is not visible");
        commonUtils.selectButtonByName("NEXT", driver);
        waitUtils.waitUntilElementIsVisibleByText(driver, 30, personalDetailsscreentitle, "Personal Details screen is not displayed");
        waitUtils.implicitWait(driver, 1000);
        //Assert.assertEquals(validateScreenTitle(personalDetailsscreentitle), personalDetailsscreentitle, "Failure in navigation to Personal Details screen");
    }*/

}


