package com.absli.pageObjects;

import com.absli.helpers.jsonReaders.ReadJson;
import com.absli.helpers.models.LoginModel;
import com.absli.helpers.models.ProposerModel;
import com.absli.utils.CommonUtils;
import com.absli.utils.PropertiesUtils;
import com.absli.utils.WaitUtils;
import com.gargoylesoftware.htmlunit.javascript.host.canvas.WebGLVertexArrayObject;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import tests.BaseTest;

import java.io.IOException;

import static com.absli.logger.LoggingManager.logMessage;

public class ChequePage extends Page{
    WebDriver driver;
    CommonUtils commonUtils;
    ReadJson jsonObj;
    LoginModel loginModel;
    SignInPage signIn;
    DashboardPage dashPage;
    WaitUtils waitUtils;
    OccupationPage occupationPage;
    QualificationPage qualificationPage;
    ChequePage chequePage;
    ProposerModel proposerModel;
    PropertiesUtils prop;

    public ChequePage(WebDriver driver) throws InterruptedException {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        logMessage("Initializing the " + this.getClass().getSimpleName() + " elements");
        PageFactory.initElements(new AppiumFieldDecorator(driver), ChequePage.class);

        jsonObj = new ReadJson();
        signIn = new SignInPage(driver);
        dashPage = new DashboardPage(driver);
        waitUtils = new WaitUtils();
        commonUtils = new CommonUtils();
        occupationPage = new OccupationPage(driver);
        qualificationPage = new QualificationPage(driver);
        prop = new PropertiesUtils();
    }

    @FindBy(xpath = "//span[contains(text(),'None')]")
    @AndroidFindBy(accessibility = "Q56.A1")
    public WebElement eleFamilyMedicalDiseaseOpt;

    @FindBy(xpath = "//div[contains(text(),'Recovered from Covid19')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Recovered from Covid19']")
    public WebElement eleCovid19DetailsOpt;

    @FindBy(xpath = "//div[contains(text(),'I agree to the Policy details mentioned above')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='I Agree to the Policy details mentioned above']")
    public WebElement eleReviewAcceptance;

    @FindBy(name = "userAgreementStatus")
    @AndroidFindBy(accessibility = "agree")
    public WebElement eleReviewAcceptanceTermAgree;

    @FindBy(xpath = "//button[@type='submit']")
    @AndroidFindBy(accessibility = "continueButton")
    public WebElement eleReviewSubmitBtn;

    @FindBy(xpath = "//span[contains(text(),'ENTER OTP')]")
    @AndroidFindBy(id = "inputotp")
    public WebElement eleEnterOTPButton;

    @FindBy(xpath = "//div[contains(text(),'Check Status')]")
    @AndroidFindBy(accessibility = "checkStatusBtn")
    public WebElement eleCheckStatusBtn;

    @FindBy(id = "inputotp")
    @AndroidFindBy(id = "inputotp")
    public WebElement eleOTPTxtField;

    @FindBy(xpath = "//div[contains(text(),'OTP VERIFIED')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='CODE VERIFIED']")
    public WebElement eleOtpVerifiedMsg;

    @FindBy(xpath = "//span[contains(text(),'PROCEED')]")
    @AndroidFindBy(accessibility = "proceedButton")
    public WebElement eleRNAProceedBtn;

    @FindBy(xpath = "//div[contains(text(),'10. Payment Mode')]")
    @AndroidFindBy(xpath = "//android.view.View[@text='10.0 Payment Mode']")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeOther[`label == '10.0 Payment Mode'`]")
    public WebElement elePaymentModeTitle;

    @FindBy(xpath = "//div[contains(text(),'CHEQUE / DEMAND DRAFT')]")
    @AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc='mainContainer']/android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup/android.widget.Button")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == 'CHEQUE / DEMAND DRAFT \uDB80\uDD40'`]")
    public WebElement eleChequeDropOpt;

    @FindBy(xpath = "//div[contains(text(),'Demand Draft')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Demand Draft']/..")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeOther[`label == 'paymentMode'`]")
    public WebElement eleDemandDraftMode;

    @FindBy(xpath = "//*[@class='delete-size']")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == 'removeBtn'`]")
    public WebElement eleImageDelete;

    @FindBy(xpath = "//span[contains(text(),'Yes')]")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == 'rightBtn'`]")
    public WebElement eleRemoveFileAlertYes;

    @FindBy(xpath = "//span[contains(text(),'UPLOAD')]")
    @AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc='mainContainer']/android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup[3]/android.view.ViewGroup/android.view.ViewGroup[3]/android.view.ViewGroup")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeOther[`label == 'UPLOAD'`]")
    public WebElement eleUploadBtn;

    @FindBy(xpath = "//div[text()='DD image']/../../../div[2]/button/span[contains(text(),'UPLOAD')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='UPLOAD']/..")
    //@iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeOther[`label == 'UPLOAD'`]")
    @iOSXCUITFindBy(iOSNsPredicate ="label=='DD IMAGE' AND name=='UPLOAD'")
    public WebElement eleDDImageUploadBtn;

    @FindBy(xpath = "//div[text()='Declaration Form']/../../../div[2]/button/span[contains(text(),'UPLOAD')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='DD DECLARATION']/following-sibling::android.view.ViewGroup")
    //@iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name='UPLOAD']")
    @iOSXCUITFindBy(iOSNsPredicate ="label=='CHEQUE IMAGE' AND name=='UPLOAD'")
    public WebElement eleDeclarationFormUploadBtn;

    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Documents']/..")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeTextField[`label == 'Documents'`]")
    public WebElement eleDocumentUploadBtn;

    @AndroidFindBy(id = "com.android.permissioncontroller:id/permission_allow_button")
    public WebElement eleAllowPermissionYes;

    @FindBy(xpath = "//span[contains(text(),'(Uploaded)')]")
    public WebElement eleUploadedMsg;

    @FindBy(id = "chequeDDNo")
    @AndroidFindBy(accessibility = "chequeDDNo")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeTextField[`label == 'chequeDDNo'`]")
    public WebElement eleChequeNumberField;

    @FindBy(id = "chequeDDNo")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeTextField[`label == 'chequeDDNo'`]")
    public WebElement eleDDNumber;

    @FindBy(id = "ifscCode")
    @AndroidFindBy(accessibility = "ifscCode")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeTextField[`label == 'ifscCode'`]")
    public WebElement elePaymentModeIFSC;

    @FindBy(id = "dd")
    @AndroidFindBy(accessibility = "day")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeTextField[`label == 'paymentday'`]")
    public WebElement elePaymentModeDate;

    @FindBy(id = "mm")
    @AndroidFindBy(accessibility = "month")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeTextField[`label == 'paymentmonth'`]")
    public WebElement elePaymentModeMonth;

    @FindBy(id = "yy")
    @AndroidFindBy(accessibility = "year")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeTextField[`label == 'paymentyear'`]")
    public WebElement elePaymentModeYear;

    @FindBy(id = "bankName")
    @AndroidFindBy(accessibility = "bankName")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeTextField[`label == 'bankName'`]")
    public WebElement elePaymentModeBankName;

    @FindBy(id = "micrCode")
    @AndroidFindBy(accessibility = "micrCode")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeTextField[`label == 'micrCode'`]")
    public WebElement elePaymentMicrCode;

    @FindBy(xpath = "//div[@class='btn-end cash-OTC-container mar-top-25']/button/span[contains(text(),'Submit')]")
    @AndroidFindBy(xpath = "(//android.widget.Button[@content-desc='continueButton'])[1]")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == 'continueButton'`]")
    public WebElement elePaymentModeSubmit;

    @FindBy(id = "chequeDDNo-helper-text")
    @AndroidFindBy(xpath = "(//android.widget.TextView[@content-desc='inputHelperText'])[1]")
    @iOSXCUITFindBy(iOSNsPredicate ="label=='chequeDDNo' AND name=='inputHelperText'")
    public WebElement eleDDNumberErrorMsg;

    @FindBy(id = "dd-helper-text")
    @iOSXCUITFindBy(iOSNsPredicate ="label=='paymentday' AND name=='inputHelperText'")
    public WebElement eleDateErrorMsg;

    @FindBy(id = "mm-helper-text")
    @iOSXCUITFindBy(iOSNsPredicate ="label=='paymentmonth' AND name=='inputHelperText'")
    public WebElement eleMonthErrorMsg;

    @FindBy(id = "yy-helper-text")
    @iOSXCUITFindBy(iOSNsPredicate ="label=='paymentyear' AND name=='inputHelperText'")
    public WebElement eleYearErrorMsg;

    @FindBy(id = "ifscCode-helper-text")
    @AndroidFindBy(xpath = "(//android.widget.TextView[@content-desc='inputHelperText'])[2]")
    @iOSXCUITFindBy(iOSNsPredicate ="label=='ifscCode' AND name=='inputHelperText'")
    public WebElement eleIFSCCodeErrorMsg;

    @FindBy(xpath = "//span[contains(text(),'Payment Sucessful')]")
    @AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc='mainContainer']/android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup[3]/android.view.ViewGroup/android.widget.TextView[1]")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == 'Payment Successful'`]")
    public WebElement elePaymentSuccessMsg;

    @FindBy(xpath = "//span[text()='NEXT']")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == 'continueButton'`]")
    public WebElement elePaymentNextBtn;

    @FindBy(xpath = "//div[text()='10.0 Documents']")
    @AndroidFindBy(xpath = "//android.view.View[@text='10. Documents']")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeOther[`label == '11.0 Documents'`]")
    public WebElement eleDocumentScreenTitle;

    public void inputPaymentChequeNumber(String ChequeNumber){
        this.eleChequeNumberField.click();
        this.eleChequeNumberField.clear();
        this.eleChequeNumberField.sendKeys(ChequeNumber);
        commonUtils.enterKey(eleChequeNumberField,driver);
    }
    public void inputPaymentModeDate(String PaymentModeDate){
        this.elePaymentModeDate.click();
        this.elePaymentModeDate.clear();
        this.elePaymentModeDate.sendKeys(PaymentModeDate);
        commonUtils.enterKey(elePaymentModeDate,driver);
    }

    public void inputPaymentModeMonth(String PaymentModeMonth){
        this.elePaymentModeMonth.click();
        this.elePaymentModeMonth.clear();
        this.elePaymentModeMonth.sendKeys(PaymentModeMonth);
        commonUtils.enterKey(elePaymentModeMonth,driver);
    }
    public void inputPaymentModeYear(String PaymentModeYear){
        this.elePaymentModeYear.click();
        this.elePaymentModeYear.clear();
        this.elePaymentModeYear.sendKeys(PaymentModeYear);
        commonUtils.enterKey(elePaymentModeYear,driver);
    }

    public void inputPaymentModeIFSC(String ChequeIFSCCode){
        this.elePaymentModeIFSC.click();
        this.elePaymentModeIFSC.clear();
        this.elePaymentModeIFSC.sendKeys(ChequeIFSCCode);
        commonUtils.enterKey(elePaymentModeIFSC,driver);
    }

    public void inputPaymentModeMicrCode(String MICRCODE){
        this.elePaymentMicrCode.click();
        this.elePaymentMicrCode.clear();
        this.elePaymentMicrCode.sendKeys(MICRCODE);
        commonUtils.enterKey(elePaymentMicrCode,driver);
    }

    public void inputPaymentDDNumber(String DDNumber){
        this.eleDDNumber.click();
        this.eleDDNumber.clear();
        this.eleDDNumber.sendKeys(DDNumber);
        commonUtils.enterKey(eleDDNumber,driver);
    }
    public void selectPersonalInfoButton() {
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                driver.findElement(By.xpath("//android.widget.TextView[@text='NEXT']")).click();
                break;
            case "ios":
                break;
            default:
                waitUtils.implicitWait(driver, 30000);
                driver.findElement(By.xpath("//*[text()='DO IT LATER ']")).click();
        }
    }

    public void selectUploadChequeFile() throws IOException {
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                eleUploadBtn.click();
                waitUtils.waitForElementToBeVisible(driver,eleDocumentUploadBtn,20,"element not visible");
                eleDocumentUploadBtn.click();

                break;
            case "ios":
                break;
            default:
                waitUtils.implicitWait(driver, 30000);
                eleUploadBtn.sendKeys(System.getProperty("user.dir")+prop.getProperties("PanCardImage"));;
        }
    }

    public void selectUploadDraftFile() throws IOException {
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":

                break;
            case "ios":
                break;
            default:
                waitUtils.implicitWait(driver, 30000);
                eleDDImageUploadBtn.sendKeys(System.getProperty("user.dir")+prop.getProperties("PanCardImage"));;
        }
    }

    public void selectUploadDeclarationFile() throws IOException {
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":

                break;
            case "ios":

                break;
            default:
                waitUtils.implicitWait(driver, 30000);
                eleDeclarationFormUploadBtn.sendKeys(System.getProperty("user.dir")+prop.getProperties("PanCardImage"));;
        }
    }

}