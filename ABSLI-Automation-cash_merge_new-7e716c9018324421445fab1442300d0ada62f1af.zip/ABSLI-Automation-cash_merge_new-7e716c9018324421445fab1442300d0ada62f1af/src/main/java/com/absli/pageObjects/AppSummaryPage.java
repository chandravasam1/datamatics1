package com.absli.pageObjects;

import com.absli.helpers.jsonReaders.ReadJson;
import com.absli.helpers.models.LoginModel;
import com.absli.helpers.models.ProposerModel;
import com.absli.utils.CommonUtils;
import com.absli.utils.WaitUtils;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import static com.absli.logger.LoggingManager.logMessage;

public class AppSummaryPage extends Page{
    WebDriver driver;
    CommonUtils commonUtils;
    ReadJson jsonObj;
    LoginModel loginModel;
    SignInPage signIn;
    DashboardPage dashPage;
    WaitUtils waitUtils;
    OccupationPage occupationPage;
    QualificationPage qualificationPage;
    ChequePage chequePage;
    ProposerModel proposerModel;
    CashPage cashPage;

    public AppSummaryPage(WebDriver driver) throws InterruptedException {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        logMessage("Initializing the " + this.getClass().getSimpleName() + " elements");
        PageFactory.initElements(new AppiumFieldDecorator(driver), CashPage.class);

        /*jsonObj = new ReadJson();
        signIn = new SignInPage(driver);
        dashPage = new DashboardPage(driver);*/
        waitUtils = new WaitUtils();
        commonUtils = new CommonUtils();
        occupationPage = new OccupationPage(driver);
        qualificationPage = new QualificationPage(driver);
    }

    @FindBy(xpath = "//input[@class='navbar-search']")
    public WebElement eleAppSummaryNavBtn;

    @FindBy(xpath = "//div[text()='Customer Profile']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='1.0 CUSTOMER PROFILE']")
    public WebElement eleCustomerProfile;

    @FindBy(xpath = "//div[text()='Select Plan']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='2.0 SELECT PLAN']")
    public WebElement eleSelectPlan;

    @FindBy(xpath = "//div[text()='Insta Verify']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='3.0 INSTA VERIFY']")
    public WebElement eleInstaVerify;

    @FindBy(xpath = "//div[text()='Bank Details']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='4.0 BANK DETAILS']")
    public WebElement eleBankDetails;

    @FindBy(xpath = "//div[text()='Nominee']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='5.0 NOMINEE']")
    public WebElement eleNominee;

    @FindBy(xpath = "//div[text()='Address']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='6.0 ADDRESS']")
    public WebElement eleAddress;

    @FindBy(xpath = "//div[text()='PersonalAndProfessionalInfo']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='7.0 PERSONALINFO']")
    public WebElement elePersonalAndProfessionalInfo;

    @FindBy(xpath = "//div[text()='Medical']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='8.0 MEDICAL']")
    public WebElement eleMedical;

    @FindBy(xpath = "//div[text()='Review & Acceptance']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='9.0 REVIEW & ACCEPTANCE']")
    public WebElement eleReviewAcceptance;

    @FindBy(xpath = "//div[text()='Payment']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='10.0 PAYMENT']")
    public WebElement elePayment;

    @FindBy(xpath = "//div[text()='Documents']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='11.0 DOCUMENTS']")
    public WebElement eleDocuments;

    @FindBy(xpath = "//div[text()='IAR']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='12.0 IAR']")
    public WebElement eleIAR;

    @FindBy(xpath = "//div[@class='card-status']")

    public WebElement eleCustomerProfilePendingStatus;

    @FindBy(xpath = "//div[text()='Customer Profile']/../../../div/div[2]")
    public WebElement eleCustomerProfileStatus;

    @FindBy(xpath = "//div[text()='Select Plan']/../../../div/div[2]")
    public WebElement eleSelectPlanStatus;

    @FindBy(xpath = "//div[text()='Bank Details']/../../../div/div[2]")
    public WebElement eleBankDetailsStatus;

    @FindBy(xpath = "//div[text()='Nominee']/../../../div/div[2]")
    public WebElement eleNomineeStatus;

    @FindBy(xpath = "//div[text()='Address']/../../../div/div[2]")
    public WebElement eleAddressStatus;

    @FindBy(xpath = "//div[text()='PersonalAndProfessionalInfo']/../../../div/div[2]")
    public WebElement elePersonalAndProfessionalInfoStatus;

    @FindBy(xpath = "//div[text()='Medical']/../../../div/div[2]")
    public WebElement eleMedicalStatus;

    @FindBy(xpath = "//div[text()='Review & Acceptance']/../../../div/div[2]")
    public WebElement eleReviewAcceptanceStatus;

    @FindBy(xpath = "//div[text()='Payment']/../../../div/div[2]")
    public WebElement elePaymentStatus;

    @FindBy(xpath = "//div[text()='Documents']/../../../div/div[2]")
    public WebElement eleDocumentsStatus;

    @FindBy(xpath = "//div[text()='IAR']/../../../div/div[2]")
    public WebElement eleIARStatus;
}
