package com.absli.pageObjects;

import com.absli.helpers.jsonReaders.ReadJson;
import com.absli.helpers.models.LoginModel;
import com.absli.helpers.models.ProposerModel;
import com.absli.utils.CommonUtils;
import com.absli.utils.WaitUtils;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import tests.BaseTest;

import static com.absli.logger.LoggingManager.logMessage;

public class EnachRegistrationPage extends Page {

    WebDriver driver;
    CommonUtils commonUtils;
    ReadJson jsonObj;
    LoginModel loginModel;
    SignInPage signIn;
    DashboardPage dashPage;
    WaitUtils waitUtils;
    ProposerModel proposerModel;

    public EnachRegistrationPage(WebDriver driver) throws InterruptedException {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        logMessage("Initializing the " + this.getClass().getSimpleName() + " elements");
        PageFactory.initElements(new AppiumFieldDecorator(driver), EnachRegistrationPage.class);

        /*jsonObj = new ReadJson();
        signIn = new SignInPage(driver);
        dashPage = new DashboardPage(driver);*/
        waitUtils = new WaitUtils();
        commonUtils = new CommonUtils();
    }
    @FindBy(xpath = "//span[@class='MuiButton-label' and contains(text(),'Send Link To Client')]")
    @AndroidFindBy(xpath="//android.widget.TextView[@text='Send Link To Client')]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"Send Link To Client\"]")
    public WebElement enachSendLink;

    public WebElement enachSendLi(){
        return this.enachSendLink;
    }

    public void EnachSendLinktoClient(String linkName){
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                WebElement androidEl=driver.findElement(By.xpath("//android.widget.TextView[@text='"+linkName+"']"));
                if(androidEl.isDisplayed()) {
                    androidEl.click();
                }
                break;
            case "ios":
                WebElement IosEl=driver.findElement(By.xpath("//XCUIElementTypeOther[@name="+ linkName +"]"));
                if(IosEl.isDisplayed()) {
                    IosEl.click();
                }
                break;

            default:
                WebElement link =  null;
                try {
                    link = driver.findElement(By.xpath("//span[@class='MuiButton-label' and contains(text(),'"+linkName+"')]"));
                    if(link.isDisplayed()) {
                        link.click();

                    }
                } catch (NoSuchElementException e) {
                    logMessage("element not found:" + By.xpath("//span[@class='MuiButton-label' and contains(text(),'"+linkName+"')]"));
                }

        }

    }
    @FindBy(tagName = "h2")
    public WebElement titleOfPage;



    @FindBy(xpath = "//span[contains(text(),'Register Now')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Register Now']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"Register Now\"]")
    public WebElement resiterNowlink;

    public WebElement resiterNow(){
        return resiterNowlink;
    }

    public void enachRegistrationLink(String linkName) {
        switch (BaseTest.PLATFORM_NAME) {
            case "android":
                driver.findElement(By.xpath("//android.widget.TextView[@text='" + linkName + "']")).click();
                break;
            case "ios":
                WebElement IosEl=driver.findElement(By.xpath("//XCUIElementTypeOther[@name="+ linkName +"]"));
                if(IosEl.isDisplayed()) {
                    IosEl.click();
                }
                break;
            default:
                driver.findElement(By.xpath("//span[contains(text(),'" + linkName + "')]")).click();
        }
    }
    @FindBy(xpath = "//div[@class='checkout-detail-box-inner']")
    @AndroidFindBy(xpath ="//android.view.View[@text='Powered by Ingenico – a Worldline brand']")
    @iOSXCUITFindBy(xpath = "")
    public WebElement registerPopUp;

    public WebElement registerPopUp(){
        return this.registerPopUp;
    }

    @FindBy(xpath = "//select[@id='selectBanks']")
    @AndroidFindBy(xpath = "//android.view.View[@text='Select bank ...']")
    @iOSXCUITFindBy(accessibility = "selectBanks")
    public WebElement selectBank;

    public WebElement getSelectBank(){
        return this.selectBank;
    }
    public void enachReSelectBank() {
        switch (BaseTest.PLATFORM_NAME) {
            case "android":
                driver.findElement(By.xpath("//android.view.View[@text='Select bank ...']")).click();
                break;
            case "ios":
                //driver.findElementByAccessibilityId(selectBanks).click();
                driver.findElement(By.xpath("//XCUIElementTypeOther[@name="+ selectBank +"]")).click();
                break;
            default:
                this.selectBank.click();
        }
    }
    public void enachRegistrationSelectBank(String selectBank) {
        switch (BaseTest.PLATFORM_NAME) {
            case "android":
                driver.findElement(By.xpath("//android.widget.CheckedTextView[@text='" + selectBank + "']")).click();
                break;
            case "ios":
                driver.findElement(By.xpath("//XCUIElementTypeOther[@name="+ selectBank +"]")).click();
                break;
            default:
                driver.findElement(By.xpath("//select[@id='selectBanks']/option[contains(text(),'"+selectBank+"')]")).click();
        }
    }
    public void selectBankFromList(String bankName){
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                driver.findElement(By.xpath("//android.widget.CheckedTextView[@text='" + selectBank + "']")).click();
                break;
            case "ios":
                driver.findElement(By.xpath("//XCUIElementTypeOther[@name="+ selectBank +"]")).click();
                break;
            default:
                driver.findElement(By.xpath("//option[contains(text(),'"+bankName+"')]")).click();
        }
    }

    public void registerAfterSelectBank(String linkName){

        switch (BaseTest.PLATFORM_NAME){
            case "android":
                driver.findElement(By.xpath("//android.widget.TextView[@text='" + linkName + "']")).click();
                break;
            case "ios":
                driver.findElement(By.xpath("//XCUIElementTypeOther[@name="+ linkName +"]")).click();
                break;

            default:
                driver.findElement(By.xpath("//div[@class='additionalMandateFieldView digital-mandate plr10']//following-sibling::div/button[contains(text(),'"+linkName+"')]")).click();

        }
    }
    @FindBy(xpath ="//div[contains(text(),'We are unable to process your request!')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='We are unable to process your request!']")
    private WebElement enachStatus;

    public WebElement enachStatus(){
        return enachStatus;
    }

    public String  statusOfEnachRegistration(){
        String status=" ";
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                status=this.enachStatus.getText();
                break;
            case "ios":
                status=this.enachStatus.getText();
                break;
            default:
                status=this.enachStatus.getText();

        }
        return status;
    }
    @FindBy(xpath = "(//div[@class='tab-control cust-cols-6 ac-checkout panNo even']//input)[1]")
    @AndroidFindBy(id = "newPanNo ")
    @iOSXCUITFindBy(accessibility = "newPanNo")
    public WebElement getEnachPan;

    @FindBy(xpath = "(//div[@class='tab-control cust-cols-6 ac-checkout phoneNo even']//input)[1]")
    @AndroidFindBy(id = "newPhoneNo ")
    @iOSXCUITFindBy(accessibility = "newPhoneNo")
    public WebElement getEnachPhone;

    @FindBy(xpath = "(//div[@class='tab-control cust-cols-6 ac-checkout eMailId odd']//input)[1]")
    @AndroidFindBy(id = "newEmailId ")
    @iOSXCUITFindBy(accessibility = "newEmailId")
    public WebElement getEnachEmail;

    public void setEnachPhoneNumber(String phoneNumber){

        switch (BaseTest.PLATFORM_NAME){
            case "android":
                driver.findElement(By.id("newPhoneNo")).sendKeys(phoneNumber);
                break;

            case "ios":
                driver.findElement(By.id("newPhoneNo")).sendKeys(phoneNumber);
                break;
            default:
                WebElement ele=driver.findElement(By.xpath("//body/div[@id='checkoutmodal']/div[1]/div[1]/div[1]/div[3]/div[8]/div[1]/div[3]/div[3]/div[1]/div[2]/div[9]/div[1]/input[1]"));
                ele.clear();
                ele.sendKeys(phoneNumber);
        }
    }
    @FindBy(xpath = "//body/div[@id='checkoutmodal']/div[1]/div[1]/div[1]/div[3]/div[8]/div[1]/div[3]/div[3]/div[1]/div[2]/div[11]/div[1]/input[1]")
    public WebElement enachPan;

    public WebElement enachPan(){
        return enachPan;
    }
    public void setEnachPanNumber(String enachPan){

        switch (BaseTest.PLATFORM_NAME){
            case "android":
                driver.findElement(By.id("newPanNo")).sendKeys(enachPan);
                break;

            case "ios":
                driver.findElement(By.id("newPanNo")).sendKeys(enachPan);
                break;
            default:
                //WebElement ele=driver.findElement(By.xpath("//input[@class='tab-input is-si txt-valid' and @id='newPanNo']"));
                this.enachPan.clear();
                this.enachPan.sendKeys(enachPan);
        }
    }
    @FindBy(xpath ="//body/div[@id='checkoutmodal']/div[1]/div[1]/div[1]/div[3]/div[8]/div[1]/div[3]/div[3]/div[1]/div[2]/div[12]/div[1]/input[1]" )
    public WebElement enachEmail;

    public WebElement enachEmail(){
        return enachEmail;
    }

    public void setEnachEmailAddress(String enachEmail){

        switch (BaseTest.PLATFORM_NAME){
            case "android":
                this.enachEmail.clear();
                this.enachEmail.sendKeys(enachEmail);
                break;

            case "ios":
                this.enachEmail.clear();
                this.enachEmail.sendKeys(enachEmail);
                break;
            default:
                //WebElement ele=driver.findElement(By.xpath("//input[@class='tab-input is-si txt-valid' and @id='newEmailId']"));
                this.enachEmail.clear();
                this.enachEmail.sendKeys(enachEmail);
        }
    }

    public String getTimeLeft(){
        String timeLeft="";
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                break;
            case "ios":
                break;
            default:
                WebElement timeele=driver.findElement(By.xpath("//span[@id='display']//b[text()]"));
                timeLeft=timeele.getText();

        }
        return timeLeft;
    }
    @FindBy(xpath = "//div[@class='additionalMandateFieldView digital-mandate plr10']/following-sibling::div/button[@type='button']")
    public WebElement enachRegister;

    @FindBy(xpath = "//input[@type='checkbox']")
    @AndroidFindBy(accessibility = "inptCheck_01")
    public WebElement checkboxClck;

    public WebElement checkboxClck(){
        return checkboxClck;
    }

    public void checkboxClick(){
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                this.checkboxClck.click();
                break;
            case "ios":
                this.checkboxClck.click();
                break;
            default:
                this.checkboxClck.click();
        }

    }


    @FindBy(xpath = "//input[@value='SUBMIT']")
    @AndroidFindBy(accessibility = "inptButton")
    @iOSXCUITFindBy(accessibility = "inptButton")
    public WebElement clickOnSubmit;

    public WebElement clickOnSubmit(){
        return clickOnSubmit;
    }

    public void clickOnSub(){
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                this.clickOnSubmit.click();
                break;
            case "ios":
                this.clickOnSubmit.click();
                break;
            default:
                this.clickOnSubmit.click();
        }

    }
    @FindBy(xpath = "//input[@value='Reject']")
    @AndroidFindBy(accessibility = "btnRejPopup ")
    @iOSXCUITFindBy(accessibility = "btnRejPopup ")
    public WebElement clickOnReject;

    public WebElement clickOnReject(){
        return clickOnReject;
    }
    public void clickOnRej(){
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                this.clickOnReject.click();
                break;
            case "ios":
                this.clickOnReject.click();
                break;
            default:
                this.clickOnReject.click();
        }

    }
    @FindBy(xpath = "//p[@class='MuiTypography-root MuiTypography-body1 MuiTypography-gutterBottom']")
    @AndroidFindBy(accessibility = "android:id/message")
    //@iOSXCUITFindBy(accessibility = "android:id/message")
    public WebElement getmessage;


    @FindBy(xpath = "//span[@class='MuiButton-label' and text()='SAVE']")
    public WebElement saveRenewalPremium;

    public WebElement saveRenewalPremium(){
        return saveRenewalPremium;
    }
    public void saveRenewalPrem(){
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                break;
            case "ios":
                break;
            default:
                this.saveRenewalPremium.click();
        }

    }

    @FindBy(xpath = "//div[text()='Your payment has been authorized successfully!']")
    @AndroidFindBy(accessibility = "android:id/message")
   // @iOSXCUITFindBy(accessibility = "android:id/message")
    public WebElement status;

    @FindBy(xpath = "//button[@class='btn checkout_btn btnOk']")
    @AndroidFindBy(accessibility = "android:id/button1 ")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"Checkout Demo\"]")
    public WebElement clickOnOk;

    @FindBy(xpath = "//div[@class='summary-payment-status']")
    @AndroidFindBy(accessibility = "android:id/message")
    //@iOSXCUITFindBy(accessibility = "android:id/message")
    public WebElement paymentStatus;

    @FindBy(xpath = "//button[text()='Retry']")
    public WebElement retryButton;

    public void verifyRepayment(){
        waitUtils.waitForElementToBeVisible(driver,retryButton,30,"Retry button is not visible");
    }

    @FindBy(xpath ="//div[contains(@class,'text-center')]")
    @AndroidFindBy(accessibility = "android:id/message")
    //@iOSXCUITFindBy(accessibility = "android:id/message")
    public WebElement statusMsg;

    public String paymentStatusMassege(){
        String statusMsg=" ";
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                statusMsg=this.statusMsg.getText();
                break;
            case "ios":
                statusMsg=this.statusMsg.getText();
                break;
            default:
                statusMsg=this.statusMsg.getText();
        }
        return statusMsg;
    }

    @FindBy(xpath = "//div[@class='text-danger text-center']")
    @AndroidFindBy(accessibility = "android:id/message")
    //@iOSXCUITFindBy(accessibility = "android:id/message")
    public WebElement dangerMessage;

    public WebElement faildAsMarchent(){
        return this.dangerMessage;
    }

    @FindBy(xpath = "//button[@data-track-mode='ReceiptCancel']")
    public WebElement cancelReg;

    public WebElement getCancelReg(){
        return  this.cancelReg;

    }
    @FindBy(xpath = "//div[@class='jss21' and contains(text(),'Direct Bill')]")
    public WebElement directBill;

    public WebElement getDirectBill(){
        return this.directBill;
    }
    @FindBy(xpath = "//input[@name='btnReject']")
    public WebElement rejectYes;

    public  WebElement getRejectYes(){
        return this.rejectYes;
    }
    @FindBy(xpath = "//input[@name='btnRejCancel']")
    public WebElement rejectCancel;

    public  WebElement getRejectCancel(){
        return this.rejectCancel;
    }

    @FindBy(xpath = "//div[contains(text(),'METHOD SELECTED')]/following-sibling::div[@class='summary-payment-value']")
    public  WebElement getPaymentStatus;


    @FindBy(xpath = "//*[contains(text(),'PREFERRED DRAW DATE')]/following-sibling::div")
    public WebElement preferedDate;

    public void enachRegistration(){
        waitUtils.wait5Seconds();
        //enachPage.directBill
        commonUtils.selectButtonByName("Direct Bill",driver);
        waitUtils.wait2Seconds();
        commonUtils.selectButtonByName("SAVE",driver);
        waitUtils.wait2Seconds();
        String actualMessage= getPaymentStatus.getText();
        waitUtils.Asserting("equals",actualMessage,"DIRECT BILL");
        waitUtils.wait2Seconds();
        commonUtils.selectButtonByName("NEXT",driver);
        waitUtils.Asserting("equals",titleOfPage.getText(),"Add Nominee");
    }

}
