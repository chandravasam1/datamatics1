package com.absli.pageObjects;

import com.absli.helpers.jsonReaders.ReadJson;
import com.absli.helpers.models.LoginModel;
import com.absli.helpers.models.ProposerModel;
import com.absli.utils.CommonUtils;
import com.absli.utils.WaitUtils;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import tests.BaseTest;

import java.util.List;

import static com.absli.logger.LoggingManager.logMessage;

public class InstaVerifyPage extends Page {
    WebDriver driver;
    CommonUtils commonUtils;
    WaitUtils waitUtils;

    public InstaVerifyPage(WebDriver driver) throws InterruptedException {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        logMessage("Initializing the " + this.getClass().getSimpleName() + " elements");
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
        waitUtils = new WaitUtils();
        commonUtils = new CommonUtils();
    }


///Insta verify

    @FindBy(xpath = "//div[@class='pathname' and text()='INSTA Verify']")
    @AndroidFindBy(xpath = "//android.view.View[@text=\"Insta Verify\"]")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"Insta Verify\"])[2]")
    public WebElement instaVerifyScreenTitle;

    @FindBy(xpath = "//span[contains(text(),'PHOTO VERIFICATION')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text=\"PHOTO VERIFICATION\"]")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeButton[@name=\"continueBtn\"])[1]")
    public WebElement photoVerificationTab;

    @FindBy(xpath = "//div[text()='Photo Verification']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text=\"Photo Verification\"]")
    @iOSXCUITFindBy(accessibility = "Photo Verification")
    public WebElement photoVerificationText;

    @FindBy(xpath = "//span[contains(text(),'VIDEO VERIFICATION')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text=\"VIDEO VERIFICATION \"]")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeButton[@name=\"continueBtn\"])[2]")
    public WebElement videoVerificationTab;

    @FindBy(xpath = "//img[@alt='camera']")
    //@AndroidFindBy(xpath = "(//android.widget.ImageView)[31]")
    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text,'Start Photo Verification')]//..//android.widget.ImageView")
    public WebElement cameraTab;


    @FindBy(xpath = "//div[contains(text(),'Selfie Tips')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text=\"Selfie Tips\"]")
    public WebElement selfieScreenTitle;

    @FindBy(xpath = "//button[contains(text(),'Proceed to Take Selfie')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text=\"Proceed to Take Selfie\"]")
    public WebElement takeSelfieTab;

    @FindBy(xpath = "//div[contains(text(),'Capture Now')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text=\"Capture Now\"]")
    public WebElement waitForCapture;

    @FindBy(xpath = "//a[@id='hv-camera-capture-button']//img")
    @AndroidFindBy(id = "com.absli.leap:id/camera_icon")
    public WebElement captureImage;

    @FindBy(xpath = "//div[contains(text(),'Capture ID Proof')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text=\"Capture ID Proof\"]")
    public WebElement captureIDProofText;

    @FindBy(xpath = "//button/span[contains(text(),'SELECT ID PROOF TYPE')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text=\"SELECT ID PROOF TYPE\"]")
    public WebElement selectIDProofType;

    @FindBy(xpath = "//div[contains(text(),'Select type of ID Proof')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text=\"Select Type Of ID Proof\"]")
    public WebElement selectIDProofText;

    @FindBy(xpath = "//div[@role='button']")
    @AndroidFindBy(xpath = "//android.widget.EditText")
    public WebElement selectTypeOfProof;

    /*@FindBy(xpath = "//ul//li/span[contains(text(),' ')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text,' ')]")*/
    @FindBy(xpath = "//ul//li/span[contains(text(),'PAN')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text,'PAN')]")
    public List<WebElement> listOfIDProofs;

    public void selectIDproof(String proofName) {
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                WebElement proof = driver.findElement(By.xpath("//android.widget.TextView[contains(@text='" + proofName + " ')]"));
                proof.click();
                break;
            case "ios":
                break;
            default:
                break;
        }
    }


    @FindBy(xpath = "//*[text()='PROCEED']")
    @AndroidFindBy(accessibility = "saveBtn")
    private WebElement eleProceedBtn;

    @AndroidFindBy(id = "com.absli.leap:id/title_text")
    public WebElement IDCaptureTips;

    @AndroidFindBy(id = "com.absli.leap:id/proceed_button")
    public WebElement proceedToCapture;

    @AndroidFindBy(id = "com.absli.leap:id/title_text")
    public WebElement docsCaptureTitle;

    @AndroidFindBy(id = "com.absli.leap:id/camera_bubble")
    public WebElement captureFrontSide;

    @AndroidFindBy(id = "com.absli.leap:id/title_text")
    public WebElement reviewPhoto;

    @AndroidFindBy(id = "com.absli.leap:id/camera_bubble")
    public WebElement captureBackSide;


    @FindBy(xpath = "//input[@id='uploadedFile']")
    WebElement uploadFile;

    @FindBy(xpath = "//button[text()='Use this Document']")
    @AndroidFindBy(id = "com.absli.leap:id/confirm_button")
    WebElement useThisDoc;

    @FindBy(xpath = "//div[contains(text(),'Photo Captured')]")
    @AndroidFindBy(xpath = "//android.view.View[@text=\"Identity Verification\"]")
    WebElement summaryPhoto;

    //video verification
    @iOSXCUITFindBy(accessibility = "Video Verification")
    @AndroidFindBy(xpath = "//android.widget.TextView[(@text='Video Verification')]")
    public WebElement videoVerificationText;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"Start Video Verification\"]/XCUIElementTypeOther")
    @AndroidFindBy(xpath = "(//android.view.ViewGroup[@index='2']/android.widget.ImageView)[2]")
    public WebElement startVideo;

    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Select Language']")
    public WebElement selectLanguageText;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"ENGLISH\"])[2]")
    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text,'ENGLISH')]")
    public WebElement selectLanguage;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[contains(@name,\"hereby confirm that I have understood the details of the (BSLI Life Shield) and agree to the terms and conditions explained to me. I hereby provide my consent to process this application.\")])[8]/XCUIElementTypeOther[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther[2]")
    @AndroidFindBy(xpath = "(//android.widget.ImageView)[35]")
    public WebElement startVideoButton;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[contains(@name,\"Secs\")])[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther")
    public WebElement stopVideoButton;

    @AndroidFindBy(xpath = "(//android.widget.Button[@content-desc=\"saveBtn\"])[2]")
    private WebElement eleInstaVerifySubmitBtn;

    //@AndroidFindBy(xpath = "//android.widget.Button[@content-desc=\"continueBtn\"]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='DO IT LATER']")
    @FindBy(xpath = "//span[text()='DO IT LATER ']")
    //@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"laterBtn\"]")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"continueBtn\"`][1]")
    public WebElement eleInstVerifyDoItLaterBtn;


    public void instaVerifyPage() throws Exception {
        switch (BaseTest.PLATFORM_NAME.toLowerCase()) {
            case "android":
                waitUtils.waitForElementToBeVisible(driver, instaVerifyScreenTitle);
                commonUtils.scrollToElementAndClick(driver, photoVerificationTab);
                waitUtils.waitForElementToBeVisible(driver, photoVerificationText);
                commonUtils.scrollToElementAndClick(driver, cameraTab);
                waitUtils.wait2Seconds();
                waitUtils.waitForElementToBeVisible(driver, selfieScreenTitle);
                commonUtils.scrollToElementAndClick(driver, takeSelfieTab);
                //waitUtils.wait2Seconds();
                waitUtils.waitForElementToBeVisible(driver, waitForCapture);
                //driver.switchTo().alert().accept();
                commonUtils.chooseActionButton(captureImage);

                int i = 5;
                while (i > 0) {
                    if (commonUtils.isDisplayed(driver, captureImage)) {
                        System.out.println("Camera cpature button displayed --------");
                        commonUtils.chooseActionButton(captureImage);
                    }
                    i--;
                }
                //waitUtils.wait2Seconds();
                //commonUtils.selectButtonByName("PROCEED", driver);
                waitUtils.waitUntilVisible(driver, eleProceedBtn, 30);
                commonUtils.chooseActionButton(eleProceedBtn);
                waitUtils.waitForElementToBeVisible(driver, captureIDProofText);
                commonUtils.scrollToElementAndClick(driver, selectIDProofType);
                waitUtils.waitForElementToBeVisible(driver, selectIDProofText);
                commonUtils.scrollToElementAndClick(driver, selectTypeOfProof);
                waitUtils.wait5Seconds();

                commonUtils.getValuesFromList(driver, listOfIDProofs, "Voter ID");
                commonUtils.chooseActionButton(eleProceedBtn);
                waitUtils.wait5Seconds();
                waitUtils.waitForElementToBeVisible(driver, IDCaptureTips);
                commonUtils.scrollToElementAndClick(driver, proceedToCapture);
                waitUtils.wait2Seconds();
                waitUtils.waitForElementToBeVisible(driver, docsCaptureTitle);
                commonUtils.scrollToElementAndClick(driver, captureFrontSide);
                waitUtils.waitForElementToBeVisible(driver, reviewPhoto);
                commonUtils.scrollToElementAndClick(driver, useThisDoc);
                waitUtils.wait2Seconds();
                waitUtils.waitForElementToBeVisible(driver, docsCaptureTitle);
                commonUtils.scrollToElementAndClick(driver, captureBackSide);
                waitUtils.waitForElementToBeVisible(driver, reviewPhoto);
                commonUtils.scrollToElementAndClick(driver, useThisDoc);
                waitUtils.waitForElementToBeVisible(driver, summaryPhoto);

                waitUtils.wait10Seconds();
                commonUtils.chooseActionButton(eleInstaVerifySubmitBtn);
                //commonUtils.selectButtonByName("PROCEED", driver);
                break;
               /*


                    waitUtils.waitForElementToBeVisible(driver, instaVerifyScreenTitle);
                    commonUtils.scrollToElementAndClick(driver,videoVerificationTab);
                    waitUtils.waitForElementToBeVisible(driver,videoVerificationText);
                   // commonUtils.scrollToElementAndClick(driver,startVideo);
                    this.startVideo.click();
                    waitUtils.wait2Seconds();
                    waitUtils.waitForElementToBeVisible(driver,selectLanguageText);
                    commonUtils.scrollToElementAndClick(driver,selectLanguage);
                    commonUtils.selectButtonByName("CONTINUE",driver);
                    waitUtils.waitForElementToBeVisible(driver,instaVerifyScreenTitle);
                   //commonUtils.scrollToElementAndClick(driver,);
*/
            case "ios":
                break;
            default:

                waitUtils.waitForElementToBeVisible(driver, instaVerifyScreenTitle);
                commonUtils.scrollToElementAndClick(driver, photoVerificationTab);
                waitUtils.waitForElementToBeVisible(driver, photoVerificationText);
                commonUtils.scrollToElementAndClick(driver, cameraTab);
                waitUtils.wait2Seconds();
                waitUtils.waitForElementToBeVisible(driver, selfieScreenTitle);
                commonUtils.scrollToElementAndClick(driver, takeSelfieTab);
                waitUtils.wait2Seconds();
                waitUtils.waitForElementToBeVisible(driver, waitForCapture);
                waitUtils.wait2Seconds();
                //driver.switchTo().alert().accept();
                commonUtils.scrollToElementAndClick(driver, captureImage);
                waitUtils.wait5Seconds();
                commonUtils.selectButtonByName("PROCEED", driver);
                waitUtils.wait2Seconds();
                waitUtils.waitForElementToBeVisible(driver, captureIDProofText);
                commonUtils.scrollToElementAndClick(driver, selectIDProofType);
                waitUtils.waitForElementToBeVisible(driver, selectIDProofText);
                commonUtils.scrollToElementAndClick(driver, selectTypeOfProof);
                waitUtils.wait5Seconds();
                commonUtils.getValuesFromList(driver, listOfIDProofs, "PAN Card");
                waitUtils.wait5Seconds();
                commonUtils.selectButtonByName("CONTINUE", driver);
                String path = "/Users/datamatics/Downloads/test-pan-card.jpeg";
                System.out.println("PATH NAME PAN CARD ======>" + path);
                this.uploadFile.sendKeys(path);
                waitUtils.wait2Seconds();
                this.useThisDoc.click();
                waitUtils.wait5Seconds();
                this.uploadFile.sendKeys(path);

                waitUtils.wait2Seconds();
                this.useThisDoc.click();
                waitUtils.wait10Seconds();
                commonUtils.selectButtonByName("PROCEED", driver);
                break;

        }
    }
}

