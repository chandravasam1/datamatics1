package com.absli.pageObjects;

import com.absli.helpers.jsonReaders.ReadJson;
import com.absli.helpers.models.LoginModel;
import com.absli.helpers.models.ProposerModel;
import com.absli.utils.CommonUtils;
import com.absli.utils.WaitUtils;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import tests.BaseTest;

import java.util.List;

import static com.absli.logger.LoggingManager.logMessage;

public class DocumentsUploadPage extends Page{
    WebDriver driver;
    CommonUtils commonUtils;
    ReadJson jsonObj;
    LoginModel loginModel;
    SignInPage signIn;
    DashboardPage dashPage;
    WaitUtils waitUtils;
    ProposerModel proposerModel;

    public DocumentsUploadPage(WebDriver driver) throws InterruptedException {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        logMessage("Initializing the " + this.getClass().getSimpleName() + " elements");
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);

        waitUtils = new WaitUtils();
        commonUtils = new CommonUtils();
    }

    @FindBy(xpath = "//input[@placeholder='Enter Weight']")
    @AndroidFindBy(xpath = "//android.widget.EditText[@content-desc=\"'10'\"]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name=\"'10'\"]")
    public WebElement weightField;

    @FindBy(xpath = "//div[contains(text(),'9.0 Review & Acceptance')]")
    @AndroidFindBy(xpath = "//android.view.View[@text='9.0 Review & Acceptance']")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"9.0 Review & Acceptance\"])[2]")
    public  WebElement RNAscreentitle;

    @FindBy(xpath = "//input[@name='userAgreementStatus']")
    @AndroidFindBy(xpath = "//android.widget.CheckBox[@content-desc=\"agree\"]")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"agree\"])[2]")
    public WebElement userAgreement;

    @FindBy(xpath = "//span[contains(text(),'SEND FOR REVIEW')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text=\"SEND FOR REVIEW\"]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"continueButton\"]")
    public WebElement sendReviewButton;

    public void setWeightField(String weightValue){
        WebElement weightField;

        switch (BaseTest.PLATFORM_NAME.toLowerCase()){
            case "android":
                weightField=driver.findElement(By.xpath("//android.widget.EditText[@content-desc=\"'10'\"]"));
                weightField.sendKeys(weightValue);
                break;
            case "ios":
                weightField=driver.findElement(By.xpath("//XCUIElementTypeTextField[@name=\"'10'\"]"));
                weightField.sendKeys(weightValue);
                break;
            default:
                weightField=driver.findElement(By.xpath("//input[@placeholder='Enter Weight']"));
                weightField.sendKeys(weightValue);
                break;
        }
    }

    @FindBy(xpath = "//div[contains(text(),'10. Payment Mode')]")
    @AndroidFindBy(xpath = "//android.view.View[@text='10.0 Payment Mode']")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"10.0 Payment Mode\"])[2]")
    public WebElement paymentScreenTitle;

    @FindBy(xpath = "//div[contains(text(),'select mode')]/following-sibling::div//div[contains(text(),'CASH')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='CASH']")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"CASH \uDB80\uDD40\"]")
    public WebElement goToPaymentMode;

    public void setGoToPaymentMode(String paymentMode){
        WebElement payment;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                payment=driver.findElement(By.xpath("//android.widget.TextView[@text='"+paymentMode+"']"));
                payment.click();
                waitUtils.wait5Seconds();
                commonUtils.selectButtonByName("NEXT",driver);
                break;
            case "ios":
                payment=driver.findElement(By.xpath("//XCUIElementTypeButton[@name=\"CASH \uDB80\uDD40\"]"));
                payment.click();
                waitUtils.wait5Seconds();

                break;
            default:
               payment= driver.findElement(By.xpath("//div[contains(text(),'select mode')]/following-sibling::div//div[contains(text(),'"+paymentMode+"')]"));
               payment.click();
        }
    }

    @FindBy(xpath = "//div[contains(text(),'select mode')]/following-sibling::div//div[contains(text(),'CASH')]//ancestor::div[@role='button']/following-sibling::div//span[contains(text(),'Submit')")
    public WebElement submitButton;

    public void submitPaymentMode(){

    }

    @FindBy(xpath = "//div[contains(text(),'10.0 Documents')]")
    @AndroidFindBy(xpath = "//android.view.View[@text='10. Documents']")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"10. Documents\"])[2]")
    public WebElement documentScreenTitle;


    @FindBy(xpath = "//button[@id='scrollable-force-tab-0']")
    @AndroidFindBy(xpath = "//android.view.View[@content-desc=\"identityProof\"]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"identityProof\"]")
    public WebElement identityProof;

    //@FindBy(xpath = "//button[@id='scrollable-force-tab-1']")
    @FindBy(xpath = "//span[contains(text(),'Non Medical Requirements')]")
    @AndroidFindBy(xpath = "//android.view.View[@content-desc=\"Non Medical Requirements\"]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"nonMedicalDocuments\"]")
    public WebElement nonMedicalProof;

    //@FindBy(xpath = "//button[@id='scrollable-force-tab-2']")
    @FindBy(xpath = "//span[text()='Medical Requirements']")
    @AndroidFindBy(xpath = "//android.view.View[@content-desc=\"Medical Requirements\"]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"medicalDocuments\"]")
    public WebElement medicalProof;

    @FindBy(xpath = "//span[contains(text(),'Age Proof')]")
    @AndroidFindBy(xpath = "//android.view.View[@content-desc=\"ageProof\"]")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"ageProof\"]")
    public WebElement proofOfDocs;

    @FindBy(xpath = "//label[contains(text(),'Select Type of Document')]/following-sibling::div//div[@role='button']")
    @AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"docType\"]/android.view.ViewGroup[2]/android.view.ViewGroup")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"docType\"])[3]")
    public WebElement getSelectTypeOfDoc;

    @FindBy(xpath = "//ul//li[@role='option']/span[contains(text(),'')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text,' ')]")
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name,' '])[2]")
    public List<WebElement> listOfDocs;

    @FindBy(xpath = "//input[@type='file']")
    @AndroidFindBy(xpath = "//android.widget.Button[@content-desc=\"uploadPhotoBtn\"]")
    public WebElement uploadFile;

    public void setUploadFile(){
        switch (BaseTest.PLATFORM_NAME.toLowerCase()){
            case "android":
                this.uploadFile.sendKeys("file:///storage/emulated/0/Downloads/PAN Card.jpg");
                break;
            case "ios":
                break;
            default:
                this.uploadFile.sendKeys("C:\\PAN CARD.jpg");
                break;
        }

    }

    @FindBy(xpath = "//div[@class='right-end']/p[contains(text(),'PAN Card')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text=\"Document Type \"]/..//android.widget.TextView[@text=\"PAN Card \"]")
    public WebElement validateDocumentType;

    public String validateDocumentType(String docType){
        WebElement validateDocType;
        String docTypeValue = null;
        switch (BaseTest.PLATFORM_NAME.toLowerCase()){
            case "android":
                validateDocType=driver.findElement(By.xpath("//android.widget.TextView[@text=\"Document Type \"]/..//android.widget.TextView[@text=\"PAN Card \"]"));
                docTypeValue=validateDocType.getText();
                break;
            case "ios":
                break;
            default:
                validateDocType=driver.findElement(By.xpath("//div[@class='right-end']/p[contains(text(),'"+docType+"')]"));
                docTypeValue=validateDocType.getText();
                break;
        }
        return docTypeValue.trim();
    }


    @FindBy(xpath = "//button[@id='scrollable-force-tab-1']")
    public WebElement ageProof;

    public void setIdentityProof(String proofName){
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                break;
            case "ios":
                break;
            default:

                break;
        }
    }

    @FindBy(xpath = "//label[@id='select-label']/following-sibling::div/div[@role='button']")
    public  WebElement selectTypeOfDoc;

    public void selectTypeOfDocument(String documentName){
        WebElement document;
        switch (BaseTest.PLATFORM_NAME){
            case "android":
                break;
            case "ios":
                break;
            default:
                document=driver.findElement(By.xpath("//ul//li//span[contains(text(),'"+documentName+"')]"));
                document.click();
                break;

        }
    }
    @FindBy(xpath = "(//div[@class='delete-container'])[2]")
    public WebElement deleteProof;

    @FindBy(xpath = "//div[contains(text(),' ')]/ancestor::div[@class='left-end']/following-sibling::div/button")
    public WebElement nonMedicalProofDocs;

    public void setNonMedicalProofDocs(String docType){
        WebElement formType;

        switch (BaseTest.PLATFORM_NAME.toLowerCase()){
            case "android":
                driver.findElement(By.xpath("//android.widget.TextView[@text=\"TO BE INSURED\"]")).click();
               formType=driver.findElement(By.xpath("//android.view.ViewGroup/..//android.widget.TextView[@text=\""+docType+"\"]/..//android.widget.TextView[@text=\"UPLOAD\"]"));

                break;
            case "ios":
                break;
            default:
                formType=driver.findElement(By.xpath("//div[contains(text(),'"+docType+" ')]/ancestor::div[@class='left-end']/following-sibling::div/button"));
                formType.sendKeys("C:\\PAN CARD.jpg");
                break;
        }
    }
    public void setMedicalProofDocs(String docType){
        WebElement formType;

        switch (BaseTest.PLATFORM_NAME.toLowerCase()){
            case "android":
                driver.findElement(By.xpath("(//android.widget.TextView[@text=\"TO BE INSURED\"])")).click();
                waitUtils.wait2Seconds();

                formType=driver.findElement(By.xpath("//android.view.ViewGroup/..//android.widget.TextView[@text=\""+docType+"\"]/..//android.widget.TextView[@text=\"UPLOAD\"]"));

                break;
            case "ios":
                break;
            default:
                formType=driver.findElement(By.xpath("//div[contains(text(),'"+docType+" ')]/ancestor::div[@class='left-end']/following-sibling::div/button"));
                formType.sendKeys("C:\\PAN CARD.jpg");
                break;
        }
    }


}
