package com.absli.pageObjects;

import com.absli.helpers.jsonReaders.ReadJson;
import com.absli.helpers.models.LoginModel;
import com.absli.helpers.models.ProposerModel;
import com.absli.utils.CommonUtils;
import com.absli.utils.WaitUtils;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import io.appium.java_client.pagefactory.AndroidFindBy;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import tests.BaseTest;

import static com.absli.logger.LoggingManager.logMessage;

public class PaymentSummaryPage extends Page{
    WebDriver driver;
    CommonUtils commonUtils;
    ReadJson jsonObj;
    LoginModel loginModel;
    SignInPage signIn;
    DashboardPage dashPage;
    WaitUtils waitUtils;
    OccupationPage occupationPage;
    QualificationPage qualificationPage;
    ChequePage chequePage;
    ProposerModel proposerModel;
    CashPage cashPage;

    public PaymentSummaryPage(WebDriver driver) throws InterruptedException {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        logMessage("Initializing the " + this.getClass().getSimpleName() + " elements");
        PageFactory.initElements(new AppiumFieldDecorator(driver), CashPage.class);

        /*jsonObj = new ReadJson();
        signIn = new SignInPage(driver);
        dashPage = new DashboardPage(driver);*/
        waitUtils = new WaitUtils();
        commonUtils = new CommonUtils();
        occupationPage = new OccupationPage(driver);
        qualificationPage = new QualificationPage(driver);
    }

    @FindBy(xpath = "//div[contains(text(),'10. Payment Mode')]")
    @AndroidFindBy(xpath = "//android.view.View[@text='10.0 Payment Mode']")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeOther[`label == '10.0 Payment Mode'`]")
    public WebElement elePaymentModeTitle;

    @FindBy(xpath = "//div[text()='Payment Summary']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text=\'Payment Summary\']")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == 'Payment Summary'`]")
    public WebElement elePaymentSummary;

    @FindBy(xpath = "//div[@id='2']//span[text()='Payment Sucessful']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Payment Sucessful']")
    @iOSXCUITFindBy(iOSNsPredicate ="label=='CASH 󰅃' AND name=='Payment Sucessful'")
    //@iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == 'Payment Sucessful'`]")
    public WebElement eleCashPaymentSuccess;

    @FindBy(xpath = "//div[@id='3']//span[text()='Payment Sucessful']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Payment Sucessful']")
    @iOSXCUITFindBy(iOSNsPredicate ="label=='WIN BACK 󰅀' AND name=='Payment Sucessful'")
    public WebElement eleWinBackPaymentSuccess;

    @FindBy(xpath = "//div[text()='CASH']/../div[text()='Paid via ']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Paid via Cash']")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == 'Paid via Cash'`]")
    public WebElement elePaymentViaCash;

    @FindBy(xpath = "//div[text()='WINBACK']/../div[text()='Paid via ']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Paid via WinBack']")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeStaticText[`label == 'Paid via WINBACK'`]")
    public WebElement elePaymentViaWinBack;

    @FindBy(xpath = "//div[@id='2']//div[text()='Amount Received']/../div[2]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Amount Recieved']")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeStaticText' AND label=='Paid via Cash' AND name BEGINSWITH[cd] 'Rs'")
    public WebElement eleCashAmountReceived;

    @FindBy(xpath = "//div[@id='3']//div[text()='Amount Received']/../div[2]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Amount Recieved']")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeStaticText' AND label=='Paid via WINBACK' AND name BEGINSWITH[cd] 'Rs'")
    public WebElement eleWinBackAmountReceived;

    @FindBy(xpath = "//div[text()='Policy No']/../div[2]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Policy no.1']/following-sibling::android.widget.TextView[1]")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeStaticText' AND label=='Policy no.1'")
    public WebElement elePolicyNumber;

    @FindBy(xpath = "//div[text()='Total Amount Paid']/../div[2]/span[2]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Total Amount Paid']/following-sibling::android.widget.TextView")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeStaticText' AND label=='Total Amount Paid' AND name BEGINSWITH[cd] 'Rs'")
    public WebElement eleTotalAmountPaid;

    @AndroidFindBy(xpath = "//android.widget.TextView[@text='CASH']/following-sibling::android.widget.TextView")
    public WebElement eleCashDropDownBtn;

    @AndroidFindBy(xpath = "//android.widget.TextView[@text='WIN BACK']/following-sibling::android.widget.TextView")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == 'WIN BACK \uDB80\uDD40'`]")
    public WebElement eleWinBackDropDownBtn;

    public void validateCashPaymentSummary() {
        Assert.assertTrue(elePaymentSummary.isDisplayed(),"Payment Summary is not displayed");
        Assert.assertTrue(elePaymentViaCash.isDisplayed(),"Payment via Cash is not displayed");
        Assert.assertTrue(elePaymentViaWinBack.isDisplayed(),"Payment via WIN BACK is not displayed");
        Assert.assertTrue(eleCashPaymentSuccess.isDisplayed(),"Cash Payment Success message is not displayed");
        Assert.assertTrue(eleCashAmountReceived.isDisplayed(),"Cash Amount received is not displayed");


        switch (BaseTest.PLATFORM_NAME) {
            case "android":
                eleWinBackDropDownBtn.click();
                waitUtils.waitForElementToBeVisible(driver,eleWinBackPaymentSuccess,30,"Element not visible");
                Assert.assertTrue(eleWinBackPaymentSuccess.isDisplayed(),"WinBack Payment Success is not displayed");
                Assert.assertTrue(eleWinBackAmountReceived.isDisplayed(),"WinBack Amount received is not displayed");
                Assert.assertTrue(elePolicyNumber.isDisplayed(),"Policy Number is not displayed");
                Assert.assertTrue(eleTotalAmountPaid.isDisplayed(),"Amount Paid is not displayed");
                break;
            case "ios":

                eleWinBackDropDownBtn.click();
                Assert.assertTrue(eleWinBackPaymentSuccess.isDisplayed(),"WinBack Payment Success is not displayed");
                Assert.assertTrue(eleWinBackAmountReceived.isDisplayed(),"WinBack Amount received is not displayed");
                Assert.assertTrue(elePolicyNumber.isDisplayed(),"Policy Number is not displayed");
                Assert.assertTrue(eleTotalAmountPaid.isDisplayed(),"Amount Paid is not displayed");

                break;
            default:
                Assert.assertTrue(eleWinBackPaymentSuccess.isDisplayed(),"WinBack Payment Success is not displayed");
                Assert.assertTrue(eleWinBackAmountReceived.isDisplayed(),"WinBack Amount received is not displayed");
                Assert.assertTrue(elePolicyNumber.isDisplayed(),"Policy Number is not displayed");
                Assert.assertTrue(eleTotalAmountPaid.isDisplayed(),"Amount Paid is not displayed");


        }
    }
}
