package com.absli.pageObjects;

import com.absli.helpers.jsonReaders.ReadJson;
import com.absli.utils.CommonUtils;
import com.absli.utils.WaitUtils;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.IOSElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;
import tests.BaseTest;

import static com.absli.logger.LoggingManager.logMessage;

public class ReviewAcceptPage extends Page {

    WebDriver driver;
    CommonUtils commonUtils;
    ReadJson jsonObj;
    SignInPage signIn;
    DashboardPage dashPage;
    WaitUtils waitUtils;


    public ReviewAcceptPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        logMessage("Initializing the " + this.getClass().getSimpleName() + " elements");
        PageFactory.initElements(new AppiumFieldDecorator(driver), ReviewAcceptPage.this);

        //jsonObj = new ReadJson();
        //signIn = new SignInPage(driver);
        //dashPage = new DashboardPage(driver);
        waitUtils = new WaitUtils();
        commonUtils = new CommonUtils();
    }

    @FindBy(css = ".application-number")
    /*@AndroidFindBy(uiAutomator = "new UiScrollable(new UiSelector().scrollable(true))"  +
            ".scrollIntoView(new UiSelector().className(\"android.widget.TextView\").instance(3))")*/
    @AndroidFindBy(accessibility = "applicationNumberText")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"YOUR APPLICATION\"]//..//XCUIElementTypeStaticText[2]")
    public WebElement eleApplNumberValue;

    @FindBy(xpath = "(//div[@class='policy-sum-amount'])[1]")
    @AndroidFindBy(accessibility = "sumAssuredAmountText")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeOther' AND name BEGINSWITH[cd] 'Policy Sum Assured'")
    public WebElement eleSumAssuredValue;

    @FindBy(xpath = "(//div[@class='policy-sum-amount'])[2]")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeOther' AND name BEGINSWITH[cd] 'Premium Amount'")
    @AndroidFindBy(accessibility = "premiumAmountText")
    public WebElement elePremiumAmountValue;

    @FindBy(id = ".heading-accordian")
    private WebElement eleHeadingTabs;

    @FindBy(xpath = "//input[@name='userAgreementStatus']//..")
    @iOSXCUITFindBy(iOSNsPredicate = "label == \"agree\" AND name == \"agree\" AND value == \"checkbox, not checked\"")
    @AndroidFindBy(accessibility = "agree")
    public WebElement eleAgreeCheckbox;

    @FindBy(xpath = "//span[text()='SEND FOR REVIEW']")
    @AndroidFindBy(accessibility = "rnaReviewButton")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"rnaReviewButton\"`]")
    public WebElement eleSendForReviewBtn;

    @FindBy(xpath = "(//div[@class='listedlineliValue'])[1]")
    private WebElement eleProtectionPlanName;

    @FindBy(xpath = "(//div[@class='listedlineliValue'])[2]")
    private WebElement elePaymentFreq;

    @FindBy(xpath = "(//div[@class='listedlineliValue'])[3]")
    private WebElement elePolicyTerm;

    @FindBy(xpath = "(//div[@class='heading-accordian'])[position()=1]")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeOther' AND name BEGINSWITH[cd] 'Proposer'")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Proposer']")
    public WebElement eleProposerTab;

    @FindBy(xpath = "(//div[@class='heading-accordian'])[position()=2]")
    private WebElement eleNomineeTab;

    @FindBy(xpath = "(//div[@class='heading-accordian'])[position()=3]")
    public WebElement eleBankTab;

    @FindBy(xpath = "(//div[@class='heading-accordian'])[position()=4]")
    private WebElement eleAddressTab;

    @FindBy(xpath = "(//div[@class='listedlineliValue'])[4]")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeOther' AND name BEGINSWITH[cd] 'Proposer'")
    public WebElement eleProposerName;

    @FindBy(xpath = "(//div[@class='listedlineliValue'])[5]")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeOther' AND name BEGINSWITH[cd] 'Proposer'")
    public WebElement eleProposerMobile;

    @FindBy(xpath = "(//div[@class='listedlineliValue'])[6]")
    private WebElement eleProposerPan;

    @FindBy(xpath = "(//div[@class='listedlineliValue'])[12]")
    public WebElement eleBankAccNo;

    @FindBy(xpath = "(//div[@class='listedlineliValue'])[11]")
    public WebElement eleIfscCode;

    @FindBy(xpath = "//span[text()='EDIT']")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"editBtn\"`]")
    public WebElement wlwRnaEditBtn;

    @FindBy(css = "#customized-dialog-title")
    public WebElement eleRnaEditAlert;

    @FindBy(xpath = "//span[text()='YES']")
    public WebElement eleAlertYesbtn;


    @AndroidFindBy(xpath = "//android.view.View[contains(@text,'Review')]")
    @FindBy(xpath = "//div[@class='pathname' and contains(text(),'Review')]")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeOther' AND name BEGINSWITH[c] 'Review'")
    public WebElement eleRnaNavText;

    @FindBy(css = ".accept-status-green")
    @iOSXCUITFindBy(accessibility = "STATUS: REVIEWED AND AGREED")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='REVIEWED AND AGREED']")
    public WebElement eleStatusReview;

    @FindBy(css = ".accept-status-green")
    @iOSXCUITFindBy(accessibility = "STATUS: REVIEWED AND ACCEPTED")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='REVIEWED AND ACCEPTED']")
    public WebElement eleStatusAccept;

    @FindBy(xpath = "//span[text()='ENTER OTP']")
    public WebElement eleEnterOtpBtn;

    @FindBy(css = "#inputotp")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeTextField[`label == \"verifyCode\"`]")
    @AndroidFindBy(accessibility = "verifyCode")
    public WebElement eleOtpInput;

    @FindBy(xpath = "//div[contains(text(),'VERIFIED')]")
    private WebElement eleOtpVerifiedLabel;

    @FindBy(xpath = "//span[text()='PROCEED']")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == \"proceedButton\"`]")
    @AndroidFindBy(accessibility = "proceedButton")
    //@AndroidFindBy(xpath = "//android.view.View[contains(@text,'PROCEED')]")
    public WebElement eleProceedBtn;

    @FindBy(xpath = "//div[@class='pathname' and contains(text(),'Payment')]")
    @iOSXCUITFindBy(iOSNsPredicate = "type == 'XCUIElementTypeOther' AND name CONTAINS[cd] 'Payment'")
    @AndroidFindBy(xpath = "//android.view.View[contains(@text,'Payment')]")
    public WebElement elePaymentNavText;


    public String getSumAssured() {
        if(new BaseTest().isIOS()) {
            return ((IOSElement)eleSumAssuredValue).findElementByIosNsPredicate("type == 'XCUIElementTypeStaticText' AND name BEGINSWITH[cd] 'Rs'").getText();
        } else {
            return eleSumAssuredValue.getText();
        }
    }

    public String getPremiumAmt() {
        if(new BaseTest().isIOS()) {
            return ((IOSElement)elePremiumAmountValue).findElementByIosNsPredicate("type == 'XCUIElementTypeStaticText' AND name BEGINSWITH[cd] 'Rs'").getText();
        } else {
            return eleSumAssuredValue.getText();
        }
    }

    public String getProposerName() {
        if(new BaseTest().isIOS()) {
            return ((IOSElement)eleProposerName).findElementByIosNsPredicate("type == 'XCUIElementTypeOther' AND name BEGINSWITH[cd] 'Name'").getText();
        } else {
            return eleProposerName.getText();
        }
    }

    public String getProposerMobile() {
        if(new BaseTest().isIOS()) {
            return ((IOSElement)eleProposerMobile).findElementByIosNsPredicate("type == 'XCUIElementTypeOther' AND name BEGINSWITH[cd] 'Mobile No'").getText();
        } else {
            return eleProposerName.getText();
        }
    }

    public void inputOtp(String otp) {
        eleOtpInput.click();
        eleOtpInput.sendKeys(otp);
        switch (BaseTest.PLATFORM_NAME) {
            case "android" :
                ((AndroidDriver)driver).hideKeyboard();
                break;
            case "ios":
                ((IOSDriver)driver).hideKeyboard();
                break;
            default:
                break;
        }
    }







}
