package com.absli.pageObjects;

import com.absli.helpers.jsonReaders.ReadJson;
import com.absli.helpers.models.LoginModel;
import com.absli.helpers.models.ProposerModel;
import com.absli.utils.CommonUtils;
import com.absli.utils.WaitUtils;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import static com.absli.logger.LoggingManager.logMessage;

public class WinBackPage extends Page{
    WebDriver driver;
    CommonUtils commonUtils;
    WaitUtils waitUtils;


    public WinBackPage(WebDriver driver) throws InterruptedException {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        logMessage("Initializing the " + this.getClass().getSimpleName() + " elements");
        PageFactory.initElements(new AppiumFieldDecorator(driver), WinBackPage.class);

        //jsonObj = new ReadJson();
        //signIn = new SignInPage(driver);
        //dashPage = new DashboardPage(driver);
        waitUtils = new WaitUtils();
        commonUtils = new CommonUtils();
        //occupationPage = new OccupationPage(driver);
        //qualificationPage = new QualificationPage(driver);
    }

    @FindBy(xpath = "//div[text()='WIN BACK']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='WIN BACK']/following-sibling::android.widget.TextView")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == 'WIN BACK \uDB80\uDD40'`]")
    public WebElement eleWinBackDrpBtn;

    @FindBy(name = "policyDetails[0].policyNo")
    @AndroidFindBy(xpath = "//android.widget.EditText[@content-desc='policyno']")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeOther[`label == 'policyno'`]")
    public WebElement elePolicyNumberInput;

    @FindBy(name = "policyDetails[0].policyAmount")
    @AndroidFindBy(xpath = "//android.widget.EditText[@content-desc='policyamount']")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeTextField[`label == 'policyamount'`]")
    public WebElement elePolicyAmountInput;

    @FindBy(xpath = "//span[text()='SAVE']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='SAVE']")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == 'saveBtn'`]")
    public WebElement elePolicySaveBtn;

    @FindBy(xpath = "//span[text()='Remove']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='REMOVE']")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == 'removeBtn'`]")
    public WebElement elePolicyRemoveBtn;

    @FindBy(xpath = "//span[text()='REDEEM']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='REDEEM']")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeButton[`label == 'verifyButton'`]")
    public WebElement elePolicyRedeemBtn;

    @FindBy(xpath = "//span[text()='Payment Sucessful']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Payment Sucessful']")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeTextField[`label == 'Payment Sucessful'`]")
    public WebElement eleCashPaymentSuccessMsg;

    public void inputPaymentPolicyNumber(String PolicyNumber){
        this.elePolicyNumberInput.click();
        this.elePolicyNumberInput.clear();
        this.elePolicyNumberInput.sendKeys(PolicyNumber);
        commonUtils.enterKey(elePolicyNumberInput,driver);
    }

    public void inputPaymentPolicyAmount(String PolicyAmount){
        this.elePolicyAmountInput.click();
        this.elePolicyAmountInput.clear();
        this.elePolicyAmountInput.sendKeys(PolicyAmount);
        commonUtils.enterKey(elePolicyAmountInput,driver);
    }

}
