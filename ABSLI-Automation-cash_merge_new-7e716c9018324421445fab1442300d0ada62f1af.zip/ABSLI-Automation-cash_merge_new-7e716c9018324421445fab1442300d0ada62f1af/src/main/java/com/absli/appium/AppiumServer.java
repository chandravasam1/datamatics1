package com.absli.appium;

import com.absli.logger.LoggingManager;
import com.absli.utils.PropertiesUtils;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;
import io.appium.java_client.service.local.flags.GeneralServerFlag;

import java.io.File;
import java.io.IOException;

public class AppiumServer {

    public static AppiumDriverLocalService appium;

    public static void start() throws IOException {
        PropertiesUtils prop = new PropertiesUtils();

        AppiumServiceBuilder builder = new AppiumServiceBuilder()
                .withAppiumJS(new File(prop.getProperties("appiumServerPath")))
                .withArgument(GeneralServerFlag.SESSION_OVERRIDE);
        appium = builder.build();
        appium.start();
        LoggingManager.logMessage("Appium server has been started");
    }

    public static void stop() throws IOException {
        appium.stop();
        LoggingManager.logMessage("Appium server has been stopped");
    }
}
