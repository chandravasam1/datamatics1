package com.absli.constant;
public class Constant{

    public enum baseUrl{
        QA("https://google.com"),
        UAT("httpd:khjfdkhfdk.com");

        private String url;

        baseUrl(String s) {
            this.url = s;
        }

        public String getUrl() {
            return url;
        }
    }

    public enum platform{
        WEB("1"),
        ANDROID("2"),
        IOS("3"),
        ;
        private String platform;

        platform(String s) {
            this.platform = s;
        }

        public String getPlatform() {
            return platform;
        }
    }

    public enum apptype {
        NATIVE("1"),
        MOBILEBROWSER("2"),
        ;

        private String apptype;

        apptype(String s) {
            this.apptype = s;
        }
        public String getApptype() {
            return apptype;
        }
    }

    public enum env {
        QA("1"),
        UAT("2");

        private String env;
        env(String s) {
            this.env = s;
        }

        public String getEnv() {
            return env;
        }
    }

    public enum browser {
        CHROME,
        FIREFOX,
        SAFARI;
        ;
    }

}