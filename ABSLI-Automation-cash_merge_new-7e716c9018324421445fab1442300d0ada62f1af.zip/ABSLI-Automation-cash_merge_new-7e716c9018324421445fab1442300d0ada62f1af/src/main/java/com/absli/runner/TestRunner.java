package com.absli.runner;

import com.absli.utils.CommonUtils;
import com.absli.utils.ExcelUtils;
import com.absli.utils.PropertiesUtils;
import com.ssts.pcloudy.Connector;
import com.ssts.pcloudy.Version;
import com.ssts.pcloudy.appium.PCloudyAppiumSession;
import com.ssts.pcloudy.dto.appium.booking.BookingDtoDevice;
import com.ssts.pcloudy.dto.device.MobileDevice;
import com.ssts.pcloudy.dto.file.PDriveFileDTO;
import com.ssts.pcloudy.exception.ConnectError;
import com.ssts.util.reporting.MultipleRunReport;
import com.ssts.util.reporting.SingleRunReport;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.TestNG;
import org.testng.xml.*;
import com.absli.helpers.models.DeviceContext;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.text.ParseException;
import java.util.*;

public class TestRunner {

    public static String PLATFORM;
    public static String BROWSER;
    public static String INSTANCE;
    static PropertiesUtils prop = new PropertiesUtils();
    public static File ReportsFolder = new File(System.getProperty("user.dir")+"/Reports");
    public static Map<String, DeviceContext> allDeviceContexts = new HashMap<String, DeviceContext>();
    public static Map<String,String> testngParams = new HashMap<String,String> ();
    public static ArrayList<String> array1 = new ArrayList<>();
    public static ArrayList<String> array2 = new ArrayList<>();
    public static ArrayList<String> array3 = new ArrayList<>();
    public static int threadCount = 2;
    static int instanceCount = 1;
    static String HEADLESS_MODE = "false";

    CommonUtils utils = new CommonUtils();

    public static void main(String args[]) throws Exception {
        TestRunner runExecution = new TestRunner();
        PLATFORM = ExcelUtils.getPlatformNameFromExcel(prop.getProperties("testExcelSheet"), "controller");
        INSTANCE = ExcelUtils.getInstanceCountFromExcel(prop.getProperties("testExcelSheet"), "controller");

        System.out.println("INSTANCE --------->"+INSTANCE);
        try {
            instanceCount = Integer.parseInt(INSTANCE);
        } catch (NumberFormatException e) {
            //
        }

        System.out.println("Platform:========" + PLATFORM);
        switch (PLATFORM.toLowerCase()) {
            case "web":
                BROWSER = ExcelUtils.getBrowserNameFromExcel(prop.getProperties("testExcelSheet"), "controller");
                //This Map can hold your testng Parameters.
                testngParams.put("platformType","web");
                testngParams.put("platformName",BROWSER);
                testngParams.put("appType","native");
                testngParams.put("runType","local");
                testngParams.put("env","qa");
                testngParams.put("headless",HEADLESS_MODE);
                runExecution.runTestNGTestWeb(testngParams);
                break;
            case "android":
                //This Map can hold your testng Parameters.
                runExecution.runTestNGTestAndroid();
                break;
            case "ios" :
                runExecution.runTestNGTestIOS();
                break;
            case "all" :
                runExecution.runAllTestNGTests();
                break;
            case "mobile" :
                runExecution.runMobileTestNGTests();
                break;
            case "iosbrowser":
                runExecution.runTestNGTestIOSSafari();
                break;
            case "androidbrowser":
                runExecution.runTestNGTestAndroidChrome();
                break;
            default:
                System.out.println("invalid platform");
        }

        System.exit(0);

    }

    private void runMobileTestNGTests() throws Exception {
        runTestNGTestIOS();

        runTestNGTestAndroid();
    }

    private void runAllTestNGTests() throws Exception {
        BROWSER = ExcelUtils.getBrowserNameFromExcel(prop.getProperties("testExcelSheet"), "controller");
        //This Map can hold your testng Parameters.
        testngParams.put("platformType","web");
        testngParams.put("platformName",BROWSER);
        testngParams.put("appType","native");
        testngParams.put("runType","local");
        testngParams.put("env","qa");
        testngParams.put("headless",HEADLESS_MODE);
        runTestNGTestWeb(testngParams);

        runTestNGTestIOS();

        runTestNGTestAndroid();
    }

    private void runTestNGTestIOS() throws IOException, ConnectError, InterruptedException, ParseException {
        int deviceBookDurationTime = 240;

        // Create an instance on TestNG
        TestNG myTestNG = new TestNG();

        // Create an instance of XML Suite and assign a name for it.
        XmlSuite mySuite = new XmlSuite();
        mySuite.setName("pCloudy IOS Suite_"+utils.getCurrentTimeStamp());
        mySuite.setParallel(XmlSuite.ParallelMode.TESTS);
        //mySuite.setConfigFailurePolicy(XmlSuite.FailurePolicy.valueOf("CONTINUE"));
        mySuite.addListener("com.absli.listeners.TestLevelDriverCreator");
        mySuite.addListener("com.absli.listeners.ExtentListener");

        if (INSTANCE.equalsIgnoreCase("1")) {
            mySuite.setParallel(XmlSuite.ParallelMode.NONE);
        }
        // Create a list of XmlTests and add the Xmltest you created earlier to it.
        List<XmlTest> allDevicesTests = new ArrayList<XmlTest>();

        Connector con = new Connector("https://device.pcloudy.com/api/");
        // User Authentication over pCloudy
        String authToken = con.authenticateUser(prop.getProperties("pCloudyUser"), prop.getProperties("pCloudyAuthKey"));
        ArrayList<MobileDevice> selectedDevices = new ArrayList<>();

        selectedDevices.addAll(con.chooseDevices(authToken, "ios", new Version("12.*.*"),new Version("14.6.*"), instanceCount ));

        String sessionName = selectedDevices.get(0).display_name + " Appium iOS Session";

        String ipaFile = new ExcelUtils().getAppFileName(prop.getProperties("testExcelSheet"), prop.getProperties("controllerSheetName"),prop.getProperties("ipaFileExcelColumnName"));
        System.out.println("IPA FILE NAME ++++++++"+ipaFile);
        //String ipaPathName = new ProcessBuilder().resignIPABuilder();
        //System.out.println("##### Resigned IPA pathname ########"+ipaPathName);
        // Select apk in pCloudy Cloud Drive
        File fileToBeUploaded = new File(ipaFile);
        //File fileToBeUploaded = new File("./"+ "\" + ipaPathName + \"");

        //File fileToBeUploaded = new File(ipaPathName);

        PDriveFileDTO alreadyUploadedApp = con.getAvailableAppIfUploaded(authToken, fileToBeUploaded.getName());
        if (alreadyUploadedApp == null) {
            System.out.println("Uploading App: " + fileToBeUploaded.getAbsolutePath());
            PDriveFileDTO uploadedApp = con.uploadApp(authToken, fileToBeUploaded, false);
            System.out.println("App uploaded");
            alreadyUploadedApp = new PDriveFileDTO();
            alreadyUploadedApp.file = uploadedApp.file;
        } else {
            System.out.println("App already present. Not uploading... ");
        }


        // Book the selected devices in pCloudy
        BookingDtoDevice[] bookedDevices = con.AppiumApis().bookDevicesForAppium(authToken, selectedDevices,deviceBookDurationTime, sessionName);
        System.out.println("Devices booked successfully");

        con.AppiumApis().initAppiumHubForApp(authToken, alreadyUploadedApp);
        URL endpoint = con.AppiumApis().getAppiumEndpoint(authToken);

        System.out.println("Appium Endpoint: " + endpoint);
        URL reportFolderOnPCloudy = con.AppiumApis().getAppiumReportFolder(authToken);
        System.out.println("Report Folder: " + reportFolderOnPCloudy);

        ArrayList<String> mySuiteData = new ArrayList<String>();
        mySuiteData = ExcelUtils.getExecutionSuitesFromController(prop.getProperties("testExcelSheet"), "controller");
        System.out.println("my suites =============" + mySuiteData);

        for (int i = 0; i < bookedDevices.length; i++) {
            BookingDtoDevice aDevice = bookedDevices[i];
            SingleRunReport report = new SingleRunReport();
            PCloudyAppiumSession pCloudySession = new PCloudyAppiumSession(con, authToken, aDevice);
            String uniqueName = aDevice.manufacturer + " " + aDevice.model + " " + aDevice.version;
            String mobNo = aDevice.phoneNumber;
            System.out.println("Mobile No ========>" + mobNo);

            System.out.println("unique name ===========" + uniqueName);

            report.Header = uniqueName;
            report.Enviroment.addDetail("NetworkType", aDevice.networkType);
            report.Enviroment.addDetail("Phone Number", aDevice.phoneNumber);
            report.HyperLinks.addLink("Appium Endpoint", endpoint);
            report.HyperLinks.addLink("pCloudy Result Folder", reportFolderOnPCloudy);

            DesiredCapabilities capabilities = new DesiredCapabilities();
            capabilities.setCapability("newCommandTimeout", 90000);
            capabilities.setCapability("launchTimeout", 90000);
            capabilities.setCapability("deviceName", aDevice.capabilities.deviceName);
            capabilities.setCapability("platformName", "ios");
            capabilities.setCapability("bundleId", "com.absli.leap");
            capabilities.setCapability("acceptAlerts", true);
            capabilities.setCapability("autoDismissAlerts", true);
            capabilities.setCapability("autoGrantPermissions", true);
            capabilities.setCapability("automationName", "Appium");
            capabilities.setCapability("noReset", true);
            capabilities.setCapability("fullReset", false);
            capabilities.setCapability("pCloudy_ApplicationName", fileToBeUploaded.getName());
            capabilities.setCapability("pCloudy_DeviceManufacturer", "Apple_iPhone");

            DeviceContext aDeviceContext = new DeviceContext(uniqueName);

            aDeviceContext.endpoint = endpoint;
            aDeviceContext.device = aDevice;
            aDeviceContext.pCloudySession = pCloudySession;
            aDeviceContext.report = report;
            aDeviceContext.capabilities = capabilities;
            aDeviceContext.mobileNo = mobNo;

            allDeviceContexts.put(uniqueName, aDeviceContext);

            XmlTest aTestNgDeviceTest = new XmlTest(mySuite);
            aTestNgDeviceTest.setName("test_" + uniqueName);
            aTestNgDeviceTest.addParameter("myDeviceContext", uniqueName);
            aTestNgDeviceTest.addParameter("platformName", "ios");
            aTestNgDeviceTest.addParameter("runType", "pcloudy");
            aTestNgDeviceTest.addParameter("appType", "native");
            aTestNgDeviceTest.addParameter("env", "qa");
            aTestNgDeviceTest.addParameter("headless", "false");
            aTestNgDeviceTest.addParameter("platformType", "mobile");

            if (bookedDevices.length == mySuiteData.size()) {
                for (int j = i; j <= i; j++) {
                    aTestNgDeviceTest = addMethods(mySuiteData.get(j), aTestNgDeviceTest, mySuite, uniqueName,"ios");
                    allDevicesTests.add(aTestNgDeviceTest);
                }
            } else if (bookedDevices.length < mySuiteData.size()) {
                if (bookedDevices.length == 1) {
                    for (int j = 0; j < mySuiteData.size(); j++) {
                        aTestNgDeviceTest = addMethods(mySuiteData.get(j), aTestNgDeviceTest, mySuite, uniqueName,"ios");
                        allDevicesTests.add(aTestNgDeviceTest);
                    }
                    //includeMethodsForExecution(aTestNgDeviceTest);
                } else {
                    int splitCount = mySuiteData.size() / bookedDevices.length;
                    if (i == 0) {
                        for (int j = 0; j < splitCount; j++) {
                            aTestNgDeviceTest = addMethods(mySuiteData.get(j), aTestNgDeviceTest, mySuite, uniqueName,"ios");
                            allDevicesTests.add(aTestNgDeviceTest);
                        }
                    }
                    if (i == 1) {
                        for (int j = splitCount; j < splitCount * 2; j++) {
                            aTestNgDeviceTest = addMethods(mySuiteData.get(j), aTestNgDeviceTest, mySuite, uniqueName,"ios");
                            allDevicesTests.add(aTestNgDeviceTest);
                        }
                    }
                    if (i == 2) {
                        for (int j = splitCount * 2; j < mySuiteData.size(); j++) {
                            aTestNgDeviceTest = addMethods(mySuiteData.get(j), aTestNgDeviceTest, mySuite, uniqueName,"ios");
                            allDevicesTests.add(aTestNgDeviceTest);
                        }
                    }
                }
            } else if (bookedDevices.length > 1 && mySuiteData.size() == 1) {
                includeMethodsForExecution(aTestNgDeviceTest);
                allDevicesTests.add(aTestNgDeviceTest);
            }
        }
        //mySuite.setThreadCount(bookedDevices.length);
        if (mySuiteData.size() > 5 ) {
            threadCount = mySuiteData.size() / 2 ;
        }
        else  {
            threadCount = bookedDevices.length;
        }
        mySuite.setThreadCount(threadCount);

        // add the list of tests to your Suite.
        mySuite.setTests(allDevicesTests);

        // Add the suite to the list of suites.
        List<XmlSuite> mySuites = new ArrayList<XmlSuite>();
        mySuites.add(mySuite);

        // Set the list of Suites to the testNG object you created earlier.
        myTestNG.setXmlSuites(mySuites);

        // Create TestNG.xml
        File file = new File("./TestNG" + System.currentTimeMillis() + ".xml");
        FileWriter writer = new FileWriter(file);
        writer.write(mySuite.toXml());
        writer.close();
        // invoke run() - this will run your class.
        myTestNG.run();

        con.revokeTokenPrivileges(authToken);

        //File consolidatedReport = new File(ReportsFolder, "Consolidated Reports.html");
        //HtmlFilePrinter printer = new HtmlFilePrinter(consolidatedReport);
        MultipleRunReport multipleReports = new MultipleRunReport();
        for (DeviceContext ctx : TestRunner.allDeviceContexts.values()) {
            multipleReports.add(ctx.report);
        }
        //printer.printConsolidatedSingleRunReport(multipleReports);
        //System.out.println("Check the reports at : " + consolidatedReport.getAbsolutePath());
        System.out.println("Execution Completed...");

    }

    private void runTestNGTestAndroidChrome() throws IOException, ConnectError, InterruptedException, ParseException {
        int deviceBookDurationTime = 240;

        // Create an instance on TestNG
        TestNG myTestNG = new TestNG();

        // Create an instance of XML Suite and assign a name for it.
        XmlSuite mySuite = new XmlSuite();
        mySuite.setName("pCloudy Android Suite - Chrome browser_"+utils.getCurrentTimeStamp());
        mySuite.setParallel(XmlSuite.ParallelMode.TESTS);
        mySuite.setConfigFailurePolicy(XmlSuite.FailurePolicy.valueOf("CONTINUE"));
        mySuite.addListener("com.absli.listeners.TestLevelDriverCreator");
        if (INSTANCE.equalsIgnoreCase("1")) {
            mySuite.setParallel(XmlSuite.ParallelMode.NONE);
        }

        // Create a list of XmlTests and add the Xmltest you created earlier to it.
        List<XmlTest> allDevicesTests = new ArrayList<XmlTest>();

        Connector con = new Connector("https://device.pcloudy.com/api/");
        // User Authentication over pCloudy
        //String authToken = con.authenticateUser("sridevi.parvatikar@digital.datamatics.com", "sndm59j4b2swkw9c2shppm4n");
        String authToken = con.authenticateUser(prop.getProperties("pCloudyUser"), prop.getProperties("pCloudyAuthKey"));
        ArrayList<MobileDevice> selectedDevices = new ArrayList<>();

        selectedDevices.addAll(con.chooseDevices(authToken, "android", new Version("9.*.*"),new Version("11.*.*"), instanceCount ));

        String sessionName = selectedDevices.get(0).display_name + " Appium Android Session";

        // Book the selected devices in pCloudy
        BookingDtoDevice[] bookedDevices = con.AppiumApis().bookDevicesForAppium(authToken, selectedDevices,deviceBookDurationTime, sessionName);
        System.out.println("Devices booked successfully");

        con.AppiumApis().initAppiumHubForBrowser(authToken, "chrome");
        URL endpoint = con.AppiumApis().getAppiumEndpoint(authToken);

        System.out.println("Appium Endpoint: " + endpoint);
        URL reportFolderOnPCloudy = con.AppiumApis().getAppiumReportFolder(authToken);
        System.out.println("Report Folder: " + reportFolderOnPCloudy);

        ArrayList<String> mySuiteData = new ArrayList<String>();
        mySuiteData = ExcelUtils.getExecutionSuitesFromController(prop.getProperties("testExcelSheet"), "controller");
        System.out.println("my suites =============" + mySuiteData);

        for (int i = 0; i < bookedDevices.length; i++) {
            BookingDtoDevice aDevice = bookedDevices[i];
            SingleRunReport report = new SingleRunReport();
            PCloudyAppiumSession pCloudySession = new PCloudyAppiumSession(con, authToken, aDevice);
            String uniqueName = aDevice.manufacturer + " " + aDevice.model + " " + aDevice.version;
            System.out.println("unique name ==========="+uniqueName);

            report.Header = uniqueName;
            report.Enviroment.addDetail("NetworkType", aDevice.networkType);
            report.Enviroment.addDetail("Phone Number", aDevice.phoneNumber);
            report.HyperLinks.addLink("Appium Endpoint", endpoint);
            report.HyperLinks.addLink("pCloudy Result Folder", reportFolderOnPCloudy);

            DesiredCapabilities capabilities = new DesiredCapabilities();
            capabilities.setCapability("newCommandTimeout", 90000);
            capabilities.setCapability("launchTimeout", 90000);
            capabilities.setCapability("deviceName", aDevice.capabilities.deviceName);
            capabilities.setCapability("platformName", "android");
            //capabilities.setCapability("browserName", "chrome");
            capabilities.setCapability("appPackage", "com.android.chrome");
            capabilities.setCapability("appActivity", "org.chromium.chrome.browser.ChromeTabbedActivity");
            capabilities.setCapability("acceptAlerts", true);
            capabilities.setCapability("autoGrantPermissions", true);


            DeviceContext aDeviceContext = new DeviceContext(uniqueName);

            aDeviceContext.endpoint = endpoint;
            aDeviceContext.device = aDevice;
            aDeviceContext.pCloudySession = pCloudySession;
            aDeviceContext.report = report;
            aDeviceContext.capabilities = capabilities;

            allDeviceContexts.put(uniqueName, aDeviceContext);

            XmlTest aTestNgDeviceTest = new XmlTest(mySuite);
            aTestNgDeviceTest.setName("test_" + uniqueName);
            aTestNgDeviceTest.addParameter("myDeviceContext", uniqueName);
            aTestNgDeviceTest.addParameter("platformName","android");
            aTestNgDeviceTest.addParameter("runType","pcloudy");
            aTestNgDeviceTest.addParameter("appType","mobilebrowser");
            aTestNgDeviceTest.addParameter("env","qa");
            aTestNgDeviceTest.addParameter("headless","false");
            aTestNgDeviceTest.addParameter("platformType", "mobile");

            if(bookedDevices.length == mySuiteData.size()) {
                for(int j=i;j<=i;j++) {
                    aTestNgDeviceTest = addMethods(mySuiteData.get(j),aTestNgDeviceTest,mySuite,uniqueName,"android");
                    allDevicesTests.add(aTestNgDeviceTest);
                }
            }
            else if(bookedDevices.length < mySuiteData.size()) {
                if(bookedDevices.length == 1 ) {
                    for(int j=0;j < mySuiteData.size();j++) {
                        aTestNgDeviceTest = addMethods(mySuiteData.get(j),aTestNgDeviceTest,mySuite,uniqueName,"android");
                        allDevicesTests.add(aTestNgDeviceTest);
                    }
                    //includeMethodsForExecution(aTestNgDeviceTest);
                }
                else {
                    int splitCount = mySuiteData.size() / bookedDevices.length;
                    if(i == 0) {
                        for (int j = 0;j < splitCount ; j++) {
                            aTestNgDeviceTest = addMethods(mySuiteData.get(j),aTestNgDeviceTest,mySuite,uniqueName,"android");
                            allDevicesTests.add(aTestNgDeviceTest);
                        }
                    }
                    if(i == 1) {
                        for (int j = splitCount ;j < splitCount * 2 ; j++) {
                            aTestNgDeviceTest = addMethods(mySuiteData.get(j),aTestNgDeviceTest,mySuite,uniqueName,"android");
                            allDevicesTests.add(aTestNgDeviceTest);
                        }
                    }
                    if(i == 2) {
                        for (int j = splitCount * 2; j < mySuiteData.size(); j++) {
                            aTestNgDeviceTest = addMethods(mySuiteData.get(j),aTestNgDeviceTest,mySuite,uniqueName,"android");
                            allDevicesTests.add(aTestNgDeviceTest);
                        }
                    }
                }
            }
            else if(bookedDevices.length > 1 && mySuiteData.size() == 1) {
                includeMethodsForExecution(aTestNgDeviceTest);
                allDevicesTests.add(aTestNgDeviceTest);
            }
        }
        //mySuite.setThreadCount(bookedDevices.length);
        if (mySuiteData.size() > 5 ) {
            threadCount = mySuiteData.size() / 2 ;
        }
        else  {
            threadCount = bookedDevices.length;
        }
        mySuite.setThreadCount(threadCount);

        // add the list of tests to your Suite.
        mySuite.setTests(allDevicesTests);

        // Add the suite to the list of suites.
        List<XmlSuite> mySuites = new ArrayList<XmlSuite>();
        mySuites.add(mySuite);

        // Set the list of Suites to the testNG object you created earlier.
        myTestNG.setXmlSuites(mySuites);

        // Create TestNG.xml
        File file = new File("./TestNG" + System.currentTimeMillis() + ".xml");
        FileWriter writer = new FileWriter(file);
        writer.write(mySuite.toXml());
        writer.close();
        // invoke run() - this will run your class.
        myTestNG.run();

        con.revokeTokenPrivileges(authToken);

        //File consolidatedReport = new File(ReportsFolder, "Consolidated Reports.html");
        //HtmlFilePrinter printer = new HtmlFilePrinter(consolidatedReport);
        MultipleRunReport multipleReports = new MultipleRunReport();
        for (DeviceContext ctx : TestRunner.allDeviceContexts.values()) {
            multipleReports.add(ctx.report);
        }
        //printer.printConsolidatedSingleRunReport(multipleReports);
        //System.out.println("Check the reports at : " + consolidatedReport.getAbsolutePath());
        System.out.println("Execution Completed...");

    }

    private void runTestNGTestIOSSafari() throws IOException, ConnectError, InterruptedException, ParseException {
        int deviceBookDurationTime = 240;

        // Create an instance on TestNG
        TestNG myTestNG = new TestNG();

        // Create an instance of XML Suite and assign a name for it.
        XmlSuite mySuite = new XmlSuite();
        mySuite.setName("pCloudy IOS Suite - Safari browser_"+utils.getCurrentTimeStamp());
        mySuite.setParallel(XmlSuite.ParallelMode.TESTS);
        mySuite.setConfigFailurePolicy(XmlSuite.FailurePolicy.valueOf("CONTINUE"));
        mySuite.addListener("com.absli.listeners.TestLevelDriverCreator");

        if (INSTANCE.equalsIgnoreCase("1")) {
            mySuite.setParallel(XmlSuite.ParallelMode.NONE);
        }

        // Create a list of XmlTests and add the Xmltest you created earlier to it.
        List<XmlTest> allDevicesTests = new ArrayList<XmlTest>();

        Connector con = new Connector("https://device.pcloudy.com/api/");
        // User Authentication over pCloudy
    //       String authToken = con.authenticateUser("sridevi.parvatikar@digital.datamatics.com", "sndm59j4b2swkw9c2shppm4n");
        String authToken = con.authenticateUser(prop.getProperties("pCloudyUser"), prop.getProperties("pCloudyAuthKey"));

        ArrayList<MobileDevice> selectedDevices = new ArrayList<>();

        selectedDevices.addAll(con.chooseDevices(authToken, "ios", new Version("13.*.*"),new Version("14.*.*"), instanceCount ));

        String sessionName = selectedDevices.get(0).display_name + " Appium iOS Session";

        // Book the selected devices in pCloudy
        BookingDtoDevice[] bookedDevices = con.AppiumApis().bookDevicesForAppium(authToken, selectedDevices,deviceBookDurationTime, sessionName);
        System.out.println("Devices booked successfully");

        con.AppiumApis().initAppiumHubForBrowser(authToken, "safari");
        URL endpoint = con.AppiumApis().getAppiumEndpoint(authToken);

        System.out.println("Appium Endpoint: " + endpoint);
        URL reportFolderOnPCloudy = con.AppiumApis().getAppiumReportFolder(authToken);
        System.out.println("Report Folder: " + reportFolderOnPCloudy);

        ArrayList<String> mySuiteData = new ArrayList<String>();
        mySuiteData = ExcelUtils.getExecutionSuitesFromController(prop.getProperties("testExcelSheet"), "controller");
        System.out.println("my suites =============" + mySuiteData);

        for (int i = 0; i < bookedDevices.length; i++) {
            BookingDtoDevice aDevice = bookedDevices[i];
            SingleRunReport report = new SingleRunReport();
            PCloudyAppiumSession pCloudySession = new PCloudyAppiumSession(con, authToken, aDevice);
            String uniqueName = aDevice.manufacturer + " " + aDevice.model + " " + aDevice.version;
            System.out.println("unique name ==========="+uniqueName);

            report.Header = uniqueName;
            report.Enviroment.addDetail("NetworkType", aDevice.networkType);
            report.Enviroment.addDetail("Phone Number", aDevice.phoneNumber);
            report.HyperLinks.addLink("Appium Endpoint", endpoint);
            report.HyperLinks.addLink("pCloudy Result Folder", reportFolderOnPCloudy);

            DesiredCapabilities capabilities = new DesiredCapabilities();
            capabilities.setCapability("newCommandTimeout", 600);
            capabilities.setCapability("launchTimeout", 90000);
            capabilities.setCapability("deviceName", aDevice.capabilities.deviceName);
            capabilities.setCapability("platformName", "ios");
            //capabilities.setCapability("browserName", "Safari");
            capabilities.setBrowserName("Safari");
            //capabilities.setCapability("includeSafariInWebviews", true);
            //capabilities.setCapability("automationName", "XCUITest");
            capabilities.setCapability("autoGrantPermissions", true);
            capabilities.setCapability("acceptAlerts", true);

            DeviceContext aDeviceContext = new DeviceContext(uniqueName);

            aDeviceContext.endpoint = endpoint;
            aDeviceContext.device = aDevice;
            aDeviceContext.pCloudySession = pCloudySession;
            aDeviceContext.report = report;
            aDeviceContext.capabilities = capabilities;

            allDeviceContexts.put(uniqueName, aDeviceContext);

            XmlTest aTestNgDeviceTest = new XmlTest(mySuite);
            aTestNgDeviceTest.setName("test_" + uniqueName);
            aTestNgDeviceTest.addParameter("myDeviceContext", uniqueName);
            aTestNgDeviceTest.addParameter("platformName","ios");
            aTestNgDeviceTest.addParameter("runType","pcloudy");
            aTestNgDeviceTest.addParameter("appType","mobilebrowser");
            aTestNgDeviceTest.addParameter("env","qa");
            aTestNgDeviceTest.addParameter("headless","false");
            aTestNgDeviceTest.addParameter("platformType", "mobile");

            if(bookedDevices.length == mySuiteData.size()) {
                for(int j=i;j<=i;j++) {
                    aTestNgDeviceTest = addMethods(mySuiteData.get(j),aTestNgDeviceTest,mySuite,uniqueName,"ios");
                    allDevicesTests.add(aTestNgDeviceTest);
                }
            }
            else if(bookedDevices.length < mySuiteData.size()) {
                if(bookedDevices.length == 1 ) {
                    for(int j=0;j < mySuiteData.size();j++) {
                        aTestNgDeviceTest = addMethods(mySuiteData.get(j),aTestNgDeviceTest,mySuite,uniqueName,"ios");
                        allDevicesTests.add(aTestNgDeviceTest);
                    }
                    //includeMethodsForExecution(aTestNgDeviceTest);
                }
                else {
                    int splitCount = mySuiteData.size() / bookedDevices.length;
                    if(i == 0) {
                        for (int j = 0;j < splitCount ; j++) {
                            aTestNgDeviceTest = addMethods(mySuiteData.get(j),aTestNgDeviceTest,mySuite,uniqueName,"ios");
                            allDevicesTests.add(aTestNgDeviceTest);
                        }
                    }
                    if(i == 1) {
                        for (int j = splitCount ;j < splitCount * 2 ; j++) {
                            aTestNgDeviceTest = addMethods(mySuiteData.get(j),aTestNgDeviceTest,mySuite,uniqueName,"ios");
                            allDevicesTests.add(aTestNgDeviceTest);
                        }
                    }
                    if(i == 2) {
                        for (int j = splitCount * 2; j < mySuiteData.size(); j++) {
                            aTestNgDeviceTest = addMethods(mySuiteData.get(j),aTestNgDeviceTest,mySuite,uniqueName,"ios");
                            allDevicesTests.add(aTestNgDeviceTest);
                        }
                    }
                }
            }
            else if(bookedDevices.length > 1 && mySuiteData.size() == 1) {
                includeMethodsForExecution(aTestNgDeviceTest);
                allDevicesTests.add(aTestNgDeviceTest);
            }
        }

        //mySuite.setThreadCount(bookedDevices.length);
        if (mySuiteData.size() > 5 ) {
            threadCount = mySuiteData.size() / 2 ;
        }
        else  {
            threadCount = bookedDevices.length;
        }
        mySuite.setThreadCount(threadCount);

        // add the list of tests to your Suite.
        mySuite.setTests(allDevicesTests);

        // Add the suite to the list of suites.
        List<XmlSuite> mySuites = new ArrayList<XmlSuite>();
        mySuites.add(mySuite);

        // Set the list of Suites to the testNG object you created earlier.
        myTestNG.setXmlSuites(mySuites);

        // Create TestNG.xml
        File file = new File("./TestNG" + System.currentTimeMillis() + ".xml");
        FileWriter writer = new FileWriter(file);
        writer.write(mySuite.toXml());
        writer.close();
        // invoke run() - this will run your class.
        myTestNG.run();

        con.revokeTokenPrivileges(authToken);

        //File consolidatedReport = new File(ReportsFolder, "Consolidated Reports.html");
        //HtmlFilePrinter printer = new HtmlFilePrinter(consolidatedReport);
        MultipleRunReport multipleReports = new MultipleRunReport();
        for (DeviceContext ctx : TestRunner.allDeviceContexts.values()) {
            multipleReports.add(ctx.report);
        }
        //printer.printConsolidatedSingleRunReport(multipleReports);
        //System.out.println("Check the reports at : " + consolidatedReport.getAbsolutePath());
        System.out.println("Execution Completed...");

    }

    public void runTestNGTestAndroid() throws Exception {

        int deviceBookDurationTime = 240;

        // Create an instance on TestNG
        TestNG myTestNG = new TestNG();

        // Create an instance of XML Suite and assign a name for it.
        XmlSuite mySuite = new XmlSuite();
        mySuite.setName("pCloudy Android Suite_"+utils.getCurrentTimeStamp());
        mySuite.setParallel(XmlSuite.ParallelMode.TESTS);
        mySuite.setPreserveOrder(Boolean.FALSE);
        mySuite.setConfigFailurePolicy(XmlSuite.FailurePolicy.valueOf("CONTINUE"));
        mySuite.addListener("com.absli.listeners.TestLevelDriverCreator");
        mySuite.addListener("com.absli.listeners.ExtentListener");

        if (INSTANCE.equalsIgnoreCase("1")) {
            mySuite.setParallel(XmlSuite.ParallelMode.NONE);
        }

        // Create a list of XmlTests and add the Xmltest you created earlier to it.
        List<XmlTest> allDevicesTests = new ArrayList<XmlTest>();

        Connector con = new Connector("https://device.pcloudy.com/api/");
        // User Authentication over pCloudy
        String authToken = con.authenticateUser(prop.getProperties("pCloudyUser"), prop.getProperties("pCloudyAuthKey"));
        ArrayList<MobileDevice> selectedDevices = new ArrayList<>();

        selectedDevices.addAll(con.chooseDevices(authToken, "android", new Version("10.*.*"),new Version("11.*.*"), instanceCount));

        String sessionName = selectedDevices.get(0).display_name + " Appium Session";
        String apkFile = new ExcelUtils().getAppFileName(prop.getProperties("testExcelSheet"), prop.getProperties("controllerSheetName"),prop.getProperties("apkFileExcelColumnName"));

        // Select apk in pCloudy Cloud Drive
        File fileToBeUploaded = new File(apkFile);
        PDriveFileDTO alreadyUploadedApp = con.getAvailableAppIfUploaded(authToken, fileToBeUploaded.getName());
        if (alreadyUploadedApp == null) {
            System.out.println("Uploading App: " + fileToBeUploaded.getAbsolutePath());
            PDriveFileDTO uploadedApp = con.uploadApp(authToken, fileToBeUploaded, false);
            System.out.println("App uploaded");
            alreadyUploadedApp = new PDriveFileDTO();
            alreadyUploadedApp.file = uploadedApp.file;
        } else {
            System.out.println("App already present. Not uploading... ");
        }

        // Book the selected devices in pCloudy
        BookingDtoDevice[] bookedDevices = con.AppiumApis().bookDevicesForAppium(authToken, selectedDevices,deviceBookDurationTime, sessionName);
        System.out.println("Devices booked successfully");

        con.AppiumApis().initAppiumHubForApp(authToken, alreadyUploadedApp);
        URL endpoint = con.AppiumApis().getAppiumEndpoint(authToken);

        System.out.println("Appium Endpoint: " + endpoint);
        URL reportFolderOnPCloudy = con.AppiumApis().getAppiumReportFolder(authToken);
        System.out.println("Report Folder: " + reportFolderOnPCloudy);

        ArrayList<String> mySuiteData = new ArrayList<String>();
        mySuiteData = ExcelUtils.getExecutionSuitesFromController(prop.getProperties("testExcelSheet"), "controller");
        System.out.println("my suites =============" + mySuiteData);

        for (int i = 0; i < bookedDevices.length ; i++) {
            BookingDtoDevice aDevice = bookedDevices[i];
            SingleRunReport report = new SingleRunReport();
            PCloudyAppiumSession pCloudySession = new PCloudyAppiumSession(con, authToken, aDevice);
            String uniqueName = aDevice.manufacturer + " " + aDevice.model + " " + aDevice.version;
            System.out.println("unique name ==========="+uniqueName);

            report.Header = uniqueName;
            report.Enviroment.addDetail("NetworkType", aDevice.networkType);
            report.Enviroment.addDetail("Phone Number", aDevice.phoneNumber);
            report.HyperLinks.addLink("Appium Endpoint", endpoint);
            report.HyperLinks.addLink("pCloudy Result Folder", reportFolderOnPCloudy);

            DesiredCapabilities capabilities = new DesiredCapabilities();
            capabilities.setCapability("newCommandTimeout", 90000);
            capabilities.setCapability("launchTimeout", 90000);
            capabilities.setCapability("deviceName", aDevice.capabilities.deviceName);
            capabilities.setCapability("platformName", "Android");
            capabilities.setCapability("appPackage", "com.absli.leap");
            capabilities.setCapability("appActivity", "com.absli.leap.MainActivity");
            capabilities.setCapability("appWaitActivity", "com.absli.leap.MainActivity");
            capabilities.setCapability("appWaitDuration", "30000");
            capabilities.setCapability("pCloudy_ApplicationName", fileToBeUploaded.getName());
            capabilities.setCapability("noReset", true);
            capabilities.setCapability("fullReset", false);
            capabilities.setCapability("autoDismissAlerts", true);
            capabilities.setCapability("autoAcceptAlerts", true);
            capabilities.setCapability("autoGrantPermissions", true);
            //capabilities.setCapability("unicodeKeyboard", true);
            //capabilities.setCapability("resetKeyboard", true);

            DeviceContext aDeviceContext = new DeviceContext(uniqueName);

            aDeviceContext.endpoint = endpoint;
            aDeviceContext.device = aDevice;
            aDeviceContext.pCloudySession = pCloudySession;
            aDeviceContext.report = report;
            aDeviceContext.capabilities = capabilities;

            allDeviceContexts.put(uniqueName, aDeviceContext);

            XmlTest aTestNgDeviceTest = new XmlTest(mySuite);
            aTestNgDeviceTest.setName("test_" + uniqueName);
            aTestNgDeviceTest.addParameter("myDeviceContext", uniqueName);
            aTestNgDeviceTest.addParameter("platformName","android");
            aTestNgDeviceTest.addParameter("runType","pcloudy");
            aTestNgDeviceTest.addParameter("appType","native");
            aTestNgDeviceTest.addParameter("env","qa");
            aTestNgDeviceTest.addParameter("headless","false");
            aTestNgDeviceTest.addParameter("platformType", "mobile");

          if(bookedDevices.length == mySuiteData.size()) {
                for(int j=i;j<=i;j++) {
                    aTestNgDeviceTest = addMethods(mySuiteData.get(j),aTestNgDeviceTest,mySuite,uniqueName,"android");
                    allDevicesTests.add(aTestNgDeviceTest);
                }
            }
            else if(bookedDevices.length < mySuiteData.size()) {
                if(bookedDevices.length == 1 ) {
                    for(int j=0;j < mySuiteData.size();j++) {
                        aTestNgDeviceTest = addMethods(mySuiteData.get(j),aTestNgDeviceTest,mySuite,uniqueName,"android");
                        allDevicesTests.add(aTestNgDeviceTest);
                    }
                    //includeMethodsForExecution(aTestNgDeviceTest);
                }
                else {
                    int splitCount = mySuiteData.size() / bookedDevices.length;
                    if(i == 0) {
                       for (int j = 0;j < splitCount ; j++) {
                           aTestNgDeviceTest = addMethods(mySuiteData.get(j),aTestNgDeviceTest,mySuite,uniqueName,"android");
                           allDevicesTests.add(aTestNgDeviceTest);
                       }
                   }
                    if(i == 1) {
                        for (int j = splitCount ;j < splitCount * 2 ; j++) {
                            aTestNgDeviceTest = addMethods(mySuiteData.get(j),aTestNgDeviceTest,mySuite,uniqueName,"android");
                            allDevicesTests.add(aTestNgDeviceTest);
                        }
                    }
                    if(i == 2) {
                        for (int j = splitCount * 2; j < mySuiteData.size(); j++) {
                            aTestNgDeviceTest = addMethods(mySuiteData.get(j),aTestNgDeviceTest,mySuite,uniqueName,"android");
                            allDevicesTests.add(aTestNgDeviceTest);
                        }
                    }
                }
                }
            else if(bookedDevices.length > 1 && mySuiteData.size() == 1) {
                includeMethodsForExecution(aTestNgDeviceTest);
                allDevicesTests.add(aTestNgDeviceTest);
          }
        }
        //mySuite.setThreadCount(bookedDevices.length);
        if (mySuiteData.size() > 5 ) {
            threadCount = mySuiteData.size() / 2 ;
        }
        else  {
            threadCount = bookedDevices.length;
        }
        mySuite.setThreadCount(threadCount);


        // add the list of tests to your Suite.
        mySuite.setTests(allDevicesTests);

        // Add the suite to the list of suites.
        List<XmlSuite> mySuites = new ArrayList<XmlSuite>();
        mySuites.add(mySuite);

        // Set the list of Suites to the testNG object you created earlier.
        myTestNG.setXmlSuites(mySuites);

        // Create TestNG.xml
        File file = new File("./TestNG" + System.currentTimeMillis() + ".xml");
        FileWriter writer = new FileWriter(file);
        writer.write(mySuite.toXml());
        writer.close();
        // invoke run() - this will run your class.
        myTestNG.run();

        con.revokeTokenPrivileges(authToken);

        //File consolidatedReport = new File(ReportsFolder, "Consolidated Reports.html");
        //HtmlFilePrinter printer = new HtmlFilePrinter(consolidatedReport);
        MultipleRunReport multipleReports = new MultipleRunReport();
        for (DeviceContext ctx : TestRunner.allDeviceContexts.values()) {
            multipleReports.add(ctx.report);
        }
        //printer.printConsolidatedSingleRunReport(multipleReports);
        //System.out.println("Check the reports at : " + consolidatedReport.getAbsolutePath());
        System.out.println("Execution Completed...");

    }

    /* Split the suites into separate arrays based on the no. suites to be executed agaist the allocated devices
    * */
    public void splitSuites(int bookedDevices, ArrayList<String> mySuiteData) {
        int splitCount = mySuiteData.size() / bookedDevices;
        System.out.println("split count :=========="+splitCount);
        if(bookedDevices == 2) {
            for(int j=0;j< splitCount;j++) {
                array1.add(mySuiteData.get(j));
            }
            for(int j=splitCount;j< mySuiteData.size();j++) {
                array2.add(mySuiteData.get(j));
            }
        }

        if(bookedDevices == 3) {
            for(int j=0;j< splitCount;j++) {
                array1.add(mySuiteData.get(j));
            }
            for(int j=splitCount;j< splitCount*2 ;j++) {
                array2.add(mySuiteData.get(j));
            }
            for(int j=splitCount*2;j< mySuiteData.size();j++) {
                array3.add(mySuiteData.get(j));
            }
        }
    }

    public XmlTest addMethods(String suiteName, XmlTest myTest,XmlSuite mySuite,String uniqueName,String platformName) throws IOException {
        List<Map<String, String>> myClassNamesHashMap = ExcelUtils.getExecutionClassMethodNames(prop.getProperties("testExcelSheet"), suiteName);
        //Create an instance of XmlTest and assign a name for it.

        int regionIndex = 1;

        // get Iterator for looping through AL
        Iterator<Map<String, String>> iterator =
                myClassNamesHashMap.iterator();

        XmlTest aTestNgDeviceTest = new XmlTest(mySuite);
        aTestNgDeviceTest.setName("test_" + uniqueName + "_" + suiteName);
        aTestNgDeviceTest.addParameter("myDeviceContext", uniqueName);
        aTestNgDeviceTest.addParameter("platformName",platformName);
        aTestNgDeviceTest.addParameter("runType","pcloudy");
        aTestNgDeviceTest.addParameter("appType","native");
        aTestNgDeviceTest.addParameter("env","qa");
        aTestNgDeviceTest.addParameter("headless","false");
        aTestNgDeviceTest.addParameter("platformType", "mobile");

        // iterate AL using while-loop
        while (iterator.hasNext()) {

            Map<String, String> region = iterator.next();

            // getting entrySet() into Set
            Set<Map.Entry<String, String>> entrySet =
                    region.entrySet();

            // for-each loop
            for (Map.Entry<String, String> set : entrySet) {

                System.out.println("class : " + set.getKey()
                        + "\tmethod : " + set.getValue());
                XmlClass myClass = new XmlClass(set.getKey());
                List<XmlInclude> myMethods = new ArrayList<>();
                myMethods.add(new XmlInclude(set.getValue()));
                myClass.setIncludedMethods(myMethods);
                aTestNgDeviceTest.getClasses().add(myClass);
            }

            // increment region index by 1
            regionIndex++;
        }
        return aTestNgDeviceTest;
    }
    public XmlTest addMethods(String suiteName, XmlTest myTest) throws IOException {
        List<Map<String, String>> myClassNamesHashMap = ExcelUtils.getExecutionClassMethodNames(prop.getProperties("testExcelSheet"), suiteName);
        //Create an instance of XmlTest and assign a name for it.

        int regionIndex = 1;

        // get Iterator for looping through AL
        Iterator<Map<String, String>> iterator =
                myClassNamesHashMap.iterator();

        // iterate AL using while-loop
        while (iterator.hasNext()) {

            Map<String, String> region = iterator.next();

            // getting entrySet() into Set
            Set<Map.Entry<String, String>> entrySet =
                    region.entrySet();

            // for-each loop
            for (Map.Entry<String, String> set : entrySet) {

                System.out.println("class : " + set.getKey()
                        + "\tmethod : " + set.getValue());
                XmlClass myClass = new XmlClass(set.getKey());
                List<XmlInclude> myMethods = new ArrayList<>();
                myMethods.add(new XmlInclude(set.getValue()));
                myClass.setIncludedMethods(myMethods);
                myTest.getClasses().add(myClass);
            }

            // increment region index by 1
            regionIndex++;
        }

        return myTest;
    }
    public XmlTest addMethods(ArrayList<String> suites, XmlTest myTest) throws IOException {
        for(String suite:suites) {
            List<Map<String, String>> myClassNamesHashMap = ExcelUtils.getExecutionClassMethodNames(prop.getProperties("testExcelSheet"), suite);
            //Create an instance of XmlTest and assign a name for it.

            int regionIndex = 1;

            // get Iterator for looping through AL
            Iterator<Map<String, String>> iterator =
                    myClassNamesHashMap.iterator();

            // iterate AL using while-loop
            while (iterator.hasNext()) {

                Map<String, String> region = iterator.next();

                // getting entrySet() into Set
                Set<Map.Entry<String, String>> entrySet =
                        region.entrySet();

                // for-each loop
                for (Map.Entry<String, String> set : entrySet) {

                    System.out.println("class : " + set.getKey()
                            + "\tmethod : " + set.getValue());
                    XmlClass myClass = new XmlClass(set.getKey());
                    List<XmlInclude> myMethods = new ArrayList<>();
                    myMethods.add(new XmlInclude(set.getValue()));
                    myClass.setIncludedMethods(myMethods);
                    myTest.getClasses().add(myClass);
                }

                // increment region index by 1
                regionIndex++;
            }

        }
        return myTest;
    }
    public List<XmlTest> addMethods(ArrayList<String> suites, List<XmlTest> myTests,XmlSuite mySuite,String uniqueName,String platformName) throws IOException {
        System.out.println("SUITES SELCTED FOR EXECUTION for TEST NG -------"+ suites);

        for(String suite:suites) {
            List<Map<String, String>> myClassNamesHashMap = ExcelUtils.getExecutionClassMethodNames(prop.getProperties("testExcelSheet"), suite);
            //Create an instance of XmlTest and assign a name for it.

            int regionIndex = 1;

            // get Iterator for looping through AL
            Iterator<Map<String, String>> iterator =
                    myClassNamesHashMap.iterator();

            XmlTest aTestNgDeviceTest = new XmlTest(mySuite);
            aTestNgDeviceTest.setName("test_" + uniqueName +  "_" + suite);
            aTestNgDeviceTest.addParameter("myDeviceContext", uniqueName);
            aTestNgDeviceTest.addParameter("platformName",platformName);
            aTestNgDeviceTest.addParameter("runType","pcloudy");
            aTestNgDeviceTest.addParameter("appType","native");
            aTestNgDeviceTest.addParameter("env","qa");
            aTestNgDeviceTest.addParameter("headless","false");
            aTestNgDeviceTest.addParameter("platformType", "mobile");

            // iterate AL using while-loop
            while (iterator.hasNext()) {

                Map<String, String> region = iterator.next();

                // getting entrySet() into Set
                Set<Map.Entry<String, String>> entrySet =
                        region.entrySet();

                // for-each loop
                for (Map.Entry<String, String> set : entrySet) {

                    System.out.println("class : " + set.getKey()
                            + "\tmethod : " + set.getValue());
                    XmlClass myClass = new XmlClass(set.getKey());
                    List<XmlInclude> myMethods = new ArrayList<>();
                    myMethods.add(new XmlInclude(set.getValue()));
                    myClass.setIncludedMethods(myMethods);
                    aTestNgDeviceTest.getClasses().add(myClass);
                }

                // increment region index by 1
                regionIndex++;
            }
            myTests.add(aTestNgDeviceTest);

        }
        return myTests;
    }

    public void runTestNGTestWeb(Map<String, String> testngParams) throws Exception {

        // Create an instance on TestNG
        TestNG myTestNG = new TestNG();

        // Create an instance of XML Suite and assign a name for it.
        XmlSuite mySuite = new XmlSuite();
        mySuite.setName("Web Suite_"+utils.getCurrentTimeStamp());
        mySuite.setParallel(XmlSuite.ParallelMode.TESTS);
        mySuite.setConfigFailurePolicy(XmlSuite.FailurePolicy.valueOf("CONTINUE"));
        mySuite.addListener("com.absli.listeners.TestLevelDriverCreator");

        if (INSTANCE.equalsIgnoreCase("1")) {
            mySuite.setParallel(XmlSuite.ParallelMode.NONE);
        }
        // Create a list which can contain the classes that you want to run.

        // get suites list from excel
        ArrayList<String> mySuiteData = new ArrayList<String>();
        mySuiteData = ExcelUtils.getExecutionSuitesFromController(prop.getProperties("testExcelSheet"), "controller");
        System.out.println("my suites =============" + mySuiteData);

        //Create a list of XmlTests and add the Xmltest you created earlier to it.
        List<XmlTest> myTests = new ArrayList<XmlTest>();
        for(String suite:mySuiteData) {
            List<Map<String, String>> myClassNamesHashMap = ExcelUtils.getExecutionClassMethodNames(prop.getProperties("testExcelSheet"), suite);
            //Create an instance of XmlTest and assign a name for it.
            XmlTest myTest = new XmlTest(mySuite);
            myTest.setName("Web Test On- "+BROWSER+"-"+suite);

            //Add any parameters that you want to set to the Test.
            myTest.setParameters(testngParams);
            //Print the parameter values
            Map<String,String> params = myTest.getAllParameters();
            for(Map.Entry<String,String> entry : params.entrySet())
            {
                System.out.println(entry.getKey() + " => " + entry.getValue());
            }

            int regionIndex = 1;

            // get Iterator for looping through AL
            Iterator<Map<String, String>> iterator =
                    myClassNamesHashMap.iterator();

            // iterate AL using while-loop
            while(iterator.hasNext()) {

                Map<String, String> region = iterator.next();

                // getting entrySet() into Set
                Set<Map.Entry<String, String>> entrySet =
                        region.entrySet();

                // for-each loop
                for(Map.Entry<String, String> set : entrySet) {

                    System.out.println("class : " + set.getKey()
                            + "\tmethod : " + set.getValue());
                    XmlClass myClass = new XmlClass(set.getKey());
                    List<XmlInclude> myMethods = new ArrayList<>();
                    myMethods.add(new XmlInclude(set.getValue()));
                    myClass.setIncludedMethods(myMethods);
                    myTest.getClasses().add(myClass);
                }

                // increment region index by 1
                regionIndex++;
            }
            myTests.add(myTest);
        }

        //add the list of tests to your Suite.
        mySuite.setTests(myTests);
        mySuite.setThreadCount(instanceCount);


        //Add the suite to the list of suites.
        List<XmlSuite> mySuites = new ArrayList<XmlSuite>();
        mySuites.add(mySuite);

        //Set the list of Suites to the testNG object you created earlier.
        myTestNG.setXmlSuites(mySuites);

        // Create TestNG.xml
        File file = new File("./TestNG" + System.currentTimeMillis() + ".xml");
        FileWriter writer = new FileWriter(file);
        writer.write(mySuite.toXml());
        writer.close();

        //invoke run() - this will run your class.
        myTestNG.run();
    }
    public void runTestNGTestWeb1(Map<String, String> testngParams) throws Exception {

        // Create an instance on TestNG
        TestNG myTestNG = new TestNG();

        // Create an instance of XML Suite and assign a name for it.
        XmlSuite mySuite = new XmlSuite();
        mySuite.setName("Web Suite_"+utils.getCurrentTimeStamp());
        mySuite.setParallel(XmlSuite.ParallelMode.TESTS);
        mySuite.setConfigFailurePolicy(XmlSuite.FailurePolicy.valueOf("CONTINUE"));
        mySuite.addListener("com.absli.listeners.TestLevelDriverCreator");

        // Create a list which can contain the classes that you want to run.

        //Create an instance of XmlTest and assign a name for it.
        XmlTest myTest = new XmlTest(mySuite);
        myTest.setName("Web Test On- "+BROWSER);
        myTest.setPreserveOrder(true);

        //Add any parameters that you want to set to the Test.
        myTest.setParameters(testngParams);


        includeMethodsForExecution(myTest);


        //Create a list of XmlTests and add the Xmltest you created earlier to it.
        List<XmlTest> myTests = new ArrayList<XmlTest>();
        myTests.add(myTest);


        //add the list of tests to your Suite.
        mySuite.setTests(myTests);
        mySuite.setThreadCount(instanceCount);


        //Add the suite to the list of suites.
        List<XmlSuite> mySuites = new ArrayList<XmlSuite>();
        mySuites.add(mySuite);

        //Set the list of Suites to the testNG object you created earlier.
        myTestNG.setXmlSuites(mySuites);

        //Print the parameter values
        Map<String,String> params = myTest.getAllParameters();
        for(Map.Entry<String,String> entry : params.entrySet())
        {
            System.out.println(entry.getKey() + " => " + entry.getValue());
        }

        // Create TestNG.xml
        File file = new File("./TestNG" + System.currentTimeMillis() + ".xml");
        FileWriter writer = new FileWriter(file);
        writer.write(mySuite.toXml());
        writer.close();

        //invoke run() - this will run your class.
        myTestNG.run();
    }

    public List<XmlClass> addClassesToExecutionSuite() throws IOException {
        // Create a list which can contain the classes that you want to run.
        List<XmlClass> myClasses = new ArrayList<XmlClass>();
        ArrayList<String> mySuiteData = new ArrayList<String>();
        ArrayList<String> myClassNames = new ArrayList<String>();

        mySuiteData = ExcelUtils.getExecutionSuitesFromController(prop.getProperties("testExcelSheet"), "controller");
        System.out.println("my suites =============" + mySuiteData);

        myClassNames = ExcelUtils.getExecutionClassNames(prop.getProperties("testExcelSheet"), mySuiteData);
        for (String name : myClassNames) {
            myClasses.add(new XmlClass(name));
        }
        return myClasses;
    }
    public ArrayList<String> addClassesToExecutionSuite1() throws IOException {
        // Create a list which can contain the classes that you want to run.
        ArrayList<String> mySuiteData = new ArrayList<String>();

        mySuiteData = ExcelUtils.getExecutionSuitesFromController(prop.getProperties("testExcelSheet"), "controller");
        System.out.println("my suites =============" + mySuiteData);

        ArrayList<String> myClasses = ExcelUtils.getExecutionClassNames(prop.getProperties("testExcelSheet"), mySuiteData);
        return myClasses;
    }

    public void  includeMethodsForExecution(XmlTest myTest) throws IOException {
        ArrayList<String> mySuiteData = new ArrayList<String>();
        mySuiteData = ExcelUtils.getExecutionSuitesFromController(prop.getProperties("testExcelSheet"), "controller");
        System.out.println("my suites =============" + mySuiteData);


        List<Map<String, String>> myClassNamesHashMap = ExcelUtils.getExecutionClassMethodNames(prop.getProperties("testExcelSheet"), mySuiteData);
        System.out.println("Classes hashmap"+ myClassNamesHashMap);

        int regionIndex = 1;

        // get Iterator for looping through AL
        Iterator<Map<String, String>> iterator =
                myClassNamesHashMap.iterator();

        // iterate AL using while-loop
        while(iterator.hasNext()) {

            Map<String, String> region = iterator.next();

            // getting entrySet() into Set
            Set<Map.Entry<String, String>> entrySet =
                    region.entrySet();

            // for-each loop
            for(Map.Entry<String, String> set : entrySet) {

                System.out.println("class : " + set.getKey()
                        + "\tmethod : " + set.getValue());
                XmlClass myClass = new XmlClass(set.getKey());
                List<XmlInclude> myMethods = new ArrayList<>();
                myMethods.add(new XmlInclude(set.getValue()));
                myClass.setIncludedMethods(myMethods);
                myTest.getClasses().add(myClass);
            }

            // increment region index by 1
            regionIndex++;
        }
    }
    public void  includeMethodsForExecution1(XmlTest myTest) throws IOException {
        ArrayList<String> mySuiteData = new ArrayList<String>();


        mySuiteData = ExcelUtils.getExecutionSuitesFromController(prop.getProperties("testExcelSheet"), "controller");
        System.out.println("my suites =============" + mySuiteData);

        for(String suite : mySuiteData) {
            List<Map<String, String>> myClassNamesHashMap = ExcelUtils.getExecutionClassMethodNames(prop.getProperties("testExcelSheet"), suite);
            System.out.println("Classes hashmap"+ myClassNamesHashMap);

            int regionIndex = 1;
            XmlClass myClass = null;
            List<XmlInclude> myMethods = new ArrayList<>();

            // get Iterator for looping through AL
            Iterator<Map<String, String>> iterator =
                    myClassNamesHashMap.iterator();

            // iterate AL using while-loop
            while(iterator.hasNext()) {

                Map<String, String> region = iterator.next();

                // getting entrySet() into Set
                Set<Map.Entry<String, String>> entrySet =
                        region.entrySet();

                // for-each loop
                for(Map.Entry<String, String> set : entrySet) {

                    System.out.println("class : " + set.getKey()
                            + "\tmethod : " + set.getValue());
                    if(regionIndex == 1) {
                        myClass = new XmlClass(set.getKey());
                    }
                    myClass = new XmlClass(set.getKey());
                    myMethods.add(new XmlInclude(set.getValue()));
                }

                // increment region index by 1
                regionIndex++;
            }
            myClass.setIncludedMethods(myMethods);
            myTest.getClasses().add(myClass);
        }
        }


}

