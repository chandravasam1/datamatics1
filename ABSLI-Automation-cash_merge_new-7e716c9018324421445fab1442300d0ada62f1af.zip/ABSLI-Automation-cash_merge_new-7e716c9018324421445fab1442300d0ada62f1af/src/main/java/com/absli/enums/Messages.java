package com.absli.enums;

public enum Messages {
    EMPTY_LEAD_ID_MSG("Please enter lead ID"),
    MIN_CHAR_LEAD_MSG ("Lead ID should be min 14 characters"),



    /*bank details*/
    EMPTY_IFSC_CODE_ERROR_MSG("Please enter IFSC Code"),
    INVALID_IFSC_CODE_ERROR_MSG("Invalid IFSC Code"),
    ;

    private String message;

    Messages(String  s) {
        this.message = s;
    }

    public String getMessage() {
        return this.message;
    }
}
