package com.absli.enums;

public enum PlatformType {
    WEB, MOBILE;
}
