package com.absli.enums;

public enum Env {
    QA("https://leapdev.adityabirlasunlifeinsurance.com/qa/#/"),
    qa("https://leapdev.adityabirlasunlifeinsurance.com/qa/#/"),
    qa1("https://leapdev.adityabirlasunlifeinsurance.com/qa/#/existing-and-refusedPolicy"),
    qa2("https://leapdev.adityabirlasunlifeinsurance.com/qa/#/health-details"),
    qa3("https://leapdev.adityabirlasunlifeinsurance.com/qa/#/payment"),
    BANK_URL("https://leapdev.adityabirlasunlifeinsurance.com/qa/#/policy-payout-details"),
    HEALTH_URL("https://leapdev.adityabirlasunlifeinsurance.com/qa/#/health-details"),
    UAT("https://www.wordpress.com");

    private String env;

    Env(String s) {
        this.env = s;
    }

    public String getUrl() {
        return env;
    }

}
