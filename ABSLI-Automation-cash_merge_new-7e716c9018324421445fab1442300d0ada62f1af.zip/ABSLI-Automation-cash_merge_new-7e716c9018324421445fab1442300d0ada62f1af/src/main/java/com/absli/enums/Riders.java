package com.absli.enums;

public enum Riders {

    ACCIDENTAL_DEATH_AND_DISABILITY("accidental death and disability");
    public String riderName;

    public String getRiderName() {
        return riderName;
    }


    Riders(String s) {
        this.riderName = s;
    }
}
