package com.absli.enums;

public enum DeviceModel {
    IPHONE6, IPHONE6S, IPADAIR, IPADAIR2, PIXEL, NEXUS;
}
