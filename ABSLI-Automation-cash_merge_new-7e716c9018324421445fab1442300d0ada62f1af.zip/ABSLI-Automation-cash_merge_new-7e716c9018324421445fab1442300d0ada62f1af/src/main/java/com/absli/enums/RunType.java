package com.absli.enums;

public enum RunType {
    LOCAL , PCLOUDY ;
}
