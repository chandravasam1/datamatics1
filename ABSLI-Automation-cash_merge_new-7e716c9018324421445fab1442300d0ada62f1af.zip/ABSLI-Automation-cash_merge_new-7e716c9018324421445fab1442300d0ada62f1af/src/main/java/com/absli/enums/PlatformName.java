package com.absli.enums;

public enum PlatformName {
    CHROME, FIREFOX, IE, ANDROID, IOS,SAFARI,APP,MOBILEBROWSER;
}
