package com.absli.enums;

public enum ScrollDirection {

    UP("up"),
    DOWN("down"), LEFT("left"), RIGHT("right");

    private String dir;

    ScrollDirection(String s) {
        this.dir = s;
    }

    public String getDir() {
        return dir;
    }
}
