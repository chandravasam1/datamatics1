package com.absli.enums;

public enum AppType {
    NATIVE , MOBILEBROWSER ;
}
